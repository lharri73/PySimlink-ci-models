/*
 * HevP4OptimalController_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4OptimalController".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:31 2022
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HevP4OptimalController_types_h_
#define RTW_HEADER_HevP4OptimalController_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_HevP4OptimalController_T_ P_HevP4OptimalController_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_HevP4OptimalController_T
  RT_MODEL_HevP4OptimalController_T;

#endif                          /* RTW_HEADER_HevP4OptimalController_types_h_ */
