/*
 * Code generation for system model 'HevP4OptimalController'
 *
 * Model                      : HevP4OptimalController
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:31 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "HevP4OptimalController_capi.h"
#include "HevP4OptimalController.h"
#include "HevP4OptimalController_private.h"
#include "intrp2d_la_pw.h"
#include "intrp4d_l_pw.h"
#include "look1_binlcapw.h"
#include "look1_binlcpw.h"
#include "look1_binlxpw.h"
#include "look2_binlcapw.h"
#include "plook_binc.h"
#include "plook_binca.h"
#include "rt_powd_snf.h"
#include "rt_roundd_snf.h"

P_HevP4OptimalController_T HevP4OptimalController_P = {
  { 0.0, 0.0 },

  { 300.0, 750.0 },
  -30000.0,
  150.0,
  46000.0,
  8.273709E+6,

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.9, 0.7, 0.5, 0.0 },

  { 0.0, 0.5, 0.7, 0.9, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 },
  3.65,

  { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 },
  4.6E+7,

  { 1.0, 4.212, 2.637, 1.8, 1.386, 1.0, 0.772 },
  750.0,
  3.32,
  4.1,
  0.327,

  { 0.0, 1.0 },
  0.15,
  60.0,

  { 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0 },
  80.0,
  40.0,

  { 0.0, 20.0, 40.0, 60.0, 80.0, 100.0, 120.0, 140.0, 160.0, 180.0, 200.0 },

  { 200.0, 200.0, 200.0, 200.0, 190.9859317, 143.2394488, 114.591559,
    95.49296586, 81.85111359, 71.61972439, 63.66197724, 57.29577951, 52.08707228,
    47.74648293 },

  { 313.0, 358.0 },

  { 25.0, 50.0, 75.0, 100.0, 150.0, 200.0, 250.0 },
  3.0,

  { 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.52, 0.62, 0.66, 0.7, 0.7,
    0.72, 0.78, 0.78, 0.78, 0.8, 0.8, 0.8, 0.82, 0.82, 0.84, 0.86, 0.86, 0.86,
    0.86, 0.86, 0.8, 0.8, 0.84, 0.86, 0.86, 0.86, 0.88, 0.88, 0.9, 0.91, 0.91,
    0.92, 0.92, 0.91, 0.82, 0.82, 0.86, 0.86, 0.88, 0.88, 0.9, 0.91, 0.92, 0.93,
    0.93, 0.93, 0.93, 0.93, 0.82, 0.82, 0.86, 0.88, 0.88, 0.9, 0.91, 0.91, 0.92,
    0.93, 0.93, 0.93, 0.93, 0.93, 0.8, 0.8, 0.86, 0.88, 0.88, 0.9, 0.91, 0.92,
    0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.78, 0.78, 0.86, 0.88, 0.88, 0.9, 0.92,
    0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.78, 0.78, 0.84, 0.86, 0.88, 0.9,
    0.92, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.76, 0.76, 0.84, 0.86, 0.86,
    0.88, 0.92, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.74, 0.74, 0.82, 0.84,
    0.86, 0.88, 0.91, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.7, 0.7, 0.82,
    0.84, 0.86, 0.88, 0.91, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93 },
  0.98,
  0.98,

  { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
    1.0, 1.0, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9,
    0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9,
    0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7,
    0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8,
    0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9,
    0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9,
    0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9,
    0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9,
    0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9,
    0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7,
    0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8,
    0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9,
    0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9,
    0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9,
    0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9,
    0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9,
    0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7,
    0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8,
    0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9,
    0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9,
    0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9,
    0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9,
    0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9,
    0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7,
    0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8,
    0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9,
    0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9,
    0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9,
    0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9,
    0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9,
    0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.78,
    0.85, 0.87, 0.88, 0.89, 0.89, 0.89, 0.73, 0.83, 0.86, 0.88, 0.89, 0.89, 0.89,
    0.72, 0.83, 0.86, 0.88, 0.89, 0.89, 0.89, 0.72, 0.83, 0.87, 0.89, 0.9, 0.89,
    0.89, 0.72, 0.83, 0.87, 0.88, 0.9, 0.89, 0.89, 0.71, 0.83, 0.87, 0.88, 0.9,
    0.89, 0.89, 0.71, 0.83, 0.86, 0.88, 0.9, 0.89, 0.89, 0.7, 0.82, 0.86, 0.88,
    0.9, 0.89, 0.89, 0.69, 0.82, 0.86, 0.88, 0.9, 0.89, 0.89, 0.67, 0.81, 0.86,
    0.88, 0.9, 0.89, 0.89, 0.63, 0.79, 0.85, 0.87, 0.89, 0.89, 0.89, 0.78, 0.85,
    0.87, 0.88, 0.89, 0.89, 0.89, 0.73, 0.83, 0.86, 0.88, 0.89, 0.89, 0.89, 0.72,
    0.83, 0.86, 0.88, 0.89, 0.89, 0.89, 0.72, 0.83, 0.87, 0.89, 0.9, 0.89, 0.89,
    0.72, 0.83, 0.87, 0.88, 0.9, 0.89, 0.89, 0.71, 0.83, 0.87, 0.88, 0.9, 0.89,
    0.89, 0.71, 0.83, 0.86, 0.88, 0.9, 0.89, 0.89, 0.7, 0.82, 0.86, 0.88, 0.9,
    0.89, 0.89, 0.69, 0.82, 0.86, 0.88, 0.9, 0.89, 0.89, 0.67, 0.81, 0.86, 0.88,
    0.9, 0.89, 0.89, 0.63, 0.79, 0.85, 0.87, 0.89, 0.89, 0.89, 0.78, 0.85, 0.87,
    0.88, 0.89, 0.89, 0.89, 0.73, 0.83, 0.86, 0.88, 0.89, 0.89, 0.89, 0.72, 0.83,
    0.86, 0.88, 0.89, 0.89, 0.89, 0.72, 0.83, 0.87, 0.89, 0.9, 0.89, 0.89, 0.72,
    0.83, 0.87, 0.88, 0.9, 0.89, 0.89, 0.71, 0.83, 0.87, 0.88, 0.9, 0.89, 0.89,
    0.71, 0.83, 0.86, 0.88, 0.9, 0.89, 0.89, 0.7, 0.82, 0.86, 0.88, 0.9, 0.89,
    0.89, 0.69, 0.82, 0.86, 0.88, 0.9, 0.89, 0.89, 0.67, 0.81, 0.86, 0.88, 0.9,
    0.89, 0.89, 0.63, 0.79, 0.85, 0.87, 0.89, 0.89, 0.89, 0.82, 0.87, 0.88, 0.89,
    0.89, 0.89, 0.89, 0.81, 0.87, 0.89, 0.89, 0.9, 0.9, 0.89, 0.76, 0.85, 0.87,
    0.89, 0.9, 0.89, 0.89, 0.72, 0.83, 0.86, 0.88, 0.89, 0.89, 0.89, 0.72, 0.83,
    0.86, 0.88, 0.89, 0.9, 0.89, 0.71, 0.82, 0.86, 0.88, 0.89, 0.9, 0.89, 0.7,
    0.82, 0.86, 0.88, 0.89, 0.9, 0.89, 0.7, 0.82, 0.86, 0.88, 0.89, 0.9, 0.89,
    0.69, 0.82, 0.86, 0.88, 0.89, 0.9, 0.89, 0.66, 0.8, 0.85, 0.87, 0.89, 0.9,
    0.89, 0.62, 0.78, 0.84, 0.86, 0.88, 0.89, 0.89, 0.81, 0.86, 0.88, 0.89, 0.89,
    0.89, 0.9, 0.77, 0.85, 0.87, 0.88, 0.89, 0.9, 0.9, 0.72, 0.82, 0.86, 0.87,
    0.88, 0.89, 0.9, 0.68, 0.8, 0.84, 0.86, 0.88, 0.89, 0.89, 0.67, 0.8, 0.84,
    0.86, 0.88, 0.89, 0.9, 0.67, 0.8, 0.84, 0.86, 0.88, 0.89, 0.9, 0.65, 0.8,
    0.84, 0.86, 0.88, 0.89, 0.9, 0.64, 0.79, 0.83, 0.86, 0.88, 0.89, 0.9, 0.63,
    0.78, 0.83, 0.86, 0.88, 0.89, 0.9, 0.59, 0.76, 0.82, 0.85, 0.87, 0.89, 0.9,
    0.53, 0.73, 0.8, 0.83, 0.86, 0.88, 0.89, 0.82, 0.89, 0.92, 0.93, 0.94, 0.95,
    0.95, 0.8, 0.89, 0.91, 0.92, 0.94, 0.95, 0.95, 0.75, 0.86, 0.9, 0.92, 0.93,
    0.94, 0.95, 0.69, 0.83, 0.88, 0.9, 0.92, 0.94, 0.94, 0.65, 0.82, 0.87, 0.89,
    0.92, 0.93, 0.94, 0.64, 0.81, 0.86, 0.89, 0.92, 0.93, 0.94, 0.62, 0.8, 0.86,
    0.89, 0.92, 0.93, 0.94, 0.59, 0.78, 0.85, 0.88, 0.91, 0.93, 0.94, 0.57, 0.77,
    0.84, 0.87, 0.91, 0.92, 0.93, 0.42, 0.7, 0.79, 0.84, 0.88, 0.91, 0.92, 0.23,
    0.62, 0.74, 0.8, 0.86, 0.89, 0.91, 0.84, 0.9, 0.92, 0.93, 0.94, 0.94, 0.95,
    0.79, 0.88, 0.91, 0.92, 0.94, 0.94, 0.95, 0.73, 0.85, 0.89, 0.91, 0.93, 0.94,
    0.95, 0.68, 0.83, 0.88, 0.9, 0.92, 0.94, 0.94, 0.66, 0.82, 0.87, 0.9, 0.92,
    0.93, 0.94, 0.67, 0.82, 0.87, 0.9, 0.92, 0.94, 0.94, 0.65, 0.82, 0.88, 0.89,
    0.92, 0.94, 0.94, 0.63, 0.8, 0.86, 0.89, 0.92, 0.93, 0.94, 0.59, 0.79, 0.85,
    0.88, 0.91, 0.94, 0.95, 0.52, 0.75, 0.82, 0.86, 0.9, 0.92, 0.93, 0.52, 0.75,
    0.82, 0.86, 0.9, 0.92, 0.93 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.000148240052081133, 0.000222144176157277, 0.000278388933443759,
    0.000338109479442496, 0.000402998287959, 0.000459805851083422,
    0.000464648322890043, 0.000464648322890043, 0.000464648322890043,
    0.000464648322890043, 0.000464648322890043, 0.000464648322890043,
    0.000464648322890043, 0.000464648322890043, 0.000464648322890043, 0.0,
    0.000206447634975338, 0.000310054896091289, 0.000383552689224961,
    0.000459310113039941, 0.000538835443188731, 0.000620323831936382,
    0.000702821725323801, 0.000817371274090134, 0.00082481147541979,
    0.00082481147541979, 0.00082481147541979, 0.00082481147541979,
    0.00082481147541979, 0.00082481147541979, 0.00082481147541979, 0.0,
    0.000293744033628025, 0.000390187941288556, 0.000484610761722036,
    0.000578710019707138, 0.000677723305385028, 0.000781807153730961,
    0.000881671397920867, 0.000988697423532871, 0.00110274726273639,
    0.00121606024959475, 0.00121606024959475, 0.00121606024959475,
    0.00121606024959475, 0.00121606024959475, 0.00121606024959475, 0.0,
    0.000351937085704759, 0.000474831523633881, 0.000589878024802542,
    0.000702445765844296, 0.000818412127949622, 0.00094014662111868,
    0.00105758588651525, 0.00118054960012307, 0.00130930537516228,
    0.00143790082909404, 0.00157077177722272, 0.00174587332509782,
    0.00188859839569664, 0.00188877049165465, 0.00188877049165465, 0.0,
    0.000410135642093442, 0.000563061595198977, 0.000695572353010492,
    0.000824387716452931, 0.000959842475745671, 0.00110694234903363,
    0.00124014091758629, 0.00137943078078674, 0.00152646863338009,
    0.00167266652345979, 0.00183105631248741, 0.0019752075661786,
    0.00214588872796034, 0.00236210930787046, 0.00254290464578929, 0.0,
    0.000468364144477942, 0.000655122712634345, 0.000802217563774539,
    0.000946570670090564, 0.00110006819763821, 0.00126387818923158,
    0.0014194987594977, 0.00157782235358302, 0.00174845951958547,
    0.00191523807094937, 0.00208580823831404, 0.00227593260666106,
    0.00249555659087868, 0.0027207155234247, 0.00298009312868423, 0.0,
    0.000526628319341081, 0.000751711063857164, 0.000909716804149853,
    0.00106946095087439, 0.00124411641325702, 0.00142466055282556,
    0.00161210337597476, 0.00179842218674701, 0.00198218678626424,
    0.00216523753223389, 0.00234432093339502, 0.00253779841346018,
    0.00275955048723379, 0.00305042202852722, 0.00335186516617903, 0.0,
    0.000584923766054015, 0.00084834503373835, 0.00102018753216226,
    0.00120087253030047, 0.00140082372204865, 0.00159555025378185,
    0.00180685415448376, 0.00201300048338791, 0.00222021540969953,
    0.00243326734845992, 0.00264165160221791, 0.00288719363813471,
    0.00321677276780145, 0.003715481425914, 0.00412579840421367, 0.0,
    0.000672295651534798, 0.000942374422156645, 0.00112882490299642,
    0.00132951139986259, 0.00155765936687714, 0.00178376909828378,
    0.00200600030561808, 0.00223079700971211, 0.00246123345141476,
    0.00268671831763671, 0.00291720936613833, 0.00317260689132838,
    0.00349924309620212, 0.00390812514748821, 0.00446585374317173, 0.0,
    0.000730567069487586, 0.0010186551259774, 0.00123726490720861,
    0.00147001408539145, 0.00171450861460732, 0.00196229029694982,
    0.00220589242468643, 0.0024521463979108, 0.00270501179572392,
    0.0029543046833636, 0.0032072651089661, 0.00348110002537701,
    0.00379359789893323, 0.00416634523964872, 0.00474284188299397, 0.0,
    0.000817959380674151, 0.0011169708316559, 0.00135840027497332,
    0.00161241534765401, 0.0018828094935477, 0.00214937196884617,
    0.00240666198000104, 0.00267511004394817, 0.00300456696664668,
    0.0032727165758423, 0.00349473785861185, 0.00375265818518292,
    0.00411190743081257, 0.00453965699477649, 0.00516965728641923,
    1.2905123549452581E-33, 0.000876317488324734, 0.00120505606459723,
    0.00147380162825817, 0.00175047262909077, 0.00204097702378798,
    0.00233584840117056, 0.00262701282455017, 0.00290876668031802,
    0.00318066094352216, 0.00347015113580896, 0.00379250759790202,
    0.00410861085830544, 0.00447492303729012, 0.00488938799881356,
    0.0053948740814314, 0.0, 0.000964064553359635, 0.00131657794225455,
    0.00160541837101483, 0.00190298755738058, 0.00221571845588893,
    0.0025405062892665, 0.0028271442729494, 0.00313283953019476,
    0.0034509109588875, 0.00378777437960752, 0.00413184820440031,
    0.0044640103968027, 0.00483252553350322, 0.00528883391451753,
    0.00575574991178776, 0.0, 0.0010519275567183, 0.00143773774550316,
    0.00175965573802239, 0.00207182773683911, 0.00238647449208377,
    0.00271249846525832, 0.0030621597168927, 0.00339485611942969,
    0.00372037921728891, 0.00406983246073166, 0.00444207863753934,
    0.00489588179180975, 0.00538805576319836, 0.00578553492112635,
    0.00624209128332965, 0.0, 0.0011400445196309, 0.00154793036055187,
    0.0018897994727543, 0.00222891996482237, 0.00256155776652261,
    0.00290071412682091, 0.00326769037859652, 0.00361186628538231,
    0.00396753565283143, 0.00440471594623472, 0.00486669266770678,
    0.00533116131328315, 0.00581023127998695, 0.00623097756022069,
    0.00688066244928602 },

  { 0.0, 6.47839451267004, 6.81037951773484, 6.9872486522108, 7.2108075651376,
    7.41442983107935, 7.60871528529661, 7.78836492926606, 7.96107212367116,
    8.10510304828295, 8.24671964744891, 8.36469696541881, 8.49674350738364,
    8.620051401674, 8.74715716665773, 8.88039047922067 },

  { 0.0, 750.0, 1053.57142857143, 1357.14285714286, 1660.71428571429,
    1964.28571428571, 2267.85714285714, 2571.42857142857, 2875.0,
    3178.57142857143, 3482.14285714286, 3785.71428571429, 4089.28571428571,
    4392.85714285714, 4696.42857142857, 5000.0 },

  { 0.0, 15.0, 26.4285714285714, 37.8571428571429, 49.2857142857143,
    60.7142857142857, 72.1428571428571, 83.5714285714286, 95.0, 106.428571428571,
    117.857142857143, 129.285714285714, 140.714285714286, 152.142857142857,
    163.571428571429, 175.0 },
  0.35,
  2.0,

  { 500.38314108091896, 749.619781962827, 1002.6761414789406, 1250.9578527022975,
    1499.239563925654, 1747.5212751490108, 1995.8029863723675, 2501.915705404595,
    2998.479127851308, 4001.1552693302488, 5003.83141080919 },

  { 0.0, 500.0, 1000.0, 1432.391138, 1500.0, 2000.0, 2500.0, 3000.0, 3500.0,
    4000.0, 4500.0, 5000.0, 5500.0, 6000.0 },
  2560000000U,

  { 0.0, 0.0 },

  { 300.0, 750.0 },
  36.0,
  750.0,
  0.001,
  0.0,
  0.0,
  1000.0,
  1.0,
  0.0,
  9.5492965855137211,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.0,

  { -200.0, -197.9899497487437, -195.97989949748742, -193.96984924623115,
    -191.95979899497485, -189.94974874371857, -187.9396984924623,
    -185.92964824120602, -183.91959798994972, -181.90954773869345,
    -179.89949748743717, -177.8894472361809, -175.8793969849246,
    -173.86934673366832, -171.85929648241205, -169.84924623115577,
    -167.83919597989947, -165.8291457286432, -163.81909547738692,
    -161.80904522613065, -159.79899497487435, -157.78894472361807,
    -155.7788944723618, -153.76884422110552, -151.75879396984922,
    -149.74874371859295, -147.73869346733667, -145.7286432160804,
    -143.7185929648241, -141.70854271356782, -139.69849246231155,
    -137.68844221105527, -135.67839195979897, -133.6683417085427,
    -131.65829145728642, -129.64824120603015, -127.63819095477386,
    -125.62814070351757, -123.6180904522613, -121.60804020100501,
    -119.59798994974874, -117.58793969849245, -115.57788944723617,
    -113.56783919597989, -111.55778894472361, -109.54773869346732,
    -107.53768844221105, -105.52763819095476, -103.51758793969849,
    -101.5075376884422, -99.497487437185924, -97.487437185929636,
    -95.477386934673362, -93.467336683417074, -91.4572864321608,
    -89.447236180904511, -87.437185929648237, -85.427135678391949,
    -83.417085427135675, -81.407035175879386, -79.396984924623112,
    -77.386934673366824, -75.37688442211055, -73.366834170854261,
    -71.356783919597987, -69.3467336683417, -67.336683417085425,
    -65.326633165829136, -63.316582914572862, -61.306532663316574,
    -59.2964824120603, -57.286432160804011, -55.276381909547737,
    -53.266331658291449, -51.256281407035175, -49.246231155778887,
    -47.236180904522612, -45.226130653266324, -43.21608040201005,
    -41.206030150753762, -39.195979899497488, -37.1859296482412,
    -35.175879396984925, -33.165829145728637, -31.155778894472359,
    -29.145728643216078, -27.135678391959797, -25.125628140703515,
    -23.115577889447234, -21.105527638190953, -19.095477386934672,
    -17.08542713567839, -15.075376884422109, -13.065326633165828,
    -11.055276381909547, -9.0452261306532655, -7.0351758793969843,
    -5.0251256281407031, -3.0150753768844218, -1.0050251256281406,
    1.0050251256281406, 3.0150753768844218, 5.0251256281407031,
    7.0351758793969843, 9.0452261306532655, 11.055276381909547,
    13.065326633165828, 15.075376884422109, 17.08542713567839,
    19.095477386934672, 21.105527638190953, 23.115577889447234,
    25.125628140703515, 27.135678391959797, 29.145728643216078,
    31.155778894472359, 33.165829145728637, 35.175879396984925, 37.1859296482412,
    39.195979899497488, 41.206030150753762, 43.21608040201005,
    45.226130653266324, 47.236180904522612, 49.246231155778887,
    51.256281407035175, 53.266331658291449, 55.276381909547737,
    57.286432160804011, 59.2964824120603, 61.306532663316574, 63.316582914572862,
    65.326633165829136, 67.336683417085425, 69.3467336683417, 71.356783919597987,
    73.366834170854261, 75.37688442211055, 77.386934673366824,
    79.396984924623112, 81.407035175879386, 83.417085427135675,
    85.427135678391949, 87.437185929648237, 89.447236180904511, 91.4572864321608,
    93.467336683417074, 95.477386934673362, 97.487437185929636,
    99.497487437185924, 101.5075376884422, 103.51758793969849,
    105.52763819095476, 107.53768844221105, 109.54773869346732,
    111.55778894472361, 113.56783919597989, 115.57788944723617,
    117.58793969849245, 119.59798994974874, 121.60804020100501,
    123.6180904522613, 125.62814070351757, 127.63819095477386,
    129.64824120603015, 131.65829145728642, 133.6683417085427,
    135.67839195979897, 137.68844221105527, 139.69849246231155,
    141.70854271356782, 143.7185929648241, 145.7286432160804, 147.73869346733667,
    149.74874371859295, 151.75879396984922, 153.76884422110552,
    155.7788944723618, 157.78894472361807, 159.79899497487435,
    161.80904522613065, 163.81909547738692, 165.8291457286432,
    167.83919597989947, 169.84924623115577, 171.85929648241205,
    173.86934673366832, 175.8793969849246, 177.8894472361809, 179.89949748743717,
    181.90954773869345, 183.91959798994972, 185.92964824120602,
    187.9396984924623, 189.94974874371857, 191.95979899497485,
    193.96984924623115, 195.97989949748742, 197.9899497487437, 200.0 },
  1.0,
  -1.0,
  9.5492965855137211,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  9.5492965855137211,

  { 15.0, 75.679770695842677, 97.173659191506, 116.8405361801169,
    152.21035415326779, 175.0, 174.99889943930509, 174.99996525557151, 175.0,
    175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0 },
  0.0,
  0.0,
  1.0,
  0.10471975511965977,
  -1.0,
  0.0,
  1.0,
  0.0,
  -1.0,
  0.0,
  1.0,
  9.5492965855137211,
  1.0,
  0.0,
  -1.0,
  0.0,
  -1.0,
  -1.0,
  0.0,
  0.0,
  0.10471975511965977,
  -1.0,
  1.0,
  0.0,
  0.0,
  0.0001,
  -1.0,
  0.001,

  { 0.0, 1.9, 2.0, 2.0 },

  { 0.0, 15.0 },

  { 20.0, 40.0 },
  1.0,
  0.0,
  0.0,
  0.0,
  1.0,
  1.0,
  0.10471975511965977,
  -1.0,
  0.0,
  0.0,
  0.0,
  -1.0,
  0.0,
  0.0,
  0.001,
  0.001,
  6.0,
  0.0,
  0.001,

  { 0.1, -0.05123 },

  { 1.0, -0.9512 },
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  9.5492965855137211,

  { 0.0, 75.679770695842677, 97.173659191506, 116.8405361801169,
    152.21035415326779, 175.0, 174.99889943930509, 174.99996525557151, 175.0,
    175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0 },
  1000.0,
  0.0,
  300.0,
  0.10471975511965977,
  1.0,
  0.10471975511965977,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.10471975511965977,
  -1.0,
  0.0,
  1.0,
  9.5492965855137211,
  0.10471975511965977,
  -1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  1.0,
  9.5492965855137211,
  1000.0,
  0.0,
  300.0,
  0.10471975511965977,

  { 0.0, 0.0, -11.4034752998755, -12.473800585417059, -13.0802423829213,
    -13.88617810916552, -14.661580473128121, -15.4412573300566,
    -16.199582035575911, -16.965095246486431, -17.63282998652614,
    -18.31714193014437, -18.909528898283622, -19.59805103111951,
    -20.266741813411549, -20.98363272465831, -21.767051759757781 },

  { 0.0, 749.0, 750.0, 1053.57142857143, 1357.14285714286, 1660.71428571429,
    1964.28571428571, 2267.85714285714, 2571.42857142857, 2875.0,
    3178.57142857143, 3482.14285714286, 3785.71428571429, 4089.28571428571,
    4392.85714285714, 4696.42857142857, 5000.0 },
  -1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.10471975511965977,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.10471975511965977,
  -1.0,
  0.0,
  0.0,
  0.0,
  1.0,
  1.0,
  9.5492965855137211,
  -1.0,
  0.10471975511965977,
  -1.0,
  0.0,
  -1.0,

  { 750.0, 1053.57142857143 },
  0.01,
  -1.0,
  0.01,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },

  { 15U, 15U },

  { 13U, 10U },

  { 1U, 1U },

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U }
};

/* System initialize for referenced model: 'HevP4OptimalController' */
void HevP4OptimalController_Init(real_T *rty_EngTrqCmd, real_T *rty_MtrTrqCmd,
  real_T *rty_Cltch1Cmd, real_T *rty_StartCmd, real_T *rty_Neutral,
  DW_HevP4OptimalController_f_T *localDW)
{
  int32_T i;

  /* SystemInitialize for IfAction SubSystem: '<S3>/Energy Management Off' */
  /* InitializeConditions for UnitDelay: '<S64>/Unit Delay' */
  localDW->UnitDelay_DSTATE_c =
    HevP4OptimalController_P.UnitDelay_InitialCondition;

  /* End of SystemInitialize for SubSystem: '<S3>/Energy Management Off' */

  /* SystemInitialize for IfAction SubSystem: '<S3>/Energy Management' */
  for (i = 0; i < 202; i++) {
    /* InitializeConditions for UnitDelay: '<S42>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE[i] =
      HevP4OptimalController_P.UnitDelay1_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S42>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE[i] =
      HevP4OptimalController_P.UnitDelay2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S60>/Unit Delay' */
    localDW->UnitDelay_DSTATE[i] =
      HevP4OptimalController_P.UnitDelay_InitialCondition_l;
  }

  /* InitializeConditions for UnitDelay: '<S18>/Unit Delay2' */
  localDW->UnitDelay2_DSTATE_d =
    HevP4OptimalController_P.UnitDelay2_InitialCondition_c;

  /* InitializeConditions for DiscreteTransferFcn: '<S18>/Discrete Transfer Fcn' */
  localDW->DiscreteTransferFcn_states =
    HevP4OptimalController_P.DiscreteTransferFcn_InitialStates;

  /* End of SystemInitialize for SubSystem: '<S3>/Energy Management' */

  /* SystemInitialize for Merge: '<S3>/Merge' */
  *rty_EngTrqCmd = HevP4OptimalController_P.Merge_InitialOutput;

  /* SystemInitialize for Merge: '<S3>/Merge1' */
  *rty_MtrTrqCmd = HevP4OptimalController_P.Merge1_InitialOutput;

  /* SystemInitialize for SignalConversion generated from: '<Root>/Cltch1Cmd' */
  *rty_Cltch1Cmd = 0.0;

  /* SystemInitialize for SignalConversion generated from: '<Root>/StartCmd' */
  *rty_StartCmd = 0.0;

  /* SystemInitialize for SignalConversion generated from: '<Root>/Neutral' */
  *rty_Neutral = 0.0;
}

/* Disable for referenced model: 'HevP4OptimalController' */
void HevP4OptimalController_Disable(RT_MODEL_HevP4OptimalController_T * const
  HevP4OptimalController_M, DW_HevP4OptimalController_f_T *localDW)
{
  /* Disable for If: '<S3>/If' */
  switch (localDW->If_ActiveSubsystem) {
   case 0:
    ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
    break;

   case 1:
    ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
    break;
  }

  localDW->If_ActiveSubsystem = -1;

  /* End of Disable for If: '<S3>/If' */
}

/* Start for referenced model: 'HevP4OptimalController' */
void HevP4OptimalController_Start(RT_MODEL_HevP4OptimalController_T * const
  HevP4OptimalController_M, DW_HevP4OptimalController_f_T *localDW)
{
  /* Start for If: '<S3>/If' */
  ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
  ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
  localDW->If_ActiveSubsystem = -1;

  /* Start for IfAction SubSystem: '<S3>/Energy Management' */
  /* Start for Sqrt: '<S24>/Sqrt1' */
  localDW->Sqrt1_DWORK1 = 0;

  /* End of Start for SubSystem: '<S3>/Energy Management' */
}

/* Outputs for referenced model: 'HevP4OptimalController' */
void HevP4OptimalController(RT_MODEL_HevP4OptimalController_T * const
  HevP4OptimalController_M, const real_T *rtu_AccelPdl, const real_T
  *rtu_DecelPdl, const real_T *rtu_VehSpdFdbk, const real_T *rtu_BattSoc, const
  real_T *rtu_MtrSpd, const real_T *rtu_TransGear, const real_T *rtu_BattVolt,
  real_T *rty_EngTrqCmd, real_T *rty_MtrTrqCmd, real_T *rty_BrkCmd, real_T
  *rty_Cltch1Cmd, real_T *rty_StartCmd, real_T *rty_Neutral, real_T
  *rty_WhlTrqCmd, B_HevP4OptimalController_c_T *localB,
  DW_HevP4OptimalController_f_T *localDW)
{
  real_T rtb_Gain_m[202];
  real_T rtb_LHV[202];
  real_T rtb_MathFunction1_p[202];
  real_T rtb_Product3_k[202];
  real_T rtb_Sqrt1[202];
  real_T rtb_Switch1[202];
  real_T rtb_Switch2_ck[202];
  real_T fractions[4];
  real_T fractions_0[4];
  real_T fractions_1[4];
  real_T fractions_4[4];
  real_T fractions_2[2];
  real_T fractions_3[2];
  real_T rtb_AccelDecelSwitch1;
  real_T rtb_BrkTrqFric;
  real_T rtb_BrkTrqFric_n;
  real_T rtb_BrkTrqReqTotal;
  real_T rtb_ChrgLmt;
  real_T rtb_Diffratio;
  real_T rtb_Divide2_n;
  real_T rtb_Divide6;
  real_T rtb_Gain3;
  real_T rtb_Gain3_po;
  real_T rtb_Gain_p;
  real_T rtb_MotTrqRegenWhl;
  real_T rtb_Round;
  real_T rtb_Switch2_k;
  real_T rtb_Switch2_o_tmp;
  real_T rtb_WhlSpd;
  real_T u0;
  int32_T b_k;
  int32_T i;
  uint32_T rtb_ConstraintPenaltyFactor[202];
  uint32_T bpIndices[4];
  uint32_T bpIndices_0[4];
  uint32_T bpIndices_1[4];
  uint32_T bpIndices_4[4];
  uint32_T bpIndices_2[2];
  uint32_T bpIndices_3[2];
  int8_T rtAction;
  int8_T rtPrevAction;
  boolean_T exitg1;
  boolean_T rtb_ChrgLmt_0;
  boolean_T rtb_Compare;
  boolean_T rtb_Gain3_0;

  /* RelationalOperator: '<S6>/Compare' incorporates:
   *  Constant: '<S6>/Constant'
   */
  rtb_Compare = (*rtu_AccelPdl <
                 HevP4OptimalController_P.CompareToConstant1_const);

  /* Switch: '<S1>/Accel Decel Switch1' incorporates:
   *  Constant: '<S1>/Constant'
   */
  if (rtb_Compare) {
    rtb_AccelDecelSwitch1 = HevP4OptimalController_P.Constant_Value_a;
  } else {
    rtb_AccelDecelSwitch1 = *rtu_AccelPdl;
  }

  /* End of Switch: '<S1>/Accel Decel Switch1' */

  /* Gain: '<S1>/Gain2' */
  rtb_Switch2_o_tmp = 1.0 / HevP4OptimalController_P.Re * *rtu_VehSpdFdbk;

  /* Rounding: '<Root>/Round' */
  rtb_Round = rt_roundd_snf(*rtu_TransGear);

  /* LookupNDDirect: '<S1>/Direct Lookup Table (n-D)' incorporates:
   *  Rounding: '<Root>/Round'
   *
   * About '<S1>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   *
   *     Remove protection against out-of-range input in generated code: 'off'
   */
  if (rtIsNaN(rtb_Round)) {
    u0 = 0.0;
  } else {
    u0 = rtb_Round;
  }

  if (u0 > 6.0) {
    u0 = 6.0;
  } else if (u0 < 0.0) {
    u0 = 0.0;
  }

  /* Gain: '<S1>/rads2rpm1' incorporates:
   *  Gain: '<S1>/Gain'
   *  Gain: '<S1>/Gain2'
   *  LookupNDDirect: '<S1>/Direct Lookup Table (n-D)'
   *  Product: '<S1>/Product'
   *
   * About '<S1>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   *
   *     Remove protection against out-of-range input in generated code: 'off'
   */
  rtb_Gain3_po = HevP4OptimalController_P.Ndiff * HevP4OptimalController_P.N
    [(int32_T)u0] * rtb_Switch2_o_tmp *
    HevP4OptimalController_P.rads2rpm1_Gain_a;

  /* Saturate: '<S10>/Saturation' */
  if (rtb_Gain3_po > HevP4OptimalController_P.Saturation_UpperSat_e) {
    rtb_MotTrqRegenWhl = HevP4OptimalController_P.Saturation_UpperSat_e;
  } else if (rtb_Gain3_po < HevP4OptimalController_P.Saturation_LowerSat_m) {
    rtb_MotTrqRegenWhl = HevP4OptimalController_P.Saturation_LowerSat_m;
  } else {
    rtb_MotTrqRegenWhl = rtb_Gain3_po;
  }

  /* End of Saturate: '<S10>/Saturation' */

  /* Sum: '<S7>/Minus' incorporates:
   *  Gain: '<S10>/Kw to w'
   *  Gain: '<S10>/rpm to rad//s'
   *  Gain: '<S4>/Gain3'
   *  Lookup_n-D: '<S10>/Accessory Load Power'
   *  Lookup_n-D: '<S7>/MaxEngineTorque'
   *  Product: '<S10>/Divide'
   */
  rtb_ChrgLmt = look1_binlcapw(rtb_Gain3_po,
    HevP4OptimalController_P.f_tbrake_n_bpt,
    HevP4OptimalController_P.MaxEngineTorque_tableData, 15U) -
    HevP4OptimalController_P.Kwtow_Gain * look1_binlcpw(rtb_Gain3_po,
    HevP4OptimalController_P.AccSpdbp, HevP4OptimalController_P.AccPwrbp, 1U) /
    (HevP4OptimalController_P.rpmtorads_Gain * rtb_MotTrqRegenWhl);

  /* Lookup_n-D: '<S13>/Eta 4D' incorporates:
   *  Abs: '<S13>/Abs1'
   *  Constant: '<S13>/Constant'
   *  Gain: '<S4>/Gain3'
   *  Rounding: '<Root>/Round'
   */
  bpIndices[0U] = plook_binc(fabs(rtb_ChrgLmt),
    HevP4OptimalController_P.Trq_bpts, 6U, &rtb_Divide2_n);
  fractions[0U] = rtb_Divide2_n;
  bpIndices[1U] = plook_binc(rtb_Gain3_po, HevP4OptimalController_P.omega_bpts,
    10U, &rtb_Divide2_n);
  fractions[1U] = rtb_Divide2_n;
  bpIndices[2U] = plook_binc(rtb_Round, HevP4OptimalController_P.G, 6U,
    &rtb_Divide2_n);
  fractions[2U] = rtb_Divide2_n;
  bpIndices[3U] = plook_binc(HevP4OptimalController_P.Temp_bpts[0],
    HevP4OptimalController_P.Temp_bpts, 1U, &rtb_Divide2_n);
  fractions[3U] = rtb_Divide2_n;
  rtb_MotTrqRegenWhl = intrp4d_l_pw(bpIndices, fractions,
    HevP4OptimalController_P.eta_tbl, HevP4OptimalController_P.Eta4D_dimSizes_m);

  /* Switch: '<S13>/Switch2' incorporates:
   *  Constant: '<S13>/Constant1'
   *  Constant: '<S13>/Constant2'
   *  Gain: '<S13>/rpm2rads'
   *  Product: '<S13>/Product1'
   */
  if (HevP4OptimalController_P.rpm2rads_Gain_m * rtb_Gain3_po * rtb_ChrgLmt >=
      HevP4OptimalController_P.Switch2_Threshold_mu) {
    rtb_WhlSpd = HevP4OptimalController_P.Constant1_Value_g;
  } else {
    rtb_WhlSpd = HevP4OptimalController_P.Constant2_Value_c;
  }

  /* End of Switch: '<S13>/Switch2' */

  /* Math: '<S13>/Math Function1' */
  if ((rtb_MotTrqRegenWhl < 0.0) && (rtb_WhlSpd > floor(rtb_WhlSpd))) {
    rtb_MotTrqRegenWhl = -rt_powd_snf(-rtb_MotTrqRegenWhl, rtb_WhlSpd);
  } else {
    rtb_MotTrqRegenWhl = rt_powd_snf(rtb_MotTrqRegenWhl, rtb_WhlSpd);
  }

  /* End of Math: '<S13>/Math Function1' */

  /* LookupNDDirect: '<S9>/Gear ratio look up' incorporates:
   *  Rounding: '<Root>/Round'
   *
   * About '<S9>/Gear ratio look up':
   *  1-dimensional Direct Look-Up returning a Scalar,
   *
   *     Remove protection against out-of-range input in generated code: 'off'
   */
  if (rtIsNaN(rtb_Round)) {
    u0 = 0.0;
  } else {
    u0 = rtb_Round;
  }

  if (u0 > 6.0) {
    u0 = 6.0;
  } else if (u0 < 0.0) {
    u0 = 0.0;
  }

  rtb_WhlSpd = HevP4OptimalController_P.N[(int32_T)u0];

  /* End of LookupNDDirect: '<S9>/Gear ratio look up' */

  /* Switch: '<S9>/Switch1' incorporates:
   *  Constant: '<S9>/neutral'
   *  Product: '<S9>/Product'
   *  Product: '<S9>/Product3'
   */
  if (rtb_Round > HevP4OptimalController_P.Switch1_Threshold_n) {
    rtb_MotTrqRegenWhl *= rtb_WhlSpd * rtb_ChrgLmt;
  } else {
    rtb_MotTrqRegenWhl = HevP4OptimalController_P.neutral_Value_a;
  }

  /* End of Switch: '<S9>/Switch1' */

  /* Switch: '<S12>/Switch2' incorporates:
   *  Constant: '<S12>/Constant1'
   *  Constant: '<S12>/Constant2'
   *  Gain: '<S12>/rpm2rads'
   *  Product: '<S12>/Product1'
   *  Product: '<S9>/Divide3'
   */
  if (rtb_Gain3_po / rtb_WhlSpd * HevP4OptimalController_P.rpm2rads_Gain_l *
      rtb_MotTrqRegenWhl >= HevP4OptimalController_P.Switch2_Threshold_c) {
    rtb_WhlSpd = HevP4OptimalController_P.Constant1_Value_aj;
  } else {
    rtb_WhlSpd = HevP4OptimalController_P.Constant2_Value_d4;
  }

  /* End of Switch: '<S12>/Switch2' */

  /* Math: '<S12>/Math Function1' incorporates:
   *  Constant: '<S12>/Constant'
   */
  if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_WhlSpd > floor
       (rtb_WhlSpd))) {
    rtb_BrkTrqFric = -rt_powd_snf(-HevP4OptimalController_P.eta_diff, rtb_WhlSpd);
  } else {
    rtb_BrkTrqFric = rt_powd_snf(HevP4OptimalController_P.eta_diff, rtb_WhlSpd);
  }

  /* End of Math: '<S12>/Math Function1' */

  /* Gain: '<S9>/Diff ratio' */
  rtb_Diffratio = HevP4OptimalController_P.Ndiff * rtb_MotTrqRegenWhl;

  /* Gain: '<S1>/rads2rpm' */
  rtb_WhlSpd = HevP4OptimalController_P.rads2rpm_Gain_b * *rtu_MtrSpd;

  /* Lookup_n-D: '<S1>/MaxMotTrqVsSpd' incorporates:
   *  Saturate: '<S4>/Negative 5'
   */
  rtb_MotTrqRegenWhl = look1_binlcapw(rtb_WhlSpd,
    HevP4OptimalController_P.w_eff_bp, HevP4OptimalController_P.T_t, 13U);

  /* Switch: '<S11>/Switch2' incorporates:
   *  Constant: '<S11>/Constant1'
   *  Constant: '<S11>/Constant2'
   *  Gain: '<S11>/rpm2rads'
   *  Product: '<S11>/Product1'
   */
  if (HevP4OptimalController_P.rpm2rads_Gain_h * rtb_WhlSpd * rtb_MotTrqRegenWhl
      >= HevP4OptimalController_P.Switch2_Threshold_a) {
    rtb_WhlSpd = HevP4OptimalController_P.Constant1_Value_au;
  } else {
    rtb_WhlSpd = HevP4OptimalController_P.Constant2_Value_il;
  }

  /* End of Switch: '<S11>/Switch2' */

  /* Math: '<S11>/Math Function1' incorporates:
   *  Constant: '<S11>/Constant'
   */
  if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_WhlSpd > floor
       (rtb_WhlSpd))) {
    rtb_BrkTrqFric_n = -rt_powd_snf(-HevP4OptimalController_P.eta_diff,
      rtb_WhlSpd);
  } else {
    rtb_BrkTrqFric_n = rt_powd_snf(HevP4OptimalController_P.eta_diff, rtb_WhlSpd);
  }

  /* End of Math: '<S11>/Math Function1' */

  /* Gain: '<S8>/Gain3' */
  rtb_Gain3 = HevP4OptimalController_P.Ndiff_P4 * rtb_MotTrqRegenWhl;

  /* Switch: '<S2>/Switch' incorporates:
   *  Constant: '<S2>/Constant1'
   */
  if (0.0 > HevP4OptimalController_P.Switch_Threshold) {
    rtb_WhlSpd = HevP4OptimalController_P.Constant1_Value_aw;
  } else {
    rtb_WhlSpd = *rtu_DecelPdl;
  }

  /* End of Switch: '<S2>/Switch' */

  /* Product: '<S2>/Product1' incorporates:
   *  Constant: '<S2>/Constant'
   */
  rtb_WhlSpd *= HevP4OptimalController_P.BrkPrsMax;

  /* Product: '<S4>/Product2' incorporates:
   *  Constant: '<S4>/Constant'
   */
  rtb_BrkTrqReqTotal = HevP4OptimalController_P.mu_kinetic * 3.1415926535897931 *
    0.0025000000000000005 * HevP4OptimalController_P.Rm *
    HevP4OptimalController_P.num_pads / 4.0 * 4.0 * rtb_WhlSpd;

  /* LookupNDDirect: '<S4>/Direct Lookup Table (n-D)' incorporates:
   *  Rounding: '<Root>/Round'
   *
   * About '<S4>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   *
   *     Remove protection against out-of-range input in generated code: 'off'
   */
  if (rtIsNaN(rtb_Round)) {
    u0 = 0.0;
  } else {
    u0 = rtb_Round;
  }

  if (u0 > 6.0) {
    u0 = 6.0;
  } else if (u0 < 0.0) {
    u0 = 0.0;
  }

  /* Gain: '<S4>/rads2rpm1' incorporates:
   *  Gain: '<S1>/Gain2'
   *  Gain: '<S4>/Gain1'
   *  LookupNDDirect: '<S4>/Direct Lookup Table (n-D)'
   *  Product: '<S4>/Product'
   *
   * About '<S4>/Direct Lookup Table (n-D)':
   *  1-dimensional Direct Look-Up returning a Scalar,
   *
   *     Remove protection against out-of-range input in generated code: 'off'
   */
  rtb_MotTrqRegenWhl = HevP4OptimalController_P.Ndiff *
    HevP4OptimalController_P.N[(int32_T)u0] * rtb_Switch2_o_tmp *
    HevP4OptimalController_P.rads2rpm1_Gain_o;

  /* Switch: '<S66>/Switch' incorporates:
   *  Constant: '<S66>/Constant2'
   */
  if (rtb_WhlSpd > HevP4OptimalController_P.Switch_Threshold_o) {
    /* Gain: '<S69>/Gain5' incorporates:
     *  Lookup_n-D: '<S69>/Max Torque vs Speed'
     *  Product: '<S4>/Product3'
     */
    u0 = HevP4OptimalController_P.Gain5_Gain * look1_binlcapw(rtb_MotTrqRegenWhl,
      HevP4OptimalController_P.MaxTorquevsSpeed_bp01Data,
      HevP4OptimalController_P.MaxTorquevsSpeed_tableData_i, 16U);

    /* Saturate: '<S69>/Saturation1' */
    if (u0 > HevP4OptimalController_P.Saturation1_UpperSat_k) {
      u0 = HevP4OptimalController_P.Saturation1_UpperSat_k;
    } else if (u0 < HevP4OptimalController_P.Saturation1_LowerSat_n) {
      u0 = HevP4OptimalController_P.Saturation1_LowerSat_n;
    }

    /* End of Saturate: '<S69>/Saturation1' */
  } else {
    u0 = HevP4OptimalController_P.Constant2_Value_ny;
  }

  /* End of Switch: '<S66>/Switch' */

  /* Saturate: '<S68>/Saturation' */
  if (rtb_MotTrqRegenWhl > HevP4OptimalController_P.Saturation_UpperSat_f) {
    rtb_WhlSpd = HevP4OptimalController_P.Saturation_UpperSat_f;
  } else if (rtb_MotTrqRegenWhl <
             HevP4OptimalController_P.Saturation_LowerSat_ch) {
    rtb_WhlSpd = HevP4OptimalController_P.Saturation_LowerSat_ch;
  } else {
    rtb_WhlSpd = rtb_MotTrqRegenWhl;
  }

  /* End of Saturate: '<S68>/Saturation' */

  /* Sum: '<S66>/Add1' incorporates:
   *  Gain: '<S68>/Kw to w'
   *  Gain: '<S68>/rpm to rad//s'
   *  Lookup_n-D: '<S68>/Accessory Load Power'
   *  Product: '<S4>/Product3'
   *  Product: '<S68>/Divide'
   */
  rtb_ChrgLmt = HevP4OptimalController_P.Kwtow_Gain_m * look1_binlcpw
    (rtb_MotTrqRegenWhl, HevP4OptimalController_P.AccessoryLoadModel_AccSpdBpts,
     HevP4OptimalController_P.AccessoryLoadModel_AccPwrTbl, 1U) /
    (HevP4OptimalController_P.rpmtorads_Gain_j * rtb_WhlSpd) + u0;

  /* Lookup_n-D: '<S72>/Eta 4D' incorporates:
   *  Abs: '<S72>/Abs1'
   *  Constant: '<S72>/Constant'
   *  Product: '<S4>/Product3'
   *  Rounding: '<Root>/Round'
   */
  bpIndices_0[0U] = plook_binc(fabs(rtb_ChrgLmt),
    HevP4OptimalController_P.Trq_bpts, 6U, &rtb_Divide2_n);
  fractions_0[0U] = rtb_Divide2_n;
  bpIndices_0[1U] = plook_binc(rtb_MotTrqRegenWhl,
    HevP4OptimalController_P.omega_bpts, 10U, &rtb_Divide2_n);
  fractions_0[1U] = rtb_Divide2_n;
  bpIndices_0[2U] = plook_binc(rtb_Round, HevP4OptimalController_P.G, 6U,
    &rtb_Divide2_n);
  fractions_0[2U] = rtb_Divide2_n;
  bpIndices_0[3U] = plook_binc(HevP4OptimalController_P.Temp_bpts[0],
    HevP4OptimalController_P.Temp_bpts, 1U, &rtb_Divide2_n);
  fractions_0[3U] = rtb_Divide2_n;
  rtb_WhlSpd = intrp4d_l_pw(bpIndices_0, fractions_0,
    HevP4OptimalController_P.eta_tbl, HevP4OptimalController_P.Eta4D_dimSizes_f);

  /* Switch: '<S72>/Switch2' incorporates:
   *  Constant: '<S72>/Constant1'
   *  Constant: '<S72>/Constant2'
   *  Gain: '<S72>/rpm2rads'
   *  Product: '<S72>/Product1'
   */
  if (HevP4OptimalController_P.rpm2rads_Gain_f * rtb_MotTrqRegenWhl *
      rtb_ChrgLmt >= HevP4OptimalController_P.Switch2_Threshold_n) {
    rtb_Gain3_po = HevP4OptimalController_P.Constant1_Value_h;
  } else {
    rtb_Gain3_po = HevP4OptimalController_P.Constant2_Value_k;
  }

  /* End of Switch: '<S72>/Switch2' */

  /* Math: '<S72>/Math Function1' */
  if ((rtb_WhlSpd < 0.0) && (rtb_Gain3_po > floor(rtb_Gain3_po))) {
    rtb_WhlSpd = -rt_powd_snf(-rtb_WhlSpd, rtb_Gain3_po);
  } else {
    rtb_WhlSpd = rt_powd_snf(rtb_WhlSpd, rtb_Gain3_po);
  }

  /* End of Math: '<S72>/Math Function1' */

  /* LookupNDDirect: '<S70>/Gear ratio look up' incorporates:
   *  Rounding: '<Root>/Round'
   *
   * About '<S70>/Gear ratio look up':
   *  1-dimensional Direct Look-Up returning a Scalar,
   *
   *     Remove protection against out-of-range input in generated code: 'off'
   */
  if (rtIsNaN(rtb_Round)) {
    u0 = 0.0;
  } else {
    u0 = rtb_Round;
  }

  if (u0 > 6.0) {
    u0 = 6.0;
  } else if (u0 < 0.0) {
    u0 = 0.0;
  }

  rtb_Gain3_po = HevP4OptimalController_P.N[(int32_T)u0];

  /* End of LookupNDDirect: '<S70>/Gear ratio look up' */

  /* Switch: '<S70>/Switch1' incorporates:
   *  Constant: '<S70>/neutral'
   *  Product: '<S70>/Product'
   *  Product: '<S70>/Product3'
   */
  if (rtb_Round > HevP4OptimalController_P.Switch1_Threshold_d) {
    rtb_WhlSpd *= rtb_Gain3_po * rtb_ChrgLmt;
  } else {
    rtb_WhlSpd = HevP4OptimalController_P.neutral_Value_a4;
  }

  /* End of Switch: '<S70>/Switch1' */

  /* Switch: '<S71>/Switch2' incorporates:
   *  Constant: '<S71>/Constant1'
   *  Constant: '<S71>/Constant2'
   *  Gain: '<S71>/rpm2rads'
   *  Product: '<S70>/Divide3'
   *  Product: '<S71>/Product1'
   */
  if (rtb_MotTrqRegenWhl / rtb_Gain3_po *
      HevP4OptimalController_P.rpm2rads_Gain_e * rtb_WhlSpd >=
      HevP4OptimalController_P.Switch2_Threshold_p) {
    rtb_ChrgLmt = HevP4OptimalController_P.Constant1_Value_ji;
  } else {
    rtb_ChrgLmt = HevP4OptimalController_P.Constant2_Value_nl;
  }

  /* End of Switch: '<S71>/Switch2' */

  /* Math: '<S71>/Math Function1' incorporates:
   *  Constant: '<S71>/Constant'
   */
  if ((HevP4OptimalController_P.Constant_Value_c < 0.0) && (rtb_ChrgLmt > floor
       (rtb_ChrgLmt))) {
    rtb_Switch2_o_tmp = -rt_powd_snf(-HevP4OptimalController_P.Constant_Value_c,
      rtb_ChrgLmt);
  } else {
    rtb_Switch2_o_tmp = rt_powd_snf(HevP4OptimalController_P.Constant_Value_c,
      rtb_ChrgLmt);
  }

  /* End of Math: '<S71>/Math Function1' */

  /* Sum: '<S66>/Add' incorporates:
   *  Gain: '<S70>/Diff ratio'
   *  Product: '<S70>/Divide2'
   */
  rtb_WhlSpd = rtb_BrkTrqReqTotal - HevP4OptimalController_P.Ndiff * rtb_WhlSpd *
    rtb_Switch2_o_tmp;

  /* Saturate: '<S66>/Saturation' */
  if (rtb_WhlSpd > HevP4OptimalController_P.Saturation_UpperSat_b) {
    rtb_WhlSpd = HevP4OptimalController_P.Saturation_UpperSat_b;
  } else if (rtb_WhlSpd < HevP4OptimalController_P.Saturation_LowerSat_n) {
    rtb_WhlSpd = HevP4OptimalController_P.Saturation_LowerSat_n;
  }

  /* End of Saturate: '<S66>/Saturation' */

  /* Gain: '<S4>/rads_to_rpm' */
  rtb_ChrgLmt = HevP4OptimalController_P.rads_to_rpm_Gain * *rtu_MtrSpd;

  /* Gain: '<S4>/Gain3' incorporates:
   *  Lookup_n-D: '<S4>/ChrgLmt'
   *  Lookup_n-D: '<S4>/MaxMotTrqVsSpd'
   */
  rtb_Gain3_po = HevP4OptimalController_P.Gain3_Gain * look1_binlcapw
    (rtb_ChrgLmt, HevP4OptimalController_P.w_eff_bp,
     HevP4OptimalController_P.T_t, 13U);

  /* Switch: '<S73>/Switch2' incorporates:
   *  Constant: '<S73>/Constant1'
   *  Constant: '<S73>/Constant2'
   *  Gain: '<S73>/rpm2rads'
   *  Product: '<S73>/Product1'
   */
  if (HevP4OptimalController_P.rpm2rads_Gain_b * rtb_ChrgLmt * rtb_Gain3_po >=
      HevP4OptimalController_P.Switch2_Threshold_l) {
    rtb_ChrgLmt = HevP4OptimalController_P.Constant1_Value_m;
  } else {
    rtb_ChrgLmt = HevP4OptimalController_P.Constant2_Value_e;
  }

  /* End of Switch: '<S73>/Switch2' */

  /* Math: '<S73>/Math Function1' incorporates:
   *  Constant: '<S73>/Constant'
   */
  if ((HevP4OptimalController_P.Constant_Value_eu < 0.0) && (rtb_ChrgLmt > floor
       (rtb_ChrgLmt))) {
    rtb_Switch2_o_tmp = -rt_powd_snf(-HevP4OptimalController_P.Constant_Value_eu,
      rtb_ChrgLmt);
  } else {
    rtb_Switch2_o_tmp = rt_powd_snf(HevP4OptimalController_P.Constant_Value_eu,
      rtb_ChrgLmt);
  }

  /* End of Math: '<S73>/Math Function1' */

  /* Gain: '<S4>/Gain5' */
  rtb_ChrgLmt = HevP4OptimalController_P.Gain5_Gain_m * *rtu_BattSoc;

  /* Gain: '<S4>/Gain4' incorporates:
   *  Gain: '<S67>/Gain3'
   *  Product: '<S67>/Divide2'
   */
  rtb_Divide2_n = HevP4OptimalController_P.Ndiff_P4 * rtb_Gain3_po *
    rtb_Switch2_o_tmp * HevP4OptimalController_P.Gain4_Gain;

  /* MinMax: '<S4>/MinMax' */
  if ((rtb_WhlSpd < rtb_Divide2_n) || rtIsNaN(rtb_Divide2_n)) {
    rtb_Divide2_n = rtb_WhlSpd;
  }

  /* End of MinMax: '<S4>/MinMax' */

  /* Product: '<S4>/Product3' incorporates:
   *  Lookup_n-D: '<S4>/ChrgLmt'
   *  Lookup_n-D: '<S4>/RegenBrakingCutoff'
   *  Product: '<S4>/Product1'
   */
  rtb_MotTrqRegenWhl = look1_binlcapw(rtb_MotTrqRegenWhl,
    HevP4OptimalController_P.RegenBrakingCutoff_bp01Data,
    HevP4OptimalController_P.RegenBrkCutOff, 1U) * look1_binlcapw(rtb_ChrgLmt,
    HevP4OptimalController_P.SOC_bpt, HevP4OptimalController_P.ChrgLmt_bpt, 10U)
    * rtb_Divide2_n;

  /* Switch: '<S1>/Accel Decel Switch' incorporates:
   *  Constant: '<S5>/Constant'
   *  Gain: '<S4>/Gain'
   *  Product: '<S1>/Product1'
   *  Product: '<S8>/Divide2'
   *  Product: '<S9>/Divide2'
   *  RelationalOperator: '<S5>/Compare'
   *  Sum: '<S1>/Add'
   */
  if (rtb_AccelDecelSwitch1 > HevP4OptimalController_P.CompareToConstant_const)
  {
    *rty_WhlTrqCmd = (rtb_BrkTrqFric * rtb_Diffratio + rtb_BrkTrqFric_n *
                      rtb_Gain3) * rtb_AccelDecelSwitch1;
  } else {
    *rty_WhlTrqCmd = HevP4OptimalController_P.Gain_Gain_mf * rtb_MotTrqRegenWhl;
  }

  /* End of Switch: '<S1>/Accel Decel Switch' */

  /* Gain: '<S3>/Gain1' */
  rtb_BrkTrqFric = HevP4OptimalController_P.Gain1_Gain_e * *rtu_BattSoc;

  /* If: '<S3>/If' incorporates:
   *  Constant: '<S17>/no electric'
   */
  rtPrevAction = localDW->If_ActiveSubsystem;
  rtAction = (int8_T)!(*rty_WhlTrqCmd <= 0.0);
  localDW->If_ActiveSubsystem = rtAction;
  if (rtPrevAction != rtAction) {
    switch (rtPrevAction) {
     case 0:
      ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
      break;

     case 1:
      ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
      break;
    }
  }

  if (rtAction == 0) {
    if (0 != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S3>/Energy Management Off' incorporates:
       *  ActionPort: '<S16>/Action Port'
       */
      /* InitializeConditions for If: '<S3>/If' incorporates:
       *  UnitDelay: '<S64>/Unit Delay'
       */
      localDW->UnitDelay_DSTATE_c =
        HevP4OptimalController_P.UnitDelay_InitialCondition;

      /* End of InitializeConditions for SubSystem: '<S3>/Energy Management Off' */

      /* Enable for IfAction SubSystem: '<S3>/Energy Management Off' incorporates:
       *  ActionPort: '<S16>/Action Port'
       */
      /* Enable for If: '<S3>/If' */
      if (rtmGetTaskTime(HevP4OptimalController_M, 0) != rtmGetTStart
          (HevP4OptimalController_M)) {
        ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
      }

      /* End of Enable for SubSystem: '<S3>/Energy Management Off' */
    }

    /* Outputs for IfAction SubSystem: '<S3>/Energy Management Off' incorporates:
     *  ActionPort: '<S16>/Action Port'
     */
    /* SignalConversion generated from: '<S16>/EngTrqCmd' incorporates:
     *  Constant: '<S16>/Constant'
     */
    *rty_EngTrqCmd = HevP4OptimalController_P.Constant_Value;

    /* Gain: '<S16>/Gain' */
    rtb_Round = HevP4OptimalController_P.Gain_Gain * *rtu_MtrSpd;

    /* Gain: '<S16>/rads2rpm' */
    rtb_Divide2_n = HevP4OptimalController_P.rads2rpm_Gain * *rtu_MtrSpd;

    /* Switch: '<S65>/Switch2' incorporates:
     *  Constant: '<S65>/Constant1'
     *  Constant: '<S65>/Constant2'
     *  Product: '<S65>/Product1'
     *  UnitDelay: '<S64>/Unit Delay'
     */
    if (localDW->UnitDelay_DSTATE_c * rtb_Divide2_n >=
        HevP4OptimalController_P.Switch2_Threshold) {
      rtb_Divide2_n = HevP4OptimalController_P.Constant1_Value;
    } else {
      rtb_Divide2_n = HevP4OptimalController_P.Constant2_Value;
    }

    /* End of Switch: '<S65>/Switch2' */

    /* Math: '<S65>/Math Function1' incorporates:
     *  Constant: '<S65>/Constant'
     */
    if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_Divide2_n > floor
         (rtb_Divide2_n))) {
      rtb_Switch2_o_tmp = -rt_powd_snf(-HevP4OptimalController_P.eta_diff,
        rtb_Divide2_n);
    } else {
      rtb_Switch2_o_tmp = rt_powd_snf(HevP4OptimalController_P.eta_diff,
        rtb_Divide2_n);
    }

    /* End of Math: '<S65>/Math Function1' */

    /* Product: '<S64>/Divide1' incorporates:
     *  Gain: '<S64>/Gain3'
     */
    localB->Divide1_d = 1.0 / HevP4OptimalController_P.Ndiff_P4 * *rty_WhlTrqCmd
      * (1.0 / rtb_Switch2_o_tmp);

    /* SignalConversion: '<S16>/Signal Conversion' incorporates:
     *  Constant: '<S62>/Constant'
     *  Product: '<S16>/Product'
     *  RelationalOperator: '<S62>/Compare'
     */
    *rty_MtrTrqCmd = (real_T)(rtb_Round >=
      HevP4OptimalController_P.GEMinSpeed_const) * localB->Divide1_d;

    /* End of Outputs for SubSystem: '<S3>/Energy Management Off' */
  } else {
    if (1 != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S3>/Energy Management' incorporates:
       *  ActionPort: '<S15>/Action Port'
       */
      for (i = 0; i < 202; i++) {
        /* InitializeConditions for If: '<S3>/If' incorporates:
         *  UnitDelay: '<S42>/Unit Delay1'
         *  UnitDelay: '<S42>/Unit Delay2'
         *  UnitDelay: '<S60>/Unit Delay'
         */
        localDW->UnitDelay1_DSTATE[i] =
          HevP4OptimalController_P.UnitDelay1_InitialCondition;
        localDW->UnitDelay2_DSTATE[i] =
          HevP4OptimalController_P.UnitDelay2_InitialCondition;
        localDW->UnitDelay_DSTATE[i] =
          HevP4OptimalController_P.UnitDelay_InitialCondition_l;
      }

      /* InitializeConditions for If: '<S3>/If' incorporates:
       *  DiscreteTransferFcn: '<S18>/Discrete Transfer Fcn'
       *  UnitDelay: '<S18>/Unit Delay2'
       */
      localDW->UnitDelay2_DSTATE_d =
        HevP4OptimalController_P.UnitDelay2_InitialCondition_c;
      localDW->DiscreteTransferFcn_states =
        HevP4OptimalController_P.DiscreteTransferFcn_InitialStates;

      /* End of InitializeConditions for SubSystem: '<S3>/Energy Management' */

      /* Enable for IfAction SubSystem: '<S3>/Energy Management' incorporates:
       *  ActionPort: '<S15>/Action Port'
       */
      /* Enable for IfAction SubSystem: '<S3>/Energy Management Off' incorporates:
       *  ActionPort: '<S16>/Action Port'
       */
      /* Enable for If: '<S3>/If' */
      if (rtmGetTaskTime(HevP4OptimalController_M, 0) != rtmGetTStart
          (HevP4OptimalController_M)) {
        ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
      }

      /* End of Enable for SubSystem: '<S3>/Energy Management Off' */

      /* End of Enable for SubSystem: '<S3>/Energy Management' */
    }

    /* Outputs for IfAction SubSystem: '<S3>/Energy Management' incorporates:
     *  ActionPort: '<S15>/Action Port'
     */
    /* Gain: '<S17>/rads2rpm' */
    rtb_Divide2_n = HevP4OptimalController_P.rads2rpm_Gain_o * *rtu_MtrSpd;

    /* Product: '<S21>/Divide2' incorporates:
     *  Constant: '<S17>/MotTrq Control Vector'
     *  Gain: '<S21>/Gain3'
     */
    for (i = 0; i < 200; i++) {
      /* Switch: '<S22>/Switch2' incorporates:
       *  Constant: '<S17>/MotTrq Control Vector'
       *  Constant: '<S22>/Constant1'
       *  Constant: '<S22>/Constant2'
       *  Product: '<S22>/Product1'
       */
      if (HevP4OptimalController_P.MotTrqControlVector_Value[i] * rtb_Divide2_n >=
          HevP4OptimalController_P.Switch2_Threshold_i) {
        rtb_Switch2_o_tmp = HevP4OptimalController_P.Constant1_Value_f;
      } else {
        rtb_Switch2_o_tmp = HevP4OptimalController_P.Constant2_Value_g;
      }

      /* End of Switch: '<S22>/Switch2' */

      /* Math: '<S22>/Math Function1' */
      if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_Switch2_o_tmp >
           floor(rtb_Switch2_o_tmp))) {
        rtb_Switch2_o_tmp = -rt_powd_snf(-HevP4OptimalController_P.eta_diff,
          rtb_Switch2_o_tmp);
      } else {
        rtb_Switch2_o_tmp = rt_powd_snf(HevP4OptimalController_P.eta_diff,
          rtb_Switch2_o_tmp);
      }

      /* End of Math: '<S22>/Math Function1' */
      rtb_Gain_m[i + 2] = HevP4OptimalController_P.Ndiff_P4 *
        HevP4OptimalController_P.MotTrqControlVector_Value[i] *
        rtb_Switch2_o_tmp;
    }

    /* End of Product: '<S21>/Divide2' */

    /* Switch: '<S17>/Switch1' incorporates:
     *  Constant: '<S17>/neutral'
     */
    if (rtb_Round > HevP4OptimalController_P.Switch1_Threshold) {
      rtb_Gain_m[0] = *rty_WhlTrqCmd;
    } else {
      rtb_Gain_m[0] = HevP4OptimalController_P.neutral_Value;
    }

    /* End of Switch: '<S17>/Switch1' */
    rtb_Gain_m[1] = HevP4OptimalController_P.noelectric_Value;

    /* Gain: '<S35>/Veh2WhlSpd' incorporates:
     *  Constant: '<S17>/no electric'
     */
    rtb_Diffratio = 1.0 / HevP4OptimalController_P.Re * *rtu_VehSpdFdbk;

    /* LookupNDDirect: '<S35>/Gear ratio look up' incorporates:
     *  Rounding: '<Root>/Round'
     *
     * About '<S35>/Gear ratio look up':
     *  1-dimensional Direct Look-Up returning a Scalar,
     *
     *     Remove protection against out-of-range input in generated code: 'off'
     */
    if (rtIsNaN(rtb_Round)) {
      u0 = 0.0;
    } else {
      u0 = rtb_Round;
    }

    if (u0 > 6.0) {
      u0 = 6.0;
    } else if (u0 < 0.0) {
      u0 = 0.0;
    }

    /* Product: '<S35>/Product1' incorporates:
     *  Gain: '<S35>/Gain'
     *  Gain: '<S35>/Veh2WhlSpd'
     *  LookupNDDirect: '<S35>/Gear ratio look up'
     *
     * About '<S35>/Gear ratio look up':
     *  1-dimensional Direct Look-Up returning a Scalar,
     *
     *     Remove protection against out-of-range input in generated code: 'off'
     */
    rtb_AccelDecelSwitch1 = HevP4OptimalController_P.Ndiff *
      HevP4OptimalController_P.N[(int32_T)u0] * rtb_Diffratio;

    /* Saturate: '<S35>/Saturation' */
    if (rtb_AccelDecelSwitch1 > HevP4OptimalController_P.Saturation_UpperSat) {
      rtb_AccelDecelSwitch1 = HevP4OptimalController_P.Saturation_UpperSat;
    } else if (rtb_AccelDecelSwitch1 <
               HevP4OptimalController_P.Saturation_LowerSat) {
      rtb_AccelDecelSwitch1 = HevP4OptimalController_P.Saturation_LowerSat;
    }

    /* End of Saturate: '<S35>/Saturation' */

    /* Gain: '<S30>/rads2rpm' */
    rtb_BrkTrqFric_n = HevP4OptimalController_P.rads2rpm_Gain_g *
      rtb_AccelDecelSwitch1;

    /* Switch: '<S41>/Switch' incorporates:
     *  Constant: '<S41>/Constant'
     *  Gain: '<S30>/rads2rpm'
     *  Lookup_n-D: '<S41>/Max Torque vs Speed'
     */
    if (rtb_BrkTrqFric_n > HevP4OptimalController_P.N_idle) {
      rtb_Gain3 = look1_binlcapw(rtb_BrkTrqFric_n,
        HevP4OptimalController_P.f_tbrake_n_bpt,
        HevP4OptimalController_P.MaxTorquevsSpeed_tableData, 15U);
    } else {
      rtb_Gain3 = HevP4OptimalController_P.Constant_Value_f;
    }

    /* End of Switch: '<S41>/Switch' */

    /* Abs: '<S44>/Abs1' incorporates:
     *  UnitDelay: '<S42>/Unit Delay1'
     */
    for (i = 0; i < 202; i++) {
      rtb_Switch1[i] = fabs(localDW->UnitDelay1_DSTATE[i]);
    }

    /* End of Abs: '<S44>/Abs1' */

    /* Lookup_n-D: '<S46>/Eta 4D' incorporates:
     *  Constant: '<Root>/Constant'
     *  Gain: '<S30>/rads2rpm'
     *  Rounding: '<Root>/Round'
     */
    bpIndices_1[1U] = plook_binc(rtb_BrkTrqFric_n,
      HevP4OptimalController_P.omega_bpts, 10U, &rtb_Divide2_n);
    fractions_1[1U] = rtb_Divide2_n;
    bpIndices_1[2U] = plook_binc(rtb_Round, HevP4OptimalController_P.G, 6U,
      &rtb_Divide2_n);
    fractions_1[2U] = rtb_Divide2_n;
    bpIndices_1[3U] = plook_binc(HevP4OptimalController_P.Temp_bpts[0],
      HevP4OptimalController_P.Temp_bpts, 1U, &rtb_Divide2_n);
    fractions_1[3U] = rtb_Divide2_n;
    for (i = 0; i < 202; i++) {
      bpIndices_1[0U] = plook_binc(rtb_Switch1[i],
        HevP4OptimalController_P.Trq_bpts, 6U, &rtb_Divide2_n);
      fractions_1[0U] = rtb_Divide2_n;
      rtb_Switch1[i] = intrp4d_l_pw(bpIndices_1, fractions_1,
        HevP4OptimalController_P.eta_tbl,
        HevP4OptimalController_P.Eta4D_dimSizes);
    }

    /* End of Lookup_n-D: '<S46>/Eta 4D' */

    /* Gain: '<S44>/rpm2rads' */
    rtb_Divide2_n = HevP4OptimalController_P.rpm2rads_Gain * rtb_BrkTrqFric_n;

    /* LookupNDDirect: '<S42>/Gear ratio look up' incorporates:
     *  Rounding: '<Root>/Round'
     *
     * About '<S42>/Gear ratio look up':
     *  1-dimensional Direct Look-Up returning a Scalar,
     *
     *     Remove protection against out-of-range input in generated code: 'off'
     */
    if (rtIsNaN(rtb_Round)) {
      u0 = 0.0;
    } else {
      u0 = rtb_Round;
    }

    if (u0 > 6.0) {
      u0 = 6.0;
    } else if (u0 < 0.0) {
      u0 = 0.0;
    }

    rtb_ChrgLmt = HevP4OptimalController_P.N[(int32_T)u0];

    /* End of LookupNDDirect: '<S42>/Gear ratio look up' */

    /* Product: '<S42>/Divide6' */
    rtb_Divide6 = rtb_BrkTrqFric_n / rtb_ChrgLmt;

    /* Gain: '<S31>/rads2rpm1' */
    rtb_Switch2_k = HevP4OptimalController_P.rads2rpm1_Gain * *rtu_MtrSpd;

    /* Lookup_n-D: '<S51>/Maximum Torque Lookup' incorporates:
     *  Abs: '<S51>/Abs1'
     */
    rtb_BrkTrqReqTotal = look1_binlcpw(fabs(rtb_Switch2_k),
      HevP4OptimalController_P.w_eff_bp, HevP4OptimalController_P.T_t, 13U);

    /* Gain: '<S60>/Gain3' */
    rtb_Switch2_o_tmp = 1.0 / HevP4OptimalController_P.Ndiff_P4;

    /* Gain: '<S51>/Gain' */
    rtb_Gain3_po = HevP4OptimalController_P.Gain_Gain_m * rtb_BrkTrqReqTotal;
    for (i = 0; i < 202; i++) {
      /* Switch: '<S61>/Switch2' incorporates:
       *  Constant: '<S61>/Constant1'
       *  Constant: '<S61>/Constant2'
       *  Product: '<S61>/Product1'
       *  UnitDelay: '<S60>/Unit Delay'
       */
      if (localDW->UnitDelay_DSTATE[i] * rtb_Switch2_k >=
          HevP4OptimalController_P.Switch2_Threshold_k) {
        rtb_Gain_p = HevP4OptimalController_P.Constant1_Value_f0;
      } else {
        rtb_Gain_p = HevP4OptimalController_P.Constant2_Value_a;
      }

      /* End of Switch: '<S61>/Switch2' */

      /* Math: '<S61>/Math Function1' */
      if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_Gain_p > floor
           (rtb_Gain_p))) {
        rtb_Gain_p = -rt_powd_snf(-HevP4OptimalController_P.eta_diff, rtb_Gain_p);
      } else {
        rtb_Gain_p = rt_powd_snf(HevP4OptimalController_P.eta_diff, rtb_Gain_p);
      }

      /* End of Math: '<S61>/Math Function1' */

      /* Product: '<S60>/Divide1' incorporates:
       *  Gain: '<S60>/Gain3'
       */
      localB->Divide1[i] = 1.0 / rtb_Gain_p * (rtb_Switch2_o_tmp * rtb_Gain_m[i]);

      /* Switch: '<S57>/Switch2' incorporates:
       *  RelationalOperator: '<S57>/LowerRelop1'
       *  RelationalOperator: '<S57>/UpperRelop'
       *  Switch: '<S57>/Switch'
       */
      if (localB->Divide1[i] > rtb_BrkTrqReqTotal) {
        u0 = rtb_BrkTrqReqTotal;
      } else if (localB->Divide1[i] < rtb_Gain3_po) {
        /* Switch: '<S57>/Switch' */
        u0 = rtb_Gain3_po;
      } else {
        u0 = localB->Divide1[i];
      }

      /* Switch: '<S59>/Switch2' incorporates:
       *  Constant: '<S59>/Constant1'
       *  Constant: '<S59>/Constant2'
       *  Product: '<S59>/Product1'
       */
      if (u0 * rtb_Switch2_k >= HevP4OptimalController_P.Switch2_Threshold_b) {
        rtb_Gain_p = HevP4OptimalController_P.Constant1_Value_c;
      } else {
        rtb_Gain_p = HevP4OptimalController_P.Constant2_Value_o;
      }

      /* End of Switch: '<S59>/Switch2' */

      /* Math: '<S59>/Math Function1' */
      if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_Gain_p > floor
           (rtb_Gain_p))) {
        rtb_Gain_p = -rt_powd_snf(-HevP4OptimalController_P.eta_diff, rtb_Gain_p);
      } else {
        rtb_Gain_p = rt_powd_snf(HevP4OptimalController_P.eta_diff, rtb_Gain_p);
      }

      /* End of Math: '<S59>/Math Function1' */

      /* Product: '<S58>/Divide2' incorporates:
       *  Gain: '<S58>/Gain3'
       */
      rtb_Sqrt1[i] = HevP4OptimalController_P.Ndiff_P4 * u0 * rtb_Gain_p;
      rtb_Gain_m[i] = u0;
    }

    /* Gain: '<S42>/Gain1' incorporates:
     *  Switch: '<S57>/Switch2'
     */
    rtb_Switch2_o_tmp = 1.0 / HevP4OptimalController_P.Ndiff;
    for (i = 0; i < 202; i++) {
      /* Switch: '<S43>/Switch2' incorporates:
       *  Constant: '<S43>/Constant1'
       *  Constant: '<S43>/Constant2'
       *  Product: '<S43>/Product1'
       *  UnitDelay: '<S42>/Unit Delay2'
       */
      if (localDW->UnitDelay2_DSTATE[i] * rtb_Divide6 >=
          HevP4OptimalController_P.Switch2_Threshold_f) {
        rtb_Gain_p = HevP4OptimalController_P.Constant1_Value_i;
      } else {
        rtb_Gain_p = HevP4OptimalController_P.Constant2_Value_m;
      }

      /* End of Switch: '<S43>/Switch2' */

      /* Math: '<S43>/Math Function1' */
      if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_Gain_p > floor
           (rtb_Gain_p))) {
        rtb_Gain_p = -rt_powd_snf(-HevP4OptimalController_P.eta_diff, rtb_Gain_p);
      } else {
        rtb_Gain_p = rt_powd_snf(HevP4OptimalController_P.eta_diff, rtb_Gain_p);
      }

      /* End of Math: '<S43>/Math Function1' */

      /* Product: '<S42>/Divide5' incorporates:
       *  Gain: '<S42>/Gain1'
       *  Sum: '<S30>/Add1'
       */
      localB->Divide5[i] = (*rty_WhlTrqCmd - rtb_Sqrt1[i]) * rtb_Switch2_o_tmp *
        (1.0 / rtb_Gain_p);

      /* Switch: '<S44>/Switch2' incorporates:
       *  Constant: '<S44>/Constant1'
       *  Constant: '<S44>/Constant2'
       *  Product: '<S44>/Product1'
       *  UnitDelay: '<S42>/Unit Delay1'
       */
      if (localDW->UnitDelay1_DSTATE[i] * rtb_Divide2_n >=
          HevP4OptimalController_P.Switch2_Threshold_m) {
        rtb_Gain_p = HevP4OptimalController_P.Constant1_Value_o;
      } else {
        rtb_Gain_p = HevP4OptimalController_P.Constant2_Value_h;
      }

      /* End of Switch: '<S44>/Switch2' */

      /* Math: '<S44>/Math Function1' */
      u0 = rtb_Switch1[i];
      if ((u0 < 0.0) && (rtb_Gain_p > floor(rtb_Gain_p))) {
        u0 = -rt_powd_snf(-u0, rtb_Gain_p);
      } else {
        u0 = rt_powd_snf(u0, rtb_Gain_p);
      }

      /* End of Math: '<S44>/Math Function1' */

      /* Product: '<S42>/Divide4' incorporates:
       *  Product: '<S42>/Divide3'
       */
      localB->Divide4[i] = 1.0 / rtb_ChrgLmt * localB->Divide5[i] * (1.0 / u0);
    }

    /* Switch: '<S40>/Switch' incorporates:
     *  Constant: '<S40>/Constant'
     *  Gain: '<S30>/rads2rpm'
     *  Lookup_n-D: '<S40>/Min Torque vs Speed'
     */
    if (rtb_BrkTrqFric_n > HevP4OptimalController_P.N_idle) {
      rtb_ChrgLmt = look1_binlxpw(rtb_BrkTrqFric_n,
        HevP4OptimalController_P.f_tbrake_n_bpt,
        HevP4OptimalController_P.f_tbrake_min, 15U);
    } else {
      rtb_ChrgLmt = HevP4OptimalController_P.Constant_Value_e;
    }

    /* End of Switch: '<S40>/Switch' */
    for (i = 0; i < 202; i++) {
      /* Switch: '<S39>/Switch' incorporates:
       *  RelationalOperator: '<S39>/UpperRelop'
       */
      if (localB->Divide4[i] < rtb_ChrgLmt) {
        u0 = rtb_ChrgLmt;
      } else {
        u0 = localB->Divide4[i];
      }

      /* End of Switch: '<S39>/Switch' */

      /* Switch: '<S39>/Switch2' incorporates:
       *  RelationalOperator: '<S39>/LowerRelop1'
       */
      if (localB->Divide4[i] > rtb_Gain3) {
        rtb_Switch2_ck[i] = rtb_Gain3;
      } else {
        rtb_Switch2_ck[i] = u0;
      }

      /* End of Switch: '<S39>/Switch2' */
    }

    /* Lookup_n-D: '<S34>/2-D Lookup Table' incorporates:
     *  Gain: '<S30>/rads2rpm'
     */
    bpIndices_2[1U] = plook_binca(rtb_BrkTrqFric_n,
      HevP4OptimalController_P.f_tbrake_n_bpt, 15U, &rtb_Divide2_n);
    fractions_2[1U] = rtb_Divide2_n;
    for (i = 0; i < 202; i++) {
      bpIndices_2[0U] = plook_binca(rtb_Switch2_ck[i],
        HevP4OptimalController_P.f_tbrake_t_bpt, 15U, &rtb_Divide2_n);
      fractions_2[0U] = rtb_Divide2_n;
      rtb_Switch1[i] = intrp2d_la_pw(bpIndices_2, fractions_2,
        HevP4OptimalController_P.f_fuel, 16U,
        HevP4OptimalController_P.uDLookupTable_maxIndex);
    }

    /* End of Lookup_n-D: '<S34>/2-D Lookup Table' */

    /* Gain: '<S18>/LHV' */
    rtb_Switch2_o_tmp = HevP4OptimalController_P.Lhv / 1000.0;

    /* Gain: '<S53>/rpm2rads' */
    rtb_Divide2_n = HevP4OptimalController_P.rpm2rads_Gain_i * rtb_Switch2_k;
    for (i = 0; i < 202; i++) {
      u0 = rtb_Gain_m[i];

      /* Gain: '<S18>/LHV' incorporates:
       *  Product: '<S53>/Product1'
       */
      rtb_LHV[i] = rtb_Switch2_o_tmp * rtb_Switch1[i];

      /* Abs: '<S53>/Abs1' */
      rtb_MathFunction1_p[i] = fabs(u0);
      rtb_Switch1[i] = rtb_Divide2_n * u0;
    }

    /* Lookup_n-D: '<S53>/Eff Map' incorporates:
     *  Abs: '<S53>/Abs'
     *  Product: '<S53>/Product1'
     */
    bpIndices_3[0U] = plook_binca(fabs(rtb_Switch2_k),
      HevP4OptimalController_P.w_eff_bp, 13U, &rtb_Divide2_n);
    fractions_3[0U] = rtb_Divide2_n;
    for (i = 0; i < 202; i++) {
      bpIndices_3[1U] = plook_binca(rtb_MathFunction1_p[i],
        HevP4OptimalController_P.T_eff_bp, 10U, &rtb_Divide2_n);
      fractions_3[1U] = rtb_Divide2_n;
      rtb_MathFunction1_p[i] = intrp2d_la_pw(bpIndices_3, fractions_3,
        HevP4OptimalController_P.efficiency_table, 14U,
        HevP4OptimalController_P.EffMap_maxIndex);
    }

    /* End of Lookup_n-D: '<S53>/Eff Map' */

    /* Saturate: '<S32>/Saturation' */
    rtb_Switch2_k = *rtu_BattVolt;
    if (rtb_Switch2_k > HevP4OptimalController_P.Saturation_UpperSat_i) {
      rtb_Switch2_k = HevP4OptimalController_P.Saturation_UpperSat_i;
    } else if (rtb_Switch2_k < HevP4OptimalController_P.Saturation_LowerSat_c) {
      rtb_Switch2_k = HevP4OptimalController_P.Saturation_LowerSat_c;
    }

    /* End of Saturate: '<S32>/Saturation' */
    for (i = 0; i < 202; i++) {
      u0 = rtb_Switch1[i];
      rtb_Divide2_n = rtb_MathFunction1_p[i];

      /* Math: '<S53>/Math Function1' incorporates:
       *  Constant: '<S53>/Constant1'
       *  Constant: '<S53>/Constant2'
       *  Product: '<S53>/Product4'
       *  Switch: '<S53>/Switch2'
       */
      if (u0 >= HevP4OptimalController_P.Switch2_Threshold_kx) {
        rtb_Switch2_o_tmp = HevP4OptimalController_P.Constant1_Value_l;
      } else {
        rtb_Switch2_o_tmp = HevP4OptimalController_P.Constant2_Value_n;
      }

      if ((rtb_Divide2_n < 0.0) && (rtb_Switch2_o_tmp > floor(rtb_Switch2_o_tmp)))
      {
        rtb_Divide2_n = -rt_powd_snf(-rtb_Divide2_n, rtb_Switch2_o_tmp);
      } else {
        rtb_Divide2_n = rt_powd_snf(rtb_Divide2_n, rtb_Switch2_o_tmp);
      }

      /* Product: '<S53>/Product4' */
      u0 *= rtb_Divide2_n;
      rtb_MathFunction1_p[i] = ((1.0 - HevP4OptimalController_P.eta_dcdc) + 1.0)
        * u0 / rtb_Switch2_k;
      rtb_Switch1[i] = u0;
    }

    /* Gain: '<S29>/Gain1' incorporates:
     *  Constant: '<S29>/Imax3'
     *  Gain: '<S32>/DCDC Constant Eff'
     *  Math: '<S53>/Math Function1'
     *  Product: '<S32>/Divide'
     *  Product: '<S53>/Product4'
     */
    rtb_Switch2_k = HevP4OptimalController_P.Gain1_Gain *
      HevP4OptimalController_P.BattCurrMax;

    /* Product: '<S18>/Product3' incorporates:
     *  RelationalOperator: '<S33>/LowerRelop1'
     */
    for (i = 0; i < 202; i++) {
      rtb_Divide2_n = rtb_MathFunction1_p[i];

      /* Switch: '<S33>/Switch2' incorporates:
       *  Constant: '<S29>/Imax3'
       *  RelationalOperator: '<S33>/LowerRelop1'
       *  RelationalOperator: '<S33>/UpperRelop'
       *  Switch: '<S33>/Switch'
       */
      if (rtb_Divide2_n > HevP4OptimalController_P.BattCurrMax) {
        rtb_Divide2_n = HevP4OptimalController_P.BattCurrMax;
      } else if (rtb_Divide2_n < rtb_Switch2_k) {
        /* Switch: '<S33>/Switch' */
        rtb_Divide2_n = rtb_Switch2_k;
      }

      /* End of Switch: '<S33>/Switch2' */
      rtb_Product3_k[i] = *rtu_BattVolt * rtb_Divide2_n;
    }

    /* End of Product: '<S18>/Product3' */

    /* Lookup_n-D: '<S26>/2-D Lookup Table' incorporates:
     *  Gain: '<S3>/Gain1'
     */
    rtb_Switch2_k = look2_binlcapw(*rtu_VehSpdFdbk, rtb_BrkTrqFric,
      HevP4OptimalController_P.uDLookupTable_bp01Data,
      HevP4OptimalController_P.uDLookupTable_bp02Data,
      HevP4OptimalController_P.uDLookupTable_tableData,
      HevP4OptimalController_P.uDLookupTable_maxIndex_o, 2U);

    /* Product: '<S26>/Divide' incorporates:
     *  Constant: '<S26>/ '
     *  Constant: '<S26>/ 1'
     *  Sum: '<S26>/Subtract'
     */
    rtb_Divide2_n = (rtb_BrkTrqFric - HevP4OptimalController_P.SOCTrgt / 100.0) /
      ((HevP4OptimalController_P.SOCmax - HevP4OptimalController_P.SOCmin) /
       200.0);

    /* Math: '<S26>/Math Function' incorporates:
     *  Constant: '<S26>/Constant1'
     */
    if ((rtb_Divide2_n < 0.0) && (HevP4OptimalController_P.a > floor
         (HevP4OptimalController_P.a))) {
      rtb_Divide2_n = -rt_powd_snf(-rtb_Divide2_n, HevP4OptimalController_P.a);
    } else {
      rtb_Divide2_n = rt_powd_snf(rtb_Divide2_n, HevP4OptimalController_P.a);
    }

    /* End of Math: '<S26>/Math Function' */

    /* Sum: '<S26>/Subtract1' incorporates:
     *  Constant: '<S26>/Constant2'
     */
    rtb_Divide2_n = HevP4OptimalController_P.Constant2_Value_p - rtb_Divide2_n;

    /* Switch: '<S28>/Switch2' incorporates:
     *  RelationalOperator: '<S28>/LowerRelop1'
     */
    if (!(rtb_Divide2_n > rtb_Switch2_k)) {
      /* Switch: '<S28>/Switch' incorporates:
       *  Constant: '<S26>/Constant'
       *  RelationalOperator: '<S28>/UpperRelop'
       */
      if (rtb_Divide2_n < HevP4OptimalController_P.Constant_Value_i) {
        rtb_Switch2_k = HevP4OptimalController_P.Constant_Value_i;
      } else {
        rtb_Switch2_k = rtb_Divide2_n;
      }

      /* End of Switch: '<S28>/Switch' */
    }

    /* End of Switch: '<S28>/Switch2' */

    /* RelationalOperator: '<S56>/Compare' incorporates:
     *  Constant: '<S56>/Constant'
     */
    rtb_Compare = (rtb_BrkTrqFric_n < HevP4OptimalController_P.EngIdle_const);

    /* Product: '<S29>/Product5' incorporates:
     *  Constant: '<S29>/MaxDischrg'
     *  Gain: '<S3>/Gain1'
     *  Lookup_n-D: '<S29>/DischrgLmt'
     */
    rtb_Divide2_n = look1_binlcapw(rtb_BrkTrqFric,
      HevP4OptimalController_P.SOC_bpt, HevP4OptimalController_P.DischrgLmt_bpt,
      10U) * HevP4OptimalController_P.BattDischrgPwrMax;

    /* Product: '<S29>/Product6' incorporates:
     *  Constant: '<S29>/MaxChrg'
     *  Gain: '<S3>/Gain1'
     *  Lookup_n-D: '<S29>/ChrgLmt'
     */
    rtb_BrkTrqFric = look1_binlcapw(rtb_BrkTrqFric,
      HevP4OptimalController_P.SOC_bpt, HevP4OptimalController_P.ChrgLmt_bpt,
      10U) * HevP4OptimalController_P.BattChrgPwrMax;
    for (i = 0; i < 202; i++) {
      u0 = rtb_Switch1[i];

      /* Switch: '<S38>/Switch' incorporates:
       *  DataTypeConversion: '<S38>/Data Type Conversion'
       *  Gain: '<S38>/Gain'
       *  RelationalOperator: '<S29>/Relational Operator1'
       *  RelationalOperator: '<S38>/Relational Operator'
       */
      if (rtb_Gain3 != 0.0) {
        rtb_Gain3_0 = (localB->Divide4[i] > rtb_Gain3);
      } else {
        rtb_Gain3_0 = (HevP4OptimalController_P.Gain_Gain_o * localB->Divide4[i]
                       != 0.0);
      }

      /* End of Switch: '<S38>/Switch' */

      /* Switch: '<S37>/Switch' incorporates:
       *  DataTypeConversion: '<S37>/Data Type Conversion'
       *  Gain: '<S37>/Gain'
       *  RelationalOperator: '<S37>/Relational Operator'
       */
      if (rtb_ChrgLmt != 0.0) {
        rtb_ChrgLmt_0 = (localB->Divide4[i] < rtb_ChrgLmt);
      } else {
        rtb_ChrgLmt_0 = (HevP4OptimalController_P.Gain_Gain_o4 * localB->
                         Divide4[i] != 0.0);
      }

      /* End of Switch: '<S37>/Switch' */

      /* Gain: '<S18>/Constraint Penalty Factor' incorporates:
       *  Abs: '<S29>/Abs'
       *  Constant: '<S29>/Imax3'
       *  Constant: '<S55>/Constant'
       *  Logic: '<S19>/Infeasible conditions'
       *  Logic: '<S29>/Logical Operator'
       *  Logic: '<S29>/Logical Operator1'
       *  Logic: '<S34>/Infeasible conditions'
       *  Logic: '<S51>/Logical Operator'
       *  Logic: '<S51>/Logical Operator1'
       *  RelationalOperator: '<S29>/Relational Operator'
       *  RelationalOperator: '<S29>/Relational Operator1'
       *  RelationalOperator: '<S29>/Relational Operator2'
       *  RelationalOperator: '<S51>/Relational Operator'
       *  RelationalOperator: '<S51>/Relational Operator1'
       *  RelationalOperator: '<S55>/Compare'
       */
      rtb_ConstraintPenaltyFactor[i] = rtb_Gain3_0 || rtb_ChrgLmt_0 ||
        ((rtb_BrkTrqReqTotal < localB->Divide1[i]) || (localB->Divide1[i] <
          rtb_Gain3_po) || ((localB->Divide1[i] <
           HevP4OptimalController_P.Constant_Value_d) && rtb_Compare)) || ((fabs
        (rtb_MathFunction1_p[i]) > HevP4OptimalController_P.BattCurrMax) || ((u0
        > rtb_Divide2_n) || (u0 < rtb_BrkTrqFric))) ?
        HevP4OptimalController_P.PenaltyFctr : 0U;
      rtb_Switch1[i] = fabs(rtb_Switch2_ck[i]);
      rtb_Product3_k[i] = HevP4OptimalController_P.W2kW_Gain * rtb_Product3_k[i]
        * HevP4OptimalController_P.ECMS_s * rtb_Switch2_k;
    }

    /* Lookup_n-D: '<S50>/Eta 4D' incorporates:
     *  Abs: '<S48>/Abs1'
     *  Constant: '<Root>/Constant'
     *  Constant: '<S27>/Constant1'
     *  Gain: '<S18>/W2kW '
     *  Gain: '<S30>/rads2rpm'
     *  Product: '<S18>/Product'
     *  RelationalOperator: '<S29>/Relational Operator1'
     *  Rounding: '<Root>/Round'
     */
    bpIndices_4[1U] = plook_binc(rtb_BrkTrqFric_n,
      HevP4OptimalController_P.omega_bpts, 10U, &rtb_Divide2_n);
    fractions_4[1U] = rtb_Divide2_n;
    bpIndices_4[2U] = plook_binc(rtb_Round, HevP4OptimalController_P.G, 6U,
      &rtb_Divide2_n);
    fractions_4[2U] = rtb_Divide2_n;
    bpIndices_4[3U] = plook_binc(HevP4OptimalController_P.Temp_bpts[0],
      HevP4OptimalController_P.Temp_bpts, 1U, &rtb_Divide2_n);
    fractions_4[3U] = rtb_Divide2_n;
    for (i = 0; i < 202; i++) {
      bpIndices_4[0U] = plook_binc(rtb_Switch1[i],
        HevP4OptimalController_P.Trq_bpts, 6U, &rtb_Divide2_n);
      fractions_4[0U] = rtb_Divide2_n;
      rtb_Switch1[i] = intrp4d_l_pw(bpIndices_4, fractions_4,
        HevP4OptimalController_P.eta_tbl,
        HevP4OptimalController_P.Eta4D_dimSizes_k);
    }

    /* End of Lookup_n-D: '<S50>/Eta 4D' */

    /* Gain: '<S48>/rpm2rads' */
    rtb_BrkTrqFric = HevP4OptimalController_P.rpm2rads_Gain_c * rtb_BrkTrqFric_n;

    /* LookupNDDirect: '<S36>/Gear ratio look up' incorporates:
     *  Rounding: '<Root>/Round'
     *
     * About '<S36>/Gear ratio look up':
     *  1-dimensional Direct Look-Up returning a Scalar,
     *
     *     Remove protection against out-of-range input in generated code: 'off'
     */
    if (rtIsNaN(rtb_Round)) {
      u0 = 0.0;
    } else {
      u0 = rtb_Round;
    }

    if (u0 > 6.0) {
      u0 = 6.0;
    } else if (u0 < 0.0) {
      u0 = 0.0;
    }

    rtb_Divide2_n = HevP4OptimalController_P.N[(int32_T)u0];

    /* End of LookupNDDirect: '<S36>/Gear ratio look up' */

    /* Switch: '<S36>/Switch1' */
    rtb_Compare = (rtb_Round > HevP4OptimalController_P.Switch1_Threshold_f);

    /* Product: '<S36>/Divide3' */
    rtb_Round = rtb_BrkTrqFric_n / rtb_Divide2_n;

    /* Saturate: '<S19>/Saturation1' incorporates:
     *  Gain: '<S35>/Veh2WhlSpd'
     */
    if (rtb_Diffratio > HevP4OptimalController_P.Saturation1_UpperSat) {
      rtb_Diffratio = HevP4OptimalController_P.Saturation1_UpperSat;
    } else if (rtb_Diffratio < HevP4OptimalController_P.Saturation1_LowerSat) {
      rtb_Diffratio = HevP4OptimalController_P.Saturation1_LowerSat;
    }

    /* End of Saturate: '<S19>/Saturation1' */
    for (i = 0; i < 202; i++) {
      u0 = rtb_Switch1[i];
      rtb_BrkTrqFric_n = rtb_Switch2_ck[i];

      /* Switch: '<S36>/Switch1' incorporates:
       *  Constant: '<S36>/neutral'
       *  Math: '<S48>/Math Function1'
       *  Product: '<S36>/Product'
       *  Product: '<S36>/Product3'
       *  Product: '<S48>/Product1'
       */
      if (rtb_Compare) {
        /* Switch: '<S48>/Switch2' incorporates:
         *  Constant: '<S48>/Constant1'
         *  Constant: '<S48>/Constant2'
         */
        if (rtb_BrkTrqFric_n * rtb_BrkTrqFric >=
            HevP4OptimalController_P.Switch2_Threshold_br) {
          rtb_Gain3 = HevP4OptimalController_P.Constant1_Value_jp;
        } else {
          rtb_Gain3 = HevP4OptimalController_P.Constant2_Value_n4;
        }

        /* End of Switch: '<S48>/Switch2' */
        if ((u0 < 0.0) && (rtb_Gain3 > floor(rtb_Gain3))) {
          u0 = -rt_powd_snf(-u0, rtb_Gain3);
        } else {
          u0 = rt_powd_snf(u0, rtb_Gain3);
        }

        u0 *= rtb_Divide2_n * rtb_BrkTrqFric_n;
      } else {
        u0 = HevP4OptimalController_P.neutral_Value_o;
      }

      /* Math: '<S47>/Math Function1' incorporates:
       *  Constant: '<S47>/Constant1'
       *  Constant: '<S47>/Constant2'
       *  Product: '<S47>/Product1'
       *  Switch: '<S47>/Switch2'
       */
      if (u0 * rtb_Round >= HevP4OptimalController_P.Switch2_Threshold_bg) {
        rtb_Switch2_o_tmp = HevP4OptimalController_P.Constant1_Value_j;
      } else {
        rtb_Switch2_o_tmp = HevP4OptimalController_P.Constant2_Value_d;
      }

      if ((HevP4OptimalController_P.eta_diff < 0.0) && (rtb_Switch2_o_tmp >
           floor(rtb_Switch2_o_tmp))) {
        rtb_Switch2_o_tmp = -rt_powd_snf(-HevP4OptimalController_P.eta_diff,
          rtb_Switch2_o_tmp);
      } else {
        rtb_Switch2_o_tmp = rt_powd_snf(HevP4OptimalController_P.eta_diff,
          rtb_Switch2_o_tmp);
      }

      /* End of Math: '<S47>/Math Function1' */
      rtb_Switch1[i] = fabs((*rty_WhlTrqCmd - (HevP4OptimalController_P.Ndiff *
        u0 * rtb_Switch2_o_tmp + rtb_Sqrt1[i])) * rtb_Diffratio) *
        HevP4OptimalController_P.W2kW1_Gain *
        HevP4OptimalController_P.TracPwrErrPenalty_Gain;
    }

    /* Product: '<S24>/Product1' incorporates:
     *  Abs: '<S19>/Abs'
     *  Gain: '<S18>/TracPwrErr Penalty'
     *  Gain: '<S18>/W2kW 1'
     *  Gain: '<S36>/Diff ratio'
     *  Math: '<S48>/Math Function1'
     *  Product: '<S19>/Product'
     *  Product: '<S36>/Divide2'
     *  Product: '<S47>/Product1'
     *  Product: '<S48>/Product1'
     *  Sum: '<S19>/Add'
     *  Sum: '<S19>/Add1'
     *  Switch: '<S36>/Switch1'
     *  UnitDelay: '<S18>/Unit Delay2'
     */
    rtb_Round = rtb_AccelDecelSwitch1 * localDW->UnitDelay2_DSTATE_d;
    for (i = 0; i < 202; i++) {
      /* Sum: '<S24>/Subtract' incorporates:
       *  Product: '<S24>/Product6'
       */
      rtb_BrkTrqFric = rtb_Switch2_ck[i] * rtb_AccelDecelSwitch1 - rtb_Round;

      /* Product: '<S24>/Product7' */
      rtb_BrkTrqFric *= rtb_BrkTrqFric;

      /* Sqrt: '<S24>/Sqrt1' */
      rtb_MathFunction1_p[i] = rtb_BrkTrqFric;
      rtb_Sqrt1[i] = rtb_BrkTrqFric;
    }

    /* Sqrt: '<S24>/Sqrt1' incorporates:
     *  Sum: '<S24>/Subtract'
     */
    if (rtmIsMajorTimeStep(HevP4OptimalController_M)) {
      if (localDW->Sqrt1_DWORK1 != 0) {
        ssSetBlockStateForSolverChangedAtMajorStep(HevP4OptimalController_M->rtS);
        localDW->Sqrt1_DWORK1 = 0;
      }

      for (i = 0; i < 202; i++) {
        rtb_Sqrt1[i] = sqrt(rtb_Sqrt1[i]);
      }
    } else {
      for (i = 0; i < 202; i++) {
        rtb_BrkTrqFric = rtb_Sqrt1[i];
        if (rtb_BrkTrqFric < 0.0) {
          rtb_BrkTrqFric = -sqrt(fabs(rtb_BrkTrqFric));
        } else {
          rtb_BrkTrqFric = sqrt(rtb_BrkTrqFric);
        }

        if (rtb_MathFunction1_p[i] < 0.0) {
          localDW->Sqrt1_DWORK1 = 1;
        }

        rtb_Sqrt1[i] = rtb_BrkTrqFric;
      }
    }

    /* Sum: '<S18>/Add' incorporates:
     *  Gain: '<S18>/Constraint Penalty Factor'
     *  Gain: '<S24>/W2kW'
     */
    for (i = 0; i < 202; i++) {
      rtb_LHV[i] = (((rtb_LHV[i] + rtb_Product3_k[i]) + (real_T)
                     rtb_ConstraintPenaltyFactor[i] * 0.00390625) +
                    rtb_Switch1[i]) + HevP4OptimalController_P.W2kW_Gain_g *
        rtb_Sqrt1[i];
    }

    /* End of Sum: '<S18>/Add' */

    /* MATLAB Function: '<S18>/MATLAB Function' */
    if (!rtIsNaN(rtb_LHV[0])) {
      i = 1;
    } else {
      i = 0;
      b_k = 2;
      exitg1 = false;
      while ((!exitg1) && (b_k < 203)) {
        if (!rtIsNaN(rtb_LHV[b_k - 1])) {
          i = b_k;
          exitg1 = true;
        } else {
          b_k++;
        }
      }
    }

    if (i == 0) {
      i = 1;
    } else {
      rtb_Round = rtb_LHV[i - 1];
      for (b_k = i; b_k + 1 < 203; b_k++) {
        if (rtb_Round > rtb_LHV[b_k]) {
          rtb_Round = rtb_LHV[b_k];
          i = b_k + 1;
        }
      }
    }

    /* MultiPortSwitch: '<S18>/Index Vector1' incorporates:
     *  MATLAB Function: '<S18>/MATLAB Function'
     *  MultiPortSwitch: '<S18>/Index Vector'
     */
    if (rtmIsMajorTimeStep(HevP4OptimalController_M)) {
      /* MultiPortSwitch: '<S18>/Index Vector1' incorporates:
       *  MATLAB Function: '<S18>/MATLAB Function'
       */
      rtb_Round = rtb_Gain_m[i - 1];
      rtb_Gain3_po = rtb_Switch2_ck[i - 1];
    } else {
      if (i > 202) {
        b_k = 202;
      } else if (i < 1) {
        b_k = 1;
      } else {
        b_k = i;
      }

      /* MultiPortSwitch: '<S18>/Index Vector1' incorporates:
       *  MATLAB Function: '<S18>/MATLAB Function'
       */
      rtb_Round = rtb_Gain_m[b_k - 1];
      if (i > 202) {
        i = 202;
      } else if (i < 1) {
        i = 1;
      }

      rtb_Gain3_po = rtb_Switch2_ck[i - 1];
    }

    /* End of MultiPortSwitch: '<S18>/Index Vector1' */

    /* DiscreteTransferFcn: '<S18>/Discrete Transfer Fcn' */
    localDW->DiscreteTransferFcn_tmp = (rtb_Round -
      HevP4OptimalController_P.DiscreteTransferFcn_DenCoef[1] *
      localDW->DiscreteTransferFcn_states) /
      HevP4OptimalController_P.DiscreteTransferFcn_DenCoef[0];

    /* Saturate: '<S18>/Saturation' */
    if (rtb_Gain3_po > HevP4OptimalController_P.Saturation_UpperSat_a) {
      /* Saturate: '<S18>/Saturation' */
      localB->Saturation = HevP4OptimalController_P.Saturation_UpperSat_a;
    } else if (rtb_Gain3_po < HevP4OptimalController_P.Saturation_LowerSat_a) {
      /* Saturate: '<S18>/Saturation' */
      localB->Saturation = HevP4OptimalController_P.Saturation_LowerSat_a;
    } else {
      /* Saturate: '<S18>/Saturation' */
      localB->Saturation = rtb_Gain3_po;
    }

    /* End of Saturate: '<S18>/Saturation' */

    /* SignalConversion: '<S18>/Signal Conversion' */
    *rty_EngTrqCmd = localB->Saturation;

    /* SignalConversion: '<S18>/Signal Conversion1' incorporates:
     *  DiscreteTransferFcn: '<S18>/Discrete Transfer Fcn'
     */
    *rty_MtrTrqCmd = HevP4OptimalController_P.DiscreteTransferFcn_NumCoef[0] *
      localDW->DiscreteTransferFcn_tmp +
      HevP4OptimalController_P.DiscreteTransferFcn_NumCoef[1] *
      localDW->DiscreteTransferFcn_states;

    /* End of Outputs for SubSystem: '<S3>/Energy Management' */
  }

  /* End of If: '<S3>/If' */

  /* Sum: '<S4>/Subtract' */
  u0 = rtb_WhlSpd - rtb_MotTrqRegenWhl;

  /* Saturate: '<S4>/Negative 5' */
  if (u0 > HevP4OptimalController_P.Negative5_UpperSat) {
    u0 = HevP4OptimalController_P.Negative5_UpperSat;
  } else if (u0 < HevP4OptimalController_P.Negative5_LowerSat) {
    u0 = HevP4OptimalController_P.Negative5_LowerSat;
  }

  /* End of Saturate: '<S4>/Negative 5' */

  /* Product: '<S4>/Product4' incorporates:
   *  Constant: '<S4>/Constant1'
   */
  *rty_BrkCmd = u0 / (HevP4OptimalController_P.mu_kinetic * 3.1415926535897931 *
                      0.0025000000000000005 * HevP4OptimalController_P.Rm *
                      HevP4OptimalController_P.num_pads / 4.0 * 4.0);

  /* SignalConversion generated from: '<Root>/Cltch1Cmd' */
  *rty_Cltch1Cmd = 0.0;

  /* SignalConversion generated from: '<Root>/StartCmd' */
  *rty_StartCmd = 0.0;

  /* SignalConversion generated from: '<Root>/Neutral' */
  *rty_Neutral = 0.0;
}

/* Update for referenced model: 'HevP4OptimalController' */
void HevP4OptimalController_Update(B_HevP4OptimalController_c_T *localB,
  DW_HevP4OptimalController_f_T *localDW)
{
  /* Update for If: '<S3>/If' */
  switch (localDW->If_ActiveSubsystem) {
   case 0:
    /* Update for IfAction SubSystem: '<S3>/Energy Management Off' incorporates:
     *  ActionPort: '<S16>/Action Port'
     */
    /* Update for UnitDelay: '<S64>/Unit Delay' */
    localDW->UnitDelay_DSTATE_c = localB->Divide1_d;

    /* End of Update for SubSystem: '<S3>/Energy Management Off' */
    break;

   case 1:
    /* Update for IfAction SubSystem: '<S3>/Energy Management' incorporates:
     *  ActionPort: '<S15>/Action Port'
     */
    /* Update for UnitDelay: '<S42>/Unit Delay1' */
    memcpy(&localDW->UnitDelay1_DSTATE[0], &localB->Divide4[0], 202U * sizeof
           (real_T));

    /* Update for UnitDelay: '<S42>/Unit Delay2' */
    memcpy(&localDW->UnitDelay2_DSTATE[0], &localB->Divide5[0], 202U * sizeof
           (real_T));

    /* Update for UnitDelay: '<S60>/Unit Delay' */
    memcpy(&localDW->UnitDelay_DSTATE[0], &localB->Divide1[0], 202U * sizeof
           (real_T));

    /* Update for UnitDelay: '<S18>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_d = localB->Saturation;

    /* Update for DiscreteTransferFcn: '<S18>/Discrete Transfer Fcn' */
    localDW->DiscreteTransferFcn_states = localDW->DiscreteTransferFcn_tmp;

    /* End of Update for SubSystem: '<S3>/Energy Management' */
    break;
  }

  /* End of Update for If: '<S3>/If' */
}

/* Model initialize function */
void HevP4OptimalController_initialize(SimStruct *const rtS, int_T mdlref_TID0,
  RT_MODEL_HevP4OptimalController_T *const HevP4OptimalController_M,
  B_HevP4OptimalController_c_T *localB, DW_HevP4OptimalController_f_T *localDW,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  HevP4OptimalController_P.Saturation_UpperSat = rtInf;
  HevP4OptimalController_P.Saturation_UpperSat_i = rtInf;
  HevP4OptimalController_P.Saturation1_UpperSat = rtInf;
  HevP4OptimalController_P.Saturation_UpperSat_a = rtInf;
  HevP4OptimalController_P.Saturation_UpperSat_e = rtInf;
  HevP4OptimalController_P.Saturation_UpperSat_f = rtInf;
  HevP4OptimalController_P.Saturation1_UpperSat_k = rtInf;
  HevP4OptimalController_P.Saturation_UpperSat_b = rtInf;
  HevP4OptimalController_P.Negative5_UpperSat = rtInf;

  /* initialize real-time model */
  (void) memset((void *)HevP4OptimalController_M, 0,
                sizeof(RT_MODEL_HevP4OptimalController_T));

  /* setup the global timing engine */
  HevP4OptimalController_M->Timing.mdlref_GlobalTID[0] = mdlref_TID0;
  HevP4OptimalController_M->rtS = (rtS);

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_HevP4OptimalController_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_HevP4OptimalController_f_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  {
    HevP4OptimalController_InitializeDataMapInfo(HevP4OptimalController_M,
      localB);
  }

  /* Initialize Parent model MMI */
  if ((rt_ParentMMI != (NULL)) && (rt_ChildPath != (NULL))) {
    rtwCAPI_SetChildMMI(*rt_ParentMMI, rt_ChildMMIIdx,
                        &(HevP4OptimalController_M->DataMapInfo.mmi));
    rtwCAPI_SetPath(HevP4OptimalController_M->DataMapInfo.mmi, rt_ChildPath);
    rtwCAPI_MMISetContStateStartIndex(HevP4OptimalController_M->DataMapInfo.mmi,
      rt_CSTATEIdx);
  }
}
