/*
 * plook_binc.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:18 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef RTW_HEADER_plook_binc_h_
#define RTW_HEADER_plook_binc_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern uint32_T plook_binc(real_T u, const real_T bp[], uint32_T maxIndex,
  real_T *fraction);

#endif                                 /* RTW_HEADER_plook_binc_h_ */
