/*
 * mpower_MkJA5ZKD.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4ReferenceApplication".
 *
 * Model version              : 2.47
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:55:03 2022
 * Created for block: HevP4ReferenceApplication
 */

#include "rtwtypes.h"
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include <math.h>
#include "mpower_MkJA5ZKD.h"

/* Function for MATLAB Function: '<S28>/Setup' */
void mpower_MkJA5ZKD(const real_T a[4], real_T b, real_T c[4])
{
  real_T aBuffer[4];
  real_T b_a[4];
  real_T cBuffer[4];
  real_T cBuffer_0[4];
  real_T cBuffer_1[4];
  real_T cBuffer_tmp;
  real_T cBuffer_tmp_0;
  real_T cBuffer_tmp_1;
  real_T y_tmp;
  int32_T b_n;
  int32_T n;
  int32_T nb;
  int32_T nbitson;
  boolean_T aBufferInUse;
  boolean_T cBufferInUse;
  boolean_T first;
  if (b == b) {
    b_a[0] = a[0];
    b_a[1] = a[1];
    b_a[2] = a[2];
    b_a[3] = a[3];
    y_tmp = fabs(b);
    n = (int32_T)y_tmp;
    b_n = (int32_T)y_tmp;
    nbitson = 0;
    nb = -2;
    while (b_n > 0) {
      nb++;
      if ((b_n & 1U) != 0U) {
        nbitson++;
      }

      b_n >>= 1;
    }

    if ((int32_T)y_tmp <= 2) {
      if (b == 2.0) {
        for (nbitson = 0; nbitson < 2; nbitson++) {
          n = nbitson << 1;
          c[n] = 0.0;
          y_tmp = a[n];
          c[n] += y_tmp * a[0];
          cBuffer_tmp = a[n + 1];
          c[n] += cBuffer_tmp * a[2];
          c[n + 1] = 0.0;
          c[n + 1] += y_tmp * a[1];
          c[n + 1] += cBuffer_tmp * a[3];
        }
      } else if (b == 1.0) {
        c[0] = a[0];
        c[1] = a[1];
        c[2] = a[2];
        c[3] = a[3];
      } else {
        c[1] = 0.0;
        c[2] = 0.0;
        c[0] = 1.0;
        c[3] = 1.0;
      }
    } else {
      first = true;
      aBufferInUse = false;
      cBufferInUse = ((nbitson & 1U) == 0U);
      for (b_n = 0; b_n <= nb; b_n++) {
        if ((n & 1U) != 0U) {
          if (first) {
            first = false;
            if (cBufferInUse) {
              if (aBufferInUse) {
                cBuffer[0] = aBuffer[0];
                cBuffer[1] = aBuffer[1];
                cBuffer[2] = aBuffer[2];
                cBuffer[3] = aBuffer[3];
              } else {
                cBuffer[0] = b_a[0];
                cBuffer[1] = b_a[1];
                cBuffer[2] = b_a[2];
                cBuffer[3] = b_a[3];
              }
            } else if (aBufferInUse) {
              c[0] = aBuffer[0];
              c[1] = aBuffer[1];
              c[2] = aBuffer[2];
              c[3] = aBuffer[3];
            } else {
              c[0] = b_a[0];
              c[1] = b_a[1];
              c[2] = b_a[2];
              c[3] = b_a[3];
            }
          } else {
            if (aBufferInUse) {
              if (cBufferInUse) {
                for (nbitson = 0; nbitson < 2; nbitson++) {
                  c[nbitson] = 0.0;
                  c[nbitson] += cBuffer[nbitson] * aBuffer[0];
                  y_tmp = cBuffer[nbitson + 2];
                  c[nbitson] += y_tmp * aBuffer[1];
                  c[nbitson + 2] = 0.0;
                  c[nbitson + 2] += cBuffer[nbitson] * aBuffer[2];
                  c[nbitson + 2] += y_tmp * aBuffer[3];
                }
              } else {
                for (nbitson = 0; nbitson < 2; nbitson++) {
                  cBuffer[nbitson] = 0.0;
                  cBuffer[nbitson] += c[nbitson] * aBuffer[0];
                  y_tmp = c[nbitson + 2];
                  cBuffer[nbitson] += y_tmp * aBuffer[1];
                  cBuffer[nbitson + 2] = 0.0;
                  cBuffer[nbitson + 2] += c[nbitson] * aBuffer[2];
                  cBuffer[nbitson + 2] += y_tmp * aBuffer[3];
                }
              }
            } else if (cBufferInUse) {
              for (nbitson = 0; nbitson < 2; nbitson++) {
                c[nbitson] = 0.0;
                c[nbitson] += cBuffer[nbitson] * b_a[0];
                y_tmp = cBuffer[nbitson + 2];
                c[nbitson] += y_tmp * b_a[1];
                c[nbitson + 2] = 0.0;
                c[nbitson + 2] += cBuffer[nbitson] * b_a[2];
                c[nbitson + 2] += y_tmp * b_a[3];
              }
            } else {
              for (nbitson = 0; nbitson < 2; nbitson++) {
                cBuffer[nbitson] = 0.0;
                cBuffer[nbitson] += c[nbitson] * b_a[0];
                y_tmp = c[nbitson + 2];
                cBuffer[nbitson] += y_tmp * b_a[1];
                cBuffer[nbitson + 2] = 0.0;
                cBuffer[nbitson + 2] += c[nbitson] * b_a[2];
                cBuffer[nbitson + 2] += y_tmp * b_a[3];
              }
            }

            cBufferInUse = !cBufferInUse;
          }
        }

        n >>= 1;
        if (aBufferInUse) {
          for (nbitson = 0; nbitson < 2; nbitson++) {
            b_a[nbitson] = 0.0;
            b_a[nbitson] += aBuffer[nbitson] * aBuffer[0];
            y_tmp = aBuffer[nbitson + 2];
            b_a[nbitson] += y_tmp * aBuffer[1];
            b_a[nbitson + 2] = 0.0;
            b_a[nbitson + 2] += aBuffer[nbitson] * aBuffer[2];
            b_a[nbitson + 2] += y_tmp * aBuffer[3];
          }
        } else {
          for (nbitson = 0; nbitson < 2; nbitson++) {
            aBuffer[nbitson] = 0.0;
            aBuffer[nbitson] += b_a[nbitson] * b_a[0];
            y_tmp = b_a[nbitson + 2];
            aBuffer[nbitson] += y_tmp * b_a[1];
            aBuffer[nbitson + 2] = 0.0;
            aBuffer[nbitson + 2] += b_a[nbitson] * b_a[2];
            aBuffer[nbitson + 2] += y_tmp * b_a[3];
          }
        }

        aBufferInUse = !aBufferInUse;
      }

      for (nbitson = 0; nbitson < 2; nbitson++) {
        n = nbitson << 1;
        cBuffer_0[n] = 0.0;
        cBuffer_1[n] = 0.0;
        y_tmp = aBuffer[n];
        cBuffer_0[n] += y_tmp * cBuffer[0];
        cBuffer_tmp = b_a[n];
        cBuffer_1[n] += cBuffer_tmp * cBuffer[0];
        cBuffer_tmp_0 = aBuffer[n + 1];
        cBuffer_0[n] += cBuffer_tmp_0 * cBuffer[2];
        cBuffer_tmp_1 = b_a[n + 1];
        cBuffer_1[n] += cBuffer_tmp_1 * cBuffer[2];
        cBuffer_0[n + 1] = 0.0;
        cBuffer_1[n + 1] = 0.0;
        cBuffer_0[n + 1] += y_tmp * cBuffer[1];
        cBuffer_1[n + 1] += cBuffer_tmp * cBuffer[1];
        cBuffer_0[n + 1] += cBuffer_tmp_0 * cBuffer[3];
        cBuffer_1[n + 1] += cBuffer_tmp_1 * cBuffer[3];
      }

      if (first) {
        if (aBufferInUse) {
          c[0] = aBuffer[0];
          c[1] = aBuffer[1];
          c[2] = aBuffer[2];
          c[3] = aBuffer[3];
        } else {
          c[0] = b_a[0];
          c[1] = b_a[1];
          c[2] = b_a[2];
          c[3] = b_a[3];
        }
      } else if (aBufferInUse) {
        c[0] = cBuffer_0[0];
        c[1] = cBuffer_0[1];
        c[2] = cBuffer_0[2];
        c[3] = cBuffer_0[3];
      } else {
        c[0] = cBuffer_1[0];
        c[1] = cBuffer_1[1];
        c[2] = cBuffer_1[2];
        c[3] = cBuffer_1[3];
      }
    }
  } else {
    c[0] = (rtNaN);
    c[1] = (rtNaN);
    c[2] = (rtNaN);
    c[3] = (rtNaN);
  }
}
