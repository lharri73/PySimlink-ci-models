/*
 * expm_9DBYDrz1.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4ReferenceApplication".
 *
 * Model version              : 2.47
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:55:03 2022
 * Created for block: HevP4ReferenceApplication
 */

#ifndef RTW_HEADER_expm_9DBYDrz1_h_
#define RTW_HEADER_expm_9DBYDrz1_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern void expm_9DBYDrz1(real_T A[4], real_T F[4]);

#endif                                 /* RTW_HEADER_expm_9DBYDrz1_h_ */
