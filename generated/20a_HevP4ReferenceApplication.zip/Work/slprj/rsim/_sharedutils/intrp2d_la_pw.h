/*
 * intrp2d_la_pw.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4OptimalController".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:31 2022
 * Created for block: HevP4OptimalController
 */

#ifndef RTW_HEADER_intrp2d_la_pw_h_
#define RTW_HEADER_intrp2d_la_pw_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T intrp2d_la_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride, const uint32_T maxIndex[]);

#endif                                 /* RTW_HEADER_intrp2d_la_pw_h_ */
