/*
 * interp2_MZVr1hxC.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:18 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef RTW_HEADER_interp2_MZVr1hxC_h_
#define RTW_HEADER_interp2_MZVr1hxC_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T interp2_MZVr1hxC(const real_T varargin_1[3], const real_T
  varargin_2[3], const real_T varargin_3[9], real_T varargin_4, real_T
  varargin_5);

#endif                                 /* RTW_HEADER_interp2_MZVr1hxC_h_ */
