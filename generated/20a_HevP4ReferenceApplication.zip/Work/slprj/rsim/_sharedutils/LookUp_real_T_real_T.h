/*
 * LookUp_real_T_real_T.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SiEngineController".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:43 2022
 * Created for block: <Root>/Sensor AFR to mv
 */

#ifndef RTW_HEADER_LookUp_real_T_real_T_h_
#define RTW_HEADER_LookUp_real_T_real_T_h_
#include "rtwtypes.h"
#include "multiword_types.h"

void LookUp_real_T_real_T(real_T *pY, const real_T *pYData, real_T u, const
  real_T *pUData, uint32_T iHi);

#endif                                 /* RTW_HEADER_LookUp_real_T_real_T_h_ */
