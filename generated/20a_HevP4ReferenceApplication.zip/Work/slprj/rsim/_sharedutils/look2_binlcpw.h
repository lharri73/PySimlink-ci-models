/*
 * look2_binlcpw.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SiEngineController".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:43 2022
 * Created for block: SiEngineController
 */

#ifndef RTW_HEADER_look2_binlcpw_h_
#define RTW_HEADER_look2_binlcpw_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T look2_binlcpw(real_T u0, real_T u1, const real_T bp0[], const
  real_T bp1[], const real_T table[], const uint32_T maxIndex[], uint32_T stride);

#endif                                 /* RTW_HEADER_look2_binlcpw_h_ */
