/*
 * look1_binlcapw.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "BattHevP4".
 *
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:53:32 2022
 * Created for block: BattHevP4
 */

#ifndef RTW_HEADER_look1_binlcapw_h_
#define RTW_HEADER_look1_binlcapw_h_
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T look1_binlcapw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif                                 /* RTW_HEADER_look1_binlcapw_h_ */
