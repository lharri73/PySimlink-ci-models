/*
 * SiMappedEngine_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SiMappedEngine".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:48 2022
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "SiMappedEngine_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "SiMappedEngine.h"
#include "SiMappedEngine_capi.h"
#include "SiMappedEngine_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 3, TARGET_STRING("SiMappedEngine/Accessory Load Model/Net Torque"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 3, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 2, 3, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/1-D Lookup Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 3, 3, TARGET_STRING("SiMappedEngine/div0protect - poly1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 4, 3, TARGET_STRING("SiMappedEngine/div0protect - poly1/Unary Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 5, 3, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 6, 3, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Engine Crank Angle Calculation/RPM to deg//s"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 7, 3, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Fuel Volume Flow/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 8, 3, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/cyls per cycle"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 9, 3, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/rev per cycle"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 10, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Load Calculation/sec per min"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 11, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Load Calculation/Nominal Cylinder Air Mass g//cyl"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 12, 2, TARGET_STRING(
    "SiMappedEngine/Three-Way Catalyst/Catalyst Activated/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 13, 2, TARGET_STRING(
    "SiMappedEngine/Three-Way Catalyst/Catalyst Activated/Constant2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 14, 2, TARGET_STRING(
    "SiMappedEngine/Three-Way Catalyst/Catalyst Activated/Constant3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 15, 3, TARGET_STRING(
    "SiMappedEngine/div0protect - poly1/Compare To Constant/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 16, 3, TARGET_STRING(
    "SiMappedEngine/div0protect - poly1/Compare To Constant1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 17, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 18, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Unary Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 19, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 20, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Unary Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 21, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Compare To Constant/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 22, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Compare To Constant1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 23, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Compare To Constant/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 24, 3, TARGET_STRING(
    "SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Compare To Constant1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 25, TARGET_STRING("SiMappedEngine/Mapped SI Engine"),
    TARGET_STRING("Sg"), 0, 0, 0 },

  { 26, TARGET_STRING("SiMappedEngine/div0protect - poly1"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 27, TARGET_STRING("SiMappedEngine/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 28, TARGET_STRING("SiMappedEngine/Electronic Throttle Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 29, TARGET_STRING("SiMappedEngine/Electronic Throttle Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 30, TARGET_STRING("SiMappedEngine/Accessory Load Model/Accessory Load Model"),
    TARGET_STRING("AccPwrTbl"), 0, 1, 0 },

  { 31, TARGET_STRING("SiMappedEngine/Accessory Load Model/Accessory Load Model"),
    TARGET_STRING("AccSpdBpts"), 0, 1, 0 },

  { 32, TARGET_STRING("SiMappedEngine/Accessory Load Model/Lumped Torque Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 33, TARGET_STRING("SiMappedEngine/Accessory Load Model/Lumped Torque Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 34, TARGET_STRING("SiMappedEngine/Actuators/EGR Valve Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 35, TARGET_STRING("SiMappedEngine/Actuators/EGR Valve Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 36, TARGET_STRING("SiMappedEngine/Actuators/Electronic Throttle Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 37, TARGET_STRING("SiMappedEngine/Actuators/Electronic Throttle Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 38, TARGET_STRING("SiMappedEngine/Actuators/Exhaust Cam Phaser  Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 39, TARGET_STRING("SiMappedEngine/Actuators/Exhaust Cam Phaser  Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 40, TARGET_STRING("SiMappedEngine/Actuators/Intake Cam Phaser  Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 41, TARGET_STRING("SiMappedEngine/Actuators/Intake Cam Phaser  Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 42, TARGET_STRING("SiMappedEngine/Actuators/Swirl Valve Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 43, TARGET_STRING("SiMappedEngine/Actuators/Swirl Valve Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 44, TARGET_STRING("SiMappedEngine/Actuators/VGT Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 45, TARGET_STRING("SiMappedEngine/Actuators/VGT Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 46, TARGET_STRING("SiMappedEngine/Actuators/Variable Compression Ratio Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 47, TARGET_STRING("SiMappedEngine/Actuators/Variable Compression Ratio Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 48, TARGET_STRING("SiMappedEngine/Actuators/Variable Intake Runner Length Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 49, TARGET_STRING("SiMappedEngine/Actuators/Variable Intake Runner Length Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 50, TARGET_STRING("SiMappedEngine/Actuators/Variable Intake Valve Lift Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 51, TARGET_STRING("SiMappedEngine/Actuators/Variable Intake Valve Lift Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 52, TARGET_STRING("SiMappedEngine/Actuators/Wastegate Actuator Dynamics"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 53, TARGET_STRING("SiMappedEngine/Actuators/Wastegate Actuator Dynamics"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 54, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 55, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/1-D Lookup Table"),
    TARGET_STRING("Table"), 0, 2, 0 },

  { 56, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/1-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 2, 0 },

  { 57, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/1-D Lookup Table1"),
    TARGET_STRING("Table"), 0, 3, 0 },

  { 58, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/1-D Lookup Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 3, 0 },

  { 59, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Merge"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 60, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Merge1"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 61, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Merge2"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 62, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/O2 Storage"),
    TARGET_STRING("A"), 0, 0, 0 },

  { 63, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/O2 Storage"),
    TARGET_STRING("C"), 0, 0, 0 },

  { 64, TARGET_STRING("SiMappedEngine/div0protect - poly1/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 65, TARGET_STRING("SiMappedEngine/div0protect - poly1/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 66, TARGET_STRING("SiMappedEngine/Accessory Load Model/Accessory Load Model/Kw to w"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 67, TARGET_STRING("SiMappedEngine/Accessory Load Model/Accessory Load Model/rpm to rad//s"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 68, TARGET_STRING("SiMappedEngine/Accessory Load Model/Accessory Load Model/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 69, TARGET_STRING("SiMappedEngine/Accessory Load Model/Accessory Load Model/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 70, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 71, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 72, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 73, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Engine Crank Angle Calculation/RPM to deg//s"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 74, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Engine Crank Angle Calculation/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 75, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Engine Crank Angle Calculation/Integrator"),
    TARGET_STRING("WrappedStateUpperValue"), 0, 0, 0 },

  { 76, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Engine Crank Angle Calculation/Integrator"),
    TARGET_STRING("WrappedStateLowerValue"), 0, 0, 0 },

  { 77, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Fuel Volume Flow/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 78, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/Engine Displacement"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 79, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/Ideal Gas Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 80, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/Standard Air Temperature"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 81, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/Standard Pressure Sea Level"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 82, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/cyls per cycle"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 83, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/cyls per cycle "),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 84, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/rev per cycle"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 85, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/sec per min"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 86, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/Saturation3"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 87, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Load Calculation/Saturation3"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 88, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Catalyst Activated/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 89, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Catalyst Activated/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 90, TARGET_STRING("SiMappedEngine/Three-Way Catalyst/Catalyst Activated/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 91, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 92, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 93, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 94, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 95, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/Bsfc Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 96, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/EngTrq Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 97, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/EoCO Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 98, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/EoCO2 Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 99, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/EoHC Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 100, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/EoNOx Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 101, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/ExhManGasTemp Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 102, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/FuelMassFlw Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  { 103, TARGET_STRING("SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine/IntkGasMassFlw Table"),
    TARGET_STRING("maxIndex"), 1, 4, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 104, TARGET_STRING("f_air"), 0, 5, 0 },

  { 105, TARGET_STRING("f_co"), 0, 5, 0 },

  { 106, TARGET_STRING("f_co2"), 0, 5, 0 },

  { 107, TARGET_STRING("f_eff"), 0, 5, 0 },

  { 108, TARGET_STRING("f_fuel"), 0, 5, 0 },

  { 109, TARGET_STRING("f_hc"), 0, 5, 0 },

  { 110, TARGET_STRING("f_nox"), 0, 5, 0 },

  { 111, TARGET_STRING("f_tbrake"), 0, 5, 0 },

  { 112, TARGET_STRING("f_tbrake_n_bpt"), 0, 6, 0 },

  { 113, TARGET_STRING("f_tbrake_t_bpt"), 0, 6, 0 },

  { 114, TARGET_STRING("f_texh"), 0, 5, 0 },

  { 115, TARGET_STRING("f_twc_eff_co"), 0, 7, 0 },

  { 116, TARGET_STRING("f_twc_eff_hc"), 0, 7, 0 },

  { 117, TARGET_STRING("f_twc_eff_lam"), 0, 7, 0 },

  { 118, TARGET_STRING("f_twc_eff_nox"), 0, 7, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void SiMappedEngine_InitializeDataAddr(void* dataAddr[],
  B_SiMappedEngine_c_T *localB)
{
  dataAddr[0] = (void*) (&localB->NetTorque);
  dataAddr[1] = (void*) (&localB->Constant1);
  dataAddr[2] = (void*) (&localB->uDLookupTable1);
  dataAddr[3] = (void*) (&localB->Constant_g4);
  dataAddr[4] = (void*) (&localB->UnaryMinus_p);
  dataAddr[5] = (void*) (&localB->Constant);
  dataAddr[6] = (void*) (&localB->RPMtodegs);
  dataAddr[7] = (void*) (&localB->Gain);
  dataAddr[8] = (void*) (&localB->cylspercycle);
  dataAddr[9] = (void*) (&localB->revpercycle);
  dataAddr[10] = (void*) (&localB->secpermin);
  dataAddr[11] = (void*) (&localB->NominalCylinderAirMassgcyl);
  dataAddr[12] = (void*) (&localB->Constant1_e);
  dataAddr[13] = (void*) (&localB->Constant2);
  dataAddr[14] = (void*) (&localB->Constant3);
  dataAddr[15] = (void*) (&localB->Constant_p);
  dataAddr[16] = (void*) (&localB->Constant_jb);
  dataAddr[17] = (void*) (&localB->Constant_j);
  dataAddr[18] = (void*) (&localB->UnaryMinus_b);
  dataAddr[19] = (void*) (&localB->Constant_c);
  dataAddr[20] = (void*) (&localB->UnaryMinus);
  dataAddr[21] = (void*) (&localB->Constant_n);
  dataAddr[22] = (void*) (&localB->Constant_h);
  dataAddr[23] = (void*) (&localB->Constant_a);
  dataAddr[24] = (void*) (&localB->Constant_g);
  dataAddr[25] = (void*) (&SiMappedEngine_P.MappedSIEngine_Sg);
  dataAddr[26] = (void*) (&SiMappedEngine_P.div0protectpoly1_thresh_l);
  dataAddr[27] = (void*) (&SiMappedEngine_P.Constant_Value_k);
  dataAddr[28] = (void*) (&SiMappedEngine_P.ElectronicThrottleActuatorDynamics_A);
  dataAddr[29] = (void*) (&SiMappedEngine_P.ElectronicThrottleActuatorDynamics_C);
  dataAddr[30] = (void*) (&SiMappedEngine_P.AccessoryLoadModel_AccPwrTbl[0]);
  dataAddr[31] = (void*) (&SiMappedEngine_P.AccessoryLoadModel_AccSpdBpts[0]);
  dataAddr[32] = (void*) (&SiMappedEngine_P.LumpedTorqueDynamics_A);
  dataAddr[33] = (void*) (&SiMappedEngine_P.LumpedTorqueDynamics_C);
  dataAddr[34] = (void*) (&SiMappedEngine_P.EGRValveDynamics_A);
  dataAddr[35] = (void*) (&SiMappedEngine_P.EGRValveDynamics_C);
  dataAddr[36] = (void*)
    (&SiMappedEngine_P.ElectronicThrottleActuatorDynamics_A_a);
  dataAddr[37] = (void*)
    (&SiMappedEngine_P.ElectronicThrottleActuatorDynamics_C_k);
  dataAddr[38] = (void*) (&SiMappedEngine_P.ExhaustCamPhaserActuatorDynamics_A);
  dataAddr[39] = (void*) (&SiMappedEngine_P.ExhaustCamPhaserActuatorDynamics_C);
  dataAddr[40] = (void*) (&SiMappedEngine_P.IntakeCamPhaserActuatorDynamics_A);
  dataAddr[41] = (void*) (&SiMappedEngine_P.IntakeCamPhaserActuatorDynamics_C);
  dataAddr[42] = (void*) (&SiMappedEngine_P.SwirlValveActuatorDynamics_A);
  dataAddr[43] = (void*) (&SiMappedEngine_P.SwirlValveActuatorDynamics_C);
  dataAddr[44] = (void*) (&SiMappedEngine_P.VGTActuatorDynamics_A);
  dataAddr[45] = (void*) (&SiMappedEngine_P.VGTActuatorDynamics_C);
  dataAddr[46] = (void*)
    (&SiMappedEngine_P.VariableCompressionRatioActuatorDynamics_A);
  dataAddr[47] = (void*)
    (&SiMappedEngine_P.VariableCompressionRatioActuatorDynamics_C);
  dataAddr[48] = (void*)
    (&SiMappedEngine_P.VariableIntakeRunnerLengthActuatorDynamics_A);
  dataAddr[49] = (void*)
    (&SiMappedEngine_P.VariableIntakeRunnerLengthActuatorDynamics_C);
  dataAddr[50] = (void*)
    (&SiMappedEngine_P.VariableIntakeValveLiftActuatorDynamics_A);
  dataAddr[51] = (void*)
    (&SiMappedEngine_P.VariableIntakeValveLiftActuatorDynamics_C);
  dataAddr[52] = (void*) (&SiMappedEngine_P.WastegateActuatorDynamics_A);
  dataAddr[53] = (void*) (&SiMappedEngine_P.WastegateActuatorDynamics_C);
  dataAddr[54] = (void*) (&SiMappedEngine_P.Constant1_Value_m);
  dataAddr[55] = (void*) (&SiMappedEngine_P.uDLookupTable_tableData[0]);
  dataAddr[56] = (void*) (&SiMappedEngine_P.uDLookupTable_bp01Data[0]);
  dataAddr[57] = (void*) (&SiMappedEngine_P.uDLookupTable1_tableData[0]);
  dataAddr[58] = (void*) (&SiMappedEngine_P.uDLookupTable1_bp01Data[0]);
  dataAddr[59] = (void*) (&SiMappedEngine_P.Merge_InitialOutput);
  dataAddr[60] = (void*) (&SiMappedEngine_P.Merge1_InitialOutput);
  dataAddr[61] = (void*) (&SiMappedEngine_P.Merge2_InitialOutput);
  dataAddr[62] = (void*) (&SiMappedEngine_P.O2Storage_A);
  dataAddr[63] = (void*) (&SiMappedEngine_P.O2Storage_C);
  dataAddr[64] = (void*) (&SiMappedEngine_P.Constant_Value_e);
  dataAddr[65] = (void*) (&SiMappedEngine_P.Switch1_Threshold_g);
  dataAddr[66] = (void*) (&SiMappedEngine_P.Kwtow_Gain);
  dataAddr[67] = (void*) (&SiMappedEngine_P.rpmtorads_Gain);
  dataAddr[68] = (void*) (&SiMappedEngine_P.Saturation_UpperSat);
  dataAddr[69] = (void*) (&SiMappedEngine_P.Saturation_LowerSat);
  dataAddr[70] = (void*) (&SiMappedEngine_P.div0protectpoly1_thresh);
  dataAddr[71] = (void*) (&SiMappedEngine_P.div0protectpoly2_thresh);
  dataAddr[72] = (void*) (&SiMappedEngine_P.Constant_Value);
  dataAddr[73] = (void*) (&SiMappedEngine_P.RPMtodegs_Gain);
  dataAddr[74] = (void*) (&SiMappedEngine_P.Integrator_IC);
  dataAddr[75] = (void*) (&SiMappedEngine_P.Integrator_WrappedStateUpperValue);
  dataAddr[76] = (void*) (&SiMappedEngine_P.Integrator_WrappedStateLowerValue);
  dataAddr[77] = (void*) (&SiMappedEngine_P.Gain_Gain);
  dataAddr[78] = (void*) (&SiMappedEngine_P.EngineDisplacement_Value);
  dataAddr[79] = (void*) (&SiMappedEngine_P.IdealGasConstant_Value);
  dataAddr[80] = (void*) (&SiMappedEngine_P.StandardAirTemperature_Value);
  dataAddr[81] = (void*) (&SiMappedEngine_P.StandardPressureSeaLevel_Value);
  dataAddr[82] = (void*) (&SiMappedEngine_P.cylspercycle_Value);
  dataAddr[83] = (void*) (&SiMappedEngine_P.cylspercycle_Value_m);
  dataAddr[84] = (void*) (&SiMappedEngine_P.revpercycle_Value);
  dataAddr[85] = (void*) (&SiMappedEngine_P.secpermin_Value);
  dataAddr[86] = (void*) (&SiMappedEngine_P.Saturation3_UpperSat);
  dataAddr[87] = (void*) (&SiMappedEngine_P.Saturation3_LowerSat);
  dataAddr[88] = (void*) (&SiMappedEngine_P.Constant1_Value);
  dataAddr[89] = (void*) (&SiMappedEngine_P.Constant2_Value);
  dataAddr[90] = (void*) (&SiMappedEngine_P.Constant3_Value);
  dataAddr[91] = (void*) (&SiMappedEngine_P.Constant_Value_b);
  dataAddr[92] = (void*) (&SiMappedEngine_P.Switch1_Threshold_j);
  dataAddr[93] = (void*) (&SiMappedEngine_P.Constant_Value_m);
  dataAddr[94] = (void*) (&SiMappedEngine_P.Switch1_Threshold);
  dataAddr[95] = (void*) (&SiMappedEngine_P.BsfcTable_maxIndex[0]);
  dataAddr[96] = (void*) (&SiMappedEngine_P.EngTrqTable_maxIndex[0]);
  dataAddr[97] = (void*) (&SiMappedEngine_P.EoCOTable_maxIndex[0]);
  dataAddr[98] = (void*) (&SiMappedEngine_P.EoCO2Table_maxIndex[0]);
  dataAddr[99] = (void*) (&SiMappedEngine_P.EoHCTable_maxIndex[0]);
  dataAddr[100] = (void*) (&SiMappedEngine_P.EoNOxTable_maxIndex[0]);
  dataAddr[101] = (void*) (&SiMappedEngine_P.ExhManGasTempTable_maxIndex[0]);
  dataAddr[102] = (void*) (&SiMappedEngine_P.FuelMassFlwTable_maxIndex[0]);
  dataAddr[103] = (void*) (&SiMappedEngine_P.IntkGasMassFlwTable_maxIndex[0]);
  dataAddr[104] = (void*) (&SiMappedEngine_P.f_air[0]);
  dataAddr[105] = (void*) (&SiMappedEngine_P.f_co[0]);
  dataAddr[106] = (void*) (&SiMappedEngine_P.f_co2[0]);
  dataAddr[107] = (void*) (&SiMappedEngine_P.f_eff[0]);
  dataAddr[108] = (void*) (&SiMappedEngine_P.f_fuel[0]);
  dataAddr[109] = (void*) (&SiMappedEngine_P.f_hc[0]);
  dataAddr[110] = (void*) (&SiMappedEngine_P.f_nox[0]);
  dataAddr[111] = (void*) (&SiMappedEngine_P.f_tbrake[0]);
  dataAddr[112] = (void*) (&SiMappedEngine_P.f_tbrake_n_bpt[0]);
  dataAddr[113] = (void*) (&SiMappedEngine_P.f_tbrake_t_bpt[0]);
  dataAddr[114] = (void*) (&SiMappedEngine_P.f_texh[0]);
  dataAddr[115] = (void*) (&SiMappedEngine_P.f_twc_eff_co[0]);
  dataAddr[116] = (void*) (&SiMappedEngine_P.f_twc_eff_hc[0]);
  dataAddr[117] = (void*) (&SiMappedEngine_P.f_twc_eff_lam[0]);
  dataAddr[118] = (void*) (&SiMappedEngine_P.f_twc_eff_nox[0]);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void SiMappedEngine_InitializeVarDimsAddr(int32_T* vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void SiMappedEngine_InitializeLoggingFunctions(RTWLoggingFcnPtr
  loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
  loggingPtrs[14] = (NULL);
  loggingPtrs[15] = (NULL);
  loggingPtrs[16] = (NULL);
  loggingPtrs[17] = (NULL);
  loggingPtrs[18] = (NULL);
  loggingPtrs[19] = (NULL);
  loggingPtrs[20] = (NULL);
  loggingPtrs[21] = (NULL);
  loggingPtrs[22] = (NULL);
  loggingPtrs[23] = (NULL);
  loggingPtrs[24] = (NULL);
  loggingPtrs[25] = (NULL);
  loggingPtrs[26] = (NULL);
  loggingPtrs[27] = (NULL);
  loggingPtrs[28] = (NULL);
  loggingPtrs[29] = (NULL);
  loggingPtrs[30] = (NULL);
  loggingPtrs[31] = (NULL);
  loggingPtrs[32] = (NULL);
  loggingPtrs[33] = (NULL);
  loggingPtrs[34] = (NULL);
  loggingPtrs[35] = (NULL);
  loggingPtrs[36] = (NULL);
  loggingPtrs[37] = (NULL);
  loggingPtrs[38] = (NULL);
  loggingPtrs[39] = (NULL);
  loggingPtrs[40] = (NULL);
  loggingPtrs[41] = (NULL);
  loggingPtrs[42] = (NULL);
  loggingPtrs[43] = (NULL);
  loggingPtrs[44] = (NULL);
  loggingPtrs[45] = (NULL);
  loggingPtrs[46] = (NULL);
  loggingPtrs[47] = (NULL);
  loggingPtrs[48] = (NULL);
  loggingPtrs[49] = (NULL);
  loggingPtrs[50] = (NULL);
  loggingPtrs[51] = (NULL);
  loggingPtrs[52] = (NULL);
  loggingPtrs[53] = (NULL);
  loggingPtrs[54] = (NULL);
  loggingPtrs[55] = (NULL);
  loggingPtrs[56] = (NULL);
  loggingPtrs[57] = (NULL);
  loggingPtrs[58] = (NULL);
  loggingPtrs[59] = (NULL);
  loggingPtrs[60] = (NULL);
  loggingPtrs[61] = (NULL);
  loggingPtrs[62] = (NULL);
  loggingPtrs[63] = (NULL);
  loggingPtrs[64] = (NULL);
  loggingPtrs[65] = (NULL);
  loggingPtrs[66] = (NULL);
  loggingPtrs[67] = (NULL);
  loggingPtrs[68] = (NULL);
  loggingPtrs[69] = (NULL);
  loggingPtrs[70] = (NULL);
  loggingPtrs[71] = (NULL);
  loggingPtrs[72] = (NULL);
  loggingPtrs[73] = (NULL);
  loggingPtrs[74] = (NULL);
  loggingPtrs[75] = (NULL);
  loggingPtrs[76] = (NULL);
  loggingPtrs[77] = (NULL);
  loggingPtrs[78] = (NULL);
  loggingPtrs[79] = (NULL);
  loggingPtrs[80] = (NULL);
  loggingPtrs[81] = (NULL);
  loggingPtrs[82] = (NULL);
  loggingPtrs[83] = (NULL);
  loggingPtrs[84] = (NULL);
  loggingPtrs[85] = (NULL);
  loggingPtrs[86] = (NULL);
  loggingPtrs[87] = (NULL);
  loggingPtrs[88] = (NULL);
  loggingPtrs[89] = (NULL);
  loggingPtrs[90] = (NULL);
  loggingPtrs[91] = (NULL);
  loggingPtrs[92] = (NULL);
  loggingPtrs[93] = (NULL);
  loggingPtrs[94] = (NULL);
  loggingPtrs[95] = (NULL);
  loggingPtrs[96] = (NULL);
  loggingPtrs[97] = (NULL);
  loggingPtrs[98] = (NULL);
  loggingPtrs[99] = (NULL);
  loggingPtrs[100] = (NULL);
  loggingPtrs[101] = (NULL);
  loggingPtrs[102] = (NULL);
  loggingPtrs[103] = (NULL);
  loggingPtrs[104] = (NULL);
  loggingPtrs[105] = (NULL);
  loggingPtrs[106] = (NULL);
  loggingPtrs[107] = (NULL);
  loggingPtrs[108] = (NULL);
  loggingPtrs[109] = (NULL);
  loggingPtrs[110] = (NULL);
  loggingPtrs[111] = (NULL);
  loggingPtrs[112] = (NULL);
  loggingPtrs[113] = (NULL);
  loggingPtrs[114] = (NULL);
  loggingPtrs[115] = (NULL);
  loggingPtrs[116] = (NULL);
  loggingPtrs[117] = (NULL);
  loggingPtrs[118] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  1,                                   /* 2 */
  2,                                   /* 3 */
  1,                                   /* 4 */
  3,                                   /* 5 */
  1,                                   /* 6 */
  4,                                   /* 7 */
  2,                                   /* 8 */
  1,                                   /* 9 */
  16,                                  /* 10 */
  16,                                  /* 11 */
  1,                                   /* 12 */
  16,                                  /* 13 */
  1,                                   /* 14 */
  7                                    /* 15 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0, 1.0
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[0],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 25,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 79,
    rtModelParameters, 15 },

  { (NULL), 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 3405093454U,
    3491883854U,
    3620542160U,
    3644731718U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  SiMappedEngine_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void SiMappedEngine_InitializeDataMapInfo(RT_MODEL_SiMappedEngine_T *const
  SiMappedEngine_M, B_SiMappedEngine_c_T *localB)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(SiMappedEngine_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(SiMappedEngine_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(SiMappedEngine_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  SiMappedEngine_InitializeDataAddr(SiMappedEngine_M->DataMapInfo.dataAddress,
    localB);
  rtwCAPI_SetDataAddressMap(SiMappedEngine_M->DataMapInfo.mmi,
    SiMappedEngine_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  SiMappedEngine_InitializeVarDimsAddr
    (SiMappedEngine_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(SiMappedEngine_M->DataMapInfo.mmi,
    SiMappedEngine_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(SiMappedEngine_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(SiMappedEngine_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  SiMappedEngine_InitializeLoggingFunctions
    (SiMappedEngine_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(SiMappedEngine_M->DataMapInfo.mmi,
    SiMappedEngine_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(SiMappedEngine_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(SiMappedEngine_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(SiMappedEngine_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void SiMappedEngine_host_InitializeDataMapInfo
    (SiMappedEngine_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: SiMappedEngine_capi.c */
