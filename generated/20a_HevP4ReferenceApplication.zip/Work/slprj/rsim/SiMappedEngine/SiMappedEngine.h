/*
 * Code generation for system model 'SiMappedEngine'
 * For more details, see corresponding source file SiMappedEngine.c
 *
 */

#ifndef RTW_HEADER_SiMappedEngine_h_
#define RTW_HEADER_SiMappedEngine_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef SiMappedEngine_COMMON_INCLUDES_
#define SiMappedEngine_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rsim.h"
#endif                                 /* SiMappedEngine_COMMON_INCLUDES_ */

#include "SiMappedEngine_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rt_nonfinite.h"

/* Block signals for model 'SiMappedEngine' */
typedef struct {
  real_T NetTorque;                    /* '<S1>/Net Torque' */
  real_T Constant;                     /* '<S11>/Constant' */
  real_T Constant_c;                   /* '<S19>/Constant' */
  real_T UnaryMinus;                   /* '<S19>/Unary Minus' */
  real_T Constant_a;                   /* '<S22>/Constant' */
  real_T Constant_g;                   /* '<S23>/Constant' */
  real_T Constant_j;                   /* '<S18>/Constant' */
  real_T UnaryMinus_b;                 /* '<S18>/Unary Minus' */
  real_T Constant_n;                   /* '<S20>/Constant' */
  real_T Constant_h;                   /* '<S21>/Constant' */
  real_T RPMtodegs;                    /* '<S12>/RPM to deg//s' */
  real_T Gain;                         /* '<S13>/Gain' */
  real_T cylspercycle;                 /* '<S14>/cyls per cycle' */
  real_T revpercycle;                  /* '<S14>/rev per cycle' */
  real_T secpermin;                    /* '<S14>/sec per min' */
  real_T NominalCylinderAirMassgcyl;
                                  /* '<S14>/Nominal Cylinder Air Mass g//cyl' */
  real_T Constant_g4;                  /* '<S5>/Constant' */
  real_T UnaryMinus_p;                 /* '<S5>/Unary Minus' */
  real_T Constant_p;                   /* '<S32>/Constant' */
  real_T Constant_jb;                  /* '<S33>/Constant' */
  real_T uDLookupTable1;               /* '<S4>/1-D Lookup Table1' */
  real_T Constant1;                    /* '<S4>/Constant1' */
  real_T Constant1_e;                  /* '<S31>/Constant1' */
  real_T Constant2;                    /* '<S31>/Constant2' */
  real_T Constant3;                    /* '<S31>/Constant3' */
} B_SiMappedEngine_c_T;

/* Block states (default storage) for model 'SiMappedEngine' */
typedef struct {
  int_T Saturation_MODE;               /* '<S6>/Saturation' */
  int8_T CatalystLightOff_ActiveSubsystem;/* '<S4>/Catalyst Light-Off' */
} DW_SiMappedEngine_f_T;

/* Continuous states for model 'SiMappedEngine' */
typedef struct {
  real_T LumpedTorqueDynamics_CSTATE;  /* '<S1>/Lumped Torque Dynamics' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE;
                            /* '<Root>/Electronic Throttle Actuator Dynamics' */
  real_T Integrator_CSTATE;            /* '<S12>/Integrator' */
  real_T O2Storage_CSTATE;             /* '<S4>/O2 Storage' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE_b;
                              /* '<S2>/Electronic Throttle Actuator Dynamics' */
  real_T WastegateActuatorDynamics_CSTATE;/* '<S2>/Wastegate Actuator Dynamics' */
  real_T IntakeCamPhaserActuatorDynamics_CSTATE;
                               /* '<S2>/Intake Cam Phaser  Actuator Dynamics' */
  real_T ExhaustCamPhaserActuatorDynamics_CSTATE;
                              /* '<S2>/Exhaust Cam Phaser  Actuator Dynamics' */
  real_T VGTActuatorDynamics_CSTATE;   /* '<S2>/VGT Actuator Dynamics' */
  real_T EGRValveDynamics_CSTATE;      /* '<S2>/EGR Valve Dynamics' */
  real_T VariableCompressionRatioActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Compression Ratio Actuator Dynamics' */
  real_T VariableIntakeValveLiftActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Intake Valve Lift Actuator Dynamics' */
  real_T VariableIntakeRunnerLengthActuatorDynamics_CSTATE;
                    /* '<S2>/Variable Intake Runner Length Actuator Dynamics' */
  real_T SwirlValveActuatorDynamics_CSTATE;
                                      /* '<S2>/Swirl Valve Actuator Dynamics' */
} X_SiMappedEngine_n_T;

/* Periodic continuous state vector (global) */
typedef int_T PeriodicIndX_SiMappedEngine_T[1];
typedef real_T PeriodicRngX_SiMappedEngine_T[2];

/* State derivatives for model 'SiMappedEngine' */
typedef struct {
  real_T LumpedTorqueDynamics_CSTATE;  /* '<S1>/Lumped Torque Dynamics' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE;
                            /* '<Root>/Electronic Throttle Actuator Dynamics' */
  real_T Integrator_CSTATE;            /* '<S12>/Integrator' */
  real_T O2Storage_CSTATE;             /* '<S4>/O2 Storage' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE_b;
                              /* '<S2>/Electronic Throttle Actuator Dynamics' */
  real_T WastegateActuatorDynamics_CSTATE;/* '<S2>/Wastegate Actuator Dynamics' */
  real_T IntakeCamPhaserActuatorDynamics_CSTATE;
                               /* '<S2>/Intake Cam Phaser  Actuator Dynamics' */
  real_T ExhaustCamPhaserActuatorDynamics_CSTATE;
                              /* '<S2>/Exhaust Cam Phaser  Actuator Dynamics' */
  real_T VGTActuatorDynamics_CSTATE;   /* '<S2>/VGT Actuator Dynamics' */
  real_T EGRValveDynamics_CSTATE;      /* '<S2>/EGR Valve Dynamics' */
  real_T VariableCompressionRatioActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Compression Ratio Actuator Dynamics' */
  real_T VariableIntakeValveLiftActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Intake Valve Lift Actuator Dynamics' */
  real_T VariableIntakeRunnerLengthActuatorDynamics_CSTATE;
                    /* '<S2>/Variable Intake Runner Length Actuator Dynamics' */
  real_T SwirlValveActuatorDynamics_CSTATE;
                                      /* '<S2>/Swirl Valve Actuator Dynamics' */
} XDot_SiMappedEngine_n_T;

/* State Disabled for model 'SiMappedEngine' */
typedef struct {
  boolean_T LumpedTorqueDynamics_CSTATE;/* '<S1>/Lumped Torque Dynamics' */
  boolean_T ElectronicThrottleActuatorDynamics_CSTATE;
                            /* '<Root>/Electronic Throttle Actuator Dynamics' */
  boolean_T Integrator_CSTATE;         /* '<S12>/Integrator' */
  boolean_T O2Storage_CSTATE;          /* '<S4>/O2 Storage' */
  boolean_T ElectronicThrottleActuatorDynamics_CSTATE_b;
                              /* '<S2>/Electronic Throttle Actuator Dynamics' */
  boolean_T WastegateActuatorDynamics_CSTATE;/* '<S2>/Wastegate Actuator Dynamics' */
  boolean_T IntakeCamPhaserActuatorDynamics_CSTATE;
                               /* '<S2>/Intake Cam Phaser  Actuator Dynamics' */
  boolean_T ExhaustCamPhaserActuatorDynamics_CSTATE;
                              /* '<S2>/Exhaust Cam Phaser  Actuator Dynamics' */
  boolean_T VGTActuatorDynamics_CSTATE;/* '<S2>/VGT Actuator Dynamics' */
  boolean_T EGRValveDynamics_CSTATE;   /* '<S2>/EGR Valve Dynamics' */
  boolean_T VariableCompressionRatioActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Compression Ratio Actuator Dynamics' */
  boolean_T VariableIntakeValveLiftActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Intake Valve Lift Actuator Dynamics' */
  boolean_T VariableIntakeRunnerLengthActuatorDynamics_CSTATE;
                    /* '<S2>/Variable Intake Runner Length Actuator Dynamics' */
  boolean_T SwirlValveActuatorDynamics_CSTATE;
                                      /* '<S2>/Swirl Valve Actuator Dynamics' */
} XDis_SiMappedEngine_n_T;

/* Continuous State Absolute Tolerance for model 'SiMappedEngine' */
typedef struct {
  real_T LumpedTorqueDynamics_CSTATE;  /* '<S1>/Lumped Torque Dynamics' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE;
                            /* '<Root>/Electronic Throttle Actuator Dynamics' */
  real_T Integrator_CSTATE;            /* '<S12>/Integrator' */
  real_T O2Storage_CSTATE;             /* '<S4>/O2 Storage' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE_b;
                              /* '<S2>/Electronic Throttle Actuator Dynamics' */
  real_T WastegateActuatorDynamics_CSTATE;/* '<S2>/Wastegate Actuator Dynamics' */
  real_T IntakeCamPhaserActuatorDynamics_CSTATE;
                               /* '<S2>/Intake Cam Phaser  Actuator Dynamics' */
  real_T ExhaustCamPhaserActuatorDynamics_CSTATE;
                              /* '<S2>/Exhaust Cam Phaser  Actuator Dynamics' */
  real_T VGTActuatorDynamics_CSTATE;   /* '<S2>/VGT Actuator Dynamics' */
  real_T EGRValveDynamics_CSTATE;      /* '<S2>/EGR Valve Dynamics' */
  real_T VariableCompressionRatioActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Compression Ratio Actuator Dynamics' */
  real_T VariableIntakeValveLiftActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Intake Valve Lift Actuator Dynamics' */
  real_T VariableIntakeRunnerLengthActuatorDynamics_CSTATE;
                    /* '<S2>/Variable Intake Runner Length Actuator Dynamics' */
  real_T SwirlValveActuatorDynamics_CSTATE;
                                      /* '<S2>/Swirl Valve Actuator Dynamics' */
} XAbsTol_SiMappedEngine_T;

/* Continuous State Perturb Min for model 'SiMappedEngine' */
typedef struct {
  real_T LumpedTorqueDynamics_CSTATE;  /* '<S1>/Lumped Torque Dynamics' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE;
                            /* '<Root>/Electronic Throttle Actuator Dynamics' */
  real_T Integrator_CSTATE;            /* '<S12>/Integrator' */
  real_T O2Storage_CSTATE;             /* '<S4>/O2 Storage' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE_b;
                              /* '<S2>/Electronic Throttle Actuator Dynamics' */
  real_T WastegateActuatorDynamics_CSTATE;/* '<S2>/Wastegate Actuator Dynamics' */
  real_T IntakeCamPhaserActuatorDynamics_CSTATE;
                               /* '<S2>/Intake Cam Phaser  Actuator Dynamics' */
  real_T ExhaustCamPhaserActuatorDynamics_CSTATE;
                              /* '<S2>/Exhaust Cam Phaser  Actuator Dynamics' */
  real_T VGTActuatorDynamics_CSTATE;   /* '<S2>/VGT Actuator Dynamics' */
  real_T EGRValveDynamics_CSTATE;      /* '<S2>/EGR Valve Dynamics' */
  real_T VariableCompressionRatioActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Compression Ratio Actuator Dynamics' */
  real_T VariableIntakeValveLiftActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Intake Valve Lift Actuator Dynamics' */
  real_T VariableIntakeRunnerLengthActuatorDynamics_CSTATE;
                    /* '<S2>/Variable Intake Runner Length Actuator Dynamics' */
  real_T SwirlValveActuatorDynamics_CSTATE;
                                      /* '<S2>/Swirl Valve Actuator Dynamics' */
} XPtMin_SiMappedEngine_T;

/* Continuous State Perturb Max for model 'SiMappedEngine' */
typedef struct {
  real_T LumpedTorqueDynamics_CSTATE;  /* '<S1>/Lumped Torque Dynamics' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE;
                            /* '<Root>/Electronic Throttle Actuator Dynamics' */
  real_T Integrator_CSTATE;            /* '<S12>/Integrator' */
  real_T O2Storage_CSTATE;             /* '<S4>/O2 Storage' */
  real_T ElectronicThrottleActuatorDynamics_CSTATE_b;
                              /* '<S2>/Electronic Throttle Actuator Dynamics' */
  real_T WastegateActuatorDynamics_CSTATE;/* '<S2>/Wastegate Actuator Dynamics' */
  real_T IntakeCamPhaserActuatorDynamics_CSTATE;
                               /* '<S2>/Intake Cam Phaser  Actuator Dynamics' */
  real_T ExhaustCamPhaserActuatorDynamics_CSTATE;
                              /* '<S2>/Exhaust Cam Phaser  Actuator Dynamics' */
  real_T VGTActuatorDynamics_CSTATE;   /* '<S2>/VGT Actuator Dynamics' */
  real_T EGRValveDynamics_CSTATE;      /* '<S2>/EGR Valve Dynamics' */
  real_T VariableCompressionRatioActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Compression Ratio Actuator Dynamics' */
  real_T VariableIntakeValveLiftActuatorDynamics_CSTATE;
                       /* '<S2>/Variable Intake Valve Lift Actuator Dynamics' */
  real_T VariableIntakeRunnerLengthActuatorDynamics_CSTATE;
                    /* '<S2>/Variable Intake Runner Length Actuator Dynamics' */
  real_T SwirlValveActuatorDynamics_CSTATE;
                                      /* '<S2>/Swirl Valve Actuator Dynamics' */
} XPtMax_SiMappedEngine_T;

/* Zero-crossing (trigger) state for model 'SiMappedEngine' */
typedef struct {
  real_T Saturation_UprLim_ZC;         /* '<S6>/Saturation' */
  real_T Saturation_LwrLim_ZC;         /* '<S6>/Saturation' */
  real_T CatalystLightOff_IfInput_ZC;  /* '<S4>/Catalyst Light-Off' */
} ZCV_SiMappedEngine_g_T;

/* Parameters (default storage) */
struct P_SiMappedEngine_T_ {
  real_T f_air[256];                   /* Variable: f_air
                                        * Referenced by: '<S25>/IntkGasMassFlw Table'
                                        */
  real_T f_co[256];                    /* Variable: f_co
                                        * Referenced by: '<S25>/EoCO Table'
                                        */
  real_T f_co2[256];                   /* Variable: f_co2
                                        * Referenced by: '<S25>/EoCO2 Table'
                                        */
  real_T f_eff[256];                   /* Variable: f_eff
                                        * Referenced by: '<S25>/Bsfc Table'
                                        */
  real_T f_fuel[256];                  /* Variable: f_fuel
                                        * Referenced by: '<S25>/FuelMassFlw Table'
                                        */
  real_T f_hc[256];                    /* Variable: f_hc
                                        * Referenced by: '<S25>/EoHC Table'
                                        */
  real_T f_nox[256];                   /* Variable: f_nox
                                        * Referenced by: '<S25>/EoNOx Table'
                                        */
  real_T f_tbrake[256];                /* Variable: f_tbrake
                                        * Referenced by: '<S25>/EngTrq Table'
                                        */
  real_T f_tbrake_n_bpt[16];           /* Variable: f_tbrake_n_bpt
                                        * Referenced by:
                                        *   '<S25>/Bsfc Table'
                                        *   '<S25>/EngTrq Table'
                                        *   '<S25>/EoCO Table'
                                        *   '<S25>/EoCO2 Table'
                                        *   '<S25>/EoHC Table'
                                        *   '<S25>/EoNOx Table'
                                        *   '<S25>/ExhManGasTemp Table'
                                        *   '<S25>/FuelMassFlw Table'
                                        *   '<S25>/IntkGasMassFlw Table'
                                        */
  real_T f_tbrake_t_bpt[16];           /* Variable: f_tbrake_t_bpt
                                        * Referenced by:
                                        *   '<S25>/Bsfc Table'
                                        *   '<S25>/EngTrq Table'
                                        *   '<S25>/EoCO Table'
                                        *   '<S25>/EoCO2 Table'
                                        *   '<S25>/EoHC Table'
                                        *   '<S25>/EoNOx Table'
                                        *   '<S25>/ExhManGasTemp Table'
                                        *   '<S25>/FuelMassFlw Table'
                                        *   '<S25>/IntkGasMassFlw Table'
                                        */
  real_T f_texh[256];                  /* Variable: f_texh
                                        * Referenced by: '<S25>/ExhManGasTemp Table'
                                        */
  real_T f_twc_eff_co[7];              /* Variable: f_twc_eff_co
                                        * Referenced by: '<S31>/TWC CO Conversion Efficiency'
                                        */
  real_T f_twc_eff_hc[7];              /* Variable: f_twc_eff_hc
                                        * Referenced by: '<S31>/TWC HC Conversion Efficiency'
                                        */
  real_T f_twc_eff_lam[7];             /* Variable: f_twc_eff_lam
                                        * Referenced by:
                                        *   '<S31>/TWC CO Conversion Efficiency'
                                        *   '<S31>/TWC HC Conversion Efficiency'
                                        *   '<S31>/TWC NOx Conversion Efficiency'
                                        */
  real_T f_twc_eff_nox[7];             /* Variable: f_twc_eff_nox
                                        * Referenced by: '<S31>/TWC NOx Conversion Efficiency'
                                        */
  real_T AccessoryLoadModel_AccPwrTbl[2];
                                 /* Mask Parameter: AccessoryLoadModel_AccPwrTbl
                                  * Referenced by: '<S6>/Accessory Load Power'
                                  */
  real_T AccessoryLoadModel_AccSpdBpts[2];
                                /* Mask Parameter: AccessoryLoadModel_AccSpdBpts
                                 * Referenced by: '<S6>/Accessory Load Power'
                                 */
  real_T MappedSIEngine_Sg;            /* Mask Parameter: MappedSIEngine_Sg
                                        * Referenced by: '<S13>/Constant'
                                        */
  real_T div0protectpoly2_thresh;     /* Mask Parameter: div0protectpoly2_thresh
                                       * Referenced by:
                                       *   '<S22>/Constant'
                                       *   '<S23>/Constant'
                                       */
  real_T div0protectpoly1_thresh;     /* Mask Parameter: div0protectpoly1_thresh
                                       * Referenced by:
                                       *   '<S20>/Constant'
                                       *   '<S21>/Constant'
                                       */
  real_T div0protectpoly1_thresh_l; /* Mask Parameter: div0protectpoly1_thresh_l
                                     * Referenced by:
                                     *   '<S32>/Constant'
                                     *   '<S33>/Constant'
                                     */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S31>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S31>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 1
                                        * Referenced by: '<S31>/Constant3'
                                        */
  real_T Kwtow_Gain;                   /* Expression: 1000
                                        * Referenced by: '<S6>/Kw to w'
                                        */
  real_T Saturation_UpperSat;          /* Expression: Inf
                                        * Referenced by: '<S6>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 300
                                        * Referenced by: '<S6>/Saturation'
                                        */
  real_T rpmtorads_Gain;               /* Expression: pi/30
                                        * Referenced by: '<S6>/rpm to rad//s'
                                        */
  real_T LumpedTorqueDynamics_A;   /* Computed Parameter: LumpedTorqueDynamics_A
                                    * Referenced by: '<S1>/Lumped Torque Dynamics'
                                    */
  real_T LumpedTorqueDynamics_C;   /* Computed Parameter: LumpedTorqueDynamics_C
                                    * Referenced by: '<S1>/Lumped Torque Dynamics'
                                    */
  real_T ElectronicThrottleActuatorDynamics_A;
                     /* Computed Parameter: ElectronicThrottleActuatorDynamics_A
                      * Referenced by: '<Root>/Electronic Throttle Actuator Dynamics'
                      */
  real_T ElectronicThrottleActuatorDynamics_C;
                     /* Computed Parameter: ElectronicThrottleActuatorDynamics_C
                      * Referenced by: '<Root>/Electronic Throttle Actuator Dynamics'
                      */
  real_T Constant_Value;               /* Expression: 100
                                        * Referenced by: '<S11>/Constant'
                                        */
  real_T Constant_Value_m;             /* Expression: 1
                                        * Referenced by: '<S19>/Constant'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S19>/Switch1'
                                        */
  real_T Constant_Value_b;             /* Expression: 1
                                        * Referenced by: '<S18>/Constant'
                                        */
  real_T Switch1_Threshold_j;          /* Expression: 0
                                        * Referenced by: '<S18>/Switch1'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S12>/Integrator'
                                        */
  real_T Integrator_WrappedStateUpperValue;/* Expression: 360*Cps
                                            * Referenced by: '<S12>/Integrator'
                                            */
  real_T Integrator_WrappedStateLowerValue;/* Expression: 0
                                            * Referenced by: '<S12>/Integrator'
                                            */
  real_T RPMtodegs_Gain;               /* Expression: 180/30
                                        * Referenced by: '<S12>/RPM to deg//s'
                                        */
  real_T Gain_Gain;                    /* Expression: 1000
                                        * Referenced by: '<S13>/Gain'
                                        */
  real_T cylspercycle_Value;           /* Expression: NCyl
                                        * Referenced by: '<S14>/cyls per cycle'
                                        */
  real_T revpercycle_Value;            /* Expression: Cps
                                        * Referenced by: '<S14>/rev per cycle'
                                        */
  real_T secpermin_Value;              /* Expression: 60
                                        * Referenced by: '<S14>/sec per min'
                                        */
  real_T EngineDisplacement_Value;     /* Expression: Vd
                                        * Referenced by: '<S14>/Engine Displacement'
                                        */
  real_T StandardPressureSeaLevel_Value;/* Expression: Pstd
                                         * Referenced by: '<S14>/Standard Pressure Sea Level'
                                         */
  real_T StandardAirTemperature_Value; /* Expression: Tstd
                                        * Referenced by: '<S14>/Standard Air Temperature'
                                        */
  real_T IdealGasConstant_Value;       /* Expression: Rair
                                        * Referenced by: '<S14>/Ideal Gas Constant'
                                        */
  real_T cylspercycle_Value_m;         /* Expression: NCyl
                                        * Referenced by: '<S14>/cyls per cycle '
                                        */
  real_T Saturation3_UpperSat;         /* Expression: 1e6
                                        * Referenced by: '<S14>/Saturation3'
                                        */
  real_T Saturation3_LowerSat;         /* Expression: 0.0001
                                        * Referenced by: '<S14>/Saturation3'
                                        */
  real_T Constant_Value_e;             /* Expression: 1
                                        * Referenced by: '<S5>/Constant'
                                        */
  real_T Switch1_Threshold_g;          /* Expression: 0
                                        * Referenced by: '<S5>/Switch1'
                                        */
  real_T uDLookupTable_tableData[3];   /* Expression: [0 15 AfrStoich]/AfrStoich
                                        * Referenced by: '<S4>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[3];    /* Expression: [0 15 100]
                                        * Referenced by: '<S4>/1-D Lookup Table'
                                        */
  real_T uDLookupTable1_tableData[4];  /* Expression: [-1 0 0 0.07]
                                        * Referenced by: '<S4>/1-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp01Data[4];   /* Expression: [0 0.97 1.03 1.1]
                                        * Referenced by: '<S4>/1-D Lookup Table1'
                                        */
  real_T O2Storage_A;                  /* Computed Parameter: O2Storage_A
                                        * Referenced by: '<S4>/O2 Storage'
                                        */
  real_T O2Storage_C;                  /* Computed Parameter: O2Storage_C
                                        * Referenced by: '<S4>/O2 Storage'
                                        */
  real_T Constant1_Value_m;            /* Expression: 1
                                        * Referenced by: '<S4>/Constant1'
                                        */
  real_T Merge_InitialOutput;         /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S4>/Merge'
                                       */
  real_T Merge1_InitialOutput;       /* Computed Parameter: Merge1_InitialOutput
                                      * Referenced by: '<S4>/Merge1'
                                      */
  real_T Merge2_InitialOutput;       /* Computed Parameter: Merge2_InitialOutput
                                      * Referenced by: '<S4>/Merge2'
                                      */
  real_T ElectronicThrottleActuatorDynamics_A_a;
                   /* Computed Parameter: ElectronicThrottleActuatorDynamics_A_a
                    * Referenced by: '<S2>/Electronic Throttle Actuator Dynamics'
                    */
  real_T ElectronicThrottleActuatorDynamics_C_k;
                   /* Computed Parameter: ElectronicThrottleActuatorDynamics_C_k
                    * Referenced by: '<S2>/Electronic Throttle Actuator Dynamics'
                    */
  real_T WastegateActuatorDynamics_A;
                              /* Computed Parameter: WastegateActuatorDynamics_A
                               * Referenced by: '<S2>/Wastegate Actuator Dynamics'
                               */
  real_T WastegateActuatorDynamics_C;
                              /* Computed Parameter: WastegateActuatorDynamics_C
                               * Referenced by: '<S2>/Wastegate Actuator Dynamics'
                               */
  real_T IntakeCamPhaserActuatorDynamics_A;
                        /* Computed Parameter: IntakeCamPhaserActuatorDynamics_A
                         * Referenced by: '<S2>/Intake Cam Phaser  Actuator Dynamics'
                         */
  real_T IntakeCamPhaserActuatorDynamics_C;
                        /* Computed Parameter: IntakeCamPhaserActuatorDynamics_C
                         * Referenced by: '<S2>/Intake Cam Phaser  Actuator Dynamics'
                         */
  real_T ExhaustCamPhaserActuatorDynamics_A;
                       /* Computed Parameter: ExhaustCamPhaserActuatorDynamics_A
                        * Referenced by: '<S2>/Exhaust Cam Phaser  Actuator Dynamics'
                        */
  real_T ExhaustCamPhaserActuatorDynamics_C;
                       /* Computed Parameter: ExhaustCamPhaserActuatorDynamics_C
                        * Referenced by: '<S2>/Exhaust Cam Phaser  Actuator Dynamics'
                        */
  real_T VGTActuatorDynamics_A;     /* Computed Parameter: VGTActuatorDynamics_A
                                     * Referenced by: '<S2>/VGT Actuator Dynamics'
                                     */
  real_T VGTActuatorDynamics_C;     /* Computed Parameter: VGTActuatorDynamics_C
                                     * Referenced by: '<S2>/VGT Actuator Dynamics'
                                     */
  real_T EGRValveDynamics_A;           /* Computed Parameter: EGRValveDynamics_A
                                        * Referenced by: '<S2>/EGR Valve Dynamics'
                                        */
  real_T EGRValveDynamics_C;           /* Computed Parameter: EGRValveDynamics_C
                                        * Referenced by: '<S2>/EGR Valve Dynamics'
                                        */
  real_T VariableCompressionRatioActuatorDynamics_A;
               /* Computed Parameter: VariableCompressionRatioActuatorDynamics_A
                * Referenced by: '<S2>/Variable Compression Ratio Actuator Dynamics'
                */
  real_T VariableCompressionRatioActuatorDynamics_C;
               /* Computed Parameter: VariableCompressionRatioActuatorDynamics_C
                * Referenced by: '<S2>/Variable Compression Ratio Actuator Dynamics'
                */
  real_T VariableIntakeValveLiftActuatorDynamics_A;
                /* Computed Parameter: VariableIntakeValveLiftActuatorDynamics_A
                 * Referenced by: '<S2>/Variable Intake Valve Lift Actuator Dynamics'
                 */
  real_T VariableIntakeValveLiftActuatorDynamics_C;
                /* Computed Parameter: VariableIntakeValveLiftActuatorDynamics_C
                 * Referenced by: '<S2>/Variable Intake Valve Lift Actuator Dynamics'
                 */
  real_T VariableIntakeRunnerLengthActuatorDynamics_A;
             /* Computed Parameter: VariableIntakeRunnerLengthActuatorDynamics_A
              * Referenced by: '<S2>/Variable Intake Runner Length Actuator Dynamics'
              */
  real_T VariableIntakeRunnerLengthActuatorDynamics_C;
             /* Computed Parameter: VariableIntakeRunnerLengthActuatorDynamics_C
              * Referenced by: '<S2>/Variable Intake Runner Length Actuator Dynamics'
              */
  real_T SwirlValveActuatorDynamics_A;
                             /* Computed Parameter: SwirlValveActuatorDynamics_A
                              * Referenced by: '<S2>/Swirl Valve Actuator Dynamics'
                              */
  real_T SwirlValveActuatorDynamics_C;
                             /* Computed Parameter: SwirlValveActuatorDynamics_C
                              * Referenced by: '<S2>/Swirl Valve Actuator Dynamics'
                              */
  real_T Constant_Value_k;             /* Expression: 375
                                        * Referenced by: '<Root>/Constant'
                                        */
  uint32_T EngTrqTable_maxIndex[2];  /* Computed Parameter: EngTrqTable_maxIndex
                                      * Referenced by: '<S25>/EngTrq Table'
                                      */
  uint32_T IntkGasMassFlwTable_maxIndex[2];
                             /* Computed Parameter: IntkGasMassFlwTable_maxIndex
                              * Referenced by: '<S25>/IntkGasMassFlw Table'
                              */
  uint32_T FuelMassFlwTable_maxIndex[2];
                                /* Computed Parameter: FuelMassFlwTable_maxIndex
                                 * Referenced by: '<S25>/FuelMassFlw Table'
                                 */
  uint32_T BsfcTable_maxIndex[2];      /* Computed Parameter: BsfcTable_maxIndex
                                        * Referenced by: '<S25>/Bsfc Table'
                                        */
  uint32_T EoCOTable_maxIndex[2];      /* Computed Parameter: EoCOTable_maxIndex
                                        * Referenced by: '<S25>/EoCO Table'
                                        */
  uint32_T EoCO2Table_maxIndex[2];    /* Computed Parameter: EoCO2Table_maxIndex
                                       * Referenced by: '<S25>/EoCO2 Table'
                                       */
  uint32_T EoHCTable_maxIndex[2];      /* Computed Parameter: EoHCTable_maxIndex
                                        * Referenced by: '<S25>/EoHC Table'
                                        */
  uint32_T EoNOxTable_maxIndex[2];    /* Computed Parameter: EoNOxTable_maxIndex
                                       * Referenced by: '<S25>/EoNOx Table'
                                       */
  uint32_T ExhManGasTempTable_maxIndex[2];
                              /* Computed Parameter: ExhManGasTempTable_maxIndex
                               * Referenced by: '<S25>/ExhManGasTemp Table'
                               */
};

/* Real-time Model Data Structure */
struct tag_RTM_SiMappedEngine_T {
  struct SimStruct_tag *rtS;

  /*
   * The following structure contains memory needed to
   * track noncontinuous signals feeding derivative ports.
   */
  struct {
    real_T mr_nonContSig0[1];
    real_T mr_nonContSig1[1];
    real_T mr_nonContSig2[1];
  } NonContDerivMemory;

  ssNonContDerivSigInfo nonContDerivSignal[3];
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[119];
    int32_T* vardimsAddress[119];
    RTWLoggingFcnPtr loggingPtrs[119];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    int_T mdlref_GlobalTID[2];
  } Timing;
};

typedef struct {
  B_SiMappedEngine_c_T rtb;
  DW_SiMappedEngine_f_T rtdw;
  RT_MODEL_SiMappedEngine_T rtm;
} MdlrefDW_SiMappedEngine_T;

/* Model reference registration function */
extern void SiMappedEngine_initialize(SimStruct *const rtS,
  ssNonContDerivSigFeedingOutports **mr_nonContOutputArray, int_T mdlref_TID0,
  int_T mdlref_TID1, RT_MODEL_SiMappedEngine_T *const SiMappedEngine_M,
  B_SiMappedEngine_c_T *localB, DW_SiMappedEngine_f_T *localDW,
  X_SiMappedEngine_n_T *localX, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const
  char_T *rt_ChildPath, int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  SiMappedEngine_GetCAPIStaticMap(void);
extern void SiMappedEngine_Init(real_T *rty_Map, real_T *rty_Mat, real_T
  *rty_TurboSpd, real_T *rty_TurbPrsRatio, real_T *rty_CompPrsRatio, real_T
  *rty_TurbTempOut, real_T *rty_CompTempOut, real_T *rty_EgrPct, real_T
  *rty_EgrMassFlwRate, real_T *rty_EgrCoolerTempOut, real_T
  *rty_IntercoolerTempOut, real_T *rty_TPHC, real_T *rty_TPCO, real_T *rty_TPNOx,
  real_T *rty_Iat, real_T *rty_EgrVlvDeltaPrs, real_T *rty_EgrVlvInTemp, real_T *
  rty_CylPrs, real_T *rty_EngTrqCrk, real_T *rty_CrkAng, X_SiMappedEngine_n_T
  *localX);
extern void SiMappedEngine_Reset(X_SiMappedEngine_n_T *localX);
extern void SiMappedEngine_Start(RT_MODEL_SiMappedEngine_T * const
  SiMappedEngine_M, real_T *rty_Ect, DW_SiMappedEngine_f_T *localDW);
extern void SiMappedEngine_Deriv(const real_T *rtu_ThrPosPctCmd, const real_T
  *rtu_WgAreaPctCmd, const real_T *rtu_IntkCamPhaseCmd, const real_T
  *rtu_ExhCamPhaseCmd, const real_T *rtu_TurboRackPosCmd, const real_T
  *rtu_EgrVlvAreaPctCmd, const real_T *rtu_VarCompRatioPosCmd, const real_T
  *rtu_IntkVlvLiftCmd, const real_T *rtu_VarIntkRunLenCmd, const real_T
  *rtu_IntkSwirlVlvPosCmd, const real_T *rtu_TrqCmd, B_SiMappedEngine_c_T
  *localB, X_SiMappedEngine_n_T *localX, XDot_SiMappedEngine_n_T *localXdot);
extern void SiMappedEngine_ZC(real_T *rty_EngSpdOut, real_T *rty_ExhManGasTemp,
  ZCV_SiMappedEngine_g_T *localZCSV);
extern void SiMappedEngine_Disable(RT_MODEL_SiMappedEngine_T * const
  SiMappedEngine_M, DW_SiMappedEngine_f_T *localDW);
extern void SiMappedEngine_Update(RT_MODEL_SiMappedEngine_T * const
  SiMappedEngine_M);
extern void SiMappedEngine(RT_MODEL_SiMappedEngine_T * const SiMappedEngine_M,
  const real_T *rtu_ClsdLpFuelMult, const real_T *rtu_EngSpd, real_T *rty_EngTrq,
  real_T *rty_EngSpdOut, real_T *rty_Map, real_T *rty_Mat, real_T *rty_ThrPosPct,
  real_T *rty_WgAreaPct, real_T *rty_IntkCamPhase, real_T *rty_ExhCamPhase,
  real_T *rty_TurboRackPos, real_T *rty_EgrVlvAreaPct, real_T
  *rty_VarCompRatioPos, real_T *rty_IntkVlvLift, real_T *rty_VarIntkRunLen,
  real_T *rty_IntkSwirlVlvPos, real_T *rty_FuelFlw, real_T *rty_FuelVolFlw,
  real_T *rty_IntkPortFlw, real_T *rty_NormAirChrg, real_T *rty_ExhManGasTemp,
  real_T *rty_Afr, real_T *rty_TurboSpd, real_T *rty_TurbPrsRatio, real_T
  *rty_CompPrsRatio, real_T *rty_TurbTempOut, real_T *rty_CompTempOut, real_T
  *rty_EgrPct, real_T *rty_EgrMassFlwRate, real_T *rty_EgrCoolerTempOut, real_T *
  rty_IntercoolerTempOut, real_T *rty_BSFC, real_T *rty_TPHC, real_T *rty_TPCO,
  real_T *rty_TPNOx, real_T *rty_TPCO2, real_T *rty_Iat, real_T *rty_Ect, real_T
  *rty_EgrVlvDeltaPrs, real_T *rty_EgrVlvInTemp, real_T *rty_CylPrs, real_T
  *rty_EngTrqCrk, real_T *rty_CrkAng, B_SiMappedEngine_c_T *localB,
  DW_SiMappedEngine_f_T *localDW, X_SiMappedEngine_n_T *localX);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SiMappedEngine'
 * '<S1>'   : 'SiMappedEngine/Accessory Load Model'
 * '<S2>'   : 'SiMappedEngine/Actuators'
 * '<S3>'   : 'SiMappedEngine/Mapped SI Engine'
 * '<S4>'   : 'SiMappedEngine/Three-Way Catalyst'
 * '<S5>'   : 'SiMappedEngine/div0protect - poly1'
 * '<S6>'   : 'SiMappedEngine/Accessory Load Model/Accessory Load Model'
 * '<S7>'   : 'SiMappedEngine/Accessory Load Model/Power Accounting Bus Creator'
 * '<S8>'   : 'SiMappedEngine/Accessory Load Model/Power Accounting Bus Creator/No PwrStored Input'
 * '<S9>'   : 'SiMappedEngine/Accessory Load Model/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S10>'  : 'SiMappedEngine/Accessory Load Model/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S11>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation'
 * '<S12>'  : 'SiMappedEngine/Mapped SI Engine/Engine Crank Angle Calculation'
 * '<S13>'  : 'SiMappedEngine/Mapped SI Engine/Fuel Volume Flow'
 * '<S14>'  : 'SiMappedEngine/Mapped SI Engine/Load Calculation'
 * '<S15>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Core Engine'
 * '<S16>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Engine Power Info'
 * '<S17>'  : 'SiMappedEngine/Mapped SI Engine/SI Engine Torque without Boost Lag'
 * '<S18>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1'
 * '<S19>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2'
 * '<S20>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Compare To Constant'
 * '<S21>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly1/Compare To Constant1'
 * '<S22>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Compare To Constant'
 * '<S23>'  : 'SiMappedEngine/Mapped SI Engine/Afr Calculation/div0protect - poly2/Compare To Constant1'
 * '<S24>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input'
 * '<S25>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Core Engine/Without Temperature Input/Mapped Core Engine'
 * '<S26>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Engine Power Info/Power Accounting Bus Creator'
 * '<S27>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Engine Power Info/Power Accounting Bus Creator/No PwrStored Input'
 * '<S28>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Engine Power Info/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S29>'  : 'SiMappedEngine/Mapped SI Engine/Mapped Engine Power Info/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S30>'  : 'SiMappedEngine/Three-Way Catalyst/Catalyst  Non-Activated'
 * '<S31>'  : 'SiMappedEngine/Three-Way Catalyst/Catalyst Activated'
 * '<S32>'  : 'SiMappedEngine/div0protect - poly1/Compare To Constant'
 * '<S33>'  : 'SiMappedEngine/div0protect - poly1/Compare To Constant1'
 */
#endif                                 /* RTW_HEADER_SiMappedEngine_h_ */
