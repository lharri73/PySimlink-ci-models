/*
 * HevP4TransmissionController_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4TransmissionController".
 *
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:36 2022
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HevP4TransmissionController_capi_h
#define RTW_HEADER_HevP4TransmissionController_capi_h
#include "HevP4TransmissionController.h"

extern void HevP4TransmissionController_InitializeDataMapInfo
  (RT_MODEL_HevP4TransmissionController_T *const HevP4TransmissionController_M,
   B_HevP4TransmissionController_c_T *localB);

#endif                       /* RTW_HEADER_HevP4TransmissionController_capi_h */

/* EOF: HevP4TransmissionController_capi.h */
