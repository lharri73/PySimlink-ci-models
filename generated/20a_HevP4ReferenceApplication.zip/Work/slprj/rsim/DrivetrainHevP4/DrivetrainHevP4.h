/*
 * Code generation for system model 'DrivetrainHevP4'
 * For more details, see corresponding source file DrivetrainHevP4.c
 *
 */

#ifndef RTW_HEADER_DrivetrainHevP4_h_
#define RTW_HEADER_DrivetrainHevP4_h_
#include <string.h>
#include <math.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef DrivetrainHevP4_COMMON_INCLUDES_
#define DrivetrainHevP4_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rsim.h"
#endif                                 /* DrivetrainHevP4_COMMON_INCLUDES_ */

#include "DrivetrainHevP4_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rt_zcfcn.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Block signals for system '<S25>/Open Differential' */
typedef struct {
  real_T xdot[2];                      /* '<S25>/Open Differential' */
} B_OpenDifferential_DrivetrainHevP4_T;

/* Block signals for system '<S228>/Clutch' */
typedef struct {
  real_T Tout;                         /* '<S228>/Clutch' */
  real_T Tfmaxs;                       /* '<S228>/Clutch' */
  real_T Tout_e;                       /* '<S228>/Clutch' */
  real_T Tfmaxs_p;                     /* '<S228>/Clutch' */
  real_T Omega;                        /* '<S228>/Clutch' */
  real_T Omegadot;                     /* '<S228>/Clutch' */
  real_T Myb;                          /* '<S228>/Clutch' */
  real_T OutputInertia;                /* '<S235>/Output Inertia' */
  boolean_T CombinatorialLogic;        /* '<S241>/Combinatorial  Logic' */
  boolean_T RelationalOperator;        /* '<S245>/Relational Operator' */
} B_Clutch_DrivetrainHevP4_k_T;

/* Block states (default storage) for system '<S228>/Clutch' */
typedef struct {
  real_T lastMajorTime;                /* '<S228>/Clutch' */
  boolean_T UnitDelay_DSTATE;          /* '<S241>/Unit Delay' */
  int8_T TmpIfAtSlippingInport3_ActiveSubsystem;/* synthesized block */
  int8_T TmpIfAtLockedInport2_ActiveSubsystem;/* synthesized block */
  uint8_T is_active_c8_autolibshared;  /* '<S228>/Clutch' */
  uint8_T is_c8_autolibshared;         /* '<S228>/Clutch' */
} DW_Clutch_DrivetrainHevP4_k_T;

/* Continuous states for system '<S228>/Clutch' */
typedef struct {
  real_T omegaWheel;                   /* '<S235>/omega wheel' */
} X_Clutch_DrivetrainHevP4_n_T;

/* State derivatives for system '<S228>/Clutch' */
typedef struct {
  real_T omegaWheel;                   /* '<S235>/omega wheel' */
} XDot_Clutch_DrivetrainHevP4_p_T;

/* State Disabled for system '<S228>/Clutch' */
typedef struct {
  boolean_T omegaWheel;                /* '<S235>/omega wheel' */
} XDis_Clutch_DrivetrainHevP4_e_T;

/* Continuous State Absolute Tolerance for system '<S228>/Clutch' */
typedef struct {
  real_T omegaWheel;                   /* '<S235>/omega wheel' */
} XAbsTol_Clutch_DrivetrainHevP4_i_T;

/* Continuous State Perturb Min for system '<S228>/Clutch' */
typedef struct {
  real_T omegaWheel;                   /* '<S235>/omega wheel' */
} XPtMin_Clutch_DrivetrainHevP4_g_T;

/* Continuous State Perturb Max for system '<S228>/Clutch' */
typedef struct {
  real_T omegaWheel;                   /* '<S235>/omega wheel' */
} XPtMax_Clutch_DrivetrainHevP4_b_T;

/* Block signals for system '<S217>/Clutch' */
typedef struct {
  B_Clutch_DrivetrainHevP4_k_T sf_Clutch;/* '<S228>/Clutch' */
} B_CoreSubsys_DrivetrainHevP4_T;

/* Block states (default storage) for system '<S217>/Clutch' */
typedef struct {
  DW_Clutch_DrivetrainHevP4_k_T sf_Clutch;/* '<S228>/Clutch' */
} DW_CoreSubsys_DrivetrainHevP4_T;

/* Continuous states for system '<S217>/Clutch' */
typedef struct {
  X_Clutch_DrivetrainHevP4_n_T sf_Clutch;/* '<S228>/Clutch' */
} X_CoreSubsys_DrivetrainHevP4_T;

/* State derivatives for system '<S217>/Clutch' */
typedef struct {
  XDot_Clutch_DrivetrainHevP4_p_T sf_Clutch;/* '<S228>/Clutch' */
} XDot_CoreSubsys_DrivetrainHevP4_T;

/* State Disabled for system '<S217>/Clutch' */
typedef struct {
  XDis_Clutch_DrivetrainHevP4_e_T sf_Clutch;/* '<S228>/Clutch' */
} XDis_CoreSubsys_DrivetrainHevP4_T;

/* Continuous State Absolute Tolerance for system '<S217>/Clutch' */
typedef struct {
  XAbsTol_Clutch_DrivetrainHevP4_i_T sf_Clutch;/* '<S228>/Clutch' */
} XAbsTol_CoreSubsys_DrivetrainHevP4_T;

/* Continuous State Perturb Min for system '<S217>/Clutch' */
typedef struct {
  XPtMin_Clutch_DrivetrainHevP4_g_T sf_Clutch;/* '<S228>/Clutch' */
} XPtMin_CoreSubsys_DrivetrainHevP4_T;

/* Continuous State Perturb Max for system '<S217>/Clutch' */
typedef struct {
  XPtMax_Clutch_DrivetrainHevP4_b_T sf_Clutch;/* '<S228>/Clutch' */
} XPtMax_CoreSubsys_DrivetrainHevP4_T;

/* Block signals for system '<S217>/Clutch' */
typedef struct {
  B_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S217>/Clutch' */
} B_Clutch_DrivetrainHevP4_T;

/* Block states (default storage) for system '<S217>/Clutch' */
typedef struct {
  DW_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S217>/Clutch' */
} DW_Clutch_DrivetrainHevP4_T;

/* Continuous states for system '<S217>/Clutch' */
typedef struct {
  X_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S228>/CoreSubsys' */
} X_Clutch_DrivetrainHevP4_T;

/* State derivatives for system '<S217>/Clutch' */
typedef struct {
  XDot_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S228>/CoreSubsys' */
} XDot_Clutch_DrivetrainHevP4_T;

/* State Disabled for system '<S217>/Clutch' */
typedef struct {
  XDis_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S228>/CoreSubsys' */
} XDis_Clutch_DrivetrainHevP4_T;

/* Continuous State Absolute Tolerance for system '<S217>/Clutch' */
typedef struct {
  XAbsTol_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S228>/CoreSubsys' */
} XAbsTol_Clutch_DrivetrainHevP4_T;

/* Continuous State Perturb Min for system '<S217>/Clutch' */
typedef struct {
  XPtMin_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S228>/CoreSubsys' */
} XPtMin_Clutch_DrivetrainHevP4_T;

/* Continuous State Perturb Max for system '<S217>/Clutch' */
typedef struct {
  XPtMax_CoreSubsys_DrivetrainHevP4_T CoreSubsys[1];/* '<S228>/CoreSubsys' */
} XPtMax_Clutch_DrivetrainHevP4_T;

/* Block signals for system '<S213>/Simple Magic Tire' */
typedef struct {
  real_T Fx;                           /* '<S213>/Simple Magic Tire' */
  real_T My;                           /* '<S213>/Simple Magic Tire' */
} B_SimpleMagicTire_DrivetrainHevP4_T;

/* Block signals for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator;                   /* '<S169>/Integrator' */
  real_T VectorConcatenate2[3];        /* '<S166>/Vector Concatenate2' */
  real_T Constant;                     /* '<S163>/Constant' */
  real_T Saturation;                   /* '<S217>/Saturation' */
  real_T Integrator1;                  /* '<S164>/Integrator1' */
  real_T Memory;                       /* '<S14>/Memory' */
  real_T domega_o;                     /* '<S13>/domega_o' */
  real_T Integrator_h;                 /* '<S246>/Integrator' */
  real_T Signconvention;               /* '<S217>/Sign convention' */
  real_T Diskbrakeactuatorbore;        /* '<S232>/Disk brake actuator bore' */
  real_T TorqueConversion1;            /* '<S232>/Torque Conversion1' */
  real_T Numberofbrakepads;            /* '<S232>/Number of brake pads' */
  real_T D;                            /* '<S224>/Constant' */
  real_T C;                            /* '<S224>/Constant1' */
  real_T B;                            /* '<S224>/Constant7' */
  real_T E;                            /* '<S224>/Constant6' */
  real_T lam_muxConstant;              /* '<S208>/lam_muxConstant' */
  real_T Constant2[34];                /* '<S224>/Constant2' */
  real_T kappaFx[3];                   /* '<S224>/Constant19' */
  real_T FzFx[3];                      /* '<S224>/Constant12' */
  real_T FxMap[9];                     /* '<S224>/Constant14' */
  real_T TirePrsConstant;              /* '<S208>/TirePrsConstant' */
  real_T FNOMIN;                       /* '<S225>/Constant5' */
  real_T NOMPRES;                      /* '<S225>/Constant2' */
  real_T QSY1;                         /* '<S225>/Constant13' */
  real_T QSY2;                         /* '<S225>/Constant8' */
  real_T QSY3;                         /* '<S225>/Constant15' */
  real_T QSY4;                         /* '<S225>/Constant16' */
  real_T QSY5;                         /* '<S225>/Constant7' */
  real_T QSY6;                         /* '<S225>/Constant9' */
  real_T QSY7;                         /* '<S225>/Constant17' */
  real_T QSY8;                         /* '<S225>/Constant18' */
  real_T gamma;                        /* '<S225>/Constant11' */
  real_T lam_My;                       /* '<S225>/Constant10' */
  real_T UNLOADED_RADIUS;              /* '<S225>/Constant4' */
  real_T PRESMIN;                      /* '<S225>/Constant1' */
  real_T PRESMAX;                      /* '<S225>/Constant3' */
  real_T VxMy[3];                      /* '<S225>/Constant19' */
  real_T FzMy[3];                      /* '<S225>/Constant12' */
  real_T MyMap[9];                     /* '<S225>/Constant14' */
  real_T NOMPRES_g;                    /* '<S226>/Constant14' */
  real_T PRESMIN_p;                    /* '<S226>/Constant1' */
  real_T PRESMAX_l;                    /* '<S226>/Constant19' */
  real_T VERTICAL_STIFFNESS;           /* '<S226>/Constant2' */
  real_T VERTICAL_DAMPING;             /* '<S226>/Constant3' */
  real_T Q_RE0;                        /* '<S226>/Constant4' */
  real_T Q_V1;                         /* '<S226>/Constant5' */
  real_T Q_V2;                         /* '<S226>/Constant6' */
  real_T Q_FZ1;                        /* '<S226>/Constant7' */
  real_T Q_FZ2;                        /* '<S226>/Constant8' */
  real_T Q_FCX;                        /* '<S226>/Constant9' */
  real_T Q_FCY;                        /* '<S226>/Constant10' */
  real_T Q_CAM;                        /* '<S226>/Constant11' */
  real_T PFZ1;                         /* '<S226>/Constant16' */
  real_T Q_FCY2;                       /* '<S226>/Constant17' */
  real_T Q_CAM1;                       /* '<S226>/Constant13' */
  real_T Q_CAM2;                       /* '<S226>/Constant15' */
  real_T Q_CAM3;                       /* '<S226>/Constant21' */
  real_T Q_FYS1;                       /* '<S226>/Constant22' */
  real_T Q_FYS2;                       /* '<S226>/Constant18' */
  real_T Q_FYS3;                       /* '<S226>/Constant20' */
  real_T BOTTOM_OFFST;                 /* '<S226>/Constant24' */
  real_T BOTTOM_STIFF;                 /* '<S226>/Constant23' */
  real_T FxType;                       /* '<S208>/FxType' */
  real_T rollType;                     /* '<S208>/rollType' */
  real_T vertType;                     /* '<S208>/vertType' */
  real_T Saturation_f;                 /* '<S259>/Saturation' */
  real_T Integrator1_d;                /* '<S163>/Integrator1' */
  real_T Memory_f;                     /* '<S61>/Memory' */
  real_T domega_o_m;                   /* '<S60>/domega_o' */
  real_T Integrator_f;                 /* '<S288>/Integrator' */
  real_T Signconvention_o;             /* '<S259>/Sign convention' */
  real_T Diskbrakeactuatorbore_j;      /* '<S274>/Disk brake actuator bore' */
  real_T TorqueConversion1_b;          /* '<S274>/Torque Conversion1' */
  real_T Numberofbrakepads_f;          /* '<S274>/Number of brake pads' */
  real_T D_c;                          /* '<S266>/Constant' */
  real_T C_g;                          /* '<S266>/Constant1' */
  real_T B_d;                          /* '<S266>/Constant7' */
  real_T E_a;                          /* '<S266>/Constant6' */
  real_T lam_muxConstant_h;            /* '<S210>/lam_muxConstant' */
  real_T Constant2_p[34];              /* '<S266>/Constant2' */
  real_T kappaFx_j[3];                 /* '<S266>/Constant19' */
  real_T FzFx_l[3];                    /* '<S266>/Constant12' */
  real_T FxMap_h[9];                   /* '<S266>/Constant14' */
  real_T TirePrsConstant_a;            /* '<S210>/TirePrsConstant' */
  real_T FNOMIN_m;                     /* '<S267>/Constant5' */
  real_T NOMPRES_h;                    /* '<S267>/Constant2' */
  real_T QSY1_k;                       /* '<S267>/Constant13' */
  real_T QSY2_g;                       /* '<S267>/Constant8' */
  real_T QSY3_h;                       /* '<S267>/Constant15' */
  real_T QSY4_k;                       /* '<S267>/Constant16' */
  real_T QSY5_p;                       /* '<S267>/Constant7' */
  real_T QSY6_i;                       /* '<S267>/Constant9' */
  real_T QSY7_j;                       /* '<S267>/Constant17' */
  real_T QSY8_d;                       /* '<S267>/Constant18' */
  real_T gamma_e;                      /* '<S267>/Constant11' */
  real_T lam_My_a;                     /* '<S267>/Constant10' */
  real_T UNLOADED_RADIUS_k;            /* '<S267>/Constant4' */
  real_T PRESMIN_g;                    /* '<S267>/Constant1' */
  real_T PRESMAX_c;                    /* '<S267>/Constant3' */
  real_T VxMy_k[3];                    /* '<S267>/Constant19' */
  real_T FzMy_g[3];                    /* '<S267>/Constant12' */
  real_T MyMap_d[9];                   /* '<S267>/Constant14' */
  real_T NOMPRES_m;                    /* '<S268>/Constant14' */
  real_T PRESMIN_b;                    /* '<S268>/Constant1' */
  real_T PRESMAX_h;                    /* '<S268>/Constant19' */
  real_T VERTICAL_STIFFNESS_e;         /* '<S268>/Constant2' */
  real_T VERTICAL_DAMPING_h;           /* '<S268>/Constant3' */
  real_T Q_RE0_p;                      /* '<S268>/Constant4' */
  real_T Q_V1_i;                       /* '<S268>/Constant5' */
  real_T Q_V2_d;                       /* '<S268>/Constant6' */
  real_T Q_FZ1_o;                      /* '<S268>/Constant7' */
  real_T Q_FZ2_j;                      /* '<S268>/Constant8' */
  real_T Q_FCX_f;                      /* '<S268>/Constant9' */
  real_T Q_FCY_l;                      /* '<S268>/Constant10' */
  real_T Q_CAM_l;                      /* '<S268>/Constant11' */
  real_T PFZ1_g;                       /* '<S268>/Constant16' */
  real_T Q_FCY2_l;                     /* '<S268>/Constant17' */
  real_T Q_CAM1_m;                     /* '<S268>/Constant13' */
  real_T Q_CAM2_a;                     /* '<S268>/Constant15' */
  real_T Q_CAM3_h;                     /* '<S268>/Constant21' */
  real_T Q_FYS1_l;                     /* '<S268>/Constant22' */
  real_T Q_FYS2_o;                     /* '<S268>/Constant18' */
  real_T Q_FYS3_b;                     /* '<S268>/Constant20' */
  real_T BOTTOM_OFFST_g;               /* '<S268>/Constant24' */
  real_T BOTTOM_STIFF_e;               /* '<S268>/Constant23' */
  real_T FxType_b;                     /* '<S210>/FxType' */
  real_T rollType_m;                   /* '<S210>/rollType' */
  real_T vertType_o;                   /* '<S210>/vertType' */
  real_T VectorConcatenate5[3];        /* '<S169>/Vector Concatenate5' */
  real_T Constant2_n;                  /* '<S206>/Constant2' */
  real_T AirTempConstant;              /* '<S165>/AirTempConstant' */
  real_T Constant3;                    /* '<S206>/Constant3' */
  real_T MExtConstant[3];              /* '<S165>/MExtConstant' */
  real_T Fz;                           /* '<S169>/m' */
  real_T FExtConstant[3];              /* '<S165>/FExtConstant' */
  real_T Constant_f;                   /* '<S164>/Constant' */
  real_T TmpSignalConversionAtIntegratorInport1[2];
  real_T Constant_m;                   /* '<S196>/Constant' */
  real_T Constant_c;                   /* '<S168>/Constant' */
  real_T TmpSignalConversionAtProductInport2[3];
  real_T Sum;                          /* '<S144>/Sum' */
  real_T Memory_k;                     /* '<S87>/Memory' */
  real_T domega_o_h;                   /* '<S86>/domega_o' */
  real_T Memory_b;                     /* '<S150>/Memory' */
  real_T Constant2_pr;                 /* '<S149>/Constant2' */
  real_T ClutchGain;                   /* '<S149>/ClutchGain' */
  real_T IC;                           /* '<S129>/IC' */
  real_T Constant_n;                   /* '<S129>/Constant' */
  real_T Switch;                       /* '<S129>/Switch' */
  real_T IC_p;                         /* '<S134>/IC' */
  real_T Constant_d;                   /* '<S134>/Constant' */
  real_T Switch_h;                     /* '<S134>/Switch' */
  real_T IC_o;                         /* '<S128>/IC' */
  real_T Constant_nu;                  /* '<S128>/Constant' */
  real_T Switch_l;                     /* '<S128>/Switch' */
  real_T PwrStoredImp;                 /* '<S126>/Merge4' */
  real_T PwrStoredTurb;                /* '<S126>/Merge4' */
  real_T SumofElements1;               /* '<S135>/Sum of Elements1' */
  real_T Hz2rad;                       /* '<S149>/Hz2rad' */
  real_T SpdRatio;                     /* '<S126>/Merge2' */
  real_T DataTypeConversion;           /* '<S149>/Data Type Conversion' */
  real_T Product;                      /* '<S150>/Product' */
  real_T Constant_cv;                  /* '<S2>/Constant' */
  real_T upi;                          /* '<S94>/2*pi' */
  real_T Constant1;                    /* '<S94>/Constant1' */
  real_T Memory_o;                     /* '<S96>/Memory' */
  real_T Switch_p;                     /* '<S96>/Switch' */
  real_T Constant_p;                   /* '<S97>/Constant' */
  real_T IC_f;                         /* '<S97>/IC' */
  real_T Switch_a;                     /* '<S97>/Switch' */
  real_T Memory_ku;                    /* '<S78>/Memory' */
  real_T domega_o_j;                   /* '<S77>/domega_o' */
  real_T IC_b;                         /* '<S101>/IC' */
  real_T Constant_cg;                  /* '<S101>/Constant' */
  real_T Switch_ht;                    /* '<S101>/Switch' */
  real_T IC_a;                         /* '<S99>/IC' */
  real_T Constant_ml;                  /* '<S99>/Constant' */
  real_T Switch_px;                    /* '<S99>/Switch' */
  real_T omega_c;                      /* '<S77>/omega_c' */
  real_T diffDir;                      /* '<S29>/Switch' */
  real_T VectorConcatenate[2];         /* '<S25>/Vector Concatenate' */
  real_T Subtract;                     /* '<S77>/Subtract' */
  real_T Product_d;                    /* '<S78>/Product' */
  real_T omega_c_o;                    /* '<S86>/omega_c' */
  real_T Subtract_n;                   /* '<S86>/Subtract' */
  real_T Product_o;                    /* '<S87>/Product' */
  real_T Constant_g;                   /* '<S58>/Constant' */
  real_T diffDir_n;                    /* '<S46>/Switch' */
  real_T VectorConcatenate_b[2];       /* '<S42>/Vector Concatenate' */
  real_T Integrator_p[2];              /* '<S42>/Integrator' */
  real_T UnaryMinus1[2];               /* '<S46>/Unary Minus1' */
  real_T VectorConcatenate_o[4];       /* '<S46>/Vector Concatenate' */
  real_T Constant_pg;                  /* '<S56>/Constant' */
  real_T Constant_cc;                  /* '<S54>/Constant' */
  real_T Product4;                     /* '<S54>/Product4' */
  real_T Constant_j;                   /* '<S55>/Constant' */
  real_T Product4_o;                   /* '<S55>/Product4' */
  real_T bw1;                          /* '<S42>/bw1' */
  real_T bd;                           /* '<S42>/bd' */
  real_T bw2;                          /* '<S42>/bw2' */
  real_T Ndiff2;                       /* '<S42>/Ndiff2' */
  real_T Jd;                           /* '<S42>/Jd' */
  real_T Jw1;                          /* '<S42>/Jw1' */
  real_T Jw3;                          /* '<S42>/Jw3' */
  real_T diffDir_g;                    /* '<S49>/Switch1' */
  real_T omega_c_l;                    /* '<S13>/omega_c' */
  real_T UnaryMinus1_l[2];             /* '<S29>/Unary Minus1' */
  real_T Switch_n;                     /* '<S14>/Switch' */
  real_T Constant_o;                   /* '<S41>/Constant' */
  real_T Constant_dy;                  /* '<S39>/Constant' */
  real_T Constant_b;                   /* '<S37>/Constant' */
  real_T Constant_cx;                  /* '<S38>/Constant' */
  real_T bw1_j;                        /* '<S25>/bw1' */
  real_T bd_o;                         /* '<S25>/bd' */
  real_T bw2_b;                        /* '<S25>/bw2' */
  real_T Ndiff2_c;                     /* '<S25>/Ndiff2' */
  real_T Jd_m;                         /* '<S25>/Jd' */
  real_T Jw1_n;                        /* '<S25>/Jw1' */
  real_T Jw3_h;                        /* '<S25>/Jw3' */
  real_T diffDir_o;                    /* '<S32>/Switch1' */
  real_T omega_c_n;                    /* '<S60>/omega_c' */
  real_T Switch_c;                     /* '<S61>/Switch' */
  real_T Constant2_f;                  /* '<S230>/Constant2' */
  real_T Constant_h;                   /* '<S248>/Constant' */
  real_T Constant_hu;                  /* '<S249>/Constant' */
  real_T Constant2_m;                  /* '<S272>/Constant2' */
  real_T Constant_pk;                  /* '<S290>/Constant' */
  real_T Constant_jn;                  /* '<S291>/Constant' */
  real_T Constant_l;                   /* '<S153>/Constant' */
  real_T VectorConcatenate_a[11];      /* '<S154>/Vector Concatenate' */
  real_T MinMax;                       /* '<S154>/MinMax' */
  real_T Constant_hd;                  /* '<S160>/Constant' */
  real_T Constant_fo;                  /* '<S161>/Constant' */
  real_T Constant_fd;                  /* '<S162>/Constant' */
  real_T Constant_e;                   /* '<S158>/Constant' */
  real_T Constant_pm;                  /* '<S154>/Constant' */
  real_T phi;                          /* '<S154>/Switch' */
  real_T Gain;                         /* '<S154>/Gain' */
  real_T phi_a[10];                    /* '<S152>/phi' */
  real_T zeta[10];                     /* '<S152>/zeta' */
  real_T psi[10];                      /* '<S152>/psi' */
  real_T Constant1_m;                  /* '<S152>/Constant1' */
  real_T ImpellerInertia;              /* '<S133>/Impeller Inertia' */
  real_T TurbineInertia;               /* '<S133>/Turbine Inertia' */
  real_T Integrator_k;                 /* '<S157>/Integrator' */
  real_T Product_f;                    /* '<S157>/Product' */
  real_T PwrCltchLoss_k;               /* '<S132>/Constant1' */
  real_T PwrFluidHeatLoss_d;           /* '<S132>/Constant2' */
  real_T Inertia;                      /* '<S132>/Inertia' */
  real_T N;                            /* '<S120>/Gear2Ratios' */
  real_T Neutral;                      /* '<S100>/Neutral' */
  real_T NoInputTorque;                /* '<S100>/No Input Torque' */
  real_T Constant_j5;                  /* '<S118>/Constant' */
  real_T First;                        /* '<S100>/First' */
  real_T Constant_a;                   /* '<S122>/Constant' */
  real_T Constant_oj;                  /* '<S123>/Constant' */
  real_T Product4_a;                   /* '<S100>/Product4' */
  real_T Product8;                     /* '<S100>/Product8' */
  real_T N_c;                          /* '<S112>/Gear2Ratios' */
  real_T Constant_ae;                  /* '<S109>/Constant' */
  real_T Constant_cw;                  /* '<S110>/Constant' */
  real_T Constant_ps;                  /* '<S114>/Constant' */
  real_T Constant_l5;                  /* '<S115>/Constant' */
  real_T Product8_e;                   /* '<S98>/Product8' */
  real_T Gain_c;                       /* '<S5>/Gain' */
  real_T product;                      /* '<S232>/product' */
  real_T DisallowNegativeBrakeTorque;
                                   /* '<S232>/Disallow Negative Brake Torque' */
  real_T TorqueConversion;             /* '<S232>/Torque Conversion' */
  real_T Ratioofstatictokinetic;       /* '<S229>/Ratio of static to kinetic' */
  real_T Fx;                           /* '<S5>/Add' */
  real_T Gain1;                        /* '<S5>/Gain1' */
  real_T product_p;                    /* '<S274>/product' */
  real_T DisallowNegativeBrakeTorque_m;
                                   /* '<S274>/Disallow Negative Brake Torque' */
  real_T TorqueConversion_b;           /* '<S274>/Torque Conversion' */
  real_T Ratioofstatictokinetic_i;     /* '<S271>/Ratio of static to kinetic' */
  real_T Fx_o;                         /* '<S5>/Add1' */
  real_T VectorConcatenate5_e[3];      /* '<S207>/Vector Concatenate5' */
  real_T UnaryMinus[3];                /* '<S169>/Unary Minus' */
  real_T Add1[3];                      /* '<S206>/Add1' */
  real_T Product_g[3];                 /* '<S206>/Product' */
  real_T SumofElements;                /* '<S206>/Sum of Elements' */
  real_T Sqrt;                         /* '<S206>/Sqrt' */
  real_T Product2;                     /* '<S206>/Product2' */
  real_T TrigonometricFunction;        /* '<S206>/Trigonometric Function' */
  real_T u[3];                         /* '<S206>/4' */
  real_T Tanh[3];                      /* '<S206>/Tanh' */
  real_T VectorConcatenate_n[6];       /* '<S206>/Vector Concatenate' */
  real_T Product1[6];                  /* '<S206>/Product1' */
  real_T uAPabsRT[6];                  /* '<S206>/.5.*A.*Pabs.//R.//T' */
  real_T Product4_k[3];                /* '<S206>/Product4' */
  real_T Add6;                         /* '<S169>/Add6' */
  real_T UnitConversion;               /* '<S166>/Unit Conversion' */
  real_T TrigonometricFunction2_o1;    /* '<S169>/Trigonometric Function2' */
  real_T TrigonometricFunction2_o2;    /* '<S169>/Trigonometric Function2' */
  real_T Product2_a;                   /* '<S169>/Product2' */
  real_T Product3[3];                  /* '<S206>/Product3' */
  real_T Add1_p;                       /* '<S169>/Add1' */
  real_T b;                            /* '<S169>/b' */
  real_T Product1_l;                   /* '<S169>/Product1' */
  real_T Add;                          /* '<S169>/Add' */
  real_T Add3;                         /* '<S169>/Add3' */
  real_T h;                            /* '<S169>/h' */
  real_T Add2;                         /* '<S169>/Add2' */
  real_T a;                            /* '<S169>/a' */
  real_T Add4;                         /* '<S169>/Add4' */
  real_T VectorConcatenate4[4];        /* '<S169>/Vector Concatenate4' */
  real_T Selector1[2];                 /* '<S178>/Selector1' */
  real_T Fz_a;                         /* '<S178>/1//NR' */
  real_T Sum_c;                        /* '<S163>/Sum' */
  real_T Divide;                       /* '<S163>/Divide' */
  real_T Fz_f;                         /* '<S178>/1//NF' */
  real_T Sum_l;                        /* '<S164>/Sum' */
  real_T Divide_l;                     /* '<S164>/Divide' */
  real_T Add_m;                        /* '<S174>/Add' */
  real_T TmpSignalConversionAtsincosInport1[3];
  real_T sincos_o1[3];                 /* '<S197>/sincos' */
  real_T sincos_o2[3];                 /* '<S197>/sincos' */
  real_T VectorConcatenate_m[9];       /* '<S198>/Vector Concatenate' */
  real_T TmpSignalConversionAtsincosInport1_n[3];
  real_T sincos_o1_j[3];               /* '<S204>/sincos' */
  real_T sincos_o2_l[3];               /* '<S204>/sincos' */
  real_T VectorConcatenate_l[9];       /* '<S205>/Vector Concatenate' */
  real_T Transpose[9];                 /* '<S168>/Transpose' */
  real_T Product_fl[3];                /* '<S168>/Product' */
  real_T VectorConcatenate1[3];        /* '<S166>/Vector Concatenate1' */
  real_T VectorConcatenate4_l[2];      /* '<S166>/Vector Concatenate4' */
  real_T VectorConcatenate6[3];        /* '<S166>/Vector Concatenate6' */
  real_T xddot;                        /* '<S169>/1//m' */
  real_T VectorConcatenate1_f[2];      /* '<S169>/Vector Concatenate1' */
  real_T Sum_j;                        /* '<S96>/Sum' */
  real_T Product_a;                    /* '<S96>/Product' */
  real_T Product1_d;                   /* '<S56>/Product1' */
  real_T Switch_cp;                    /* '<S56>/Switch' */
  real_T UnaryMinus2[2];               /* '<S49>/Unary Minus2' */
  real_T Product1_p[2];                /* '<S49>/Product1' */
  real_T Gain1_h[2];                   /* '<S49>/Gain1' */
  real_T omegadot[3];                  /* '<S49>/Vector Concatenate' */
  real_T Subtract_l;                   /* '<S13>/Subtract' */
  real_T Sum_h;                        /* '<S14>/Sum' */
  real_T Product_m;                    /* '<S14>/Product' */
  real_T Subtract_e;                   /* '<S60>/Subtract' */
  real_T Sum_cw;                       /* '<S61>/Sum' */
  real_T Product_b;                    /* '<S61>/Product' */
  real_T Product_g3;                   /* '<S230>/Product' */
  real_T Add_g;                        /* '<S230>/Add' */
  real_T Product3_c;                   /* '<S230>/Product3' */
  real_T Fcn;                          /* '<S247>/Fcn' */
  real_T Abs;                          /* '<S247>/Abs' */
  real_T Switch_f;                     /* '<S247>/Switch' */
  real_T Product2_o;                   /* '<S230>/Product2' */
  real_T Sum_i;                        /* '<S246>/Sum' */
  real_T Product_o4;                   /* '<S246>/Product' */
  real_T Product_fv;                   /* '<S272>/Product' */
  real_T Add_a;                        /* '<S272>/Add' */
  real_T Product3_a;                   /* '<S272>/Product3' */
  real_T Fcn_b;                        /* '<S289>/Fcn' */
  real_T Abs_f;                        /* '<S289>/Abs' */
  real_T Switch_m;                     /* '<S289>/Switch' */
  real_T Product2_j;                   /* '<S272>/Product2' */
  real_T Sum_e;                        /* '<S288>/Sum' */
  real_T Product_de;                   /* '<S288>/Product' */
  real_T ImpAsg_InsertedFor_Omega_at_inport_0;/* '<S270>/Clutch' */
  real_T ImpAsg_InsertedFor_Omega_at_inport_0_i;/* '<S228>/Clutch' */
  boolean_T VelocitiesMatch;           /* '<S144>/Velocities Match' */
  boolean_T Memory_kc;                 /* '<S145>/Memory' */
  boolean_T LowerRelop1;               /* '<S159>/LowerRelop1' */
  boolean_T UpperRelop;                /* '<S159>/UpperRelop' */
  boolean_T Compare;                   /* '<S155>/Compare' */
  boolean_T HiddenBuf_InsertedFor_LPF_at_inport_2;/* '<S153>/Compare To Zero' */
  boolean_T Compare_i;                 /* '<S248>/Compare' */
  boolean_T Compare_a;                 /* '<S249>/Compare' */
  boolean_T LogicalOperator;           /* '<S247>/Logical Operator' */
  boolean_T Compare_e;                 /* '<S290>/Compare' */
  boolean_T Compare_l;                 /* '<S291>/Compare' */
  boolean_T LogicalOperator_h;         /* '<S289>/Logical Operator' */
  B_SimpleMagicTire_DrivetrainHevP4_T sf_SimpleMagicTire_c;/* '<S255>/Simple Magic Tire' */
  B_SimpleMagicTire_DrivetrainHevP4_T sf_SimpleMagicTire;/* '<S213>/Simple Magic Tire' */
  B_OpenDifferential_DrivetrainHevP4_T sf_OpenDifferential_l;/* '<S42>/Open Differential' */
  B_Clutch_DrivetrainHevP4_T Clutch_e; /* '<S259>/Clutch' */
  B_Clutch_DrivetrainHevP4_T Clutch;   /* '<S217>/Clutch' */
  B_OpenDifferential_DrivetrainHevP4_T sf_OpenDifferential;/* '<S25>/Open Differential' */
} B_DrivetrainHevP4_c_T;

/* Block states (default storage) for model 'DrivetrainHevP4' */
typedef struct {
  real_T Memory_PreviousInput;         /* '<S14>/Memory' */
  real_T Memory_PreviousInput_f;       /* '<S61>/Memory' */
  real_T Memory_PreviousInput_e;       /* '<S87>/Memory' */
  real_T Memory_PreviousInput_d;       /* '<S150>/Memory' */
  real_T Memory_PreviousInput_j;       /* '<S96>/Memory' */
  real_T Memory_PreviousInput_h;       /* '<S78>/Memory' */
  uint32_T speedratioPrelookup_DWORK1; /* '<S152>/speed ratio Prelookup' */
  int_T Integrator_IWORK;              /* '<S14>/Integrator' */
  int_T Integrator_IWORK_m;            /* '<S61>/Integrator' */
  int_T Integrator_IWORK_d;            /* '<S87>/Integrator' */
  int_T Integrator_IWORK_h;            /* '<S150>/Integrator' */
  int_T Integrator_IWORK_n;            /* '<S96>/Integrator' */
  int_T Integrator_IWORK_l;            /* '<S78>/Integrator' */
  int_T Integrator_IWORK_j;            /* '<S25>/Integrator' */
  int_T Integrator_IWORK_mn;           /* '<S42>/Integrator' */
  int_T PumpIntegrator_IWORK;          /* '<S133>/Pump Integrator' */
  int_T TurbineIntegrator_IWORK;       /* '<S133>/Turbine Integrator' */
  int_T LockedShaftIntegrator_IWORK;   /* '<S132>/Locked Shaft Integrator' */
  int_T xe_IWORK;                      /* '<S100>/xe' */
  int_T xv_IWORK;                      /* '<S100>/xv' */
  int_T x_IWORK;                       /* '<S98>/x' */
  int_T VelocitiesMatch_MODE;          /* '<S144>/Velocities Match' */
  int_T Saturation_MODE;               /* '<S151>/Saturation' */
  int_T Abs_MODE;                      /* '<S135>/Abs' */
  int_T PumpIntegrator_MODE;           /* '<S133>/Pump Integrator' */
  int_T TurbineIntegrator_MODE;        /* '<S133>/Turbine Integrator' */
  int_T MinMax_MODE;                   /* '<S154>/MinMax' */
  int_T Abs_MODE_n;                    /* '<S100>/Abs' */
  int_T Abs_MODE_g;                    /* '<S98>/Abs' */
  int8_T If_ActiveSubsystem;           /* '<S126>/If' */
  int8_T If_ActiveSubsystem_b;         /* '<S94>/If' */
  int8_T Sqrt_DWORK1;                  /* '<S206>/Sqrt' */
  boolean_T Memory_PreviousInput_jb;   /* '<S145>/Memory' */
  boolean_T IC_FirstOutputTime;        /* '<S129>/IC' */
  boolean_T IC_FirstOutputTime_d;      /* '<S134>/IC' */
  boolean_T IC_FirstOutputTime_m;      /* '<S128>/IC' */
  boolean_T Relay1_Mode;               /* '<S149>/Relay1' */
  boolean_T RelationalOperator_Mode;   /* '<S149>/Relational Operator' */
  boolean_T IC_FirstOutputTime_k;      /* '<S97>/IC' */
  boolean_T IC_FirstOutputTime_f;      /* '<S101>/IC' */
  boolean_T IC_FirstOutputTime_j;      /* '<S99>/IC' */
  boolean_T LowerRelop1_Mode;          /* '<S159>/LowerRelop1' */
  boolean_T UpperRelop_Mode;           /* '<S159>/UpperRelop' */
  boolean_T LPF_MODE;                  /* '<S153>/LPF' */
  DW_Clutch_DrivetrainHevP4_T Clutch_e;/* '<S259>/Clutch' */
  DW_Clutch_DrivetrainHevP4_T Clutch;  /* '<S217>/Clutch' */
} DW_DrivetrainHevP4_f_T;

/* Continuous states for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S169>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S164>/Integrator1' */
  real_T Integrator_CSTATE_a;          /* '<S14>/Integrator' */
  real_T Integrator_CSTATE_c;          /* '<S13>/Integrator' */
  real_T Integrator_CSTATE_h;          /* '<S246>/Integrator' */
  real_T Integrator1_CSTATE_g;         /* '<S163>/Integrator1' */
  real_T Integrator_CSTATE_l;          /* '<S61>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S60>/Integrator' */
  real_T Integrator_CSTATE_hm;         /* '<S288>/Integrator' */
  real_T Integrator_CSTATE_d[2];       /* '<S3>/Integrator' */
  real_T Integrator3_CSTATE;           /* '<S177>/Integrator3' */
  real_T Integrator1_CSTATE_f;         /* '<S166>/Integrator1' */
  real_T Integrator_CSTATE_de;         /* '<S87>/Integrator' */
  real_T Integrator_CSTATE_g;          /* '<S86>/Integrator' */
  real_T Integrator_CSTATE_b;          /* '<S150>/Integrator' */
  real_T Integrator_CSTATE_h1;         /* '<S96>/Integrator' */
  real_T Integrator_CSTATE_j;          /* '<S78>/Integrator' */
  real_T Integrator_CSTATE_g4;         /* '<S77>/Integrator' */
  real_T Integrator_CSTATE_o[2];       /* '<S25>/Integrator' */
  real_T Integrator_CSTATE_n[2];       /* '<S42>/Integrator' */
  real_T PumpIntegrator_CSTATE;        /* '<S133>/Pump Integrator' */
  real_T TurbineIntegrator_CSTATE;     /* '<S133>/Turbine Integrator' */
  real_T Integrator_CSTATE_e;          /* '<S157>/Integrator' */
  real_T LockedShaftIntegrator_CSTATE; /* '<S132>/Locked Shaft Integrator' */
  real_T we;                           /* '<S100>/xe' */
  real_T wv;                           /* '<S100>/xv' */
  real_T w;                            /* '<S98>/x' */
  X_Clutch_DrivetrainHevP4_T Clutch_e; /* '<S217>/Clutch' */
  X_Clutch_DrivetrainHevP4_T Clutch;   /* '<S217>/Clutch' */
} X_DrivetrainHevP4_n_T;

/* State derivatives for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S169>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S164>/Integrator1' */
  real_T Integrator_CSTATE_a;          /* '<S14>/Integrator' */
  real_T Integrator_CSTATE_c;          /* '<S13>/Integrator' */
  real_T Integrator_CSTATE_h;          /* '<S246>/Integrator' */
  real_T Integrator1_CSTATE_g;         /* '<S163>/Integrator1' */
  real_T Integrator_CSTATE_l;          /* '<S61>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S60>/Integrator' */
  real_T Integrator_CSTATE_hm;         /* '<S288>/Integrator' */
  real_T Integrator_CSTATE_d[2];       /* '<S3>/Integrator' */
  real_T Integrator3_CSTATE;           /* '<S177>/Integrator3' */
  real_T Integrator1_CSTATE_f;         /* '<S166>/Integrator1' */
  real_T Integrator_CSTATE_de;         /* '<S87>/Integrator' */
  real_T Integrator_CSTATE_g;          /* '<S86>/Integrator' */
  real_T Integrator_CSTATE_b;          /* '<S150>/Integrator' */
  real_T Integrator_CSTATE_h1;         /* '<S96>/Integrator' */
  real_T Integrator_CSTATE_j;          /* '<S78>/Integrator' */
  real_T Integrator_CSTATE_g4;         /* '<S77>/Integrator' */
  real_T Integrator_CSTATE_o[2];       /* '<S25>/Integrator' */
  real_T Integrator_CSTATE_n[2];       /* '<S42>/Integrator' */
  real_T PumpIntegrator_CSTATE;        /* '<S133>/Pump Integrator' */
  real_T TurbineIntegrator_CSTATE;     /* '<S133>/Turbine Integrator' */
  real_T Integrator_CSTATE_e;          /* '<S157>/Integrator' */
  real_T LockedShaftIntegrator_CSTATE; /* '<S132>/Locked Shaft Integrator' */
  real_T we;                           /* '<S100>/xe' */
  real_T wv;                           /* '<S100>/xv' */
  real_T w;                            /* '<S98>/x' */
  XDot_Clutch_DrivetrainHevP4_T Clutch_e;/* '<S217>/Clutch' */
  XDot_Clutch_DrivetrainHevP4_T Clutch;/* '<S217>/Clutch' */
} XDot_DrivetrainHevP4_n_T;

/* State Disabled for model 'DrivetrainHevP4' */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<S169>/Integrator' */
  boolean_T Integrator1_CSTATE;        /* '<S164>/Integrator1' */
  boolean_T Integrator_CSTATE_a;       /* '<S14>/Integrator' */
  boolean_T Integrator_CSTATE_c;       /* '<S13>/Integrator' */
  boolean_T Integrator_CSTATE_h;       /* '<S246>/Integrator' */
  boolean_T Integrator1_CSTATE_g;      /* '<S163>/Integrator1' */
  boolean_T Integrator_CSTATE_l;       /* '<S61>/Integrator' */
  boolean_T Integrator_CSTATE_i;       /* '<S60>/Integrator' */
  boolean_T Integrator_CSTATE_hm;      /* '<S288>/Integrator' */
  boolean_T Integrator_CSTATE_d[2];    /* '<S3>/Integrator' */
  boolean_T Integrator3_CSTATE;        /* '<S177>/Integrator3' */
  boolean_T Integrator1_CSTATE_f;      /* '<S166>/Integrator1' */
  boolean_T Integrator_CSTATE_de;      /* '<S87>/Integrator' */
  boolean_T Integrator_CSTATE_g;       /* '<S86>/Integrator' */
  boolean_T Integrator_CSTATE_b;       /* '<S150>/Integrator' */
  boolean_T Integrator_CSTATE_h1;      /* '<S96>/Integrator' */
  boolean_T Integrator_CSTATE_j;       /* '<S78>/Integrator' */
  boolean_T Integrator_CSTATE_g4;      /* '<S77>/Integrator' */
  boolean_T Integrator_CSTATE_o[2];    /* '<S25>/Integrator' */
  boolean_T Integrator_CSTATE_n[2];    /* '<S42>/Integrator' */
  boolean_T PumpIntegrator_CSTATE;     /* '<S133>/Pump Integrator' */
  boolean_T TurbineIntegrator_CSTATE;  /* '<S133>/Turbine Integrator' */
  boolean_T Integrator_CSTATE_e;       /* '<S157>/Integrator' */
  boolean_T LockedShaftIntegrator_CSTATE;/* '<S132>/Locked Shaft Integrator' */
  boolean_T we;                        /* '<S100>/xe' */
  boolean_T wv;                        /* '<S100>/xv' */
  boolean_T w;                         /* '<S98>/x' */
  XDis_Clutch_DrivetrainHevP4_T Clutch_e;/* '<S217>/Clutch' */
  XDis_Clutch_DrivetrainHevP4_T Clutch;/* '<S217>/Clutch' */
} XDis_DrivetrainHevP4_n_T;

/* Continuous State Absolute Tolerance for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S169>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S164>/Integrator1' */
  real_T Integrator_CSTATE_a;          /* '<S14>/Integrator' */
  real_T Integrator_CSTATE_c;          /* '<S13>/Integrator' */
  real_T Integrator_CSTATE_h;          /* '<S246>/Integrator' */
  real_T Integrator1_CSTATE_g;         /* '<S163>/Integrator1' */
  real_T Integrator_CSTATE_l;          /* '<S61>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S60>/Integrator' */
  real_T Integrator_CSTATE_hm;         /* '<S288>/Integrator' */
  real_T Integrator_CSTATE_d[2];       /* '<S3>/Integrator' */
  real_T Integrator3_CSTATE;           /* '<S177>/Integrator3' */
  real_T Integrator1_CSTATE_f;         /* '<S166>/Integrator1' */
  real_T Integrator_CSTATE_de;         /* '<S87>/Integrator' */
  real_T Integrator_CSTATE_g;          /* '<S86>/Integrator' */
  real_T Integrator_CSTATE_b;          /* '<S150>/Integrator' */
  real_T Integrator_CSTATE_h1;         /* '<S96>/Integrator' */
  real_T Integrator_CSTATE_j;          /* '<S78>/Integrator' */
  real_T Integrator_CSTATE_g4;         /* '<S77>/Integrator' */
  real_T Integrator_CSTATE_o[2];       /* '<S25>/Integrator' */
  real_T Integrator_CSTATE_n[2];       /* '<S42>/Integrator' */
  real_T PumpIntegrator_CSTATE;        /* '<S133>/Pump Integrator' */
  real_T TurbineIntegrator_CSTATE;     /* '<S133>/Turbine Integrator' */
  real_T Integrator_CSTATE_e;          /* '<S157>/Integrator' */
  real_T LockedShaftIntegrator_CSTATE; /* '<S132>/Locked Shaft Integrator' */
  real_T we;                           /* '<S100>/xe' */
  real_T wv;                           /* '<S100>/xv' */
  real_T w;                            /* '<S98>/x' */
  XAbsTol_Clutch_DrivetrainHevP4_T Clutch_e;/* '<S217>/Clutch' */
  XAbsTol_Clutch_DrivetrainHevP4_T Clutch;/* '<S217>/Clutch' */
} XAbsTol_DrivetrainHevP4_T;

/* Continuous State Perturb Min for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S169>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S164>/Integrator1' */
  real_T Integrator_CSTATE_a;          /* '<S14>/Integrator' */
  real_T Integrator_CSTATE_c;          /* '<S13>/Integrator' */
  real_T Integrator_CSTATE_h;          /* '<S246>/Integrator' */
  real_T Integrator1_CSTATE_g;         /* '<S163>/Integrator1' */
  real_T Integrator_CSTATE_l;          /* '<S61>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S60>/Integrator' */
  real_T Integrator_CSTATE_hm;         /* '<S288>/Integrator' */
  real_T Integrator_CSTATE_d[2];       /* '<S3>/Integrator' */
  real_T Integrator3_CSTATE;           /* '<S177>/Integrator3' */
  real_T Integrator1_CSTATE_f;         /* '<S166>/Integrator1' */
  real_T Integrator_CSTATE_de;         /* '<S87>/Integrator' */
  real_T Integrator_CSTATE_g;          /* '<S86>/Integrator' */
  real_T Integrator_CSTATE_b;          /* '<S150>/Integrator' */
  real_T Integrator_CSTATE_h1;         /* '<S96>/Integrator' */
  real_T Integrator_CSTATE_j;          /* '<S78>/Integrator' */
  real_T Integrator_CSTATE_g4;         /* '<S77>/Integrator' */
  real_T Integrator_CSTATE_o[2];       /* '<S25>/Integrator' */
  real_T Integrator_CSTATE_n[2];       /* '<S42>/Integrator' */
  real_T PumpIntegrator_CSTATE;        /* '<S133>/Pump Integrator' */
  real_T TurbineIntegrator_CSTATE;     /* '<S133>/Turbine Integrator' */
  real_T Integrator_CSTATE_e;          /* '<S157>/Integrator' */
  real_T LockedShaftIntegrator_CSTATE; /* '<S132>/Locked Shaft Integrator' */
  real_T we;                           /* '<S100>/xe' */
  real_T wv;                           /* '<S100>/xv' */
  real_T w;                            /* '<S98>/x' */
  XPtMin_Clutch_DrivetrainHevP4_T Clutch_e;/* '<S217>/Clutch' */
  XPtMin_Clutch_DrivetrainHevP4_T Clutch;/* '<S217>/Clutch' */
} XPtMin_DrivetrainHevP4_T;

/* Continuous State Perturb Max for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S169>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S164>/Integrator1' */
  real_T Integrator_CSTATE_a;          /* '<S14>/Integrator' */
  real_T Integrator_CSTATE_c;          /* '<S13>/Integrator' */
  real_T Integrator_CSTATE_h;          /* '<S246>/Integrator' */
  real_T Integrator1_CSTATE_g;         /* '<S163>/Integrator1' */
  real_T Integrator_CSTATE_l;          /* '<S61>/Integrator' */
  real_T Integrator_CSTATE_i;          /* '<S60>/Integrator' */
  real_T Integrator_CSTATE_hm;         /* '<S288>/Integrator' */
  real_T Integrator_CSTATE_d[2];       /* '<S3>/Integrator' */
  real_T Integrator3_CSTATE;           /* '<S177>/Integrator3' */
  real_T Integrator1_CSTATE_f;         /* '<S166>/Integrator1' */
  real_T Integrator_CSTATE_de;         /* '<S87>/Integrator' */
  real_T Integrator_CSTATE_g;          /* '<S86>/Integrator' */
  real_T Integrator_CSTATE_b;          /* '<S150>/Integrator' */
  real_T Integrator_CSTATE_h1;         /* '<S96>/Integrator' */
  real_T Integrator_CSTATE_j;          /* '<S78>/Integrator' */
  real_T Integrator_CSTATE_g4;         /* '<S77>/Integrator' */
  real_T Integrator_CSTATE_o[2];       /* '<S25>/Integrator' */
  real_T Integrator_CSTATE_n[2];       /* '<S42>/Integrator' */
  real_T PumpIntegrator_CSTATE;        /* '<S133>/Pump Integrator' */
  real_T TurbineIntegrator_CSTATE;     /* '<S133>/Turbine Integrator' */
  real_T Integrator_CSTATE_e;          /* '<S157>/Integrator' */
  real_T LockedShaftIntegrator_CSTATE; /* '<S132>/Locked Shaft Integrator' */
  real_T we;                           /* '<S100>/xe' */
  real_T wv;                           /* '<S100>/xv' */
  real_T w;                            /* '<S98>/x' */
  XPtMax_Clutch_DrivetrainHevP4_T Clutch_e;/* '<S217>/Clutch' */
  XPtMax_Clutch_DrivetrainHevP4_T Clutch;/* '<S217>/Clutch' */
} XPtMax_DrivetrainHevP4_T;

/* Zero-crossing (trigger) state for model 'DrivetrainHevP4' */
typedef struct {
  real_T Integrator_Reset_ZC;          /* '<S14>/Integrator' */
  real_T Integrator_Reset_ZC_f;        /* '<S61>/Integrator' */
  real_T VelocitiesMatch_Input_ZC;     /* '<S144>/Velocities Match' */
  real_T Integrator_Reset_ZC_j;        /* '<S87>/Integrator' */
  real_T Integrator_Reset_ZC_i;        /* '<S150>/Integrator' */
  real_T Saturation_UprLim_ZC;         /* '<S151>/Saturation' */
  real_T Saturation_LwrLim_ZC;         /* '<S151>/Saturation' */
  real_T Abs_AbsZc_ZC;                 /* '<S135>/Abs' */
  real_T Relay1_RelayZC_ZC;            /* '<S149>/Relay1' */
  real_T RelationalOperator_RelopInput_ZC;/* '<S149>/Relational Operator' */
  real_T Integrator_Reset_ZC_l;        /* '<S96>/Integrator' */
  real_T Integrator_Reset_ZC_ld;       /* '<S78>/Integrator' */
  real_T If_IfInput_ZC;                /* '<S94>/If' */
  real_T PumpIntegrator_IntgUpLimit_ZC;/* '<S133>/Pump Integrator' */
  real_T PumpIntegrator_IntgLoLimit_ZC;/* '<S133>/Pump Integrator' */
  real_T PumpIntegrator_LeaveSaturate_ZC;/* '<S133>/Pump Integrator' */
  real_T TurbineIntegrator_IntgUpLimit_ZC;/* '<S133>/Turbine Integrator' */
  real_T TurbineIntegrator_IntgLoLimit_ZC;/* '<S133>/Turbine Integrator' */
  real_T TurbineIntegrator_LeaveSaturate_ZC;/* '<S133>/Turbine Integrator' */
  real_T MinMax_MinmaxInput_ZC;        /* '<S154>/MinMax' */
  real_T LowerRelop1_RelopInput_ZC;    /* '<S159>/LowerRelop1' */
  real_T UpperRelop_RelopInput_ZC;     /* '<S159>/UpperRelop' */
  real_T Abs_AbsZc_ZC_o;               /* '<S100>/Abs' */
  real_T Abs_AbsZc_ZC_d;               /* '<S98>/Abs' */
} ZCV_DrivetrainHevP4_g_T;

/* Zero-crossing (trigger) state for model 'DrivetrainHevP4' */
typedef struct {
  ZCSigState Integrator_Reset_ZCE;     /* '<S14>/Integrator' */
  ZCSigState Integrator_Reset_ZCE_a;   /* '<S61>/Integrator' */
  ZCSigState VelocitiesMatch_Input_ZCE;/* '<S144>/Velocities Match' */
  ZCSigState Integrator_Reset_ZCE_j;   /* '<S87>/Integrator' */
  ZCSigState Integrator_Reset_ZCE_f;   /* '<S150>/Integrator' */
  ZCSigState Integrator_Reset_ZCE_m;   /* '<S96>/Integrator' */
  ZCSigState Integrator_Reset_ZCE_fz;  /* '<S78>/Integrator' */
} ZCE_DrivetrainHevP4_T;

/* Parameters for system: '<S25>/Open Differential' */
struct P_OpenDifferential_DrivetrainHevP4_T_ {
  real_T OpenDifferential_shaftSwitchMask;/* Expression: shaftSwitchMask
                                           * Referenced by: '<S25>/Open Differential'
                                           */
};

/* Parameters for system: '<S228>/Clutch' */
struct P_Clutch_DrivetrainHevP4_o_T_ {
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S236>/Constant'
                                        */
  real_T locked_Value;                 /* Expression: 0
                                        * Referenced by: '<S234>/locked'
                                        */
  real_T locked1_Value;                /* Expression: 0
                                        * Referenced by: '<S234>/locked1'
                                        */
  real_T locked2_Value;                /* Expression: 0
                                        * Referenced by: '<S234>/locked2'
                                        */
  real_T u_Gain;                       /* Expression: -4
                                        * Referenced by: '<S235>/-4'
                                        */
  boolean_T yn_Y0;                     /* Computed Parameter: yn_Y0
                                        * Referenced by: '<S237>/yn'
                                        */
  boolean_T yn_Y0_e;                   /* Computed Parameter: yn_Y0_e
                                        * Referenced by: '<S236>/yn'
                                        */
  boolean_T UnitDelay_InitialCondition;
                               /* Computed Parameter: UnitDelay_InitialCondition
                                * Referenced by: '<S241>/Unit Delay'
                                */
  boolean_T CombinatorialLogic_table[8];
                                 /* Computed Parameter: CombinatorialLogic_table
                                  * Referenced by: '<S241>/Combinatorial  Logic'
                                  */
};

/* Parameters for system: '<S217>/Clutch' */
struct P_CoreSubsys_DrivetrainHevP4_T_ {
  P_Clutch_DrivetrainHevP4_o_T sf_Clutch;/* '<S228>/Clutch' */
};

/* Parameters for system: '<S217>/Clutch' */
struct P_Clutch_DrivetrainHevP4_T_ {
  P_CoreSubsys_DrivetrainHevP4_T CoreSubsys;/* '<S217>/Clutch' */
};

/* Parameters (default storage) */
struct P_DrivetrainHevP4_T_ {
  real_T Af;                           /* Variable: Af
                                        * Referenced by: '<S206>/.5.*A.*Pabs.//R.//T'
                                        */
  real_T Cd;                           /* Variable: Cd
                                        * Referenced by: '<S206>/Constant'
                                        */
  real_T FZMAX;                        /* Variable: FZMAX
                                        * Referenced by:
                                        *   '<S213>/Simple Magic Tire'
                                        *   '<S255>/Simple Magic Tire'
                                        */
  real_T FZMIN;                        /* Variable: FZMIN
                                        * Referenced by:
                                        *   '<S213>/Simple Magic Tire'
                                        *   '<S255>/Simple Magic Tire'
                                        */
  real_T G[7];                         /* Variable: G
                                        * Referenced by:
                                        *   '<S100>/Gear2damping'
                                        *   '<S100>/Gear2inertias'
                                        *   '<S100>/Gear2inertias1'
                                        *   '<S112>/Gear2Ratios'
                                        *   '<S112>/Gear2damping'
                                        *   '<S112>/Gear2inertias'
                                        *   '<S120>/Gear2Ratios'
                                        *   '<S120>/Gear2damping'
                                        *   '<S120>/Gear2inertias'
                                        *   '<S117>/Eta 4D'
                                        *   '<S125>/Eta 4D'
                                        */
  real_T Iyy_Whl;                      /* Variable: Iyy_Whl
                                        * Referenced by:
                                        *   '<S235>/Output Inertia'
                                        *   '<S277>/Output Inertia'
                                        */
  real_T Jd;                           /* Variable: Jd
                                        * Referenced by:
                                        *   '<S25>/Jd'
                                        *   '<S42>/Jd'
                                        */
  real_T Ji;                           /* Variable: Ji
                                        * Referenced by:
                                        *   '<S132>/Inertia'
                                        *   '<S132>/Inertia1'
                                        *   '<S133>/Impeller Inertia'
                                        *   '<S146>/Inertia Ratio'
                                        *   '<S147>/Inertia Ratio'
                                        */
  real_T Jout[7];                      /* Variable: Jout
                                        * Referenced by:
                                        *   '<S100>/Gear2inertias'
                                        *   '<S100>/Gear2inertias1'
                                        *   '<S112>/Gear2inertias'
                                        *   '<S120>/Gear2inertias'
                                        */
  real_T Jt;                           /* Variable: Jt
                                        * Referenced by:
                                        *   '<S132>/Inertia'
                                        *   '<S132>/Inertia2'
                                        *   '<S133>/Turbine Inertia'
                                        *   '<S146>/Inertia Ratio'
                                        *   '<S147>/Inertia Ratio'
                                        */
  real_T Jw1;                          /* Variable: Jw1
                                        * Referenced by:
                                        *   '<S25>/Jw1'
                                        *   '<S42>/Jw1'
                                        */
  real_T Jw2;                          /* Variable: Jw2
                                        * Referenced by:
                                        *   '<S25>/Jw3'
                                        *   '<S42>/Jw3'
                                        */
  real_T K_c;                          /* Variable: K_c
                                        * Referenced by: '<S149>/ClutchGain'
                                        */
  real_T Lrel;                         /* Variable: Lrel
                                        * Referenced by:
                                        *   '<S230>/Constant2'
                                        *   '<S272>/Constant2'
                                        */
  real_T Mass;                         /* Variable: Mass
                                        * Referenced by:
                                        *   '<S169>/1//m'
                                        *   '<S169>/m'
                                        */
  real_T N[7];                         /* Variable: N
                                        * Referenced by:
                                        *   '<S112>/Gear2Ratios'
                                        *   '<S120>/Gear2Ratios'
                                        */
  real_T NF;                           /* Variable: NF
                                        * Referenced by: '<S178>/1//NF'
                                        */
  real_T NR;                           /* Variable: NR
                                        * Referenced by: '<S178>/1//NR'
                                        */
  real_T Ndiff;                        /* Variable: Ndiff
                                        * Referenced by:
                                        *   '<S25>/Ndiff2'
                                        *   '<S29>/Gain'
                                        *   '<S32>/Gain1'
                                        */
  real_T Ndiff_P4;                     /* Variable: Ndiff_P4
                                        * Referenced by:
                                        *   '<S42>/Ndiff2'
                                        *   '<S46>/Gain'
                                        *   '<S49>/Gain1'
                                        */
  real_T Pabs;                         /* Variable: Pabs
                                        * Referenced by: '<S206>/.5.*A.*Pabs.//R.//T'
                                        */
  real_T Re;                           /* Variable: Re
                                        * Referenced by:
                                        *   '<S217>/Constant9'
                                        *   '<S259>/Constant9'
                                        *   '<S228>/Clutch'
                                        *   '<S270>/Clutch'
                                        */
  real_T Reff;                         /* Variable: Reff
                                        * Referenced by: '<S151>/Torque Conversion'
                                        */
  real_T Rm;                           /* Variable: Rm
                                        * Referenced by:
                                        *   '<S232>/Torque Conversion'
                                        *   '<S274>/Torque Conversion'
                                        */
  real_T T;                            /* Variable: T
                                        * Referenced by: '<S165>/AirTempConstant'
                                        */
  real_T Temp_bpts[2];                 /* Variable: Temp_bpts
                                        * Referenced by:
                                        *   '<S2>/Constant'
                                        *   '<S117>/Eta 4D'
                                        *   '<S125>/Eta 4D'
                                        */
  real_T Trq_bpts[7];                  /* Variable: Trq_bpts
                                        * Referenced by:
                                        *   '<S117>/Eta 4D'
                                        *   '<S125>/Eta 4D'
                                        */
  real_T UNLOADED_RADIUS;              /* Variable: UNLOADED_RADIUS
                                        * Referenced by:
                                        *   '<S225>/Constant4'
                                        *   '<S267>/Constant4'
                                        */
  real_T VXLOW;                        /* Variable: VXLOW
                                        * Referenced by:
                                        *   '<S213>/Simple Magic Tire'
                                        *   '<S255>/Simple Magic Tire'
                                        *   '<S228>/Clutch'
                                        *   '<S270>/Clutch'
                                        *   '<S248>/Constant'
                                        *   '<S249>/Constant'
                                        *   '<S290>/Constant'
                                        *   '<S291>/Constant'
                                        */
  real_T aMy;                          /* Variable: aMy
                                        * Referenced by:
                                        *   '<S225>/Constant13'
                                        *   '<S267>/Constant13'
                                        */
  real_T a_CG;                         /* Variable: a_CG
                                        * Referenced by:
                                        *   '<S169>/1//(a+b)'
                                        *   '<S169>/1//(a+b) '
                                        *   '<S169>/a'
                                        *   '<S206>/Constant3'
                                        *   '<S180>/R_T1'
                                        */
  real_T alphaMy;                      /* Variable: alphaMy
                                        * Referenced by:
                                        *   '<S225>/Constant18'
                                        *   '<S267>/Constant18'
                                        */
  real_T b;                            /* Variable: b
                                        * Referenced by:
                                        *   '<S13>/Gain2'
                                        *   '<S60>/Gain2'
                                        *   '<S77>/Gain2'
                                        *   '<S86>/Gain2'
                                        */
  real_T bMy;                          /* Variable: bMy
                                        * Referenced by:
                                        *   '<S225>/Constant8'
                                        *   '<S267>/Constant8'
                                        */
  real_T b_CG;                         /* Variable: b_CG
                                        * Referenced by:
                                        *   '<S169>/1//(a+b)'
                                        *   '<S169>/1//(a+b) '
                                        *   '<S169>/b'
                                        *   '<S206>/Constant3'
                                        *   '<S181>/R_T1'
                                        */
  real_T bd;                           /* Variable: bd
                                        * Referenced by:
                                        *   '<S25>/bd'
                                        *   '<S42>/bd'
                                        */
  real_T betaMy;                       /* Variable: betaMy
                                        * Referenced by:
                                        *   '<S225>/Constant17'
                                        *   '<S267>/Constant17'
                                        */
  real_T bi;                           /* Variable: bi
                                        * Referenced by:
                                        *   '<S132>/Impeller Damping'
                                        *   '<S133>/Impeller Damping'
                                        *   '<S146>/Impeller Damping'
                                        *   '<S147>/Input Damping'
                                        */
  real_T bout[7];                      /* Variable: bout
                                        * Referenced by:
                                        *   '<S100>/Gear2damping'
                                        *   '<S112>/Gear2damping'
                                        *   '<S120>/Gear2damping'
                                        */
  real_T br;                           /* Variable: br
                                        * Referenced by:
                                        *   '<S235>/Output Damping'
                                        *   '<S277>/Output Damping'
                                        *   '<S242>/Output Damping'
                                        *   '<S284>/Output Damping'
                                        */
  real_T bt;                           /* Variable: bt
                                        * Referenced by:
                                        *   '<S132>/Turbine Damping'
                                        *   '<S133>/Turbine Damping'
                                        *   '<S146>/Turbine Damping'
                                        *   '<S147>/Output Damping'
                                        */
  real_T bw1;                          /* Variable: bw1
                                        * Referenced by:
                                        *   '<S25>/bw1'
                                        *   '<S42>/bw1'
                                        */
  real_T bw2;                          /* Variable: bw2
                                        * Referenced by:
                                        *   '<S25>/bw2'
                                        *   '<S42>/bw2'
                                        */
  real_T cMy;                          /* Variable: cMy
                                        * Referenced by:
                                        *   '<S225>/Constant15'
                                        *   '<S267>/Constant15'
                                        */
  real_T disk_abore;                   /* Variable: disk_abore
                                        * Referenced by:
                                        *   '<S232>/Disk brake actuator bore'
                                        *   '<S274>/Disk brake actuator bore'
                                        */
  real_T domega_o;                     /* Variable: domega_o
                                        * Referenced by:
                                        *   '<S13>/domega_o'
                                        *   '<S60>/domega_o'
                                        *   '<S77>/domega_o'
                                        *   '<S86>/domega_o'
                                        */
  real_T eta_diff;                     /* Variable: eta_diff
                                        * Referenced by:
                                        *   '<S41>/Constant'
                                        *   '<S58>/Constant'
                                        */
  real_T eta_tbl[1078];                /* Variable: eta_tbl
                                        * Referenced by:
                                        *   '<S117>/Eta 4D'
                                        *   '<S125>/Eta 4D'
                                        */
  real_T g;                            /* Variable: g
                                        * Referenced by: '<S169>/g'
                                        */
  real_T h;                            /* Variable: h
                                        * Referenced by:
                                        *   '<S169>/h'
                                        *   '<S180>/R_T3'
                                        *   '<S181>/R_T3'
                                        */
  real_T k;                            /* Variable: k
                                        * Referenced by:
                                        *   '<S13>/Gain1'
                                        *   '<S60>/Gain1'
                                        *   '<S77>/Gain1'
                                        *   '<S86>/Gain1'
                                        */
  real_T kappamax;                     /* Variable: kappamax
                                        * Referenced by:
                                        *   '<S213>/Simple Magic Tire'
                                        *   '<S255>/Simple Magic Tire'
                                        */
  real_T lam_x;                        /* Variable: lam_x
                                        * Referenced by:
                                        *   '<S208>/lam_muxConstant'
                                        *   '<S210>/lam_muxConstant'
                                        */
  real_T mu_kinetic;                   /* Variable: mu_kinetic
                                        * Referenced by:
                                        *   '<S229>/Ratio of static to kinetic'
                                        *   '<S271>/Ratio of static to kinetic'
                                        *   '<S232>/Torque Conversion'
                                        *   '<S274>/Torque Conversion'
                                        */
  real_T mu_static;                    /* Variable: mu_static
                                        * Referenced by:
                                        *   '<S229>/Ratio of static to kinetic'
                                        *   '<S271>/Ratio of static to kinetic'
                                        */
  real_T muk;                          /* Variable: muk
                                        * Referenced by:
                                        *   '<S151>/Ratio of static to kinetic'
                                        *   '<S151>/Torque Conversion'
                                        */
  real_T mus;                          /* Variable: mus
                                        * Referenced by: '<S151>/Ratio of static to kinetic'
                                        */
  real_T num_pads;                     /* Variable: num_pads
                                        * Referenced by:
                                        *   '<S232>/Number of brake pads'
                                        *   '<S274>/Number of brake pads'
                                        */
  real_T omega_bpts[11];               /* Variable: omega_bpts
                                        * Referenced by:
                                        *   '<S117>/Eta 4D'
                                        *   '<S125>/Eta 4D'
                                        */
  real_T omega_c;                      /* Variable: omega_c
                                        * Referenced by:
                                        *   '<S13>/omega_c'
                                        *   '<S60>/omega_c'
                                        *   '<S77>/omega_c'
                                        *   '<S86>/omega_c'
                                        */
  real_T omega_o;                      /* Variable: omega_o
                                        * Referenced by:
                                        *   '<S97>/Constant'
                                        *   '<S101>/Constant'
                                        */
  real_T omegai_o;                     /* Variable: omegai_o
                                        * Referenced by:
                                        *   '<S128>/Constant'
                                        *   '<S129>/Constant'
                                        */
  real_T omegal;                       /* Variable: omegal
                                        * Referenced by: '<S149>/Relay1'
                                        */
  real_T omegao;                       /* Variable: omegao
                                        * Referenced by:
                                        *   '<S228>/Clutch'
                                        *   '<S270>/Clutch'
                                        *   '<S235>/omega wheel'
                                        *   '<S277>/omega wheel'
                                        */
  real_T omegat_o;                     /* Variable: omegat_o
                                        * Referenced by: '<S134>/Constant'
                                        */
  real_T omegau;                       /* Variable: omegau
                                        * Referenced by: '<S149>/Relay1'
                                        */
  real_T omegaw1o;                     /* Variable: omegaw1o
                                        * Referenced by:
                                        *   '<S25>/Constant'
                                        *   '<S42>/Constant'
                                        */
  real_T omegaw2o;                     /* Variable: omegaw2o
                                        * Referenced by:
                                        *   '<S25>/Constant1'
                                        *   '<S42>/Constant1'
                                        */
  real_T phi[10];                      /* Variable: phi
                                        * Referenced by:
                                        *   '<S152>/phi'
                                        *   '<S154>/Constant2'
                                        */
  real_T philu;                        /* Variable: philu
                                        * Referenced by: '<S149>/Constant'
                                        */
  real_T press;                        /* Variable: press
                                        * Referenced by:
                                        *   '<S208>/TirePrsConstant'
                                        *   '<S210>/TirePrsConstant'
                                        */
  real_T psi[10];                      /* Variable: psi
                                        * Referenced by: '<S152>/psi'
                                        */
  real_T tauC;                         /* Variable: tauC
                                        * Referenced by: '<S149>/Constant1'
                                        */
  real_T tauTC;                        /* Variable: tauTC
                                        * Referenced by: '<S153>/Constant'
                                        */
  real_T tau_s;                        /* Variable: tau_s
                                        * Referenced by: '<S94>/Constant'
                                        */
  real_T theta_o;                      /* Variable: theta_o
                                        * Referenced by:
                                        *   '<S13>/Integrator'
                                        *   '<S60>/Integrator'
                                        *   '<S77>/Integrator'
                                        *   '<S86>/Integrator'
                                        */
  real_T wc;                           /* Variable: wc
                                        * Referenced by:
                                        *   '<S163>/Constant'
                                        *   '<S164>/Constant'
                                        */
  real_T x_o;                          /* Variable: x_o
                                        * Referenced by: '<S166>/Integrator1'
                                        */
  real_T xdot_o;                       /* Variable: xdot_o
                                        * Referenced by:
                                        *   '<S169>/Integrator'
                                        *   '<S177>/Integrator3'
                                        */
  real_T zeta[10];                     /* Variable: zeta
                                        * Referenced by: '<S152>/zeta'
                                        */
  real_T VehicleBody1DOFLongitudinal_Cl;
                               /* Mask Parameter: VehicleBody1DOFLongitudinal_Cl
                                * Referenced by: '<S206>/Constant1'
                                */
  real_T VehicleBody1DOFLongitudinal_Cpm;
                              /* Mask Parameter: VehicleBody1DOFLongitudinal_Cpm
                               * Referenced by: '<S206>/Constant2'
                               */
  real_T DragForce_Cs[2];              /* Mask Parameter: DragForce_Cs
                                        * Referenced by: '<S206>/Cs'
                                        */
  real_T DragForce_Cym[2];             /* Mask Parameter: DragForce_Cym
                                        * Referenced by: '<S206>/Cym'
                                        */
  real_T IdealFixedGearTransmission_G_o;
                               /* Mask Parameter: IdealFixedGearTransmission_G_o
                                * Referenced by: '<S94>/Constant1'
                                */
  real_T TorqueConverter_KType;        /* Mask Parameter: TorqueConverter_KType
                                        * Referenced by: '<S152>/Constant1'
                                        */
  real_T DragForce_R;                  /* Mask Parameter: DragForce_R
                                        * Referenced by: '<S206>/.5.*A.*Pabs.//R.//T'
                                        */
  real_T HardPointCoordinateTransformFront_R_T2;
                       /* Mask Parameter: HardPointCoordinateTransformFront_R_T2
                        * Referenced by: '<S180>/R_T2'
                        */
  real_T HardPointCoordinateTransformRear_R_T2;
                        /* Mask Parameter: HardPointCoordinateTransformRear_R_T2
                         * Referenced by: '<S181>/R_T2'
                         */
  real_T DragForce_beta_w[2];          /* Mask Parameter: DragForce_beta_w
                                        * Referenced by:
                                        *   '<S206>/Cs'
                                        *   '<S206>/Cym'
                                        */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S158>/Constant'
                                      */
  real_T IdealFixedGearTransmission_omegaN_o;
                          /* Mask Parameter: IdealFixedGearTransmission_omegaN_o
                           * Referenced by: '<S99>/Constant'
                           */
  real_T div0protectabspoly_thresh; /* Mask Parameter: div0protectabspoly_thresh
                                     * Referenced by:
                                     *   '<S114>/Constant'
                                     *   '<S115>/Constant'
                                     */
  real_T div0protectabspoly_thresh_k;
                                  /* Mask Parameter: div0protectabspoly_thresh_k
                                   * Referenced by:
                                   *   '<S122>/Constant'
                                   *   '<S123>/Constant'
                                   */
  real_T div0protectpoly_thresh;       /* Mask Parameter: div0protectpoly_thresh
                                        * Referenced by:
                                        *   '<S161>/Constant'
                                        *   '<S162>/Constant'
                                        */
  real_T Gain_Gain;                    /* Expression: 0.6
                                        * Referenced by: '<S5>/Gain'
                                        */
  real_T DisallowNegativeBrakeTorque_UpperSat;/* Expression: inf
                                               * Referenced by: '<S232>/Disallow Negative Brake Torque'
                                               */
  real_T DisallowNegativeBrakeTorque_LowerSat;/* Expression: eps
                                               * Referenced by: '<S232>/Disallow Negative Brake Torque'
                                               */
  real_T Gain1_Gain;                   /* Expression: 0.4
                                        * Referenced by: '<S5>/Gain1'
                                        */
  real_T DisallowNegativeBrakeTorque_UpperSat_o;/* Expression: inf
                                                 * Referenced by: '<S274>/Disallow Negative Brake Torque'
                                                 */
  real_T DisallowNegativeBrakeTorque_LowerSat_o;/* Expression: eps
                                                 * Referenced by: '<S274>/Disallow Negative Brake Torque'
                                                 */
  real_T Crm_tableData[2];             /* Expression: [0 0]
                                        * Referenced by: '<S206>/Crm'
                                        */
  real_T Crm_bp01Data[2];              /* Expression: [-1 1]
                                        * Referenced by: '<S206>/Crm'
                                        */
  real_T u_Gain[3];                    /* Expression: 4.*ones(3,1)
                                        * Referenced by: '<S206>/4'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S56>/Switch'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S109>/Constant'
                                        */
  real_T Switch_Threshold_l;           /* Expression: 0
                                        * Referenced by: '<S109>/Switch'
                                        */
  real_T Constant_Value_f;             /* Expression: 1
                                        * Referenced by: '<S110>/Constant'
                                        */
  real_T Switch_Threshold_a;           /* Expression: 0
                                        * Referenced by: '<S110>/Switch'
                                        */
  real_T Gain_Gain_n;                  /* Expression: -1
                                        * Referenced by: '<S111>/Gain'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 0
                                        * Referenced by: '<S111>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -inf
                                        * Referenced by: '<S111>/Saturation1'
                                        */
  real_T Saturation2_UpperSat;         /* Expression: inf
                                        * Referenced by: '<S111>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S111>/Saturation2'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 1
                                        * Referenced by: '<S111>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0
                                        * Referenced by: '<S111>/Saturation'
                                        */
  real_T Neutral_Value;                /* Expression: 0
                                        * Referenced by: '<S100>/Neutral'
                                        */
  real_T NoInputTorque_Value;          /* Expression: 0
                                        * Referenced by: '<S100>/No Input Torque'
                                        */
  real_T Constant_Value_i;             /* Expression: 1
                                        * Referenced by: '<S118>/Constant'
                                        */
  real_T Switch_Threshold_i;           /* Expression: 0
                                        * Referenced by: '<S118>/Switch'
                                        */
  real_T First_Value;                  /* Expression: 1
                                        * Referenced by: '<S100>/First'
                                        */
  real_T Gain_Gain_m;                  /* Expression: -1
                                        * Referenced by: '<S119>/Gain'
                                        */
  real_T Saturation1_UpperSat_i;       /* Expression: 0
                                        * Referenced by: '<S119>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_k;       /* Expression: -inf
                                        * Referenced by: '<S119>/Saturation1'
                                        */
  real_T Saturation2_UpperSat_b;       /* Expression: inf
                                        * Referenced by: '<S119>/Saturation2'
                                        */
  real_T Saturation2_LowerSat_d;       /* Expression: 0
                                        * Referenced by: '<S119>/Saturation2'
                                        */
  real_T Saturation_UpperSat_i;        /* Expression: 1
                                        * Referenced by: '<S119>/Saturation'
                                        */
  real_T Saturation_LowerSat_l;        /* Expression: 0
                                        * Referenced by: '<S119>/Saturation'
                                        */
  real_T LockedShaftIntegrator_UpperSat;/* Expression: maxAbsSpd
                                         * Referenced by: '<S132>/Locked Shaft Integrator'
                                         */
  real_T LockedShaftIntegrator_LowerSat;/* Expression: -maxAbsSpd
                                         * Referenced by: '<S132>/Locked Shaft Integrator'
                                         */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S132>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S132>/Constant2'
                                        */
  real_T Constant_Value_a;             /* Expression: 1
                                        * Referenced by: '<S132>/Constant'
                                        */
  real_T Out1_Y0;                      /* Expression: 0
                                        * Referenced by: '<S156>/Out1'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S157>/Integrator'
                                        */
  real_T Gain_Gain_d;                  /* Expression: 1/2/pi
                                        * Referenced by: '<S156>/Gain'
                                        */
  real_T Saturation_UpperSat_b;        /* Expression: inf
                                        * Referenced by: '<S156>/Saturation'
                                        */
  real_T Saturation_LowerSat_o;        /* Expression: eps
                                        * Referenced by: '<S156>/Saturation'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S155>/Constant'
                                        */
  real_T PumpIntegrator_UpperSat;      /* Expression: maxAbsSpd
                                        * Referenced by: '<S133>/Pump Integrator'
                                        */
  real_T PumpIntegrator_LowerSat;      /* Expression: -maxAbsSpd
                                        * Referenced by: '<S133>/Pump Integrator'
                                        */
  real_T TurbineIntegrator_UpperSat;   /* Expression: maxAbsSpd
                                        * Referenced by: '<S133>/Turbine Integrator'
                                        */
  real_T TurbineIntegrator_LowerSat;   /* Expression: -maxAbsSpd
                                        * Referenced by: '<S133>/Turbine Integrator'
                                        */
  real_T u_Gain_m;                     /* Expression: 4
                                        * Referenced by: '<S133>/4'
                                        */
  real_T Constant1_Value_h;            /* Expression: 1
                                        * Referenced by: '<S154>/Constant1'
                                        */
  real_T Constant_Value_c;             /* Expression: 1
                                        * Referenced by: '<S160>/Constant'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S160>/Switch1'
                                        */
  real_T Constant_Value_p;             /* Expression: 1
                                        * Referenced by: '<S154>/Constant'
                                        */
  real_T Gain_Gain_p;                  /* Expression: -1
                                        * Referenced by: '<S154>/Gain'
                                        */
  real_T Switch_Threshold_lw;          /* Expression: 0
                                        * Referenced by: '<S153>/Switch'
                                        */
  real_T Switch1_Threshold_f;          /* Expression: 1
                                        * Referenced by: '<S152>/Switch1'
                                        */
  real_T uniclutch_UpperSat;           /* Expression: inf
                                        * Referenced by: '<S152>/uniclutch'
                                        */
  real_T uniclutch_LowerSat;           /* Expression: 0
                                        * Referenced by: '<S152>/uniclutch'
                                        */
  real_T Saturation_UpperSat_f;        /* Expression: inf
                                        * Referenced by: '<S217>/Saturation'
                                        */
  real_T Saturation_LowerSat_n;        /* Expression: eps
                                        * Referenced by: '<S217>/Saturation'
                                        */
  real_T Integrator1_IC;               /* Expression: 0
                                        * Referenced by: '<S164>/Integrator1'
                                        */
  real_T Memory_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S14>/Memory'
                                        */
  real_T Integrator_IC_c;              /* Expression: 0
                                        * Referenced by: '<S246>/Integrator'
                                        */
  real_T Signconvention_Gain;          /* Expression: -1
                                        * Referenced by: '<S217>/Sign convention'
                                        */
  real_T TorqueConversion1_Gain;       /* Expression: pi/4
                                        * Referenced by: '<S232>/Torque Conversion1'
                                        */
  real_T Constant_Value_px;            /* Expression: D
                                        * Referenced by: '<S224>/Constant'
                                        */
  real_T Constant1_Value_n;            /* Expression: C
                                        * Referenced by: '<S224>/Constant1'
                                        */
  real_T Constant7_Value;              /* Expression: B
                                        * Referenced by: '<S224>/Constant7'
                                        */
  real_T Constant6_Value;              /* Expression: E
                                        * Referenced by: '<S224>/Constant6'
                                        */
  real_T Constant2_Value_i[34];        /* Expression: zeros(34,1)
                                        * Referenced by: '<S224>/Constant2'
                                        */
  real_T Constant19_Value[3];          /* Expression: zeros(1,3)
                                        * Referenced by: '<S224>/Constant19'
                                        */
  real_T Constant12_Value[3];          /* Expression: zeros(1,3)
                                        * Referenced by: '<S224>/Constant12'
                                        */
  real_T Constant14_Value[9];          /* Expression: zeros(3,3)
                                        * Referenced by: '<S224>/Constant14'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S225>/Constant5'
                                        */
  real_T Constant2_Value_c;            /* Expression: 0
                                        * Referenced by: '<S225>/Constant2'
                                        */
  real_T Constant16_Value;             /* Expression: 0
                                        * Referenced by: '<S225>/Constant16'
                                        */
  real_T Constant7_Value_o;            /* Expression: 0
                                        * Referenced by: '<S225>/Constant7'
                                        */
  real_T Constant9_Value;              /* Expression: 0
                                        * Referenced by: '<S225>/Constant9'
                                        */
  real_T Constant11_Value;             /* Expression: 0
                                        * Referenced by: '<S225>/Constant11'
                                        */
  real_T Constant10_Value;             /* Expression: 0
                                        * Referenced by: '<S225>/Constant10'
                                        */
  real_T Constant1_Value_i;            /* Expression: PRESMIN
                                        * Referenced by: '<S225>/Constant1'
                                        */
  real_T Constant3_Value;              /* Expression: PRESMAX
                                        * Referenced by: '<S225>/Constant3'
                                        */
  real_T Constant19_Value_f[3];        /* Expression: zeros(1,3)
                                        * Referenced by: '<S225>/Constant19'
                                        */
  real_T Constant12_Value_b[3];        /* Expression: zeros(1,3)
                                        * Referenced by: '<S225>/Constant12'
                                        */
  real_T Constant14_Value_m[9];        /* Expression: zeros(3,3)
                                        * Referenced by: '<S225>/Constant14'
                                        */
  real_T Constant14_Value_h;           /* Expression: 0
                                        * Referenced by: '<S226>/Constant14'
                                        */
  real_T Constant1_Value_m;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant1'
                                        */
  real_T Constant19_Value_h;           /* Expression: 0
                                        * Referenced by: '<S226>/Constant19'
                                        */
  real_T Constant2_Value_f;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant2'
                                        */
  real_T Constant3_Value_a;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S226>/Constant4'
                                        */
  real_T Constant5_Value_e;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant5'
                                        */
  real_T Constant6_Value_i;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant6'
                                        */
  real_T Constant7_Value_l;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant7'
                                        */
  real_T Constant8_Value;              /* Expression: 0
                                        * Referenced by: '<S226>/Constant8'
                                        */
  real_T Constant9_Value_m;            /* Expression: 0
                                        * Referenced by: '<S226>/Constant9'
                                        */
  real_T Constant10_Value_a;           /* Expression: 0
                                        * Referenced by: '<S226>/Constant10'
                                        */
  real_T Constant11_Value_f;           /* Expression: 0
                                        * Referenced by: '<S226>/Constant11'
                                        */
  real_T Constant16_Value_i;           /* Expression: 0
                                        * Referenced by: '<S226>/Constant16'
                                        */
  real_T Constant17_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant17'
                                        */
  real_T Constant13_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant13'
                                        */
  real_T Constant15_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant15'
                                        */
  real_T Constant21_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant21'
                                        */
  real_T Constant22_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant22'
                                        */
  real_T Constant18_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant18'
                                        */
  real_T Constant20_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant20'
                                        */
  real_T Constant24_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant24'
                                        */
  real_T Constant23_Value;             /* Expression: 0
                                        * Referenced by: '<S226>/Constant23'
                                        */
  real_T FxType_Value;                 /* Expression: 0
                                        * Referenced by: '<S208>/FxType'
                                        */
  real_T rollType_Value;               /* Expression: 1
                                        * Referenced by: '<S208>/rollType'
                                        */
  real_T vertType_Value;               /* Expression: 0
                                        * Referenced by: '<S208>/vertType'
                                        */
  real_T Saturation_UpperSat_p;        /* Expression: inf
                                        * Referenced by: '<S259>/Saturation'
                                        */
  real_T Saturation_LowerSat_d;        /* Expression: eps
                                        * Referenced by: '<S259>/Saturation'
                                        */
  real_T Integrator1_IC_f;             /* Expression: 0
                                        * Referenced by: '<S163>/Integrator1'
                                        */
  real_T Memory_InitialCondition_j;    /* Expression: 0
                                        * Referenced by: '<S61>/Memory'
                                        */
  real_T Integrator_IC_h;              /* Expression: 0
                                        * Referenced by: '<S288>/Integrator'
                                        */
  real_T Signconvention_Gain_c;        /* Expression: -1
                                        * Referenced by: '<S259>/Sign convention'
                                        */
  real_T TorqueConversion1_Gain_b;     /* Expression: pi/4
                                        * Referenced by: '<S274>/Torque Conversion1'
                                        */
  real_T Constant_Value_n;             /* Expression: D
                                        * Referenced by: '<S266>/Constant'
                                        */
  real_T Constant1_Value_if;           /* Expression: C
                                        * Referenced by: '<S266>/Constant1'
                                        */
  real_T Constant7_Value_i;            /* Expression: B
                                        * Referenced by: '<S266>/Constant7'
                                        */
  real_T Constant6_Value_k;            /* Expression: E
                                        * Referenced by: '<S266>/Constant6'
                                        */
  real_T Constant2_Value_f4[34];       /* Expression: zeros(34,1)
                                        * Referenced by: '<S266>/Constant2'
                                        */
  real_T Constant19_Value_e[3];        /* Expression: zeros(1,3)
                                        * Referenced by: '<S266>/Constant19'
                                        */
  real_T Constant12_Value_m[3];        /* Expression: zeros(1,3)
                                        * Referenced by: '<S266>/Constant12'
                                        */
  real_T Constant14_Value_n[9];        /* Expression: zeros(3,3)
                                        * Referenced by: '<S266>/Constant14'
                                        */
  real_T Constant5_Value_k;            /* Expression: 0
                                        * Referenced by: '<S267>/Constant5'
                                        */
  real_T Constant2_Value_h;            /* Expression: 0
                                        * Referenced by: '<S267>/Constant2'
                                        */
  real_T Constant16_Value_g;           /* Expression: 0
                                        * Referenced by: '<S267>/Constant16'
                                        */
  real_T Constant7_Value_c;            /* Expression: 0
                                        * Referenced by: '<S267>/Constant7'
                                        */
  real_T Constant9_Value_d;            /* Expression: 0
                                        * Referenced by: '<S267>/Constant9'
                                        */
  real_T Constant11_Value_b;           /* Expression: 0
                                        * Referenced by: '<S267>/Constant11'
                                        */
  real_T Constant10_Value_g;           /* Expression: 0
                                        * Referenced by: '<S267>/Constant10'
                                        */
  real_T Constant1_Value_o;            /* Expression: PRESMIN
                                        * Referenced by: '<S267>/Constant1'
                                        */
  real_T Constant3_Value_i;            /* Expression: PRESMAX
                                        * Referenced by: '<S267>/Constant3'
                                        */
  real_T Constant19_Value_b[3];        /* Expression: zeros(1,3)
                                        * Referenced by: '<S267>/Constant19'
                                        */
  real_T Constant12_Value_g[3];        /* Expression: zeros(1,3)
                                        * Referenced by: '<S267>/Constant12'
                                        */
  real_T Constant14_Value_j[9];        /* Expression: zeros(3,3)
                                        * Referenced by: '<S267>/Constant14'
                                        */
  real_T Constant14_Value_b;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant14'
                                        */
  real_T Constant1_Value_b;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant1'
                                        */
  real_T Constant19_Value_j;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant19'
                                        */
  real_T Constant2_Value_o;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant2'
                                        */
  real_T Constant3_Value_f;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant3'
                                        */
  real_T Constant4_Value_h;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant4'
                                        */
  real_T Constant5_Value_h;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant5'
                                        */
  real_T Constant6_Value_h;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant6'
                                        */
  real_T Constant7_Value_k;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant7'
                                        */
  real_T Constant8_Value_d;            /* Expression: 0
                                        * Referenced by: '<S268>/Constant8'
                                        */
  real_T Constant9_Value_dg;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant9'
                                        */
  real_T Constant10_Value_p;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant10'
                                        */
  real_T Constant11_Value_fj;          /* Expression: 0
                                        * Referenced by: '<S268>/Constant11'
                                        */
  real_T Constant16_Value_p;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant16'
                                        */
  real_T Constant17_Value_a;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant17'
                                        */
  real_T Constant13_Value_i;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant13'
                                        */
  real_T Constant15_Value_l;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant15'
                                        */
  real_T Constant21_Value_m;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant21'
                                        */
  real_T Constant22_Value_n;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant22'
                                        */
  real_T Constant18_Value_e;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant18'
                                        */
  real_T Constant20_Value_a;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant20'
                                        */
  real_T Constant24_Value_n;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant24'
                                        */
  real_T Constant23_Value_n;           /* Expression: 0
                                        * Referenced by: '<S268>/Constant23'
                                        */
  real_T FxType_Value_m;               /* Expression: 0
                                        * Referenced by: '<S210>/FxType'
                                        */
  real_T rollType_Value_h;             /* Expression: 1
                                        * Referenced by: '<S210>/rollType'
                                        */
  real_T vertType_Value_e;             /* Expression: 0
                                        * Referenced by: '<S210>/vertType'
                                        */
  real_T MExtConstant_Value[3];        /* Expression: [0,0,0]
                                        * Referenced by: '<S165>/MExtConstant'
                                        */
  real_T FExtConstant_Value[3];        /* Expression: [0,0,0]
                                        * Referenced by: '<S165>/FExtConstant'
                                        */
  real_T Integrator_IC_f;              /* Expression: 0
                                        * Referenced by: '<S3>/Integrator'
                                        */
  real_T Constant2_Value_m;            /* Expression: 0
                                        * Referenced by: '<S174>/Constant2'
                                        */
  real_T Constant1_Value_bz;           /* Expression: 0
                                        * Referenced by: '<S174>/Constant1'
                                        */
  real_T Constant_Value_cb;            /* Expression: 0
                                        * Referenced by: '<S196>/Constant'
                                        */
  real_T Constant_Value_l;             /* Expression: 0
                                        * Referenced by: '<S168>/Constant'
                                        */
  real_T VelocitiesMatch_Offset;       /* Expression: 0
                                        * Referenced by: '<S144>/Velocities Match'
                                        */
  real_T Memory_InitialCondition_g;    /* Expression: 0
                                        * Referenced by: '<S87>/Memory'
                                        */
  real_T Memory_InitialCondition_e;    /* Expression: 0
                                        * Referenced by: '<S150>/Memory'
                                        */
  real_T Constant2_Value_a;            /* Expression: ClutchLocked
                                        * Referenced by: '<S149>/Constant2'
                                        */
  real_T Saturation_UpperSat_h;        /* Expression: inf
                                        * Referenced by: '<S151>/Saturation'
                                        */
  real_T Saturation_LowerSat_f;        /* Expression: eps
                                        * Referenced by: '<S151>/Saturation'
                                        */
  real_T Constant1_Value_j;            /* Expression: 1
                                        * Referenced by: '<S129>/Constant1'
                                        */
  real_T IC_Value;                     /* Expression: 0
                                        * Referenced by: '<S129>/IC'
                                        */
  real_T Switch_Threshold_g;           /* Expression: 0
                                        * Referenced by: '<S129>/Switch'
                                        */
  real_T Constant1_Value_io;           /* Expression: 1
                                        * Referenced by: '<S134>/Constant1'
                                        */
  real_T IC_Value_o;                   /* Expression: 0
                                        * Referenced by: '<S134>/IC'
                                        */
  real_T Switch_Threshold_m;           /* Expression: 0
                                        * Referenced by: '<S134>/Switch'
                                        */
  real_T Constant1_Value_bf;           /* Expression: 1
                                        * Referenced by: '<S128>/Constant1'
                                        */
  real_T IC_Value_i;                   /* Expression: 0
                                        * Referenced by: '<S128>/IC'
                                        */
  real_T Switch_Threshold_k;           /* Expression: 0
                                        * Referenced by: '<S128>/Switch'
                                        */
  real_T Merge1_InitialOutput;       /* Computed Parameter: Merge1_InitialOutput
                                      * Referenced by: '<S126>/Merge1'
                                      */
  real_T Merge4_4_InitialOutput;   /* Computed Parameter: Merge4_4_InitialOutput
                                    * Referenced by: '<S126>/Merge4'
                                    */
  real_T Merge4_5_InitialOutput;   /* Computed Parameter: Merge4_5_InitialOutput
                                    * Referenced by: '<S126>/Merge4'
                                    */
  real_T Saturation1_UpperSat_k;       /* Expression: 0
                                        * Referenced by: '<S135>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_h;       /* Expression: -inf
                                        * Referenced by: '<S135>/Saturation1'
                                        */
  real_T Hz2rad_Gain;                  /* Expression: 2*pi
                                        * Referenced by: '<S149>/Hz2rad'
                                        */
  real_T Reset_Value;                  /* Expression: 1
                                        * Referenced by: '<S150>/Reset'
                                        */
  real_T Merge4_1_InitialOutput;   /* Computed Parameter: Merge4_1_InitialOutput
                                    * Referenced by: '<S126>/Merge4'
                                    */
  real_T Merge4_2_InitialOutput;   /* Computed Parameter: Merge4_2_InitialOutput
                                    * Referenced by: '<S126>/Merge4'
                                    */
  real_T Merge4_3_InitialOutput;   /* Computed Parameter: Merge4_3_InitialOutput
                                    * Referenced by: '<S126>/Merge4'
                                    */
  real_T upi_Gain;                     /* Expression: 2*pi
                                        * Referenced by: '<S94>/2*pi'
                                        */
  real_T Memory_InitialCondition_b;    /* Expression: 0
                                        * Referenced by: '<S96>/Memory'
                                        */
  real_T Reset_Value_m;                /* Expression: 1
                                        * Referenced by: '<S96>/Reset'
                                        */
  real_T Constant1_Value_f;            /* Expression: 1
                                        * Referenced by: '<S97>/Constant1'
                                        */
  real_T IC_Value_k;                   /* Expression: 0
                                        * Referenced by: '<S97>/IC'
                                        */
  real_T Switch_Threshold_il;          /* Expression: 0
                                        * Referenced by: '<S97>/Switch'
                                        */
  real_T Memory_InitialCondition_f;    /* Expression: 0
                                        * Referenced by: '<S78>/Memory'
                                        */
  real_T Constant1_Value_g;            /* Expression: 1
                                        * Referenced by: '<S101>/Constant1'
                                        */
  real_T IC_Value_b;                   /* Expression: 0
                                        * Referenced by: '<S101>/IC'
                                        */
  real_T Switch_Threshold_gl;          /* Expression: 0
                                        * Referenced by: '<S101>/Switch'
                                        */
  real_T Constant1_Value_ou;           /* Expression: 1
                                        * Referenced by: '<S99>/Constant1'
                                        */
  real_T IC_Value_bb;                  /* Expression: 0
                                        * Referenced by: '<S99>/IC'
                                        */
  real_T Switch_Threshold_l2;          /* Expression: 0
                                        * Referenced by: '<S99>/Switch'
                                        */
  real_T Merge2_1_InitialOutput;   /* Computed Parameter: Merge2_1_InitialOutput
                                    * Referenced by: '<S94>/Merge2'
                                    */
  real_T Merge2_2_InitialOutput;   /* Computed Parameter: Merge2_2_InitialOutput
                                    * Referenced by: '<S94>/Merge2'
                                    */
  real_T Merge2_3_InitialOutput;   /* Computed Parameter: Merge2_3_InitialOutput
                                    * Referenced by: '<S94>/Merge2'
                                    */
  real_T Constant1_Value_iv;           /* Expression: 1
                                        * Referenced by: '<S29>/Constant1'
                                        */
  real_T Constant_Value_d;             /* Expression: shaftSwitchMask
                                        * Referenced by: '<S29>/Constant'
                                        */
  real_T Switch_Threshold_c;           /* Expression: 1
                                        * Referenced by: '<S29>/Switch'
                                        */
  real_T Integrator_UpperSat;          /* Expression: maxAbsSpd
                                        * Referenced by: '<S25>/Integrator'
                                        */
  real_T Integrator_LowerSat;          /* Expression: -maxAbsSpd
                                        * Referenced by: '<S25>/Integrator'
                                        */
  real_T Reset_Value_i;                /* Expression: 1
                                        * Referenced by: '<S78>/Reset'
                                        */
  real_T Reset_Value_g;                /* Expression: 1
                                        * Referenced by: '<S87>/Reset'
                                        */
  real_T Constant1_Value_m0;           /* Expression: 1
                                        * Referenced by: '<S46>/Constant1'
                                        */
  real_T Constant_Value_nn;            /* Expression: shaftSwitchMask
                                        * Referenced by: '<S46>/Constant'
                                        */
  real_T Switch_Threshold_b;           /* Expression: 1
                                        * Referenced by: '<S46>/Switch'
                                        */
  real_T Integrator_UpperSat_j;        /* Expression: maxAbsSpd
                                        * Referenced by: '<S42>/Integrator'
                                        */
  real_T Integrator_LowerSat_o;        /* Expression: -maxAbsSpd
                                        * Referenced by: '<S42>/Integrator'
                                        */
  real_T Gain1_Gain_f;                 /* Expression: 1/2
                                        * Referenced by: '<S46>/Gain1'
                                        */
  real_T Constant_Value_e;             /* Expression: 1
                                        * Referenced by: '<S56>/Constant'
                                        */
  real_T Constant_Value_j;             /* Expression: 1
                                        * Referenced by: '<S54>/Constant'
                                        */
  real_T Switch_Threshold_bp;          /* Expression: 0
                                        * Referenced by: '<S54>/Switch'
                                        */
  real_T Constant_Value_jy;            /* Expression: 1
                                        * Referenced by: '<S55>/Constant'
                                        */
  real_T Switch_Threshold_au;          /* Expression: 0
                                        * Referenced by: '<S55>/Switch'
                                        */
  real_T Constant_Value_o;             /* Expression: shaftSwitchMask
                                        * Referenced by: '<S49>/Constant'
                                        */
  real_T Constant6_Value_f;            /* Expression: 1
                                        * Referenced by: '<S49>/Constant6'
                                        */
  real_T Switch1_Threshold_b;          /* Expression: 1
                                        * Referenced by: '<S49>/Switch1'
                                        */
  real_T Reset_Value_e;                /* Expression: 1
                                        * Referenced by: '<S14>/Reset'
                                        */
  real_T Gain1_Gain_a;                 /* Expression: 1/2
                                        * Referenced by: '<S29>/Gain1'
                                        */
  real_T Constant_Value_cg;            /* Expression: 1
                                        * Referenced by: '<S39>/Constant'
                                        */
  real_T Switch_Threshold_j;           /* Expression: 0
                                        * Referenced by: '<S39>/Switch'
                                        */
  real_T Constant_Value_h;             /* Expression: 1
                                        * Referenced by: '<S37>/Constant'
                                        */
  real_T Switch_Threshold_kx;          /* Expression: 0
                                        * Referenced by: '<S37>/Switch'
                                        */
  real_T Constant_Value_kx;            /* Expression: 1
                                        * Referenced by: '<S38>/Constant'
                                        */
  real_T Switch_Threshold_mt;          /* Expression: 0
                                        * Referenced by: '<S38>/Switch'
                                        */
  real_T Constant_Value_jq;            /* Expression: shaftSwitchMask
                                        * Referenced by: '<S32>/Constant'
                                        */
  real_T Constant6_Value_fv;           /* Expression: 1
                                        * Referenced by: '<S32>/Constant6'
                                        */
  real_T Switch1_Threshold_n;          /* Expression: 1
                                        * Referenced by: '<S32>/Switch1'
                                        */
  real_T Reset_Value_l;                /* Expression: 1
                                        * Referenced by: '<S61>/Reset'
                                        */
  uint32_T Eta4D_maxIndex[4];          /* Computed Parameter: Eta4D_maxIndex
                                        * Referenced by: '<S117>/Eta 4D'
                                        */
  uint32_T Eta4D_dimSizes[4];          /* Computed Parameter: Eta4D_dimSizes
                                        * Referenced by: '<S117>/Eta 4D'
                                        */
  uint32_T Eta4D_maxIndex_m[4];        /* Computed Parameter: Eta4D_maxIndex_m
                                        * Referenced by: '<S125>/Eta 4D'
                                        */
  uint32_T Eta4D_dimSizes_m[4];        /* Computed Parameter: Eta4D_dimSizes_m
                                        * Referenced by: '<S125>/Eta 4D'
                                        */
  uint32_T TorqueRatiozetaInterpolation_maxIndex;
                    /* Computed Parameter: TorqueRatiozetaInterpolation_maxIndex
                     * Referenced by: '<S152>/Torque Ratio zeta Interpolation'
                     */
  uint32_T CapacityKfactorInterpolation_maxIndex;
                    /* Computed Parameter: CapacityKfactorInterpolation_maxIndex
                     * Referenced by: '<S152>/Capacity, K-factor Interpolation'
                     */
  boolean_T Memory_InitialCondition_o; /* Expression: ClutchLocked
                                        * Referenced by: '<S145>/Memory'
                                        */
  boolean_T CombinatorialLogic_table[8];
                                 /* Computed Parameter: CombinatorialLogic_table
                                  * Referenced by: '<S145>/Combinatorial  Logic'
                                  */
  boolean_T Relay1_YOn;                /* Computed Parameter: Relay1_YOn
                                        * Referenced by: '<S149>/Relay1'
                                        */
  boolean_T Relay1_YOff;               /* Computed Parameter: Relay1_YOff
                                        * Referenced by: '<S149>/Relay1'
                                        */
  P_OpenDifferential_DrivetrainHevP4_T sf_OpenDifferential_l;/* '<S42>/Open Differential' */
  P_Clutch_DrivetrainHevP4_T Clutch_e; /* '<S259>/Clutch' */
  P_Clutch_DrivetrainHevP4_T Clutch;   /* '<S217>/Clutch' */
  P_OpenDifferential_DrivetrainHevP4_T sf_OpenDifferential;/* '<S25>/Open Differential' */
};

/* Real-time Model Data Structure */
struct tag_RTM_DrivetrainHevP4_T {
  struct SimStruct_tag *rtS;

  /*
   * The following structure contains memory needed to
   * track noncontinuous signals feeding derivative ports.
   */
  struct {
    real_T mr_nonContSig0[1];
    real_T mr_nonContSig1[1];
    real_T mr_nonContSig2[1];
    real_T mr_nonContSig3[1];
    real_T mr_nonContSig4[1];
    real_T mr_nonContSig5[1];
    real_T mr_nonContSig6[1];
    real_T mr_nonContSig7[1];
    real_T mr_nonContSig8[1];
    real_T mr_nonContSig9[1];
    real_T mr_nonContSig10[1];
    real_T mr_nonContSig11[1];
    real_T mr_nonContSig12[1];
    real_T mr_nonContSig13[1];
    real_T mr_nonContSig14[1];
    real_T mr_nonContSig15[1];
    boolean_T mr_nonContSig16[1];
    boolean_T mr_nonContSig17[1];
    boolean_T mr_nonContSig18[1];
    boolean_T mr_nonContSig19[1];
    boolean_T mr_nonContSig20[1];
    boolean_T mr_nonContSig21[1];
  } NonContDerivMemory;

  ssNonContDerivSigInfo nonContDerivSignal[22];
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[819];
    int32_T* vardimsAddress[819];
    RTWLoggingFcnPtr loggingPtrs[819];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    int_T mdlref_GlobalTID[2];
  } Timing;
};

typedef struct {
  B_DrivetrainHevP4_c_T rtb;
  DW_DrivetrainHevP4_f_T rtdw;
  RT_MODEL_DrivetrainHevP4_T rtm;
  ZCE_DrivetrainHevP4_T rtzce;
} MdlrefDW_DrivetrainHevP4_T;

/* Model reference registration function */
extern void DrivetrainHevP4_initialize(SimStruct *const rtS,
  ssNonContDerivSigFeedingOutports **mr_nonContOutputArray, int_T mdlref_TID0,
  int_T mdlref_TID1, RT_MODEL_DrivetrainHevP4_T *const DrivetrainHevP4_M,
  B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  X_DrivetrainHevP4_n_T *localX, ZCE_DrivetrainHevP4_T *localZCE,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  DrivetrainHevP4_GetCAPIStaticMap(void);
extern void DrivetrainHevP4_OpenDifferential(real_T rtu_u, real_T rtu_u_m,
  real_T rtu_u_k, real_T rtu_bw1, real_T rtu_bd, real_T rtu_bw2, real_T
  rtu_Ndiff, real_T rtu_Jd, real_T rtu_Jw1, real_T rtu_Jw2, const real_T rtu_x[2],
  B_OpenDifferential_DrivetrainHevP4_T *localB,
  P_OpenDifferential_DrivetrainHevP4_T *localP);
extern void DrivetrainHevP4_Clutch_Init(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, P_Clutch_DrivetrainHevP4_o_T *localP,
  X_Clutch_DrivetrainHevP4_n_T *localX);
extern void DrivetrainHevP4_Clutch_Reset(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, X_Clutch_DrivetrainHevP4_n_T *localX);
extern void DrivetrainHevP4_Clutch_Start(B_Clutch_DrivetrainHevP4_k_T *localB);
extern void DrivetrainHevP4_Clutch_Deriv(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, XDot_Clutch_DrivetrainHevP4_p_T
  *localXdot);
extern void DrivetrainHevP4_Clutch(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, real_T rtu_Tout, real_T rtu_Tfmaxs, real_T rtu_Tfmaxk,
  real_T rtp_OmegaTol, B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, P_Clutch_DrivetrainHevP4_o_T *localP,
  X_Clutch_DrivetrainHevP4_n_T *localX);
extern void DrivetrainHevP4_Clutch_g_Init(B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, P_Clutch_DrivetrainHevP4_T *localP,
  X_Clutch_DrivetrainHevP4_T *localX);
extern void DrivetrainHevP4_Clutch_b_Reset(B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, X_Clutch_DrivetrainHevP4_T *localX);
extern void DrivetrainHevP4_Clutch_i_Start(B_Clutch_DrivetrainHevP4_T *localB);
extern void DrivetrainHevP4_Clutch_d_Deriv(real_T rtu_Tout, real_T rtu_Tfmaxs,
  real_T rtu_Tfmaxk, B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, XDot_Clutch_DrivetrainHevP4_T *localXdot);
extern void DrivetrainHevP4_Clutch_l(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, real_T rtu_Tout, real_T rtu_Tfmaxs, real_T rtu_Tfmaxk,
  real_T *rty_Omega, B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, P_Clutch_DrivetrainHevP4_T *localP,
  X_Clutch_DrivetrainHevP4_T *localX);
extern void DrivetrainHevP4_SimpleMagicTire(real_T rtu_ReNom, real_T rtu_Fz,
  real_T rtu_Omega, real_T rtu_Vx, real_T rtu_MagicPeak, real_T rtu_MagicPeak_a,
  real_T rtu_MagicPeak_m, real_T rtu_MagicPeak_b, real_T rtu_MagicPeak_l, const
  real_T rtu_MagicFxo[34], const real_T rtu_kappaFx[3], const real_T rtu_FzFx[3],
  const real_T rtu_FxMap[9], real_T rtu_RollRes, real_T rtu_RollRes_f, real_T
  rtu_RollRes_m, real_T rtu_RollRes_k, real_T rtu_RollRes_b, real_T
  rtu_RollRes_km, real_T rtu_RollRes_l, real_T rtu_RollRes_ly, real_T
  rtu_RollRes_i, real_T rtu_RollRes_c, real_T rtu_RollRes_h, real_T
  rtu_RollRes_bu, real_T rtu_RollRes_d, real_T rtu_RollRes_is, real_T
  rtu_RollRes_im, real_T rtu_RollRes_ic, const real_T rtu_VxMy[3], const real_T
  rtu_FzMy[3], const real_T rtu_MyMap[9], real_T rtu_rho, real_T rtu_FxType,
  real_T rtu_rollingType, real_T rtu_vertType,
  B_SimpleMagicTire_DrivetrainHevP4_T *localB);
extern void DrivetrainHevP4_Init(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, real_T *rty_EngSpd, B_DrivetrainHevP4_c_T *localB,
  DW_DrivetrainHevP4_f_T *localDW, X_DrivetrainHevP4_n_T *localX);
extern void DrivetrainHevP4_Reset(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, X_DrivetrainHevP4_n_T *localX);
extern void DrivetrainHevP4_Start(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, XDis_DrivetrainHevP4_n_T *localXdis);
extern void DrivetrainHevP4_Deriv(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, const real_T *rtu_MotTrq, const real_T *rtu_Grade, const
  real_T *rtu_WindVel, const real_T *rtu_BrkCmd, const real_T *rtu_GearCmd,
  B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  X_DrivetrainHevP4_n_T *localX, XDis_DrivetrainHevP4_n_T *localXdis,
  XDot_DrivetrainHevP4_n_T *localXdot);
extern void DrivetrainHevP4_ZC(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, const real_T *rtu_MotTrq, const real_T *rtu_Grade, const
  real_T *rtu_WindVel, const real_T *rtu_BrkCmd, const real_T *rtu_GearCmd,
  real_T *rty_EngSpd, real_T *rty_TransGear, B_DrivetrainHevP4_c_T *localB,
  DW_DrivetrainHevP4_f_T *localDW, X_DrivetrainHevP4_n_T *localX,
  ZCV_DrivetrainHevP4_g_T *localZCSV);
extern void DrivetrainHevP4_Disable(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, DW_DrivetrainHevP4_f_T *localDW, XDis_DrivetrainHevP4_n_T
  *localXdis);
extern void DrivetrainHevP4_Update(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, const real_T *rtu_MotTrq, const real_T *rtu_Grade, const
  real_T *rtu_WindVel, const real_T *rtu_BrkCmd, const real_T *rtu_GearCmd,
  boolean_T *rty_Cltch2State, B_DrivetrainHevP4_c_T *localB,
  DW_DrivetrainHevP4_f_T *localDW, X_DrivetrainHevP4_n_T *localX,
  XDis_DrivetrainHevP4_n_T *localXdis);
extern void DrivetrainHevP4(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  const real_T *rtu_EngTrq, real_T *rty_VehSpd, real_T *rty_EngSpd, boolean_T
  *rty_Cltch1State, boolean_T *rty_Cltch2State, real_T *rty_MotSpd, real_T
  *rty_TransGear, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  X_DrivetrainHevP4_n_T *localX, ZCE_DrivetrainHevP4_T *localZCE,
  XDis_DrivetrainHevP4_n_T *localXdis);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'DrivetrainHevP4'
 * '<S1>'   : 'DrivetrainHevP4/Differential and Compliance'
 * '<S2>'   : 'DrivetrainHevP4/Torque Converter Automatic Transmission'
 * '<S3>'   : 'DrivetrainHevP4/Vehicle'
 * '<S4>'   : 'DrivetrainHevP4/Vehicle Output Interface'
 * '<S5>'   : 'DrivetrainHevP4/Wheels and Brakes'
 * '<S6>'   : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1'
 * '<S7>'   : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 2'
 * '<S8>'   : 'DrivetrainHevP4/Differential and Compliance/Open Differential'
 * '<S9>'   : 'DrivetrainHevP4/Differential and Compliance/Open Differential1'
 * '<S10>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1'
 * '<S11>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 2'
 * '<S12>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way'
 * '<S13>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear'
 * '<S14>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn'
 * '<S15>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power'
 * '<S16>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Damping Power'
 * '<S17>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator'
 * '<S18>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S19>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S20>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S21>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 2/Power Accounting Bus Creator'
 * '<S22>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 2/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S23>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 2/Power Accounting Bus Creator/PwrStored Input'
 * '<S24>'  : 'DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 2/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S25>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential'
 * '<S26>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation'
 * '<S27>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency'
 * '<S28>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Open Differential'
 * '<S29>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/y'
 * '<S30>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power'
 * '<S31>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Damping Power'
 * '<S32>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Kinetic Power'
 * '<S33>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Power Accounting Bus Creator'
 * '<S34>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S35>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S36>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S37>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Axle 1 Efficiency'
 * '<S38>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Axle 2 Efficiency'
 * '<S39>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Drive Efficiency'
 * '<S40>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Eta'
 * '<S41>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Eta/Constant Eta'
 * '<S42>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential'
 * '<S43>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation'
 * '<S44>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency'
 * '<S45>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Open Differential'
 * '<S46>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/y'
 * '<S47>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power'
 * '<S48>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Damping Power'
 * '<S49>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Kinetic Power'
 * '<S50>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Power Accounting Bus Creator'
 * '<S51>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S52>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S53>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S54>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Axle 1 Efficiency'
 * '<S55>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Axle 2 Efficiency'
 * '<S56>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Drive Efficiency'
 * '<S57>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Eta'
 * '<S58>'  : 'DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Eta/Constant Eta'
 * '<S59>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way'
 * '<S60>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear'
 * '<S61>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn'
 * '<S62>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power'
 * '<S63>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Damping Power'
 * '<S64>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator'
 * '<S65>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S66>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S67>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S68>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 2/Power Accounting Bus Creator'
 * '<S69>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 2/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S70>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 2/Power Accounting Bus Creator/PwrStored Input'
 * '<S71>'  : 'DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 2/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S72>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance'
 * '<S73>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1'
 * '<S74>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission'
 * '<S75>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter'
 * '<S76>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way'
 * '<S77>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear'
 * '<S78>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn'
 * '<S79>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power'
 * '<S80>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Damping Power'
 * '<S81>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator'
 * '<S82>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S83>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S84>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S85>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way'
 * '<S86>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear'
 * '<S87>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn'
 * '<S88>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power'
 * '<S89>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Damping Power'
 * '<S90>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator'
 * '<S91>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S92>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S93>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S94>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission'
 * '<S95>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation'
 * '<S96>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Cont LPF IC Dyn'
 * '<S97>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/IC tunable'
 * '<S98>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked'
 * '<S99>'  : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Neutral IC'
 * '<S100>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked'
 * '<S101>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/input IC'
 * '<S102>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/Power Accounting Bus Creator'
 * '<S103>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/div0protect - abs poly1'
 * '<S104>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S105>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/Power Accounting Bus Creator/PwrStored Input'
 * '<S106>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S107>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/div0protect - abs poly1/Compare To Constant'
 * '<S108>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Bus Creation/div0protect - abs poly1/Compare To Constant1'
 * '<S109>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Apply Efficiency'
 * '<S110>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Apply Efficiency '
 * '<S111>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency'
 * '<S112>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/gear2props'
 * '<S113>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/div0protect - abs poly'
 * '<S114>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/div0protect - abs poly/Compare To Constant'
 * '<S115>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/div0protect - abs poly/Compare To Constant1'
 * '<S116>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/gear2props/Eta Lookup'
 * '<S117>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/gear2props/Eta Lookup/Eta 4D'
 * '<S118>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Apply Efficiency'
 * '<S119>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency'
 * '<S120>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/gear2props'
 * '<S121>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/div0protect - abs poly'
 * '<S122>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/div0protect - abs poly/Compare To Constant'
 * '<S123>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/div0protect - abs poly/Compare To Constant1'
 * '<S124>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/gear2props/Eta Lookup'
 * '<S125>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/gear2props/Eta Lookup/Eta 4D'
 * '<S126>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up'
 * '<S127>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation'
 * '<S128>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable'
 * '<S129>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable1'
 * '<S130>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic'
 * '<S131>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type'
 * '<S132>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked'
 * '<S133>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked'
 * '<S134>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/output IC'
 * '<S135>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Efficiency Calculation'
 * '<S136>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Power Accounting Bus Creator'
 * '<S137>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Efficiency Calculation/div0protect - abs poly'
 * '<S138>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Efficiency Calculation/div0protect - abs poly/Compare To Constant'
 * '<S139>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Efficiency Calculation/div0protect - abs poly/Compare To Constant1'
 * '<S140>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S141>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Power Accounting Bus Creator/PwrStored Input'
 * '<S142>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Bus Creation/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S143>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Break Apart Detection'
 * '<S144>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup Detection'
 * '<S145>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup FSM'
 * '<S146>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Requisite Friction'
 * '<S147>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup Detection/Friction Calc'
 * '<S148>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup Detection/Required Friction for Lockup'
 * '<S149>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal'
 * '<S150>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Cont LPF IC Dyn'
 * '<S151>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Friction Model'
 * '<S152>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter'
 * '<S153>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response'
 * '<S154>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio'
 * '<S155>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/Compare To Zero'
 * '<S156>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF'
 * '<S157>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Cont LPF Dyn'
 * '<S158>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Compare To Constant2'
 * '<S159>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Saturation Dynamic'
 * '<S160>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/div0protect - poly'
 * '<S161>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/div0protect - poly/Compare To Constant'
 * '<S162>' : 'DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/div0protect - poly/Compare To Constant1'
 * '<S163>' : 'DrivetrainHevP4/Vehicle/Cont LPF'
 * '<S164>' : 'DrivetrainHevP4/Vehicle/Cont LPF1'
 * '<S165>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal'
 * '<S166>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF'
 * '<S167>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation'
 * '<S168>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Inertial Axes'
 * '<S169>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle'
 * '<S170>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/WindDim'
 * '<S171>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Body Frame'
 * '<S172>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Forces'
 * '<S173>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing'
 * '<S174>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame'
 * '<S175>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Moments'
 * '<S176>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Power'
 * '<S177>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Body Frame/Longitudinal 1DOF'
 * '<S178>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Forces/Forces 1DOF'
 * '<S179>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF'
 * '<S180>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front'
 * '<S181>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear'
 * '<S182>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/Rotation Angles to Direction Cosine Matrix'
 * '<S183>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/transform to Inertial axes'
 * '<S184>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/transform to Inertial axes1'
 * '<S185>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/wxR'
 * '<S186>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S187>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/wxR/Subsystem'
 * '<S188>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front/wxR/Subsystem1'
 * '<S189>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/Rotation Angles to Direction Cosine Matrix'
 * '<S190>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/transform to Inertial axes'
 * '<S191>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/transform to Inertial axes1'
 * '<S192>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/wxR'
 * '<S193>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S194>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/wxR/Subsystem'
 * '<S195>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear/wxR/Subsystem1'
 * '<S196>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame/Inertial Axes'
 * '<S197>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix'
 * '<S198>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S199>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Power/Longitudinal 1DOF'
 * '<S200>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Power/Longitudinal 1DOF/Power Accounting Bus Creator'
 * '<S201>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Power/Longitudinal 1DOF/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S202>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Power/Longitudinal 1DOF/Power Accounting Bus Creator/PwrStored Input'
 * '<S203>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Power/Longitudinal 1DOF/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S204>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Inertial Axes/Rotation Angles to Direction Cosine Matrix'
 * '<S205>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S206>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force'
 * '<S207>' : 'DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/WindDim/WindX'
 * '<S208>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1'
 * '<S209>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 2'
 * '<S210>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1'
 * '<S211>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 2'
 * '<S212>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Bus Routing'
 * '<S213>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Basic Magic Tire'
 * '<S214>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters'
 * '<S215>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters'
 * '<S216>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF'
 * '<S217>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module'
 * '<S218>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Bus Routing/Power'
 * '<S219>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Bus Routing/Power/Power Accounting Bus Creator'
 * '<S220>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Bus Routing/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S221>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Bus Routing/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S222>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Bus Routing/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S223>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Basic Magic Tire/Simple Magic Tire'
 * '<S224>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value'
 * '<S225>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple'
 * '<S226>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None'
 * '<S227>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes'
 * '<S228>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch'
 * '<S229>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Friction Model'
 * '<S230>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation'
 * '<S231>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake'
 * '<S232>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake/Disk Brake'
 * '<S233>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch'
 * '<S234>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked'
 * '<S235>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Slipping'
 * '<S236>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup'
 * '<S237>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectSlip'
 * '<S238>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic'
 * '<S239>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Break Apart Detection'
 * '<S240>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup Detection'
 * '<S241>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM'
 * '<S242>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Requisite Friction'
 * '<S243>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup Detection/Friction Calc'
 * '<S244>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup Detection/Required Friction for Lockup'
 * '<S245>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectSlip/Break Apart Detection'
 * '<S246>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/Cont LPF Dyn'
 * '<S247>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/div0protect - abs poly'
 * '<S248>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/div0protect - abs poly/Compare To Constant'
 * '<S249>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/div0protect - abs poly/Compare To Constant1'
 * '<S250>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 2/Power Accounting Bus Creator'
 * '<S251>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 2/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S252>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 2/Power Accounting Bus Creator/PwrStored Input'
 * '<S253>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 2/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S254>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Bus Routing'
 * '<S255>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Basic Magic Tire'
 * '<S256>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters'
 * '<S257>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters'
 * '<S258>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF'
 * '<S259>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module'
 * '<S260>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Bus Routing/Power'
 * '<S261>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Bus Routing/Power/Power Accounting Bus Creator'
 * '<S262>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Bus Routing/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S263>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Bus Routing/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S264>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Bus Routing/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S265>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Basic Magic Tire/Simple Magic Tire'
 * '<S266>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value'
 * '<S267>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple'
 * '<S268>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None'
 * '<S269>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes'
 * '<S270>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch'
 * '<S271>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Friction Model'
 * '<S272>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation'
 * '<S273>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake'
 * '<S274>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake/Disk Brake'
 * '<S275>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch'
 * '<S276>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked'
 * '<S277>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Slipping'
 * '<S278>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup'
 * '<S279>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectSlip'
 * '<S280>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic'
 * '<S281>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Break Apart Detection'
 * '<S282>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup Detection'
 * '<S283>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM'
 * '<S284>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Requisite Friction'
 * '<S285>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup Detection/Friction Calc'
 * '<S286>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup Detection/Required Friction for Lockup'
 * '<S287>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectSlip/Break Apart Detection'
 * '<S288>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/Cont LPF Dyn'
 * '<S289>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/div0protect - abs poly'
 * '<S290>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/div0protect - abs poly/Compare To Constant'
 * '<S291>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/div0protect - abs poly/Compare To Constant1'
 * '<S292>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 2/Power Accounting Bus Creator'
 * '<S293>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 2/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S294>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 2/Power Accounting Bus Creator/PwrStored Input'
 * '<S295>' : 'DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 2/Power Accounting Bus Creator/PwrTrnsfrd Input'
 */
#endif                                 /* RTW_HEADER_DrivetrainHevP4_h_ */
