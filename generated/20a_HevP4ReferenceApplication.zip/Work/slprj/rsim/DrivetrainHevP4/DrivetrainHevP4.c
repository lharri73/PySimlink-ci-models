/*
 * Code generation for system model 'DrivetrainHevP4'
 *
 * Model                      : DrivetrainHevP4
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:18 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "DrivetrainHevP4_capi.h"
#include "DrivetrainHevP4.h"
#include "DrivetrainHevP4_private.h"
#include "automldiffopen_ZyWLRRPX.h"
#include "interp2_MZVr1hxC.h"
#include "intrp1d_la_pw.h"
#include "intrp4d_l_pw.h"
#include "look1_binlcpw.h"
#include "look1_binlxpw.h"
#include "plook_binc.h"
#include "plook_bincpa.h"
#include "plook_u32d_binckan.h"
#include "rt_atan2d_snf.h"
#include "rt_powd_snf.h"

/* Named constants for Chart: '<S228>/Clutch' */
#define DrivetrainHevP4_IN_Locked      ((uint8_T)1U)
#define DrivetrainHevP4_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define DrivetrainHevP4_IN_Slipping    ((uint8_T)2U)

P_DrivetrainHevP4_T DrivetrainHevP4_P = {
  2.46,
  0.25,
  6570.0,
  0.0,

  { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 },
  0.8,
  0.01,
  0.2,

  { 0.009, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01 },
  0.01,
  0.01,
  0.01,
  10000.0,
  0.15,
  1623.0,

  { 1.0, 4.212, 2.637, 1.8, 1.386, 1.0, 0.772 },
  2.0,
  2.0,
  3.32,
  4.1,
  101325.0,
  0.327,
  0.11,
  0.15,
  300.0,

  { 313.0, 358.0 },

  { 25.0, 50.0, 75.0, 100.0, 150.0, 200.0, 250.0 },
  0.336,
  2.0,
  0.01,
  1.09,
  0.0,
  400.0,
  0.0,
  1.7,
  0.001,
  1.0,
  0.001,

  { 0.003, 0.003, 0.003, 0.003, 0.003, 0.003, 0.003 },
  0.001,
  0.001,
  0.001,
  0.001,
  0.0,
  0.05,
  0.0,
  0.98,

  { 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124 },
  9.81,
  0.5,
  10000.0,
  1.5,
  1.0,
  0.35,
  0.45,
  0.4,
  0.45,
  2.0,

  { 500.38314108091896, 749.619781962827, 1002.6761414789406, 1250.9578527022975,
    1499.239563925654, 1747.5212751490108, 1995.8029863723675, 2501.915705404595,
    2998.479127851308, 4001.1552693302488, 5003.83141080919 },
  500.0,
  0.0,
  0.0,
  94.247779607693786,
  0.0,
  0.0,
  83.775804095727821,
  0.0,
  0.0,

  { 0.0, 0.5, 0.6, 0.7, 0.8, 0.87, 0.92, 0.94, 0.96, 0.97 },
  0.85,
  234400.0,

  { 12.2938, 12.8588, 13.1452, 13.6285, 14.6163, 16.2675, 19.3503, 22.1046,
    29.9986, 50.0 },
  0.6,
  0.1,
  0.08,
  0.0,
  10.0,
  0.0,
  0.0,

  { 2.232, 1.5462, 1.4058, 1.2746, 1.1528, 1.0732, 1.0192, 0.9983, 0.9983,
    0.9983 },
  0.0,
  0.0,

  { 0.0, 0.0 },

  { 0.0, 0.0 },
  0.0,
  1.0,
  287.058,
  0.0,
  0.0,

  { -1.0, 1.0 },
  1.0,
  0.0,
  1.0E-6,
  1.0E-6,
  1.0,
  0.6,
  0.0,
  2.2204460492503131E-16,
  0.4,
  0.0,
  2.2204460492503131E-16,

  { 0.0, 0.0 },

  { -1.0, 1.0 },

  { 4.0, 4.0, 4.0 },
  0.0,
  1.0,
  0.0,
  1.0,
  0.0,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  1.0,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  5000.0,
  -5000.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.15915494309189535,
  0.0,
  2.2204460492503131E-16,
  0.0,
  5000.0,
  -5000.0,
  5000.0,
  -5000.0,
  4.0,
  1.0,
  1.0,
  0.0,
  1.0,
  -1.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  2.2204460492503131E-16,
  0.0,
  0.0,
  0.0,
  -1.0,
  0.78539816339744828,
  1.0,
  1.65,
  10.0,
  0.01,

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  10000.0,
  1.0E+6,

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  2.2204460492503131E-16,
  0.0,
  0.0,
  0.0,
  -1.0,
  0.78539816339744828,
  1.0,
  1.65,
  10.0,
  0.01,

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  10000.0,
  1.0E+6,

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  2.2204460492503131E-16,
  1.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  6.2831853071795862,
  1.0,
  0.0,
  0.0,
  0.0,
  6.2831853071795862,
  0.0,
  1.0,
  1.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  1.0,
  1.0,
  5000.0,
  -5000.0,
  1.0,
  1.0,
  1.0,
  1.0,
  1.0,
  5000.0,
  -5000.0,
  0.5,
  1.0,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  1.0,
  1.0,
  1.0,
  0.5,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  1.0,
  1.0,
  1.0,

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },
  9U,
  9U,
  false,

  { false, true, false, false, true, true, true, false },
  true,
  false,

  /* Start of '<S42>/Open Differential' */
  {
    1.0
  }
  ,

  /* End of '<S42>/Open Differential' */

  /* Start of '<S259>/Clutch' */
  {
    /* Start of '<S228>/CoreSubsys' */
    {
      /* Start of '<S228>/Clutch' */
      {
        0.0,
        0.0,
        0.0,
        0.0,
        -4.0,
        false,
        false,
        false,

        { false, true, false, false, true, true, true, false }
      }
      /* End of '<S228>/Clutch' */
    }
    /* End of '<S228>/CoreSubsys' */
  }
  ,

  /* End of '<S259>/Clutch' */

  /* Start of '<S217>/Clutch' */
  {
    /* Start of '<S228>/CoreSubsys' */
    {
      /* Start of '<S228>/Clutch' */
      {
        0.0,
        0.0,
        0.0,
        0.0,
        -4.0,
        false,
        false,
        false,

        { false, true, false, false, true, true, true, false }
      }
      /* End of '<S228>/Clutch' */
    }
    /* End of '<S228>/CoreSubsys' */
  }
  ,

  /* End of '<S217>/Clutch' */

  /* Start of '<S25>/Open Differential' */
  {
    1.0
  }
  /* End of '<S25>/Open Differential' */
};

/* Forward declaration for local functions */
static boolean_T DrivetrainHevP4_detectSlip(real_T Tout, real_T Tfmaxs,
  B_Clutch_DrivetrainHevP4_k_T *localB);
static boolean_T DrivetrainHevP4_detectLockup(real_T Tout, real_T Tfmaxs,
  B_Clutch_DrivetrainHevP4_k_T *localB, DW_Clutch_DrivetrainHevP4_k_T *localDW,
  P_Clutch_DrivetrainHevP4_o_T *localP);

/* Forward declaration for local functions */
static void DrivetrainHevP4_power(const real_T a_data[], const int32_T a_size[2],
  real_T y_data[], int32_T y_size[2]);
static real_T DrivetrainHevP4_automltirekappa(real_T Re, real_T omega, real_T Vx,
  real_T b_VXLOW, real_T b_kappamax);
static real_T DrivetrainHevP4_automltirepurelongFx(real_T kappa, real_T Vx,
  real_T Fz, real_T b_gamma, real_T LONGVL, real_T FNOMIN, real_T b_FZMIN,
  real_T b_FZMAX, real_T press, real_T NOMPRES, real_T PRESMIN, real_T PRESMAX,
  real_T PCX1, real_T PDX1, real_T PDX2, real_T PDX3, real_T PEX1, real_T PEX2,
  real_T PEX3, real_T PEX4, real_T PKX1, real_T PKX2, real_T PKX3, real_T PHX1,
  real_T PHX2, real_T PVX1, real_T PVX2, real_T PPX1, real_T PPX2, real_T PPX3,
  real_T PPX4, real_T lam_Fzo, real_T lam_muV, real_T lam_mux, real_T
  lam_Kxkappa, real_T lam_Cx, real_T lam_Ex, real_T lam_Hx, real_T lam_Vx);
static real_T DrivetrainHevP4_automltirelongFxMapped(real_T kappa, real_T Fz,
  const real_T kappaFx[3], const real_T FzFx[3], const real_T FxMap[9], real_T
  b_FZMIN, real_T b_FZMAX, real_T lam_mux);
static real_T DrivetrainHevP4_automltirelongMySAE(real_T Fz, real_T omega,
  real_T Vx, real_T press, real_T QSY1, real_T QSY2, real_T QSY3, real_T QSY7,
  real_T QSY8, real_T UNLOADED_RADIUS, real_T b_FZMIN, real_T b_FZMAX, real_T
  PRESMIN, real_T PRESMAX);
static real_T DrivetrainHevP4_automltirelongMyMapped(real_T omega, real_T Fz,
  real_T Vx, const real_T VxMy[3], const real_T FzMy[3], const real_T MyMap[9],
  real_T b_FZMAX);
static real_T DrivetrainHevP4_automltirelongMyISO(real_T Fz, real_T omega,
  real_T Tamb, real_T Fpl, real_T Cr, real_T Kt, real_T Tmeas, real_T Re, real_T
  b_FZMIN, real_T b_FZMAX, real_T TMIN, real_T TMAX);

/*
 * Output and update for atomic system:
 *    '<S25>/Open Differential'
 *    '<S42>/Open Differential'
 */
void DrivetrainHevP4_OpenDifferential(real_T rtu_u, real_T rtu_u_m, real_T
  rtu_u_k, real_T rtu_bw1, real_T rtu_bd, real_T rtu_bw2, real_T rtu_Ndiff,
  real_T rtu_Jd, real_T rtu_Jw1, real_T rtu_Jw2, const real_T rtu_x[2],
  B_OpenDifferential_DrivetrainHevP4_T *localB,
  P_OpenDifferential_DrivetrainHevP4_T *localP)
{
  real_T a__2[3];
  real_T rtu_u_0[3];
  if (localP->OpenDifferential_shaftSwitchMask == 1.0) {
    /* SignalConversion generated from: '<S28>/ SFunction ' */
    rtu_u_0[0] = rtu_u;
    rtu_u_0[1] = rtu_u_m;
    rtu_u_0[2] = rtu_u_k;
    automldiffopen_ZyWLRRPX(rtu_u_0, rtu_bw1, rtu_bd, rtu_bw2, rtu_Ndiff, 1.0,
      rtu_Jd, rtu_Jw1, rtu_Jw2, rtu_x, a__2, localB->xdot);
  } else {
    /* SignalConversion generated from: '<S28>/ SFunction ' */
    rtu_u_0[0] = rtu_u;
    rtu_u_0[1] = rtu_u_m;
    rtu_u_0[2] = rtu_u_k;
    automldiffopen_ZyWLRRPX(rtu_u_0, rtu_bw1, rtu_bd, rtu_bw2, rtu_Ndiff, 0.0,
      rtu_Jd, rtu_Jw1, rtu_Jw2, rtu_x, a__2, localB->xdot);
  }
}

/* Function for Chart: '<S228>/Clutch' */
static boolean_T DrivetrainHevP4_detectSlip(real_T Tout, real_T Tfmaxs,
  B_Clutch_DrivetrainHevP4_k_T *localB)
{
  localB->Tout = Tout;
  localB->Tfmaxs = Tfmaxs;

  /* Outputs for Function Call SubSystem: '<S233>/detectSlip' */
  /* RelationalOperator: '<S245>/Relational Operator' incorporates:
   *  Abs: '<S245>/Abs'
   */
  localB->RelationalOperator = (fabs(localB->Tout) >= localB->Tfmaxs);

  /* End of Outputs for SubSystem: '<S233>/detectSlip' */
  return localB->RelationalOperator;
}

/* Function for Chart: '<S228>/Clutch' */
static boolean_T DrivetrainHevP4_detectLockup(real_T Tout, real_T Tfmaxs,
  B_Clutch_DrivetrainHevP4_k_T *localB, DW_Clutch_DrivetrainHevP4_k_T *localDW,
  P_Clutch_DrivetrainHevP4_o_T *localP)
{
  real_T rtb_Abs_f;
  localB->Tout_e = Tout;
  localB->Tfmaxs_p = Tfmaxs;

  /* Outputs for Function Call SubSystem: '<S233>/detectLockup' */
  /* Gain: '<S242>/Output Damping' incorporates:
   *  Constant: '<S236>/Constant'
   */
  rtb_Abs_f = DrivetrainHevP4_P.br * localP->Constant_Value;

  /* CombinatorialLogic: '<S241>/Combinatorial  Logic' incorporates:
   *  Abs: '<S239>/Abs'
   *  Abs: '<S244>/Abs'
   *  RelationalOperator: '<S239>/Relational Operator'
   *  RelationalOperator: '<S244>/Relational Operator'
   *  Sum: '<S242>/Sum1'
   *  Sum: '<S242>/Sum2'
   *  UnaryMinus: '<S243>/Unary Minus'
   *  UnitDelay: '<S241>/Unit Delay'
   */
  localB->CombinatorialLogic = localP->CombinatorialLogic_table[(((fabs(((0.0 -
    localB->Tout_e) - rtb_Abs_f) + rtb_Abs_f) >= localB->Tfmaxs_p) + ((uint32_T)
    (fabs(-localB->Tout_e) <= localB->Tfmaxs_p) << 1)) << 1) +
    localDW->UnitDelay_DSTATE];

  /* Update for UnitDelay: '<S241>/Unit Delay' */
  localDW->UnitDelay_DSTATE = localB->CombinatorialLogic;

  /* End of Outputs for SubSystem: '<S233>/detectLockup' */
  return localB->CombinatorialLogic;
}

/*
 * System initialize for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Init(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, P_Clutch_DrivetrainHevP4_o_T *localP,
  X_Clutch_DrivetrainHevP4_n_T *localX)
{
  localDW->is_active_c8_autolibshared = 0U;
  localDW->is_c8_autolibshared = DrivetrainHevP4_IN_NO_ACTIVE_CHILD;

  /* InitializeConditions for Merge: '<S233>/ Merge ' */
  localB->Omega = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 1' */
  localB->Omegadot = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 3' */
  localB->Myb = 0.0;

  /* SystemInitialize for Function Call SubSystem: '<S233>/detectSlip' */
  /* SystemInitialize for RelationalOperator: '<S245>/Relational Operator' incorporates:
   *  Outport: '<S237>/yn'
   */
  localB->RelationalOperator = localP->yn_Y0;

  /* End of SystemInitialize for SubSystem: '<S233>/detectSlip' */

  /* SystemInitialize for Function Call SubSystem: '<S233>/detectLockup' */
  /* InitializeConditions for UnitDelay: '<S241>/Unit Delay' */
  localDW->UnitDelay_DSTATE = localP->UnitDelay_InitialCondition;

  /* SystemInitialize for CombinatorialLogic: '<S241>/Combinatorial  Logic' incorporates:
   *  Outport: '<S236>/yn'
   */
  localB->CombinatorialLogic = localP->yn_Y0_e;

  /* End of SystemInitialize for SubSystem: '<S233>/detectLockup' */

  /* SystemInitialize for IfAction SubSystem: '<S233>/Slipping' */
  /* InitializeConditions for Integrator: '<S235>/omega wheel' */
  localX->omegaWheel = DrivetrainHevP4_P.omegao;

  /* End of SystemInitialize for SubSystem: '<S233>/Slipping' */
}

/*
 * System reset for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Reset(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, X_Clutch_DrivetrainHevP4_n_T *localX)
{
  localDW->is_active_c8_autolibshared = 0U;
  localDW->is_c8_autolibshared = DrivetrainHevP4_IN_NO_ACTIVE_CHILD;
  localX->omegaWheel = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge ' */
  localB->Omega = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 1' */
  localB->Omegadot = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 3' */
  localB->Myb = 0.0;
}

/*
 * Start for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Start(B_Clutch_DrivetrainHevP4_k_T *localB)
{
  localB->Tout = 0.0;
  localB->Tfmaxs = 0.0;
  localB->Tout_e = 0.0;
  localB->Tfmaxs_p = 0.0;

  /* Merge: '<S233>/ Merge ' */
  localB->Omega = 0.0;

  /* Merge: '<S233>/ Merge 1' */
  localB->Omegadot = 0.0;

  /* Merge: '<S233>/ Merge 3' */
  localB->Myb = 0.0;

  /* Start for Function Call SubSystem: '<S233>/detectSlip' */
  /* Start for RelationalOperator: '<S245>/Relational Operator' */
  localB->RelationalOperator = false;

  /* End of Start for SubSystem: '<S233>/detectSlip' */

  /* Start for Function Call SubSystem: '<S233>/detectLockup' */
  /* Start for CombinatorialLogic: '<S241>/Combinatorial  Logic' */
  localB->CombinatorialLogic = false;

  /* End of Start for SubSystem: '<S233>/detectLockup' */

  /* Start for IfAction SubSystem: '<S233>/Slipping' */
  /* Start for Gain: '<S235>/Output Inertia' */
  localB->OutputInertia = 0.0;

  /* End of Start for SubSystem: '<S233>/Slipping' */
}

/*
 * Outputs for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  real_T rtu_Tout, real_T rtu_Tfmaxs, real_T rtu_Tfmaxk, real_T rtp_OmegaTol,
  B_Clutch_DrivetrainHevP4_k_T *localB, DW_Clutch_DrivetrainHevP4_k_T *localDW,
  P_Clutch_DrivetrainHevP4_o_T *localP, X_Clutch_DrivetrainHevP4_n_T *localX)
{
  real_T rtb_OutputSum_e;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    localDW->lastMajorTime = rtmGetTaskTime(DrivetrainHevP4_M, 0);

    /* Chart: '<S228>/Clutch' */
    if (localDW->is_active_c8_autolibshared == 0U) {
      localDW->is_active_c8_autolibshared = 1U;
      localX->omegaWheel = DrivetrainHevP4_P.omegao;
      localDW->is_c8_autolibshared = DrivetrainHevP4_IN_Slipping;

      /* Gain: '<S235>/Output Damping' incorporates:
       *  Integrator: '<S235>/omega wheel'
       */
      rtb_OutputSum_e = DrivetrainHevP4_P.br * localX->omegaWheel;

      /* Merge: '<S233>/ Merge 3' incorporates:
       *  SignalConversion generated from: '<S235>/Myb'
       */
      localB->Myb = rtb_OutputSum_e;

      /* Merge: '<S233>/ Merge ' incorporates:
       *  Integrator: '<S235>/omega wheel'
       *  SignalConversion generated from: '<S235>/Omega'
       */
      localB->Omega = localX->omegaWheel;

      /* Gain: '<S235>/Output Inertia' incorporates:
       *  Gain: '<S235>/-4'
       *  Integrator: '<S235>/omega wheel'
       *  Product: '<S235>/Max Dynamic Friction Torque1'
       *  Sum: '<S235>/Output Sum'
       *  Trigonometry: '<S235>/Trigonometric Function'
       */
      localB->OutputInertia = ((tanh(localP->u_Gain * localX->omegaWheel) *
        rtu_Tfmaxk - rtu_Tout) - rtb_OutputSum_e) * (1.0 /
        DrivetrainHevP4_P.Iyy_Whl);

      /* Merge: '<S233>/ Merge 1' incorporates:
       *  SignalConversion generated from: '<S235>/Omegadot'
       */
      localB->Omegadot = localB->OutputInertia;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    } else if (localDW->is_c8_autolibshared == DrivetrainHevP4_IN_Locked) {
      if (DrivetrainHevP4_detectSlip(rtu_Tout, rtu_Tfmaxs, localB)) {
        localX->omegaWheel = 0.0;
        localDW->is_c8_autolibshared = DrivetrainHevP4_IN_Slipping;

        /* Gain: '<S235>/Output Damping' incorporates:
         *  Integrator: '<S235>/omega wheel'
         */
        rtb_OutputSum_e = DrivetrainHevP4_P.br * localX->omegaWheel;

        /* Merge: '<S233>/ Merge 3' incorporates:
         *  SignalConversion generated from: '<S235>/Myb'
         */
        localB->Myb = rtb_OutputSum_e;

        /* Merge: '<S233>/ Merge ' incorporates:
         *  Integrator: '<S235>/omega wheel'
         *  SignalConversion generated from: '<S235>/Omega'
         */
        localB->Omega = localX->omegaWheel;

        /* Gain: '<S235>/Output Inertia' incorporates:
         *  Gain: '<S235>/-4'
         *  Integrator: '<S235>/omega wheel'
         *  Product: '<S235>/Max Dynamic Friction Torque1'
         *  Sum: '<S235>/Output Sum'
         *  Trigonometry: '<S235>/Trigonometric Function'
         */
        localB->OutputInertia = ((tanh(localP->u_Gain * localX->omegaWheel) *
          rtu_Tfmaxk - rtu_Tout) - rtb_OutputSum_e) * (1.0 /
          DrivetrainHevP4_P.Iyy_Whl);

        /* Merge: '<S233>/ Merge 1' incorporates:
         *  SignalConversion generated from: '<S235>/Omegadot'
         */
        localB->Omegadot = localB->OutputInertia;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }

      /* case IN_Slipping: */
    } else if (DrivetrainHevP4_detectLockup(rtu_Tout, rtu_Tfmaxs, localB,
                localDW, localP) && (fabs(localB->Omega) <= rtp_OmegaTol)) {
      localDW->is_c8_autolibshared = DrivetrainHevP4_IN_Locked;
      if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
          (DrivetrainHevP4_M, 1, 0)) {
        /* Merge: '<S233>/ Merge ' incorporates:
         *  Constant: '<S234>/locked'
         *  SignalConversion generated from: '<S234>/Omega'
         */
        localB->Omega = localP->locked_Value;

        /* Merge: '<S233>/ Merge 1' incorporates:
         *  Constant: '<S234>/locked1'
         *  SignalConversion generated from: '<S234>/Omegadot'
         */
        localB->Omegadot = localP->locked1_Value;

        /* Merge: '<S233>/ Merge 3' incorporates:
         *  Constant: '<S234>/locked2'
         *  SignalConversion generated from: '<S234>/Myb'
         */
        localB->Myb = localP->locked2_Value;
      }

      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    /* End of Chart: '<S228>/Clutch' */
  }

  if (localDW->is_c8_autolibshared == DrivetrainHevP4_IN_Locked) {
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      /* Merge: '<S233>/ Merge ' incorporates:
       *  Constant: '<S234>/locked'
       *  SignalConversion generated from: '<S234>/Omega'
       */
      localB->Omega = localP->locked_Value;

      /* Merge: '<S233>/ Merge 1' incorporates:
       *  Constant: '<S234>/locked1'
       *  SignalConversion generated from: '<S234>/Omegadot'
       */
      localB->Omegadot = localP->locked1_Value;

      /* Merge: '<S233>/ Merge 3' incorporates:
       *  Constant: '<S234>/locked2'
       *  SignalConversion generated from: '<S234>/Myb'
       */
      localB->Myb = localP->locked2_Value;
    }
  } else {
    /* Gain: '<S235>/Output Damping' incorporates:
     *  Integrator: '<S235>/omega wheel'
     */
    /* case IN_Slipping: */
    rtb_OutputSum_e = DrivetrainHevP4_P.br * localX->omegaWheel;

    /* Merge: '<S233>/ Merge 3' incorporates:
     *  SignalConversion generated from: '<S235>/Myb'
     */
    localB->Myb = rtb_OutputSum_e;

    /* Merge: '<S233>/ Merge ' incorporates:
     *  Integrator: '<S235>/omega wheel'
     *  SignalConversion generated from: '<S235>/Omega'
     */
    localB->Omega = localX->omegaWheel;

    /* Gain: '<S235>/Output Inertia' incorporates:
     *  Gain: '<S235>/-4'
     *  Integrator: '<S235>/omega wheel'
     *  Product: '<S235>/Max Dynamic Friction Torque1'
     *  Sum: '<S235>/Output Sum'
     *  Trigonometry: '<S235>/Trigonometric Function'
     */
    localB->OutputInertia = ((tanh(localP->u_Gain * localX->omegaWheel) *
      rtu_Tfmaxk - rtu_Tout) - rtb_OutputSum_e) * (1.0 /
      DrivetrainHevP4_P.Iyy_Whl);

    /* Merge: '<S233>/ Merge 1' incorporates:
     *  SignalConversion generated from: '<S235>/Omegadot'
     */
    localB->Omegadot = localB->OutputInertia;
  }
}

/*
 * Derivatives for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Deriv(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, XDot_Clutch_DrivetrainHevP4_p_T
  *localXdot)
{
  localXdot->omegaWheel = 0.0;
  if (localDW->is_c8_autolibshared == 2) {
    /* Derivatives for Integrator: '<S235>/omega wheel' */
    localXdot->omegaWheel = localB->OutputInertia;
  }
}

/*
 * System initialize for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_g_Init(B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, P_Clutch_DrivetrainHevP4_T *localP,
  X_Clutch_DrivetrainHevP4_T *localX)
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* SystemInitialize for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Init(&localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localP->CoreSubsys.sf_Clutch,
      &localX->CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/*
 * System reset for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_b_Reset(B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, X_Clutch_DrivetrainHevP4_T *localX)
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* SystemReset for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Reset(&localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localX->
      CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/*
 * Start for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_i_Start(B_Clutch_DrivetrainHevP4_T *localB)
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* Start for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Start(&localB->CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/*
 * Outputs for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_l(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, real_T rtu_Tout, real_T rtu_Tfmaxs, real_T rtu_Tfmaxk,
  real_T *rty_Omega, B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, P_Clutch_DrivetrainHevP4_T *localP,
  X_Clutch_DrivetrainHevP4_T *localX)
{
  /* local block i/o variables */
  real_T rtb_ImpSel_InsertedFor_Tout_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0;

  /* local scratch DWork variables */
  int32_T ForEach_itr;

  /* Outputs for Iterator SubSystem: '<S217>/Clutch' incorporates:
   *  ForEach: '<S228>/For Each'
   */
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* ForEachSliceSelector generated from: '<S228>/Tout' */
    rtb_ImpSel_InsertedFor_Tout_at_outport_0 = rtu_Tout;

    /* ForEachSliceSelector generated from: '<S228>/Tfmaxs' */
    rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0 = rtu_Tfmaxs;

    /* ForEachSliceSelector generated from: '<S228>/Tfmaxk' */
    rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0 = rtu_Tfmaxk;

    /* Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch(DrivetrainHevP4_M,
      rtb_ImpSel_InsertedFor_Tout_at_outport_0,
      rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0,
      rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0, DrivetrainHevP4_P.VXLOW *
      DrivetrainHevP4_P.Re * 0.0, &localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localP->CoreSubsys.sf_Clutch,
      &localX->CoreSubsys[ForEach_itr].sf_Clutch);

    /* ForEachSliceAssignment generated from: '<S228>/Omega' */
    *rty_Omega = localB->CoreSubsys[ForEach_itr].sf_Clutch.Omega;
  }

  /* End of Outputs for SubSystem: '<S217>/Clutch' */
}

/*
 * Derivatives for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_d_Deriv(real_T rtu_Tout, real_T rtu_Tfmaxs, real_T
  rtu_Tfmaxk, B_Clutch_DrivetrainHevP4_T *localB, DW_Clutch_DrivetrainHevP4_T
  *localDW, XDot_Clutch_DrivetrainHevP4_T *localXdot)
{
  /* local block i/o variables */
  real_T rtb_ImpSel_InsertedFor_Tout_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0;

  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* Derivatives for ForEachSliceSelector generated from: '<S228>/Tout' */
    rtb_ImpSel_InsertedFor_Tout_at_outport_0 = rtu_Tout;

    /* Derivatives for ForEachSliceSelector generated from: '<S228>/Tfmaxs' */
    rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0 = rtu_Tfmaxs;

    /* Derivatives for ForEachSliceSelector generated from: '<S228>/Tfmaxk' */
    rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0 = rtu_Tfmaxk;

    /* Derivatives for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Deriv(&localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localXdot->
      CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static void DrivetrainHevP4_power(const real_T a_data[], const int32_T a_size[2],
  real_T y_data[], int32_T y_size[2])
{
  real_T y_data_tmp;
  y_size[0] = 1;
  y_size[1] = a_size[1];
  if (0 <= (int8_T)a_size[1] - 1) {
    y_data_tmp = a_data[0];
    y_data[0] = y_data_tmp * y_data_tmp;
  }
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirekappa(real_T Re, real_T omega, real_T Vx,
  real_T b_VXLOW, real_T b_kappamax)
{
  real_T Vxpabs;
  real_T Vxpabs_data;
  real_T kappa;
  real_T tmp_data;
  int32_T Vxpabs_size[2];
  int32_T tmp_size[2];
  int32_T b_trueCount;
  Vxpabs = fabs(Vx);
  b_trueCount = 0;
  if (Vxpabs < b_VXLOW) {
    b_trueCount = 1;
  }

  Vxpabs_size[0] = 1;
  Vxpabs_size[1] = b_trueCount;
  if (0 <= b_trueCount - 1) {
    Vxpabs_data = Vxpabs / b_VXLOW;
  }

  if (0 <= b_trueCount - 1) {
    DrivetrainHevP4_power(&Vxpabs_data, Vxpabs_size, &tmp_data, tmp_size);
    Vxpabs_data = 2.0 * b_VXLOW / (3.0 - tmp_data);
  }

  if (Vxpabs < b_VXLOW) {
    Vxpabs = Vxpabs_data;
  }

  kappa = (Re * omega - Vx) / Vxpabs;
  b_trueCount = 0;
  if (kappa < -b_kappamax) {
    b_trueCount = 1;
  }

  if (0 <= b_trueCount - 1) {
    kappa = -b_kappamax;
  }

  if (kappa > b_kappamax) {
    kappa = b_kappamax;
  }

  return kappa;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirepurelongFx(real_T kappa, real_T Vx,
  real_T Fz, real_T b_gamma, real_T LONGVL, real_T FNOMIN, real_T b_FZMIN,
  real_T b_FZMAX, real_T press, real_T NOMPRES, real_T PRESMIN, real_T PRESMAX,
  real_T PCX1, real_T PDX1, real_T PDX2, real_T PDX3, real_T PEX1, real_T PEX2,
  real_T PEX3, real_T PEX4, real_T PKX1, real_T PKX2, real_T PKX3, real_T PHX1,
  real_T PHX2, real_T PVX1, real_T PVX2, real_T PPX1, real_T PPX2, real_T PPX3,
  real_T PPX4, real_T lam_Fzo, real_T lam_muV, real_T lam_mux, real_T
  lam_Kxkappa, real_T lam_Cx, real_T lam_Ex, real_T lam_Hx, real_T lam_Vx)
{
  real_T Cx;
  real_T Cx_tmp;
  real_T Fxo;
  real_T Vsx;
  real_T a__1;
  real_T a__1_data;
  real_T b_idx_0;
  real_T dfz;
  real_T dpi;
  real_T f_idx_0;
  real_T g_idx_0;
  real_T h_idx_0;
  real_T kappa_x;
  real_T tmp_data;
  int32_T a__1_size[2];
  int32_T tmp_size[2];
  int32_T trueCount;
  b_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    b_idx_0 = b_FZMIN;
  }

  if (b_idx_0 > b_FZMAX) {
    b_idx_0 = b_FZMAX;
  }

  dfz = press;
  if (press < PRESMIN) {
    dfz = PRESMIN;
  }

  if (dfz > PRESMAX) {
    dfz = PRESMAX;
  }

  dpi = (dfz - NOMPRES) / NOMPRES;
  dfz = (b_idx_0 - FNOMIN * lam_Fzo) / FNOMIN * lam_Fzo;
  kappa_x = (PHX2 * dfz + PHX1) * lam_Hx + kappa;
  Vsx = -fabs(Vx) * kappa;
  Vsx = lam_mux / (sqrt(Vsx * Vsx) * lam_muV / LONGVL + 1.0);
  Cx = PCX1 * lam_Cx;
  f_idx_0 = Cx;
  if (Cx < 0.0) {
    f_idx_0 = 0.0;
  }

  Cx_tmp = dpi * dpi;
  Cx = ((PPX3 * dpi + 1.0) + Cx_tmp * PPX4) * (PDX2 * dfz + PDX1) * (1.0 -
    b_gamma * b_gamma * PDX3) * Vsx * b_idx_0;
  g_idx_0 = Cx;
  if (Cx < 0.0) {
    g_idx_0 = 0.0;
  }

  Cx = ((PEX2 * dfz + PEX1) + dfz * dfz * PEX3) * (1.0 - tanh(10.0 * kappa_x) *
    PEX4) * lam_Ex;
  h_idx_0 = Cx;
  if (Cx > 1.0) {
    h_idx_0 = 1.0;
  }

  Cx = f_idx_0 * g_idx_0;
  a__1 = fabs(Cx);
  trueCount = 0;
  if (a__1 < 0.1) {
    trueCount = 1;
  }

  a__1_size[0] = 1;
  a__1_size[1] = trueCount;
  if (0 <= trueCount - 1) {
    a__1_data = a__1 / 0.1;
  }

  if (0 <= trueCount - 1) {
    DrivetrainHevP4_power(&a__1_data, a__1_size, &tmp_data, tmp_size);
    a__1_data = 0.2 / (3.0 - tmp_data);
  }

  if (a__1 < 0.1) {
    a__1 = a__1_data;
  }

  trueCount = 0;
  if (Cx < 0.0) {
    trueCount = 1;
  }

  if (0 <= trueCount - 1) {
    a__1_data = -a__1;
  }

  if (Cx < 0.0) {
    a__1 = a__1_data;
  }

  dpi = (PKX2 * dfz + PKX1) * b_idx_0 * exp(PKX3 * dfz) * ((PPX1 * dpi + 1.0) +
    Cx_tmp * PPX2) * lam_Kxkappa / a__1 * kappa_x;
  Fxo = sin(atan(dpi - (dpi - atan(dpi)) * h_idx_0) * f_idx_0) * g_idx_0 + (PVX2
    * dfz + PVX1) * b_idx_0 * (Vsx * 10.0 / (9.0 * Vsx + 1.0)) * lam_Vx;
  return Fxo;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongFxMapped(real_T kappa, real_T Fz,
  const real_T kappaFx[3], const real_T FzFx[3], const real_T FxMap[9], real_T
  b_FZMIN, real_T b_FZMAX, real_T lam_mux)
{
  real_T FxMap_0[9];
  real_T Fx;
  real_T b_idx_0;
  int32_T i;
  b_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    b_idx_0 = b_FZMIN;
  }

  if (b_idx_0 > b_FZMAX) {
    b_idx_0 = b_FZMAX;
  }

  for (i = 0; i < 3; i++) {
    FxMap_0[3 * i] = FxMap[i];
    FxMap_0[3 * i + 1] = FxMap[i + 3];
    FxMap_0[3 * i + 2] = FxMap[i + 6];
  }

  Fx = interp2_MZVr1hxC(kappaFx, FzFx, FxMap_0, kappa, b_idx_0) * lam_mux;
  return Fx;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongMySAE(real_T Fz, real_T omega,
  real_T Vx, real_T press, real_T QSY1, real_T QSY2, real_T QSY3, real_T QSY7,
  real_T QSY8, real_T UNLOADED_RADIUS, real_T b_FZMIN, real_T b_FZMAX, real_T
  PRESMIN, real_T PRESMAX)
{
  real_T My;
  real_T b_idx_0;
  real_T d_idx_0;
  b_idx_0 = press;
  if (press < PRESMIN) {
    b_idx_0 = PRESMIN;
  }

  if (b_idx_0 > PRESMAX) {
    b_idx_0 = PRESMAX;
  }

  d_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    d_idx_0 = b_FZMIN;
  }

  if (d_idx_0 > b_FZMAX) {
    d_idx_0 = b_FZMAX;
  }

  My = ((QSY2 * fabs(Vx) + QSY1) + Vx * Vx * QSY3) * (tanh(omega) *
    UNLOADED_RADIUS) * (rt_powd_snf(d_idx_0, QSY7) * rt_powd_snf(b_idx_0, QSY8));
  return My;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongMyMapped(real_T omega, real_T Fz,
  real_T Vx, const real_T VxMy[3], const real_T FzMy[3], const real_T MyMap[9],
  real_T b_FZMAX)
{
  real_T MyMap_0[9];
  real_T My;
  real_T b_idx_0;
  int32_T i;
  b_idx_0 = Fz;
  if (Fz < 0.0) {
    b_idx_0 = 0.0;
  }

  if (b_idx_0 > b_FZMAX) {
    b_idx_0 = b_FZMAX;
  }

  for (i = 0; i < 3; i++) {
    MyMap_0[3 * i] = MyMap[i];
    MyMap_0[3 * i + 1] = MyMap[i + 3];
    MyMap_0[3 * i + 2] = MyMap[i + 6];
  }

  My = tanh(omega) * interp2_MZVr1hxC(VxMy, FzMy, MyMap_0, Vx, b_idx_0);
  return My;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongMyISO(real_T Fz, real_T omega,
  real_T Tamb, real_T Fpl, real_T Cr, real_T Kt, real_T Tmeas, real_T Re, real_T
  b_FZMIN, real_T b_FZMAX, real_T TMIN, real_T TMAX)
{
  real_T b_idx_0;
  real_T d_idx_0;
  b_idx_0 = Tamb;
  if (Tamb < TMIN) {
    b_idx_0 = TMIN;
  }

  if (b_idx_0 > TMAX) {
    b_idx_0 = TMAX;
  }

  d_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    d_idx_0 = b_FZMIN;
  }

  if (d_idx_0 > b_FZMAX) {
    d_idx_0 = b_FZMAX;
  }

  return (d_idx_0 * Cr * 0.001 / ((b_idx_0 - Tmeas) * Kt + 1.0) + Fpl) * (-tanh
    (omega) * Re);
}

/*
 * Output and update for atomic system:
 *    '<S213>/Simple Magic Tire'
 *    '<S255>/Simple Magic Tire'
 */
void DrivetrainHevP4_SimpleMagicTire(real_T rtu_ReNom, real_T rtu_Fz, real_T
  rtu_Omega, real_T rtu_Vx, real_T rtu_MagicPeak, real_T rtu_MagicPeak_a, real_T
  rtu_MagicPeak_m, real_T rtu_MagicPeak_b, real_T rtu_MagicPeak_l, const real_T
  rtu_MagicFxo[34], const real_T rtu_kappaFx[3], const real_T rtu_FzFx[3], const
  real_T rtu_FxMap[9], real_T rtu_RollRes, real_T rtu_RollRes_f, real_T
  rtu_RollRes_m, real_T rtu_RollRes_k, real_T rtu_RollRes_b, real_T
  rtu_RollRes_km, real_T rtu_RollRes_l, real_T rtu_RollRes_ly, real_T
  rtu_RollRes_i, real_T rtu_RollRes_c, real_T rtu_RollRes_h, real_T
  rtu_RollRes_bu, real_T rtu_RollRes_d, real_T rtu_RollRes_is, real_T
  rtu_RollRes_im, real_T rtu_RollRes_ic, const real_T rtu_VxMy[3], const real_T
  rtu_FzMy[3], const real_T rtu_MyMap[9], real_T rtu_rho, real_T rtu_FxType,
  real_T rtu_rollingType, real_T rtu_vertType,
  B_SimpleMagicTire_DrivetrainHevP4_T *localB)
{
  real_T Kappa;
  real_T Re;
  real_T c_idx_0;
  switch ((int32_T)rtu_vertType) {
   case 0:
    Re = rtu_ReNom;
    break;

   case 1:
    Re = 0.0 * fabs(rtu_Omega) + rtu_rho;
    if (Re < 0.001) {
      Re = 0.001;
    }
    break;

   case 2:
    Re = rtu_ReNom;
    break;

   default:
    Re = rtu_ReNom;
    break;
  }

  Kappa = DrivetrainHevP4_automltirekappa(rtu_ReNom, rtu_Omega, rtu_Vx,
    DrivetrainHevP4_P.VXLOW, DrivetrainHevP4_P.kappamax);
  switch ((int32_T)rtu_FxType) {
   case 0:
    c_idx_0 = rtu_Fz;
    if (rtu_Fz < DrivetrainHevP4_P.FZMIN) {
      c_idx_0 = DrivetrainHevP4_P.FZMIN;
    }

    if (c_idx_0 > DrivetrainHevP4_P.FZMAX) {
      c_idx_0 = DrivetrainHevP4_P.FZMAX;
    }

    /* SignalConversion generated from: '<S223>/ SFunction ' */
    Kappa *= rtu_MagicPeak_m;
    Kappa = sin(atan(Kappa - (Kappa - atan(Kappa)) * rtu_MagicPeak_b) *
                rtu_MagicPeak_a) * rtu_MagicPeak * (c_idx_0 * rtu_MagicPeak_l);
    break;

   case 2:
    Kappa = DrivetrainHevP4_automltirepurelongFx(Kappa, rtu_Vx, rtu_Fz,
      rtu_MagicFxo[0], rtu_MagicFxo[1], rtu_MagicFxo[2], DrivetrainHevP4_P.FZMIN,
      DrivetrainHevP4_P.FZMAX, rtu_MagicFxo[3], rtu_MagicFxo[4], rtu_MagicFxo[5],
      rtu_MagicFxo[6], rtu_MagicFxo[7], rtu_MagicFxo[8], rtu_MagicFxo[9],
      rtu_MagicFxo[10], rtu_MagicFxo[11], rtu_MagicFxo[12], rtu_MagicFxo[13],
      rtu_MagicFxo[14], rtu_MagicFxo[15], rtu_MagicFxo[16], rtu_MagicFxo[17],
      rtu_MagicFxo[18], rtu_MagicFxo[19], rtu_MagicFxo[20], rtu_MagicFxo[21],
      rtu_MagicFxo[22], rtu_MagicFxo[23], rtu_MagicFxo[24], rtu_MagicFxo[25],
      rtu_MagicFxo[26], rtu_MagicFxo[27], rtu_MagicFxo[28], rtu_MagicFxo[29],
      rtu_MagicFxo[30], rtu_MagicFxo[31], rtu_MagicFxo[32], rtu_MagicFxo[33]);
    break;

   case 3:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    Kappa = DrivetrainHevP4_automltirelongFxMapped(Kappa, rtu_Fz, rtu_kappaFx,
      rtu_FzFx, rtu_FxMap, DrivetrainHevP4_P.FZMIN, DrivetrainHevP4_P.FZMAX,
      rtu_MagicPeak_l);
    break;

   default:
    Kappa = 0.0;
    break;
  }

  switch ((int32_T)rtu_rollingType) {
   case 0:
    localB->My = 0.0;
    break;

   case 1:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    localB->My = DrivetrainHevP4_automltirelongMySAE(rtu_Fz, rtu_Omega, rtu_Vx,
      rtu_RollRes, rtu_RollRes_k, rtu_RollRes_b, rtu_RollRes_km, rtu_RollRes_c,
      rtu_RollRes_h, Re, DrivetrainHevP4_P.FZMIN, DrivetrainHevP4_P.FZMAX,
      rtu_RollRes_im, rtu_RollRes_ic);
    break;

   case 2:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    Re = rtu_RollRes;
    if (rtu_RollRes < rtu_RollRes_im) {
      Re = rtu_RollRes_im;
    }

    if (Re > rtu_RollRes_ic) {
      Re = rtu_RollRes_ic;
    }

    c_idx_0 = rtu_Fz;
    if (rtu_Fz < 0.0) {
      c_idx_0 = 0.0;
    }

    if (c_idx_0 > DrivetrainHevP4_P.FZMAX) {
      c_idx_0 = DrivetrainHevP4_P.FZMAX;
    }

    /* SignalConversion generated from: '<S223>/ SFunction ' */
    localB->My = ((((rtu_RollRes_b * Kappa / rtu_RollRes_f + rtu_RollRes_k) +
                    fabs(rtu_Vx / 16.7) * rtu_RollRes_km) + rt_powd_snf(rtu_Vx /
      16.7, 4.0) * rtu_RollRes_l) + (c_idx_0 * rtu_RollRes_i / rtu_RollRes_f +
      rtu_RollRes_ly) * (rtu_RollRes_bu * rtu_RollRes_bu)) * (tanh(rtu_Omega) *
      c_idx_0 * rtu_RollRes_is) * (rt_powd_snf(c_idx_0 / rtu_RollRes_f,
      rtu_RollRes_c) * rt_powd_snf(Re / rtu_RollRes_m, rtu_RollRes_h)) *
      rtu_RollRes_d;
    break;

   case 3:
    localB->My = -DrivetrainHevP4_automltirelongMyMapped(rtu_Omega, rtu_Fz,
      rtu_Vx, rtu_VxMy, rtu_FzMy, rtu_MyMap, DrivetrainHevP4_P.FZMAX);
    break;

   case 4:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    localB->My = -DrivetrainHevP4_automltirelongMyISO(rtu_Fz, rtu_Omega,
      rtu_RollRes, rtu_RollRes_k, rtu_RollRes_b, rtu_RollRes_km, rtu_RollRes_l,
      Re, DrivetrainHevP4_P.FZMIN, DrivetrainHevP4_P.FZMAX, rtu_RollRes_im,
      rtu_RollRes_ic);
    break;

   default:
    localB->My = 0.0;
    break;
  }

  localB->Fx = Kappa;
}

/* System initialize for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Init(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  real_T *rty_EngSpd, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, X_DrivetrainHevP4_n_T *localX)
{
  /* InitializeConditions for Integrator: '<S169>/Integrator' */
  localX->Integrator_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S164>/Integrator1' */
  localX->Integrator1_CSTATE = DrivetrainHevP4_P.Integrator1_IC;

  /* InitializeConditions for Memory: '<S14>/Memory' */
  localDW->Memory_PreviousInput = DrivetrainHevP4_P.Memory_InitialCondition;

  /* InitializeConditions for Integrator: '<S14>/Integrator' incorporates:
   *  Integrator: '<S61>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_a = 0.0;
    localX->Integrator_CSTATE_l = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S14>/Integrator' */

  /* InitializeConditions for Integrator: '<S13>/Integrator' */
  localX->Integrator_CSTATE_c = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S246>/Integrator' */
  localX->Integrator_CSTATE_h = DrivetrainHevP4_P.Integrator_IC_c;

  /* InitializeConditions for Integrator: '<S163>/Integrator1' */
  localX->Integrator1_CSTATE_g = DrivetrainHevP4_P.Integrator1_IC_f;

  /* InitializeConditions for Memory: '<S61>/Memory' */
  localDW->Memory_PreviousInput_f = DrivetrainHevP4_P.Memory_InitialCondition_j;

  /* InitializeConditions for Integrator: '<S61>/Integrator' */
  localDW->Integrator_IWORK_m = 1;

  /* InitializeConditions for Integrator: '<S60>/Integrator' */
  localX->Integrator_CSTATE_i = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S288>/Integrator' */
  localX->Integrator_CSTATE_hm = DrivetrainHevP4_P.Integrator_IC_h;

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  localX->Integrator_CSTATE_d[0] = DrivetrainHevP4_P.Integrator_IC_f;
  localX->Integrator_CSTATE_d[1] = DrivetrainHevP4_P.Integrator_IC_f;

  /* InitializeConditions for Integrator: '<S177>/Integrator3' */
  localX->Integrator3_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S166>/Integrator1' */
  localX->Integrator1_CSTATE_f = DrivetrainHevP4_P.x_o;

  /* InitializeConditions for Memory: '<S87>/Memory' */
  localDW->Memory_PreviousInput_e = DrivetrainHevP4_P.Memory_InitialCondition_g;

  /* InitializeConditions for Integrator: '<S87>/Integrator' incorporates:
   *  Integrator: '<S150>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_de = 0.0;
    localX->Integrator_CSTATE_b = 0.0;
  }

  localDW->Integrator_IWORK_d = 1;

  /* End of InitializeConditions for Integrator: '<S87>/Integrator' */

  /* InitializeConditions for Integrator: '<S86>/Integrator' */
  localX->Integrator_CSTATE_g = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Memory: '<S150>/Memory' */
  localDW->Memory_PreviousInput_d = DrivetrainHevP4_P.Memory_InitialCondition_e;

  /* InitializeConditions for Integrator: '<S150>/Integrator' */
  localDW->Integrator_IWORK_h = 1;

  /* InitializeConditions for Memory: '<S145>/Memory' */
  localDW->Memory_PreviousInput_jb = DrivetrainHevP4_P.Memory_InitialCondition_o;

  /* InitializeConditions for Memory: '<S96>/Memory' */
  localDW->Memory_PreviousInput_j = DrivetrainHevP4_P.Memory_InitialCondition_b;

  /* InitializeConditions for Integrator: '<S96>/Integrator' incorporates:
   *  Integrator: '<S78>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_h1 = 0.0;
    localX->Integrator_CSTATE_j = 0.0;
  }

  localDW->Integrator_IWORK_n = 1;

  /* End of InitializeConditions for Integrator: '<S96>/Integrator' */

  /* InitializeConditions for Memory: '<S78>/Memory' */
  localDW->Memory_PreviousInput_h = DrivetrainHevP4_P.Memory_InitialCondition_f;

  /* InitializeConditions for Integrator: '<S78>/Integrator' */
  localDW->Integrator_IWORK_l = 1;

  /* InitializeConditions for Integrator: '<S77>/Integrator' */
  localX->Integrator_CSTATE_g4 = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S25>/Integrator' incorporates:
   *  Integrator: '<S42>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_o[0] = 0.0;
    localX->Integrator_CSTATE_o[1] = 0.0;
    localX->Integrator_CSTATE_n[0] = 0.0;
    localX->Integrator_CSTATE_n[1] = 0.0;
  }

  localDW->Integrator_IWORK_j = 1;

  /* End of InitializeConditions for Integrator: '<S25>/Integrator' */

  /* InitializeConditions for Integrator: '<S42>/Integrator' */
  localDW->Integrator_IWORK_mn = 1;

  /* SystemInitialize for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_g_Init(&localB->Clutch, &localDW->Clutch,
    &DrivetrainHevP4_P.Clutch, &localX->Clutch);

  /* End of SystemInitialize for SubSystem: '<S217>/Clutch' */

  /* SystemInitialize for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_g_Init(&localB->Clutch_e, &localDW->Clutch_e,
    &DrivetrainHevP4_P.Clutch_e, &localX->Clutch_e);

  /* End of SystemInitialize for SubSystem: '<S259>/Clutch' */

  /* SystemInitialize for IfAction SubSystem: '<S126>/Unlocked' */
  /* SystemInitialize for IfAction SubSystem: '<S126>/Locked' */
  /* InitializeConditions for Integrator: '<S132>/Locked Shaft Integrator' incorporates:
   *  Integrator: '<S133>/Pump Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->LockedShaftIntegrator_CSTATE = 0.0;
    localX->PumpIntegrator_CSTATE = 0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S126>/Unlocked' */
  localDW->LockedShaftIntegrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S132>/Locked Shaft Integrator' */
  /* End of SystemInitialize for SubSystem: '<S126>/Locked' */

  /* SystemInitialize for IfAction SubSystem: '<S126>/Unlocked' */
  /* InitializeConditions for Integrator: '<S133>/Pump Integrator' */
  localDW->PumpIntegrator_IWORK = 1;

  /* SystemInitialize for IfAction SubSystem: '<S94>/Locked' */
  /* InitializeConditions for Integrator: '<S133>/Turbine Integrator' incorporates:
   *  Integrator: '<S98>/x'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->TurbineIntegrator_CSTATE = 0.0;
    localX->w = 0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S94>/Locked' */
  localDW->TurbineIntegrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S133>/Turbine Integrator' */

  /* SystemInitialize for Enabled SubSystem: '<S153>/LPF' */
  /* InitializeConditions for Integrator: '<S157>/Integrator' */
  localX->Integrator_CSTATE_e = DrivetrainHevP4_P.Integrator_IC;

  /* SystemInitialize for Integrator: '<S157>/Integrator' incorporates:
   *  Outport: '<S156>/Out1'
   */
  localB->Integrator_k = DrivetrainHevP4_P.Out1_Y0;

  /* End of SystemInitialize for SubSystem: '<S153>/LPF' */
  /* End of SystemInitialize for SubSystem: '<S126>/Unlocked' */

  /* SystemInitialize for Merge: '<S126>/Merge1' */
  *rty_EngSpd = DrivetrainHevP4_P.Merge1_InitialOutput;

  /* SystemInitialize for Merge generated from: '<S126>/Merge4' */
  localB->PwrStoredImp = DrivetrainHevP4_P.Merge4_4_InitialOutput;

  /* SystemInitialize for Merge generated from: '<S126>/Merge4' */
  localB->PwrStoredTurb = DrivetrainHevP4_P.Merge4_5_InitialOutput;

  /* SystemInitialize for IfAction SubSystem: '<S94>/Locked' */
  /* InitializeConditions for Integrator: '<S98>/x' */
  localDW->x_IWORK = 1;

  /* End of SystemInitialize for SubSystem: '<S94>/Locked' */

  /* SystemInitialize for IfAction SubSystem: '<S94>/Unlocked' */
  /* InitializeConditions for Integrator: '<S100>/xe' incorporates:
   *  Integrator: '<S100>/xv'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->we = 0.0;
    localX->wv = 0.0;
  }

  localDW->xe_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S100>/xe' */

  /* InitializeConditions for Integrator: '<S100>/xv' */
  localDW->xv_IWORK = 1;

  /* End of SystemInitialize for SubSystem: '<S94>/Unlocked' */
}

/* System reset for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Reset(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  X_DrivetrainHevP4_n_T *localX)
{
  /* InitializeConditions for Integrator: '<S169>/Integrator' */
  localX->Integrator_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S164>/Integrator1' */
  localX->Integrator1_CSTATE = DrivetrainHevP4_P.Integrator1_IC;

  /* InitializeConditions for Memory: '<S14>/Memory' */
  localDW->Memory_PreviousInput = DrivetrainHevP4_P.Memory_InitialCondition;

  /* InitializeConditions for Integrator: '<S14>/Integrator' incorporates:
   *  Integrator: '<S61>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_a = 0.0;
    localX->Integrator_CSTATE_l = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S14>/Integrator' */

  /* InitializeConditions for Integrator: '<S13>/Integrator' */
  localX->Integrator_CSTATE_c = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S246>/Integrator' */
  localX->Integrator_CSTATE_h = DrivetrainHevP4_P.Integrator_IC_c;

  /* InitializeConditions for Integrator: '<S163>/Integrator1' */
  localX->Integrator1_CSTATE_g = DrivetrainHevP4_P.Integrator1_IC_f;

  /* InitializeConditions for Memory: '<S61>/Memory' */
  localDW->Memory_PreviousInput_f = DrivetrainHevP4_P.Memory_InitialCondition_j;

  /* InitializeConditions for Integrator: '<S61>/Integrator' */
  localDW->Integrator_IWORK_m = 1;

  /* InitializeConditions for Integrator: '<S60>/Integrator' */
  localX->Integrator_CSTATE_i = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S288>/Integrator' */
  localX->Integrator_CSTATE_hm = DrivetrainHevP4_P.Integrator_IC_h;

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  localX->Integrator_CSTATE_d[0] = DrivetrainHevP4_P.Integrator_IC_f;
  localX->Integrator_CSTATE_d[1] = DrivetrainHevP4_P.Integrator_IC_f;

  /* InitializeConditions for Integrator: '<S177>/Integrator3' */
  localX->Integrator3_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S166>/Integrator1' */
  localX->Integrator1_CSTATE_f = DrivetrainHevP4_P.x_o;

  /* InitializeConditions for Memory: '<S87>/Memory' */
  localDW->Memory_PreviousInput_e = DrivetrainHevP4_P.Memory_InitialCondition_g;

  /* InitializeConditions for Integrator: '<S87>/Integrator' incorporates:
   *  Integrator: '<S150>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_de = 0.0;
    localX->Integrator_CSTATE_b = 0.0;
  }

  localDW->Integrator_IWORK_d = 1;

  /* End of InitializeConditions for Integrator: '<S87>/Integrator' */

  /* InitializeConditions for Integrator: '<S86>/Integrator' */
  localX->Integrator_CSTATE_g = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Memory: '<S150>/Memory' */
  localDW->Memory_PreviousInput_d = DrivetrainHevP4_P.Memory_InitialCondition_e;

  /* InitializeConditions for Integrator: '<S150>/Integrator' */
  localDW->Integrator_IWORK_h = 1;

  /* InitializeConditions for Memory: '<S145>/Memory' */
  localDW->Memory_PreviousInput_jb = DrivetrainHevP4_P.Memory_InitialCondition_o;

  /* InitializeConditions for Memory: '<S96>/Memory' */
  localDW->Memory_PreviousInput_j = DrivetrainHevP4_P.Memory_InitialCondition_b;

  /* InitializeConditions for Integrator: '<S96>/Integrator' incorporates:
   *  Integrator: '<S78>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_h1 = 0.0;
    localX->Integrator_CSTATE_j = 0.0;
  }

  localDW->Integrator_IWORK_n = 1;

  /* End of InitializeConditions for Integrator: '<S96>/Integrator' */

  /* InitializeConditions for Memory: '<S78>/Memory' */
  localDW->Memory_PreviousInput_h = DrivetrainHevP4_P.Memory_InitialCondition_f;

  /* InitializeConditions for Integrator: '<S78>/Integrator' */
  localDW->Integrator_IWORK_l = 1;

  /* InitializeConditions for Integrator: '<S77>/Integrator' */
  localX->Integrator_CSTATE_g4 = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S25>/Integrator' incorporates:
   *  Integrator: '<S42>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_o[0] = 0.0;
    localX->Integrator_CSTATE_o[1] = 0.0;
    localX->Integrator_CSTATE_n[0] = 0.0;
    localX->Integrator_CSTATE_n[1] = 0.0;
  }

  localDW->Integrator_IWORK_j = 1;

  /* End of InitializeConditions for Integrator: '<S25>/Integrator' */

  /* InitializeConditions for Integrator: '<S42>/Integrator' */
  localDW->Integrator_IWORK_mn = 1;

  /* SystemReset for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_b_Reset(&localB->Clutch, &localDW->Clutch,
    &localX->Clutch);

  /* End of SystemReset for SubSystem: '<S217>/Clutch' */

  /* SystemReset for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_b_Reset(&localB->Clutch_e, &localDW->Clutch_e,
    &localX->Clutch_e);

  /* End of SystemReset for SubSystem: '<S259>/Clutch' */
}

/* Disable for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Disable(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, DW_DrivetrainHevP4_f_T *localDW, XDis_DrivetrainHevP4_n_T
  *localXdis)
{
  /* Disable for If: '<S126>/If' */
  switch (localDW->If_ActiveSubsystem) {
   case 0:
    ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    localXdis->LockedShaftIntegrator_CSTATE = 1;
    break;

   case 1:
    ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    (void) memset(&(localXdis->PumpIntegrator_CSTATE), 1,
                  3*sizeof(boolean_T));

    /* Disable for Enabled SubSystem: '<S153>/LPF' */
    localDW->LPF_MODE = false;

    /* End of Disable for SubSystem: '<S153>/LPF' */
    break;
  }

  localDW->If_ActiveSubsystem = -1;

  /* End of Disable for If: '<S126>/If' */

  /* Disable for If: '<S94>/If' */
  switch (localDW->If_ActiveSubsystem_b) {
   case 0:
    ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    localXdis->w = 1;
    break;

   case 1:
    ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    (void) memset(&(localXdis->we), 1,
                  2*sizeof(boolean_T));
    break;
  }

  localDW->If_ActiveSubsystem_b = -1;

  /* End of Disable for If: '<S94>/If' */
}

/* Start for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Start(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  XDis_DrivetrainHevP4_n_T *localXdis)
{
  /* Start for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_i_Start(&localB->Clutch);

  /* End of Start for SubSystem: '<S217>/Clutch' */

  /* Start for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_i_Start(&localB->Clutch_e);

  /* End of Start for SubSystem: '<S259>/Clutch' */

  /* Start for Sqrt: '<S206>/Sqrt' */
  localDW->Sqrt_DWORK1 = 0;

  /* Start for Constant: '<S13>/domega_o' */
  localB->domega_o = DrivetrainHevP4_P.domega_o;

  /* Start for Constant: '<S224>/Constant2' */
  memcpy(&localB->Constant2[0], &DrivetrainHevP4_P.Constant2_Value_i[0], 34U *
         sizeof(real_T));

  /* Start for Constant: '<S224>/Constant19' */
  localB->kappaFx[0] = DrivetrainHevP4_P.Constant19_Value[0];

  /* Start for Constant: '<S224>/Constant12' */
  localB->FzFx[0] = DrivetrainHevP4_P.Constant12_Value[0];

  /* Start for Constant: '<S224>/Constant19' */
  localB->kappaFx[1] = DrivetrainHevP4_P.Constant19_Value[1];

  /* Start for Constant: '<S224>/Constant12' */
  localB->FzFx[1] = DrivetrainHevP4_P.Constant12_Value[1];

  /* Start for Constant: '<S224>/Constant19' */
  localB->kappaFx[2] = DrivetrainHevP4_P.Constant19_Value[2];

  /* Start for Constant: '<S224>/Constant12' */
  localB->FzFx[2] = DrivetrainHevP4_P.Constant12_Value[2];

  /* Start for Constant: '<S225>/Constant19' */
  localB->VxMy[0] = DrivetrainHevP4_P.Constant19_Value_f[0];

  /* Start for Constant: '<S225>/Constant12' */
  localB->FzMy[0] = DrivetrainHevP4_P.Constant12_Value_b[0];

  /* Start for Constant: '<S225>/Constant19' */
  localB->VxMy[1] = DrivetrainHevP4_P.Constant19_Value_f[1];

  /* Start for Constant: '<S225>/Constant12' */
  localB->FzMy[1] = DrivetrainHevP4_P.Constant12_Value_b[1];

  /* Start for Constant: '<S225>/Constant19' */
  localB->VxMy[2] = DrivetrainHevP4_P.Constant19_Value_f[2];

  /* Start for Constant: '<S225>/Constant12' */
  localB->FzMy[2] = DrivetrainHevP4_P.Constant12_Value_b[2];

  /* Start for Constant: '<S224>/Constant14' */
  memcpy(&localB->FxMap[0], &DrivetrainHevP4_P.Constant14_Value[0], 9U * sizeof
         (real_T));

  /* Start for Constant: '<S225>/Constant14' */
  memcpy(&localB->MyMap[0], &DrivetrainHevP4_P.Constant14_Value_m[0], 9U *
         sizeof(real_T));

  /* Start for Constant: '<S208>/FxType' */
  localB->FxType = DrivetrainHevP4_P.FxType_Value;

  /* Start for Constant: '<S208>/rollType' */
  localB->rollType = DrivetrainHevP4_P.rollType_Value;

  /* Start for Constant: '<S208>/vertType' */
  localB->vertType = DrivetrainHevP4_P.vertType_Value;

  /* Start for Constant: '<S60>/domega_o' */
  localB->domega_o_m = DrivetrainHevP4_P.domega_o;

  /* Start for Constant: '<S266>/Constant2' */
  memcpy(&localB->Constant2_p[0], &DrivetrainHevP4_P.Constant2_Value_f4[0], 34U *
         sizeof(real_T));

  /* Start for Constant: '<S266>/Constant19' */
  localB->kappaFx_j[0] = DrivetrainHevP4_P.Constant19_Value_e[0];

  /* Start for Constant: '<S266>/Constant12' */
  localB->FzFx_l[0] = DrivetrainHevP4_P.Constant12_Value_m[0];

  /* Start for Constant: '<S266>/Constant19' */
  localB->kappaFx_j[1] = DrivetrainHevP4_P.Constant19_Value_e[1];

  /* Start for Constant: '<S266>/Constant12' */
  localB->FzFx_l[1] = DrivetrainHevP4_P.Constant12_Value_m[1];

  /* Start for Constant: '<S266>/Constant19' */
  localB->kappaFx_j[2] = DrivetrainHevP4_P.Constant19_Value_e[2];

  /* Start for Constant: '<S266>/Constant12' */
  localB->FzFx_l[2] = DrivetrainHevP4_P.Constant12_Value_m[2];

  /* Start for Constant: '<S267>/Constant19' */
  localB->VxMy_k[0] = DrivetrainHevP4_P.Constant19_Value_b[0];

  /* Start for Constant: '<S267>/Constant12' */
  localB->FzMy_g[0] = DrivetrainHevP4_P.Constant12_Value_g[0];

  /* Start for Constant: '<S267>/Constant19' */
  localB->VxMy_k[1] = DrivetrainHevP4_P.Constant19_Value_b[1];

  /* Start for Constant: '<S267>/Constant12' */
  localB->FzMy_g[1] = DrivetrainHevP4_P.Constant12_Value_g[1];

  /* Start for Constant: '<S267>/Constant19' */
  localB->VxMy_k[2] = DrivetrainHevP4_P.Constant19_Value_b[2];

  /* Start for Constant: '<S267>/Constant12' */
  localB->FzMy_g[2] = DrivetrainHevP4_P.Constant12_Value_g[2];

  /* Start for Constant: '<S266>/Constant14' */
  memcpy(&localB->FxMap_h[0], &DrivetrainHevP4_P.Constant14_Value_n[0], 9U *
         sizeof(real_T));

  /* Start for Constant: '<S267>/Constant14' */
  memcpy(&localB->MyMap_d[0], &DrivetrainHevP4_P.Constant14_Value_j[0], 9U *
         sizeof(real_T));

  /* Start for Constant: '<S210>/FxType' */
  localB->FxType_b = DrivetrainHevP4_P.FxType_Value_m;

  /* Start for Constant: '<S210>/rollType' */
  localB->rollType_m = DrivetrainHevP4_P.rollType_Value_h;

  /* Start for Constant: '<S210>/vertType' */
  localB->vertType_o = DrivetrainHevP4_P.vertType_Value_e;

  /* Start for Constant: '<S86>/domega_o' */
  localB->domega_o_h = DrivetrainHevP4_P.domega_o;

  /* Start for Constant: '<S149>/Constant2' */
  localB->Constant2_pr = DrivetrainHevP4_P.Constant2_Value_a;

  /* Start for InitialCondition: '<S129>/IC' */
  localDW->IC_FirstOutputTime = true;

  /* Start for InitialCondition: '<S134>/IC' */
  localDW->IC_FirstOutputTime_d = true;

  /* Start for InitialCondition: '<S128>/IC' */
  localDW->IC_FirstOutputTime_m = true;

  /* Start for If: '<S126>/If' */
  ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
  localXdis->LockedShaftIntegrator_CSTATE = 1;
  ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
  (void) memset(&(localXdis->PumpIntegrator_CSTATE), 1,
                3*sizeof(boolean_T));
  localDW->If_ActiveSubsystem = -1;

  /* Start for IfAction SubSystem: '<S126>/Unlocked' */
  /* Start for Enabled SubSystem: '<S153>/LPF' */
  localDW->LPF_MODE = false;
  ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
  localXdis->Integrator_CSTATE_e = 1;

  /* End of Start for SubSystem: '<S153>/LPF' */
  /* End of Start for SubSystem: '<S126>/Unlocked' */

  /* Start for Constant: '<S94>/Constant1' */
  localB->Constant1 = DrivetrainHevP4_P.IdealFixedGearTransmission_G_o;

  /* Start for InitialCondition: '<S97>/IC' */
  localDW->IC_FirstOutputTime_k = true;

  /* Start for Constant: '<S77>/domega_o' */
  localB->domega_o_j = DrivetrainHevP4_P.domega_o;

  /* Start for InitialCondition: '<S101>/IC' */
  localDW->IC_FirstOutputTime_f = true;

  /* Start for InitialCondition: '<S99>/IC' */
  localDW->IC_FirstOutputTime_j = true;

  /* Start for If: '<S94>/If' */
  ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
  localXdis->w = 1;
  ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
  (void) memset(&(localXdis->we), 1,
                2*sizeof(boolean_T));
  localDW->If_ActiveSubsystem_b = -1;

  /* Start for Constant: '<S42>/bw1' */
  localB->bw1 = DrivetrainHevP4_P.bw1;

  /* Start for Constant: '<S42>/bd' */
  localB->bd = DrivetrainHevP4_P.bd;

  /* Start for Constant: '<S42>/bw2' */
  localB->bw2 = DrivetrainHevP4_P.bw2;

  /* Start for Constant: '<S42>/Ndiff2' */
  localB->Ndiff2 = DrivetrainHevP4_P.Ndiff_P4;

  /* Start for Constant: '<S42>/Jd' */
  localB->Jd = DrivetrainHevP4_P.Jd;

  /* Start for Constant: '<S42>/Jw1' */
  localB->Jw1 = DrivetrainHevP4_P.Jw1;

  /* Start for Constant: '<S42>/Jw3' */
  localB->Jw3 = DrivetrainHevP4_P.Jw2;

  /* Start for Constant: '<S25>/bw1' */
  localB->bw1_j = DrivetrainHevP4_P.bw1;

  /* Start for Constant: '<S25>/bd' */
  localB->bd_o = DrivetrainHevP4_P.bd;

  /* Start for Constant: '<S25>/bw2' */
  localB->bw2_b = DrivetrainHevP4_P.bw2;

  /* Start for Constant: '<S25>/Ndiff2' */
  localB->Ndiff2_c = DrivetrainHevP4_P.Ndiff;

  /* Start for Constant: '<S25>/Jd' */
  localB->Jd_m = DrivetrainHevP4_P.Jd;

  /* Start for Constant: '<S25>/Jw1' */
  localB->Jw1_n = DrivetrainHevP4_P.Jw1;

  /* Start for Constant: '<S25>/Jw3' */
  localB->Jw3_h = DrivetrainHevP4_P.Jw2;
}

/* Outputs for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M, const
                     real_T *rtu_EngTrq, real_T *rty_VehSpd, real_T *rty_EngSpd,
                     boolean_T *rty_Cltch1State, boolean_T *rty_Cltch2State,
                     real_T *rty_MotSpd, real_T *rty_TransGear,
                     B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
                     *localDW, X_DrivetrainHevP4_n_T *localX,
                     ZCE_DrivetrainHevP4_T *localZCE, XDis_DrivetrainHevP4_n_T
                     *localXdis)
{
  /* local block i/o variables */
  real_T rtb_Integrator_g[2];
  real_T rtb_Product4;
  real_T rtb_Product4_p;
  real_T rtb_Product4_o;
  real_T tmp[10];
  real_T fractions[4];
  real_T rtb_InertiaRatio;
  real_T rtb_Integrator_l;
  real_T rtb_Integrator_o;
  real_T rtb_OutputDamping;
  real_T rtb_OutputSum;
  real_T rtb_Subtract1;
  real_T rtb_Subtract1_p;
  real_T rtb_Sum;
  real_T rtb_Switch;
  real_T rtb_Switch2;
  real_T rtb_TorqueConversion;
  real_T rtb_TorqueRatiozetaInterpolation;
  real_T rtb_UnaryMinus1;
  real_T rtb_UnaryMinus1_p;
  real_T rtb_u;
  real_T rtb_u_tmp;
  real_T rtb_uniclutch;
  real_T rtb_xe;
  real_T u0;
  int32_T i;
  uint32_T bpIndices[4];
  uint32_T rtb_speedratioPrelookup_o1;
  int8_T rtAction;
  int8_T rtPrevAction;
  boolean_T rtb_Logic;
  ZCEventType zcEvent;

  /* Integrator: '<S169>/Integrator' */
  localB->Integrator = localX->Integrator_CSTATE;

  /* SignalConversion generated from: '<S166>/Vector Concatenate2' */
  localB->VectorConcatenate2[0] = localB->Integrator;

  /* SignalConversion generated from: '<S166>/Vector Concatenate2' */
  localB->VectorConcatenate2[1] = 0.0;

  /* SignalConversion generated from: '<S166>/Vector Concatenate2' */
  localB->VectorConcatenate2[2] = 0.0;

  /* SignalConversion generated from: '<Root>/VehSpd' */
  *rty_VehSpd = localB->VectorConcatenate2[0];
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S163>/Constant' */
    localB->Constant = DrivetrainHevP4_P.wc;

    /* Saturate: '<S217>/Saturation' */
    if (DrivetrainHevP4_P.Re > DrivetrainHevP4_P.Saturation_UpperSat_f) {
      /* Saturate: '<S217>/Saturation' */
      localB->Saturation = DrivetrainHevP4_P.Saturation_UpperSat_f;
    } else if (DrivetrainHevP4_P.Re < DrivetrainHevP4_P.Saturation_LowerSat_n) {
      /* Saturate: '<S217>/Saturation' */
      localB->Saturation = DrivetrainHevP4_P.Saturation_LowerSat_n;
    } else {
      /* Saturate: '<S217>/Saturation' */
      localB->Saturation = DrivetrainHevP4_P.Re;
    }

    /* End of Saturate: '<S217>/Saturation' */

    /* Memory: '<S14>/Memory' */
    localB->Memory = localDW->Memory_PreviousInput;

    /* Constant: '<S13>/domega_o' */
    localB->domega_o = DrivetrainHevP4_P.domega_o;
  }

  /* Integrator: '<S164>/Integrator1' */
  localB->Integrator1 = localX->Integrator1_CSTATE;

  /* Integrator: '<S14>/Integrator' */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE,
                       (localB->Memory));
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK != 0)) {
      localX->Integrator_CSTATE_a = localB->domega_o;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    rtb_Integrator_o = localX->Integrator_CSTATE_a;
  } else {
    rtb_Integrator_o = localX->Integrator_CSTATE_a;
  }

  /* End of Integrator: '<S14>/Integrator' */

  /* Sum: '<S13>/Subtract1' incorporates:
   *  Gain: '<S13>/Gain1'
   *  Gain: '<S13>/Gain2'
   *  Integrator: '<S13>/Integrator'
   */
  rtb_UnaryMinus1 = DrivetrainHevP4_P.b * rtb_Integrator_o + DrivetrainHevP4_P.k
    * localX->Integrator_CSTATE_c;

  /* Integrator: '<S246>/Integrator' */
  localB->Integrator_h = localX->Integrator_CSTATE_h;

  /* Gain: '<S217>/Sign convention' incorporates:
   *  Product: '<S230>/Product1'
   *  Sum: '<S217>/Add1'
   */
  localB->Signconvention = (rtb_UnaryMinus1 - localB->Integrator_h *
    localB->Saturation) * DrivetrainHevP4_P.Signconvention_Gain;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S232>/Disk brake actuator bore' */
    localB->Diskbrakeactuatorbore = DrivetrainHevP4_P.disk_abore;

    /* Gain: '<S232>/Torque Conversion1' */
    localB->TorqueConversion1 = DrivetrainHevP4_P.TorqueConversion1_Gain *
      localB->Diskbrakeactuatorbore;

    /* Constant: '<S232>/Number of brake pads' */
    localB->Numberofbrakepads = DrivetrainHevP4_P.num_pads;

    /* Constant: '<S224>/Constant' */
    localB->D = DrivetrainHevP4_P.Constant_Value_px;

    /* Constant: '<S224>/Constant1' */
    localB->C = DrivetrainHevP4_P.Constant1_Value_n;

    /* Constant: '<S224>/Constant7' */
    localB->B = DrivetrainHevP4_P.Constant7_Value;

    /* Constant: '<S224>/Constant6' */
    localB->E = DrivetrainHevP4_P.Constant6_Value;

    /* Constant: '<S208>/lam_muxConstant' */
    localB->lam_muxConstant = DrivetrainHevP4_P.lam_x;

    /* Constant: '<S224>/Constant2' */
    memcpy(&localB->Constant2[0], &DrivetrainHevP4_P.Constant2_Value_i[0], 34U *
           sizeof(real_T));

    /* Constant: '<S224>/Constant19' */
    localB->kappaFx[0] = DrivetrainHevP4_P.Constant19_Value[0];

    /* Constant: '<S224>/Constant12' */
    localB->FzFx[0] = DrivetrainHevP4_P.Constant12_Value[0];

    /* Constant: '<S224>/Constant19' */
    localB->kappaFx[1] = DrivetrainHevP4_P.Constant19_Value[1];

    /* Constant: '<S224>/Constant12' */
    localB->FzFx[1] = DrivetrainHevP4_P.Constant12_Value[1];

    /* Constant: '<S224>/Constant19' */
    localB->kappaFx[2] = DrivetrainHevP4_P.Constant19_Value[2];

    /* Constant: '<S224>/Constant12' */
    localB->FzFx[2] = DrivetrainHevP4_P.Constant12_Value[2];

    /* Constant: '<S208>/TirePrsConstant' */
    localB->TirePrsConstant = DrivetrainHevP4_P.press;

    /* Constant: '<S225>/Constant5' */
    localB->FNOMIN = DrivetrainHevP4_P.Constant5_Value;

    /* Constant: '<S225>/Constant2' */
    localB->NOMPRES = DrivetrainHevP4_P.Constant2_Value_c;

    /* Constant: '<S225>/Constant13' */
    localB->QSY1 = DrivetrainHevP4_P.aMy;

    /* Constant: '<S225>/Constant8' */
    localB->QSY2 = DrivetrainHevP4_P.bMy;

    /* Constant: '<S225>/Constant15' */
    localB->QSY3 = DrivetrainHevP4_P.cMy;

    /* Constant: '<S225>/Constant16' */
    localB->QSY4 = DrivetrainHevP4_P.Constant16_Value;

    /* Constant: '<S225>/Constant7' */
    localB->QSY5 = DrivetrainHevP4_P.Constant7_Value_o;

    /* Constant: '<S225>/Constant9' */
    localB->QSY6 = DrivetrainHevP4_P.Constant9_Value;

    /* Constant: '<S225>/Constant17' */
    localB->QSY7 = DrivetrainHevP4_P.betaMy;

    /* Constant: '<S225>/Constant18' */
    localB->QSY8 = DrivetrainHevP4_P.alphaMy;

    /* Constant: '<S225>/Constant11' */
    localB->gamma = DrivetrainHevP4_P.Constant11_Value;

    /* Constant: '<S225>/Constant10' */
    localB->lam_My = DrivetrainHevP4_P.Constant10_Value;

    /* Constant: '<S225>/Constant4' */
    localB->UNLOADED_RADIUS = DrivetrainHevP4_P.UNLOADED_RADIUS;

    /* Constant: '<S225>/Constant1' */
    localB->PRESMIN = DrivetrainHevP4_P.Constant1_Value_i;

    /* Constant: '<S225>/Constant3' */
    localB->PRESMAX = DrivetrainHevP4_P.Constant3_Value;

    /* Constant: '<S225>/Constant19' */
    localB->VxMy[0] = DrivetrainHevP4_P.Constant19_Value_f[0];

    /* Constant: '<S225>/Constant12' */
    localB->FzMy[0] = DrivetrainHevP4_P.Constant12_Value_b[0];

    /* Constant: '<S225>/Constant19' */
    localB->VxMy[1] = DrivetrainHevP4_P.Constant19_Value_f[1];

    /* Constant: '<S225>/Constant12' */
    localB->FzMy[1] = DrivetrainHevP4_P.Constant12_Value_b[1];

    /* Constant: '<S225>/Constant19' */
    localB->VxMy[2] = DrivetrainHevP4_P.Constant19_Value_f[2];

    /* Constant: '<S225>/Constant12' */
    localB->FzMy[2] = DrivetrainHevP4_P.Constant12_Value_b[2];

    /* Constant: '<S224>/Constant14' */
    memcpy(&localB->FxMap[0], &DrivetrainHevP4_P.Constant14_Value[0], 9U *
           sizeof(real_T));

    /* Constant: '<S225>/Constant14' */
    memcpy(&localB->MyMap[0], &DrivetrainHevP4_P.Constant14_Value_m[0], 9U *
           sizeof(real_T));

    /* Constant: '<S226>/Constant14' */
    localB->NOMPRES_g = DrivetrainHevP4_P.Constant14_Value_h;

    /* Constant: '<S226>/Constant1' */
    localB->PRESMIN_p = DrivetrainHevP4_P.Constant1_Value_m;

    /* Constant: '<S226>/Constant19' */
    localB->PRESMAX_l = DrivetrainHevP4_P.Constant19_Value_h;

    /* Constant: '<S226>/Constant2' */
    localB->VERTICAL_STIFFNESS = DrivetrainHevP4_P.Constant2_Value_f;

    /* Constant: '<S226>/Constant3' */
    localB->VERTICAL_DAMPING = DrivetrainHevP4_P.Constant3_Value_a;

    /* Constant: '<S226>/Constant4' */
    localB->Q_RE0 = DrivetrainHevP4_P.Constant4_Value;

    /* Constant: '<S226>/Constant5' */
    localB->Q_V1 = DrivetrainHevP4_P.Constant5_Value_e;

    /* Constant: '<S226>/Constant6' */
    localB->Q_V2 = DrivetrainHevP4_P.Constant6_Value_i;

    /* Constant: '<S226>/Constant7' */
    localB->Q_FZ1 = DrivetrainHevP4_P.Constant7_Value_l;

    /* Constant: '<S226>/Constant8' */
    localB->Q_FZ2 = DrivetrainHevP4_P.Constant8_Value;

    /* Constant: '<S226>/Constant9' */
    localB->Q_FCX = DrivetrainHevP4_P.Constant9_Value_m;

    /* Constant: '<S226>/Constant10' */
    localB->Q_FCY = DrivetrainHevP4_P.Constant10_Value_a;

    /* Constant: '<S226>/Constant11' */
    localB->Q_CAM = DrivetrainHevP4_P.Constant11_Value_f;

    /* Constant: '<S226>/Constant16' */
    localB->PFZ1 = DrivetrainHevP4_P.Constant16_Value_i;

    /* Constant: '<S226>/Constant17' */
    localB->Q_FCY2 = DrivetrainHevP4_P.Constant17_Value;

    /* Constant: '<S226>/Constant13' */
    localB->Q_CAM1 = DrivetrainHevP4_P.Constant13_Value;

    /* Constant: '<S226>/Constant15' */
    localB->Q_CAM2 = DrivetrainHevP4_P.Constant15_Value;

    /* Constant: '<S226>/Constant21' */
    localB->Q_CAM3 = DrivetrainHevP4_P.Constant21_Value;

    /* Constant: '<S226>/Constant22' */
    localB->Q_FYS1 = DrivetrainHevP4_P.Constant22_Value;

    /* Constant: '<S226>/Constant18' */
    localB->Q_FYS2 = DrivetrainHevP4_P.Constant18_Value;

    /* Constant: '<S226>/Constant20' */
    localB->Q_FYS3 = DrivetrainHevP4_P.Constant20_Value;

    /* Constant: '<S226>/Constant24' */
    localB->BOTTOM_OFFST = DrivetrainHevP4_P.Constant24_Value;

    /* Constant: '<S226>/Constant23' */
    localB->BOTTOM_STIFF = DrivetrainHevP4_P.Constant23_Value;

    /* Constant: '<S208>/FxType' */
    localB->FxType = DrivetrainHevP4_P.FxType_Value;

    /* Constant: '<S208>/rollType' */
    localB->rollType = DrivetrainHevP4_P.rollType_Value;

    /* Constant: '<S208>/vertType' */
    localB->vertType = DrivetrainHevP4_P.vertType_Value;

    /* Saturate: '<S259>/Saturation' */
    if (DrivetrainHevP4_P.Re > DrivetrainHevP4_P.Saturation_UpperSat_p) {
      /* Saturate: '<S259>/Saturation' */
      localB->Saturation_f = DrivetrainHevP4_P.Saturation_UpperSat_p;
    } else if (DrivetrainHevP4_P.Re < DrivetrainHevP4_P.Saturation_LowerSat_d) {
      /* Saturate: '<S259>/Saturation' */
      localB->Saturation_f = DrivetrainHevP4_P.Saturation_LowerSat_d;
    } else {
      /* Saturate: '<S259>/Saturation' */
      localB->Saturation_f = DrivetrainHevP4_P.Re;
    }

    /* End of Saturate: '<S259>/Saturation' */

    /* Memory: '<S61>/Memory' */
    localB->Memory_f = localDW->Memory_PreviousInput_f;

    /* Constant: '<S60>/domega_o' */
    localB->domega_o_m = DrivetrainHevP4_P.domega_o;
  }

  /* Integrator: '<S163>/Integrator1' */
  localB->Integrator1_d = localX->Integrator1_CSTATE_g;

  /* Integrator: '<S61>/Integrator' */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_a,
                       (localB->Memory_f));
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_m != 0)) {
      localX->Integrator_CSTATE_l = localB->domega_o_m;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    rtb_Integrator_l = localX->Integrator_CSTATE_l;
  } else {
    rtb_Integrator_l = localX->Integrator_CSTATE_l;
  }

  /* End of Integrator: '<S61>/Integrator' */

  /* Sum: '<S60>/Subtract1' incorporates:
   *  Gain: '<S60>/Gain1'
   *  Gain: '<S60>/Gain2'
   *  Integrator: '<S60>/Integrator'
   */
  rtb_UnaryMinus1_p = DrivetrainHevP4_P.b * rtb_Integrator_l +
    DrivetrainHevP4_P.k * localX->Integrator_CSTATE_i;

  /* Integrator: '<S288>/Integrator' */
  localB->Integrator_f = localX->Integrator_CSTATE_hm;

  /* Gain: '<S259>/Sign convention' incorporates:
   *  Product: '<S272>/Product1'
   *  Sum: '<S259>/Add1'
   */
  localB->Signconvention_o = (rtb_UnaryMinus1_p - localB->Integrator_f *
    localB->Saturation_f) * DrivetrainHevP4_P.Signconvention_Gain_c;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S274>/Disk brake actuator bore' */
    localB->Diskbrakeactuatorbore_j = DrivetrainHevP4_P.disk_abore;

    /* Gain: '<S274>/Torque Conversion1' */
    localB->TorqueConversion1_b = DrivetrainHevP4_P.TorqueConversion1_Gain_b *
      localB->Diskbrakeactuatorbore_j;

    /* Constant: '<S274>/Number of brake pads' */
    localB->Numberofbrakepads_f = DrivetrainHevP4_P.num_pads;

    /* Constant: '<S266>/Constant' */
    localB->D_c = DrivetrainHevP4_P.Constant_Value_n;

    /* Constant: '<S266>/Constant1' */
    localB->C_g = DrivetrainHevP4_P.Constant1_Value_if;

    /* Constant: '<S266>/Constant7' */
    localB->B_d = DrivetrainHevP4_P.Constant7_Value_i;

    /* Constant: '<S266>/Constant6' */
    localB->E_a = DrivetrainHevP4_P.Constant6_Value_k;

    /* Constant: '<S210>/lam_muxConstant' */
    localB->lam_muxConstant_h = DrivetrainHevP4_P.lam_x;

    /* Constant: '<S266>/Constant2' */
    memcpy(&localB->Constant2_p[0], &DrivetrainHevP4_P.Constant2_Value_f4[0],
           34U * sizeof(real_T));

    /* Constant: '<S266>/Constant19' */
    localB->kappaFx_j[0] = DrivetrainHevP4_P.Constant19_Value_e[0];

    /* Constant: '<S266>/Constant12' */
    localB->FzFx_l[0] = DrivetrainHevP4_P.Constant12_Value_m[0];

    /* Constant: '<S266>/Constant19' */
    localB->kappaFx_j[1] = DrivetrainHevP4_P.Constant19_Value_e[1];

    /* Constant: '<S266>/Constant12' */
    localB->FzFx_l[1] = DrivetrainHevP4_P.Constant12_Value_m[1];

    /* Constant: '<S266>/Constant19' */
    localB->kappaFx_j[2] = DrivetrainHevP4_P.Constant19_Value_e[2];

    /* Constant: '<S266>/Constant12' */
    localB->FzFx_l[2] = DrivetrainHevP4_P.Constant12_Value_m[2];

    /* Constant: '<S210>/TirePrsConstant' */
    localB->TirePrsConstant_a = DrivetrainHevP4_P.press;

    /* Constant: '<S267>/Constant5' */
    localB->FNOMIN_m = DrivetrainHevP4_P.Constant5_Value_k;

    /* Constant: '<S267>/Constant2' */
    localB->NOMPRES_h = DrivetrainHevP4_P.Constant2_Value_h;

    /* Constant: '<S267>/Constant13' */
    localB->QSY1_k = DrivetrainHevP4_P.aMy;

    /* Constant: '<S267>/Constant8' */
    localB->QSY2_g = DrivetrainHevP4_P.bMy;

    /* Constant: '<S267>/Constant15' */
    localB->QSY3_h = DrivetrainHevP4_P.cMy;

    /* Constant: '<S267>/Constant16' */
    localB->QSY4_k = DrivetrainHevP4_P.Constant16_Value_g;

    /* Constant: '<S267>/Constant7' */
    localB->QSY5_p = DrivetrainHevP4_P.Constant7_Value_c;

    /* Constant: '<S267>/Constant9' */
    localB->QSY6_i = DrivetrainHevP4_P.Constant9_Value_d;

    /* Constant: '<S267>/Constant17' */
    localB->QSY7_j = DrivetrainHevP4_P.betaMy;

    /* Constant: '<S267>/Constant18' */
    localB->QSY8_d = DrivetrainHevP4_P.alphaMy;

    /* Constant: '<S267>/Constant11' */
    localB->gamma_e = DrivetrainHevP4_P.Constant11_Value_b;

    /* Constant: '<S267>/Constant10' */
    localB->lam_My_a = DrivetrainHevP4_P.Constant10_Value_g;

    /* Constant: '<S267>/Constant4' */
    localB->UNLOADED_RADIUS_k = DrivetrainHevP4_P.UNLOADED_RADIUS;

    /* Constant: '<S267>/Constant1' */
    localB->PRESMIN_g = DrivetrainHevP4_P.Constant1_Value_o;

    /* Constant: '<S267>/Constant3' */
    localB->PRESMAX_c = DrivetrainHevP4_P.Constant3_Value_i;

    /* Constant: '<S267>/Constant19' */
    localB->VxMy_k[0] = DrivetrainHevP4_P.Constant19_Value_b[0];

    /* Constant: '<S267>/Constant12' */
    localB->FzMy_g[0] = DrivetrainHevP4_P.Constant12_Value_g[0];

    /* Constant: '<S267>/Constant19' */
    localB->VxMy_k[1] = DrivetrainHevP4_P.Constant19_Value_b[1];

    /* Constant: '<S267>/Constant12' */
    localB->FzMy_g[1] = DrivetrainHevP4_P.Constant12_Value_g[1];

    /* Constant: '<S267>/Constant19' */
    localB->VxMy_k[2] = DrivetrainHevP4_P.Constant19_Value_b[2];

    /* Constant: '<S267>/Constant12' */
    localB->FzMy_g[2] = DrivetrainHevP4_P.Constant12_Value_g[2];

    /* Constant: '<S266>/Constant14' */
    memcpy(&localB->FxMap_h[0], &DrivetrainHevP4_P.Constant14_Value_n[0], 9U *
           sizeof(real_T));

    /* Constant: '<S267>/Constant14' */
    memcpy(&localB->MyMap_d[0], &DrivetrainHevP4_P.Constant14_Value_j[0], 9U *
           sizeof(real_T));

    /* Constant: '<S268>/Constant14' */
    localB->NOMPRES_m = DrivetrainHevP4_P.Constant14_Value_b;

    /* Constant: '<S268>/Constant1' */
    localB->PRESMIN_b = DrivetrainHevP4_P.Constant1_Value_b;

    /* Constant: '<S268>/Constant19' */
    localB->PRESMAX_h = DrivetrainHevP4_P.Constant19_Value_j;

    /* Constant: '<S268>/Constant2' */
    localB->VERTICAL_STIFFNESS_e = DrivetrainHevP4_P.Constant2_Value_o;

    /* Constant: '<S268>/Constant3' */
    localB->VERTICAL_DAMPING_h = DrivetrainHevP4_P.Constant3_Value_f;

    /* Constant: '<S268>/Constant4' */
    localB->Q_RE0_p = DrivetrainHevP4_P.Constant4_Value_h;

    /* Constant: '<S268>/Constant5' */
    localB->Q_V1_i = DrivetrainHevP4_P.Constant5_Value_h;

    /* Constant: '<S268>/Constant6' */
    localB->Q_V2_d = DrivetrainHevP4_P.Constant6_Value_h;

    /* Constant: '<S268>/Constant7' */
    localB->Q_FZ1_o = DrivetrainHevP4_P.Constant7_Value_k;

    /* Constant: '<S268>/Constant8' */
    localB->Q_FZ2_j = DrivetrainHevP4_P.Constant8_Value_d;

    /* Constant: '<S268>/Constant9' */
    localB->Q_FCX_f = DrivetrainHevP4_P.Constant9_Value_dg;

    /* Constant: '<S268>/Constant10' */
    localB->Q_FCY_l = DrivetrainHevP4_P.Constant10_Value_p;

    /* Constant: '<S268>/Constant11' */
    localB->Q_CAM_l = DrivetrainHevP4_P.Constant11_Value_fj;

    /* Constant: '<S268>/Constant16' */
    localB->PFZ1_g = DrivetrainHevP4_P.Constant16_Value_p;

    /* Constant: '<S268>/Constant17' */
    localB->Q_FCY2_l = DrivetrainHevP4_P.Constant17_Value_a;

    /* Constant: '<S268>/Constant13' */
    localB->Q_CAM1_m = DrivetrainHevP4_P.Constant13_Value_i;

    /* Constant: '<S268>/Constant15' */
    localB->Q_CAM2_a = DrivetrainHevP4_P.Constant15_Value_l;

    /* Constant: '<S268>/Constant21' */
    localB->Q_CAM3_h = DrivetrainHevP4_P.Constant21_Value_m;

    /* Constant: '<S268>/Constant22' */
    localB->Q_FYS1_l = DrivetrainHevP4_P.Constant22_Value_n;

    /* Constant: '<S268>/Constant18' */
    localB->Q_FYS2_o = DrivetrainHevP4_P.Constant18_Value_e;

    /* Constant: '<S268>/Constant20' */
    localB->Q_FYS3_b = DrivetrainHevP4_P.Constant20_Value_a;

    /* Constant: '<S268>/Constant24' */
    localB->BOTTOM_OFFST_g = DrivetrainHevP4_P.Constant24_Value_n;

    /* Constant: '<S268>/Constant23' */
    localB->BOTTOM_STIFF_e = DrivetrainHevP4_P.Constant23_Value_n;

    /* Constant: '<S210>/FxType' */
    localB->FxType_b = DrivetrainHevP4_P.FxType_Value_m;

    /* Constant: '<S210>/rollType' */
    localB->rollType_m = DrivetrainHevP4_P.rollType_Value_h;

    /* Constant: '<S210>/vertType' */
    localB->vertType_o = DrivetrainHevP4_P.vertType_Value_e;

    /* Constant: '<S206>/Constant' */
    localB->VectorConcatenate_n[0] = DrivetrainHevP4_P.Cd;

    /* Constant: '<S206>/Constant1' */
    localB->VectorConcatenate_n[2] =
      DrivetrainHevP4_P.VehicleBody1DOFLongitudinal_Cl;

    /* Constant: '<S206>/Constant2' */
    localB->Constant2_n = DrivetrainHevP4_P.VehicleBody1DOFLongitudinal_Cpm;

    /* Constant: '<S165>/AirTempConstant' */
    localB->AirTempConstant = DrivetrainHevP4_P.T;

    /* Constant: '<S206>/Constant3' */
    localB->Constant3 = DrivetrainHevP4_P.a_CG + DrivetrainHevP4_P.b_CG;

    /* Gain: '<S169>/m' incorporates:
     *  Constant: '<S169>/g'
     */
    localB->Fz = DrivetrainHevP4_P.Mass * DrivetrainHevP4_P.g;

    /* Constant: '<S165>/MExtConstant' */
    localB->MExtConstant[0] = DrivetrainHevP4_P.MExtConstant_Value[0];

    /* Constant: '<S165>/FExtConstant' */
    localB->FExtConstant[0] = DrivetrainHevP4_P.FExtConstant_Value[0];

    /* Constant: '<S165>/MExtConstant' */
    localB->MExtConstant[1] = DrivetrainHevP4_P.MExtConstant_Value[1];

    /* Constant: '<S165>/FExtConstant' */
    localB->FExtConstant[1] = DrivetrainHevP4_P.FExtConstant_Value[1];

    /* Constant: '<S165>/MExtConstant' */
    localB->MExtConstant[2] = DrivetrainHevP4_P.MExtConstant_Value[2];

    /* Constant: '<S165>/FExtConstant' */
    localB->FExtConstant[2] = DrivetrainHevP4_P.FExtConstant_Value[2];

    /* Constant: '<S164>/Constant' */
    localB->Constant_f = DrivetrainHevP4_P.wc;
  }

  /* SignalConversion generated from: '<S169>/Vector Concatenate5' */
  localB->VectorConcatenate5[0] = localB->Integrator;

  /* SignalConversion generated from: '<S169>/Vector Concatenate5' */
  localB->VectorConcatenate5[1] = 0.0;

  /* SignalConversion generated from: '<S169>/Vector Concatenate5' */
  localB->VectorConcatenate5[2] = 0.0;

  /* SignalConversion generated from: '<S207>/Vector Concatenate5' */
  localB->VectorConcatenate5_e[1] = 0.0;

  /* SignalConversion generated from: '<S207>/Vector Concatenate5' */
  localB->VectorConcatenate5_e[2] = 0.0;

  /* SignalConversion generated from: '<S3>/Integrator' */
  localB->TmpSignalConversionAtIntegratorInport1[0] = 0.0;
  localB->TmpSignalConversionAtIntegratorInport1[1] = 0.0;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S196>/Constant' */
    localB->Constant_m = DrivetrainHevP4_P.Constant_Value_cb;

    /* Constant: '<S168>/Constant' */
    localB->Constant_c = DrivetrainHevP4_P.Constant_Value_l;
  }

  /* SignalConversion generated from: '<S166>/Vector Concatenate1' */
  localB->VectorConcatenate1[1] = 0.0;

  /* SignalConversion generated from: '<S166>/Vector Concatenate1' */
  localB->VectorConcatenate1[2] = 0.0;

  /* SignalConversion generated from: '<S168>/Product' incorporates:
   *  Integrator: '<S166>/Integrator1'
   *  SignalConversion generated from: '<S166>/Vector Concatenate5'
   */
  localB->TmpSignalConversionAtProductInport2[0] = localX->Integrator1_CSTATE_f;
  localB->TmpSignalConversionAtProductInport2[1] = localB->Constant_c;
  localB->TmpSignalConversionAtProductInport2[2] = 0.0;

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[1] = 0.0;

  /* Sum: '<S144>/Sum' */
  localB->Sum = localX->PumpIntegrator_CSTATE - localX->TurbineIntegrator_CSTATE;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* HitCross: '<S144>/Velocities Match' */
    zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,&localZCE->VelocitiesMatch_Input_ZCE,
                       (localB->Sum - DrivetrainHevP4_P.VelocitiesMatch_Offset));
    if (localDW->VelocitiesMatch_MODE == 0) {
      if (zcEvent != NO_ZCEVENT) {
        /* HitCross: '<S144>/Velocities Match' */
        localB->VelocitiesMatch = !localB->VelocitiesMatch;
        localDW->VelocitiesMatch_MODE = 1;
      } else if (localB->VelocitiesMatch) {
        /* HitCross: '<S144>/Velocities Match' */
        localB->VelocitiesMatch = ((!(localB->Sum !=
          DrivetrainHevP4_P.VelocitiesMatch_Offset)) && localB->VelocitiesMatch);
      } else {
        /* HitCross: '<S144>/Velocities Match' */
        localB->VelocitiesMatch = ((localB->Sum ==
          DrivetrainHevP4_P.VelocitiesMatch_Offset) || localB->VelocitiesMatch);
      }
    } else {
      /* HitCross: '<S144>/Velocities Match' */
      localB->VelocitiesMatch = ((!(localB->Sum !=
        DrivetrainHevP4_P.VelocitiesMatch_Offset)) && localB->VelocitiesMatch);
      localDW->VelocitiesMatch_MODE = 0;
    }

    /* End of HitCross: '<S144>/Velocities Match' */

    /* Memory: '<S87>/Memory' */
    localB->Memory_k = localDW->Memory_PreviousInput_e;

    /* Constant: '<S86>/domega_o' */
    localB->domega_o_h = DrivetrainHevP4_P.domega_o;
  }

  /* Integrator: '<S87>/Integrator' */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_j,
                       (localB->Memory_k));
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_d != 0)) {
      localX->Integrator_CSTATE_de = localB->domega_o_h;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    rtb_Switch = localX->Integrator_CSTATE_de;
  } else {
    rtb_Switch = localX->Integrator_CSTATE_de;
  }

  /* End of Integrator: '<S87>/Integrator' */

  /* Sum: '<S86>/Subtract1' incorporates:
   *  Gain: '<S86>/Gain1'
   *  Gain: '<S86>/Gain2'
   *  Integrator: '<S86>/Integrator'
   */
  rtb_Subtract1 = DrivetrainHevP4_P.b * rtb_Switch + DrivetrainHevP4_P.k *
    localX->Integrator_CSTATE_g;

  /* Gain: '<S147>/Output Damping' */
  rtb_OutputDamping = DrivetrainHevP4_P.bt * localX->PumpIntegrator_CSTATE;

  /* Outputs for IfAction SubSystem: '<S126>/Locked' incorporates:
   *  ActionPort: '<S132>/Action'
   */
  /* If: '<S126>/If' incorporates:
   *  Sum: '<S132>/Sum'
   *  Sum: '<S146>/Sum'
   *  Sum: '<S147>/Sum'
   *  UnaryMinus: '<S86>/Unary Minus'
   */
  rtb_u = *rtu_EngTrq + -rtb_Subtract1;

  /* End of Outputs for SubSystem: '<S126>/Locked' */

  /* Gain: '<S147>/Inertia Ratio' incorporates:
   *  Gain: '<S147>/Input Damping'
   *  Sum: '<S147>/Sum'
   */
  rtb_InertiaRatio = DrivetrainHevP4_P.Jt / (DrivetrainHevP4_P.Ji +
    DrivetrainHevP4_P.Jt) * ((rtb_u - DrivetrainHevP4_P.bi *
    localX->PumpIntegrator_CSTATE) - rtb_OutputDamping);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Memory: '<S150>/Memory' */
    localB->Memory_b = localDW->Memory_PreviousInput_d;

    /* Constant: '<S149>/Constant2' */
    localB->Constant2_pr = DrivetrainHevP4_P.Constant2_Value_a;
  }

  /* Integrator: '<S150>/Integrator' */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_f,
                       (localB->Memory_b));
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_h != 0)) {
      localX->Integrator_CSTATE_b = localB->Constant2_pr;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    rtb_Sum = localX->Integrator_CSTATE_b;
  } else {
    rtb_Sum = localX->Integrator_CSTATE_b;
  }

  /* End of Integrator: '<S150>/Integrator' */

  /* Gain: '<S149>/ClutchGain' */
  localB->ClutchGain = DrivetrainHevP4_P.K_c * rtb_Sum;

  /* Saturate: '<S151>/Saturation' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    localDW->Saturation_MODE = localB->ClutchGain >=
      DrivetrainHevP4_P.Saturation_UpperSat_h ? 1 : localB->ClutchGain >
      DrivetrainHevP4_P.Saturation_LowerSat_f ? 0 : -1;
  }

  /* Gain: '<S151>/Torque Conversion' incorporates:
   *  Saturate: '<S151>/Saturation'
   */
  rtb_TorqueConversion = DrivetrainHevP4_P.Reff * DrivetrainHevP4_P.muk *
    (localDW->Saturation_MODE == 1 ? DrivetrainHevP4_P.Saturation_UpperSat_h :
     localDW->Saturation_MODE == -1 ? DrivetrainHevP4_P.Saturation_LowerSat_f :
     localB->ClutchGain);

  /* Gain: '<S151>/Ratio of static to kinetic' */
  rtb_Subtract1_p = DrivetrainHevP4_P.mus / DrivetrainHevP4_P.muk *
    rtb_TorqueConversion;

  /* Logic: '<S144>/Logic' incorporates:
   *  Abs: '<S148>/Abs'
   *  RelationalOperator: '<S148>/Relational Operator'
   *  Sum: '<S147>/Sum1'
   */
  rtb_Logic = (localB->VelocitiesMatch && (fabs(rtb_InertiaRatio +
    rtb_OutputDamping) <= rtb_Subtract1_p));

  /* Gain: '<S146>/Turbine Damping' */
  rtb_OutputDamping = DrivetrainHevP4_P.bt *
    localX->LockedShaftIntegrator_CSTATE;

  /* Abs: '<S143>/Abs' incorporates:
   *  Gain: '<S146>/Impeller Damping'
   *  Gain: '<S146>/Inertia Ratio'
   *  Sum: '<S146>/Sum'
   *  Sum: '<S146>/Sum1'
   */
  rtb_OutputDamping = fabs(DrivetrainHevP4_P.Jt / (DrivetrainHevP4_P.Ji +
    DrivetrainHevP4_P.Jt) * ((rtb_u - DrivetrainHevP4_P.bi *
    localX->LockedShaftIntegrator_CSTATE) - rtb_OutputDamping) +
    rtb_OutputDamping);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Memory: '<S145>/Memory' */
    localB->Memory_kc = localDW->Memory_PreviousInput_jb;

    /* InitialCondition: '<S129>/IC' */
    if (localDW->IC_FirstOutputTime) {
      localDW->IC_FirstOutputTime = false;

      /* InitialCondition: '<S129>/IC' */
      localB->IC = DrivetrainHevP4_P.IC_Value;
    } else {
      /* InitialCondition: '<S129>/IC' incorporates:
       *  Constant: '<S129>/Constant1'
       */
      localB->IC = DrivetrainHevP4_P.Constant1_Value_j;
    }

    /* End of InitialCondition: '<S129>/IC' */

    /* Constant: '<S129>/Constant' */
    localB->Constant_n = DrivetrainHevP4_P.omegai_o;
  }

  /* CombinatorialLogic: '<S145>/Combinatorial  Logic' incorporates:
   *  RelationalOperator: '<S143>/Relational Operator'
   */
  *rty_Cltch2State = DrivetrainHevP4_P.CombinatorialLogic_table[((((uint32_T)
    rtb_Logic << 1) + (rtb_OutputDamping >= rtb_Subtract1_p)) << 1) +
    localB->Memory_kc];

  /* Switch: '<S129>/Switch' */
  if (localB->IC > DrivetrainHevP4_P.Switch_Threshold_g) {
    /* Switch: '<S129>/Switch' */
    localB->Switch = localX->LockedShaftIntegrator_CSTATE;
  } else {
    /* Switch: '<S129>/Switch' */
    localB->Switch = localB->Constant_n;
  }

  /* End of Switch: '<S129>/Switch' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* InitialCondition: '<S134>/IC' */
    if (localDW->IC_FirstOutputTime_d) {
      localDW->IC_FirstOutputTime_d = false;

      /* InitialCondition: '<S134>/IC' */
      localB->IC_p = DrivetrainHevP4_P.IC_Value_o;
    } else {
      /* InitialCondition: '<S134>/IC' incorporates:
       *  Constant: '<S134>/Constant1'
       */
      localB->IC_p = DrivetrainHevP4_P.Constant1_Value_io;
    }

    /* End of InitialCondition: '<S134>/IC' */

    /* Constant: '<S134>/Constant' */
    localB->Constant_d = DrivetrainHevP4_P.omegat_o;

    /* InitialCondition: '<S128>/IC' */
    if (localDW->IC_FirstOutputTime_m) {
      localDW->IC_FirstOutputTime_m = false;

      /* InitialCondition: '<S128>/IC' */
      localB->IC_o = DrivetrainHevP4_P.IC_Value_i;
    } else {
      /* InitialCondition: '<S128>/IC' incorporates:
       *  Constant: '<S128>/Constant1'
       */
      localB->IC_o = DrivetrainHevP4_P.Constant1_Value_bf;
    }

    /* End of InitialCondition: '<S128>/IC' */

    /* Constant: '<S128>/Constant' */
    localB->Constant_nu = DrivetrainHevP4_P.omegai_o;
  }

  /* Switch: '<S134>/Switch' */
  if (localB->IC_p > DrivetrainHevP4_P.Switch_Threshold_m) {
    /* Switch: '<S134>/Switch' */
    localB->Switch_h = localX->LockedShaftIntegrator_CSTATE;
  } else {
    /* Switch: '<S134>/Switch' */
    localB->Switch_h = localB->Constant_d;
  }

  /* End of Switch: '<S134>/Switch' */

  /* Switch: '<S128>/Switch' */
  if (localB->IC_o > DrivetrainHevP4_P.Switch_Threshold_k) {
    /* Switch: '<S128>/Switch' */
    localB->Switch_l = localX->PumpIntegrator_CSTATE;
  } else {
    /* Switch: '<S128>/Switch' */
    localB->Switch_l = localB->Constant_nu;
  }

  /* End of Switch: '<S128>/Switch' */

  /* If: '<S126>/If' incorporates:
   *  Constant: '<S132>/Constant1'
   *  Constant: '<S132>/Constant2'
   *  Constant: '<S152>/Constant1'
   *  Constant: '<S152>/phi'
   *  Constant: '<S152>/psi'
   *  Constant: '<S152>/zeta'
   *  Constant: '<S153>/Constant'
   *  Constant: '<S154>/Constant'
   *  Constant: '<S154>/Constant1'
   *  Constant: '<S154>/Constant2'
   *  Constant: '<S158>/Constant'
   *  Constant: '<S160>/Constant'
   *  Constant: '<S161>/Constant'
   *  Constant: '<S162>/Constant'
   */
  rtPrevAction = localDW->If_ActiveSubsystem;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    rtAction = (int8_T)!*rty_Cltch2State;
    localDW->If_ActiveSubsystem = rtAction;
  } else {
    rtAction = localDW->If_ActiveSubsystem;
  }

  if (rtPrevAction != rtAction) {
    switch (rtPrevAction) {
     case 0:
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      localXdis->LockedShaftIntegrator_CSTATE = 1;
      break;

     case 1:
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      (void) memset(&(localXdis->PumpIntegrator_CSTATE), 1,
                    3*sizeof(boolean_T));

      /* Disable for Enabled SubSystem: '<S153>/LPF' */
      localDW->LPF_MODE = false;

      /* End of Disable for SubSystem: '<S153>/LPF' */
      break;
    }
  }

  switch (rtAction) {
   case 0:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S126>/Locked' incorporates:
       *  ActionPort: '<S132>/Action'
       */
      /* InitializeConditions for If: '<S126>/If' incorporates:
       *  Integrator: '<S132>/Locked Shaft Integrator'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->LockedShaftIntegrator_CSTATE = 0.0;
      }

      localDW->LockedShaftIntegrator_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S126>/Locked' */

      /* Enable for IfAction SubSystem: '<S126>/Locked' incorporates:
       *  ActionPort: '<S132>/Action'
       */
      /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
       *  EnablePort: '<S156>/Enable'
       */
      /* Enable for If: '<S126>/If' */
      if (rtmGetTaskTime(DrivetrainHevP4_M, 0) != rtmGetTStart(DrivetrainHevP4_M))
      {
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }

      /* End of Outputs for SubSystem: '<S153>/LPF' */
      localXdis->LockedShaftIntegrator_CSTATE = 0;

      /* End of Enable for SubSystem: '<S126>/Locked' */
    }

    /* Outputs for IfAction SubSystem: '<S126>/Locked' incorporates:
     *  ActionPort: '<S132>/Action'
     */
    /* Integrator: '<S132>/Locked Shaft Integrator' */
    /* Limited  Integrator  */
    rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
    if (rtb_Logic) {
      if (localDW->LockedShaftIntegrator_IWORK != 0) {
        localX->LockedShaftIntegrator_CSTATE = localB->Switch_l;
        ssSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->rtS);
      }

      if (localX->LockedShaftIntegrator_CSTATE >=
          DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat) {
        if (localX->LockedShaftIntegrator_CSTATE !=
            DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat) {
          localX->LockedShaftIntegrator_CSTATE =
            DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat;
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
          ssSetContTimeOutputInconsistentWithStateAtMajorStep
            (DrivetrainHevP4_M->rtS);
        }
      } else if ((localX->LockedShaftIntegrator_CSTATE <=
                  DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat) &&
                 (localX->LockedShaftIntegrator_CSTATE !=
                  DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat)) {
        localX->LockedShaftIntegrator_CSTATE =
          DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
        ssSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->rtS);
      }

      rtb_OutputDamping = localX->LockedShaftIntegrator_CSTATE;
    } else if (localX->LockedShaftIntegrator_CSTATE >=
               DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat) {
      rtb_OutputDamping = DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat;
      localX->LockedShaftIntegrator_CSTATE =
        DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat;
    } else if (localX->LockedShaftIntegrator_CSTATE <=
               DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat) {
      rtb_OutputDamping = DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat;
      localX->LockedShaftIntegrator_CSTATE =
        DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat;
    } else {
      rtb_OutputDamping = localX->LockedShaftIntegrator_CSTATE;
    }

    /* End of Integrator: '<S132>/Locked Shaft Integrator' */
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->PwrCltchLoss_k = DrivetrainHevP4_P.Constant1_Value;
      localB->PwrFluidHeatLoss_d = DrivetrainHevP4_P.Constant2_Value;

      /* Merge: '<S126>/Merge2' incorporates:
       *  Constant: '<S132>/Constant'
       *  Constant: '<S132>/Constant1'
       *  Constant: '<S132>/Constant2'
       *  SignalConversion generated from: '<S132>/Speed Ratio'
       */
      localB->SpdRatio = DrivetrainHevP4_P.Constant_Value_a;
    }

    /* Gain: '<S132>/Inertia' incorporates:
     *  Constant: '<S132>/Constant1'
     *  Constant: '<S132>/Constant2'
     *  Gain: '<S132>/Impeller Damping'
     *  Gain: '<S132>/Turbine Damping'
     *  Sum: '<S132>/Add1'
     *  Sum: '<S132>/Sum'
     */
    localB->Inertia = 1.0 / (DrivetrainHevP4_P.Ji + DrivetrainHevP4_P.Jt) *
      (rtb_u - (DrivetrainHevP4_P.bi * rtb_OutputDamping + DrivetrainHevP4_P.bt *
                rtb_OutputDamping));

    /* Product: '<S132>/Product1' */
    rtb_Subtract1_p = rtb_OutputDamping * localB->Inertia;

    /* SignalConversion: '<S132>/Signal Conversion1' */
    *rty_EngSpd = rtb_OutputDamping;

    /* Merge generated from: '<S126>/Merge4' incorporates:
     *  Gain: '<S132>/Inertia1'
     *  SignalConversion generated from: '<S132>/Signal Conversion2'
     */
    localB->PwrStoredImp = DrivetrainHevP4_P.Ji * rtb_Subtract1_p;

    /* Merge generated from: '<S126>/Merge4' incorporates:
     *  Gain: '<S132>/Inertia2'
     *  SignalConversion generated from: '<S132>/Signal Conversion2'
     */
    localB->PwrStoredTurb = DrivetrainHevP4_P.Jt * rtb_Subtract1_p;

    /* End of Outputs for SubSystem: '<S126>/Locked' */
    break;

   case 1:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S126>/Unlocked' incorporates:
       *  ActionPort: '<S133>/Action'
       */
      /* InitializeConditions for If: '<S126>/If' incorporates:
       *  Integrator: '<S133>/Pump Integrator'
       *  Integrator: '<S133>/Turbine Integrator'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->PumpIntegrator_CSTATE = 0.0;
        localX->TurbineIntegrator_CSTATE = 0.0;
      }

      localDW->PumpIntegrator_IWORK = 1;
      localDW->TurbineIntegrator_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S126>/Unlocked' */

      /* Enable for IfAction SubSystem: '<S126>/Unlocked' incorporates:
       *  ActionPort: '<S133>/Action'
       */
      /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
       *  EnablePort: '<S156>/Enable'
       */
      /* Enable for If: '<S126>/If' */
      if (rtmGetTaskTime(DrivetrainHevP4_M, 0) != rtmGetTStart(DrivetrainHevP4_M))
      {
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }

      /* End of Outputs for SubSystem: '<S153>/LPF' */
      (void) memset(&(localXdis->PumpIntegrator_CSTATE), 0,
                    3*sizeof(boolean_T));

      /* End of Enable for SubSystem: '<S126>/Unlocked' */
    }

    /* Outputs for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* Integrator: '<S133>/Pump Integrator' */
    /* Limited  Integrator  */
    rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
    if (rtb_Logic) {
      if (localDW->PumpIntegrator_IWORK != 0) {
        localX->PumpIntegrator_CSTATE = localB->Switch;
        ssSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->rtS);
      }

      if (localX->PumpIntegrator_CSTATE >=
          DrivetrainHevP4_P.PumpIntegrator_UpperSat) {
        if (localX->PumpIntegrator_CSTATE !=
            DrivetrainHevP4_P.PumpIntegrator_UpperSat) {
          localX->PumpIntegrator_CSTATE =
            DrivetrainHevP4_P.PumpIntegrator_UpperSat;
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
          ssSetContTimeOutputInconsistentWithStateAtMajorStep
            (DrivetrainHevP4_M->rtS);
        }

        localDW->PumpIntegrator_MODE = 3;
      } else if (localX->PumpIntegrator_CSTATE <=
                 DrivetrainHevP4_P.PumpIntegrator_LowerSat) {
        if (localX->PumpIntegrator_CSTATE !=
            DrivetrainHevP4_P.PumpIntegrator_LowerSat) {
          localX->PumpIntegrator_CSTATE =
            DrivetrainHevP4_P.PumpIntegrator_LowerSat;
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
          ssSetContTimeOutputInconsistentWithStateAtMajorStep
            (DrivetrainHevP4_M->rtS);
        }

        localDW->PumpIntegrator_MODE = 4;
      } else {
        if (localDW->PumpIntegrator_MODE != 0) {
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
        }

        localDW->PumpIntegrator_MODE = 0;
      }

      rtb_InertiaRatio = localX->PumpIntegrator_CSTATE;
    } else {
      rtb_InertiaRatio = localX->PumpIntegrator_CSTATE;
    }

    /* End of Integrator: '<S133>/Pump Integrator' */

    /* Integrator: '<S133>/Turbine Integrator' */
    /* Limited  Integrator  */
    rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
    if (rtb_Logic) {
      if (localDW->TurbineIntegrator_IWORK != 0) {
        localX->TurbineIntegrator_CSTATE = localB->Switch_h;
        ssSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->rtS);
      }

      if (localX->TurbineIntegrator_CSTATE >=
          DrivetrainHevP4_P.TurbineIntegrator_UpperSat) {
        if (localX->TurbineIntegrator_CSTATE !=
            DrivetrainHevP4_P.TurbineIntegrator_UpperSat) {
          localX->TurbineIntegrator_CSTATE =
            DrivetrainHevP4_P.TurbineIntegrator_UpperSat;
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
          ssSetContTimeOutputInconsistentWithStateAtMajorStep
            (DrivetrainHevP4_M->rtS);
        }

        localDW->TurbineIntegrator_MODE = 3;
      } else if (localX->TurbineIntegrator_CSTATE <=
                 DrivetrainHevP4_P.TurbineIntegrator_LowerSat) {
        if (localX->TurbineIntegrator_CSTATE !=
            DrivetrainHevP4_P.TurbineIntegrator_LowerSat) {
          localX->TurbineIntegrator_CSTATE =
            DrivetrainHevP4_P.TurbineIntegrator_LowerSat;
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
          ssSetContTimeOutputInconsistentWithStateAtMajorStep
            (DrivetrainHevP4_M->rtS);
        }

        localDW->TurbineIntegrator_MODE = 4;
      } else {
        if (localDW->TurbineIntegrator_MODE != 0) {
          ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
        }

        localDW->TurbineIntegrator_MODE = 0;
      }

      rtb_OutputDamping = localX->TurbineIntegrator_CSTATE;
    } else {
      rtb_OutputDamping = localX->TurbineIntegrator_CSTATE;
    }

    /* End of Integrator: '<S133>/Turbine Integrator' */

    /* Sum: '<S133>/W_Slip' incorporates:
     *  Sum: '<S154>/Add'
     */
    rtb_u_tmp = rtb_InertiaRatio - rtb_OutputDamping;

    /* Gain: '<S133>/4' incorporates:
     *  Sum: '<S133>/W_Slip'
     */
    rtb_u = rtb_u_tmp * DrivetrainHevP4_P.u_Gain_m;

    /* Gain: '<S133>/Turbine Damping' */
    rtb_OutputSum = DrivetrainHevP4_P.bt * rtb_OutputDamping;

    /* Gain: '<S133>/Impeller Damping' */
    rtb_Subtract1_p = DrivetrainHevP4_P.bi * rtb_InertiaRatio;
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->Constant_l = DrivetrainHevP4_P.tauTC;
      localB->VectorConcatenate_a[0] = DrivetrainHevP4_P.Constant1_Value_h;
      memcpy(&localB->VectorConcatenate_a[1], &DrivetrainHevP4_P.phi[0], 10U *
             sizeof(real_T));
      localB->Constant_hd = DrivetrainHevP4_P.Constant_Value_c;
      localB->Constant_fo = -DrivetrainHevP4_P.div0protectpoly_thresh;
      localB->Constant_fd = DrivetrainHevP4_P.div0protectpoly_thresh;
      localB->Constant_e = DrivetrainHevP4_P.CompareToConstant2_const;
      localB->Constant_pm = DrivetrainHevP4_P.Constant_Value_p;
    }

    /* MinMax: '<S154>/MinMax' incorporates:
     *  Constant: '<S153>/Constant'
     *  Constant: '<S154>/Constant'
     *  Constant: '<S154>/Constant1'
     *  Constant: '<S154>/Constant2'
     *  Constant: '<S158>/Constant'
     *  Constant: '<S160>/Constant'
     *  Constant: '<S161>/Constant'
     *  Constant: '<S162>/Constant'
     */
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
      rtb_Switch2 = localB->VectorConcatenate_a[0];
      localDW->MinMax_MODE = 0;
      for (i = 0; i < 10; i++) {
        rtb_uniclutch = localB->VectorConcatenate_a[i + 1];
        if (rtb_uniclutch > rtb_Switch2) {
          rtb_Switch2 = rtb_uniclutch;
          localDW->MinMax_MODE = i + 1;
        }
      }

      /* MinMax: '<S154>/MinMax' */
      localB->MinMax = rtb_Switch2;
    } else {
      /* MinMax: '<S154>/MinMax' */
      localB->MinMax = localB->VectorConcatenate_a[localDW->MinMax_MODE];
    }

    /* End of MinMax: '<S154>/MinMax' */

    /* Switch: '<S154>/Switch' incorporates:
     *  Abs: '<S154>/Abs'
     *  RelationalOperator: '<S158>/Compare'
     */
    if (fabs(rtb_InertiaRatio) > localB->Constant_e) {
      /* Switch: '<S160>/Switch' incorporates:
       *  Fcn: '<S160>/Fcn'
       *  Logic: '<S160>/Logical Operator'
       *  Product: '<S160>/Product'
       *  RelationalOperator: '<S161>/Compare'
       *  RelationalOperator: '<S162>/Compare'
       */
      if ((rtb_InertiaRatio >= localB->Constant_fo) && (rtb_InertiaRatio <=
           localB->Constant_fd)) {
        /* Switch: '<S160>/Switch1' incorporates:
         *  UnaryMinus: '<S160>/Unary Minus'
         */
        if (rtb_InertiaRatio >= DrivetrainHevP4_P.Switch1_Threshold) {
          rtb_Switch2 = localB->Constant_hd;
        } else {
          rtb_Switch2 = -localB->Constant_hd;
        }

        /* End of Switch: '<S160>/Switch1' */
        rtb_Switch2 *= 2.0 / (3.0 - rt_powd_snf(rtb_InertiaRatio, 2.0));
      } else {
        rtb_Switch2 = rtb_InertiaRatio;
      }

      /* End of Switch: '<S160>/Switch' */

      /* Switch: '<S154>/Switch' incorporates:
       *  Product: '<S154>/Divide'
       */
      localB->phi = rtb_OutputDamping / rtb_Switch2;
    } else {
      /* Switch: '<S154>/Switch' */
      localB->phi = localB->Constant_pm;
    }

    /* End of Switch: '<S154>/Switch' */
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      /* RelationalOperator: '<S159>/LowerRelop1' */
      if (ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS)) {
        localDW->LowerRelop1_Mode = (localB->phi > localB->MinMax);
      }

      /* RelationalOperator: '<S159>/LowerRelop1' */
      localB->LowerRelop1 = localDW->LowerRelop1_Mode;
    }

    /* Gain: '<S154>/Gain' */
    localB->Gain = DrivetrainHevP4_P.Gain_Gain_p * localB->MinMax;
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      /* RelationalOperator: '<S159>/UpperRelop' */
      if (ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS)) {
        localDW->UpperRelop_Mode = (localB->phi < localB->Gain);
      }

      /* RelationalOperator: '<S159>/UpperRelop' */
      localB->UpperRelop = localDW->UpperRelop_Mode;
      memcpy(&localB->phi_a[0], &DrivetrainHevP4_P.phi[0], 10U * sizeof(real_T));
    }

    /* Switch: '<S159>/Switch2' incorporates:
     *  Constant: '<S152>/phi'
     *  Switch: '<S159>/Switch'
     */
    if (localB->LowerRelop1) {
      rtb_Switch2 = localB->MinMax;
    } else if (localB->UpperRelop) {
      /* Switch: '<S159>/Switch' */
      rtb_Switch2 = localB->Gain;
    } else {
      rtb_Switch2 = localB->phi;
    }

    /* End of Switch: '<S159>/Switch2' */

    /* PreLookup: '<S152>/speed ratio Prelookup' */
    rtb_speedratioPrelookup_o1 = plook_bincpa(rtb_Switch2, localB->phi_a, 9U,
      &rtb_uniclutch, &localDW->speedratioPrelookup_DWORK1);
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      memcpy(&localB->zeta[0], &DrivetrainHevP4_P.zeta[0], 10U * sizeof(real_T));
    }

    /* Interpolation_n-D: '<S152>/Torque Ratio zeta Interpolation' incorporates:
     *  Constant: '<S152>/zeta'
     */
    rtb_TorqueRatiozetaInterpolation = intrp1d_la_pw(rtb_speedratioPrelookup_o1,
      rtb_uniclutch, localB->zeta, 9U);

    /* RelationalOperator: '<S155>/Compare' incorporates:
     *  Constant: '<S155>/Constant'
     */
    localB->Compare = (localB->Constant_l > DrivetrainHevP4_P.Constant_Value_k);
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      /* SignalConversion generated from: '<S156>/Enable' */
      localB->HiddenBuf_InsertedFor_LPF_at_inport_2 = localB->Compare;

      /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
       *  EnablePort: '<S156>/Enable'
       */
      if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
        if (localB->HiddenBuf_InsertedFor_LPF_at_inport_2) {
          if (!localDW->LPF_MODE) {
            if (rtmGetTaskTime(DrivetrainHevP4_M, 1) != rtmGetTStart
                (DrivetrainHevP4_M)) {
              ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
            }

            localXdis->Integrator_CSTATE_e = 0;

            /* InitializeConditions for Integrator: '<S157>/Integrator' */
            localX->Integrator_CSTATE_e = DrivetrainHevP4_P.Integrator_IC;
            localDW->LPF_MODE = true;
          }
        } else {
          if (rtmGetTaskTime(DrivetrainHevP4_M, 1) == rtmGetTStart
              (DrivetrainHevP4_M)) {
            localXdis->Integrator_CSTATE_e = 1;
          }

          if (localDW->LPF_MODE) {
            ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
            localXdis->Integrator_CSTATE_e = 1;
            localDW->LPF_MODE = false;
          }
        }
      }

      /* End of Outputs for SubSystem: '<S153>/LPF' */
      memcpy(&localB->psi[0], &DrivetrainHevP4_P.psi[0], 10U * sizeof(real_T));
      localB->Constant1_m = DrivetrainHevP4_P.TorqueConverter_KType;
    }

    /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
     *  EnablePort: '<S156>/Enable'
     */
    if (localDW->LPF_MODE) {
      /* Integrator: '<S157>/Integrator' */
      localB->Integrator_k = localX->Integrator_CSTATE_e;

      /* Gain: '<S156>/Gain' */
      u0 = DrivetrainHevP4_P.Gain_Gain_d * localB->Constant_l;

      /* Saturate: '<S156>/Saturation' */
      if (u0 > DrivetrainHevP4_P.Saturation_UpperSat_b) {
        u0 = DrivetrainHevP4_P.Saturation_UpperSat_b;
      } else if (u0 < DrivetrainHevP4_P.Saturation_LowerSat_o) {
        u0 = DrivetrainHevP4_P.Saturation_LowerSat_o;
      }

      /* End of Saturate: '<S156>/Saturation' */

      /* Product: '<S157>/Product' incorporates:
       *  Product: '<S156>/Product'
       *  Sum: '<S157>/Sum'
       */
      localB->Product_f = 1.0 / u0 * (rtb_TorqueRatiozetaInterpolation -
        localB->Integrator_k);
    }

    /* End of Outputs for SubSystem: '<S153>/LPF' */

    /* Switch: '<S152>/Switch1' incorporates:
     *  Constant: '<S152>/Constant1'
     *  Constant: '<S152>/psi'
     *  Product: '<S152>/Product3'
     */
    rtb_Logic = (localB->Constant1_m > DrivetrainHevP4_P.Switch1_Threshold_f);
    for (i = 0; i < 10; i++) {
      if (rtb_Logic) {
        tmp[i] = localB->psi[i];
      } else {
        tmp[i] = 1.0 / localB->psi[i] / localB->psi[i];
      }
    }

    /* End of Switch: '<S152>/Switch1' */

    /* Product: '<S152>/Divide1' incorporates:
     *  Interpolation_n-D: '<S152>/Capacity, K-factor Interpolation'
     *  Trigonometry: '<S152>/Trigonometric Function'
     */
    rtb_uniclutch = tanh(rtb_u_tmp) * intrp1d_la_pw(rtb_speedratioPrelookup_o1,
      rtb_uniclutch, tmp, 9U) * rtb_InertiaRatio * rtb_InertiaRatio;

    /* Saturate: '<S152>/uniclutch' */
    if (rtb_uniclutch > DrivetrainHevP4_P.uniclutch_UpperSat) {
      rtb_uniclutch = DrivetrainHevP4_P.uniclutch_UpperSat;
    } else if (rtb_uniclutch < DrivetrainHevP4_P.uniclutch_LowerSat) {
      rtb_uniclutch = DrivetrainHevP4_P.uniclutch_LowerSat;
    }

    /* End of Saturate: '<S152>/uniclutch' */

    /* Product: '<S133>/Max Dynamic Friction Torque' incorporates:
     *  Trigonometry: '<S133>/Trigonometric Function'
     */
    rtb_TorqueConversion *= tanh(rtb_u);

    /* Switch: '<S153>/Switch' */
    if (localB->Constant_l > DrivetrainHevP4_P.Switch_Threshold_lw) {
      rtb_TorqueRatiozetaInterpolation = localB->Integrator_k;
    }

    /* End of Switch: '<S153>/Switch' */

    /* Sum: '<S133>/Add1' incorporates:
     *  Product: '<S152>/Divide2'
     *  Sum: '<S133>/Output Sum'
     *  UnaryMinus: '<S86>/Unary Minus'
     */
    rtb_OutputSum = ((rtb_TorqueRatiozetaInterpolation * rtb_uniclutch +
                      rtb_TorqueConversion) - rtb_OutputSum) + -rtb_Subtract1;

    /* Sum: '<S133>/Input Sum' */
    rtb_Subtract1_p = ((*rtu_EngTrq - rtb_TorqueConversion) - rtb_uniclutch) -
      rtb_Subtract1_p;

    /* Gain: '<S133>/Impeller Inertia' */
    localB->ImpellerInertia = 1.0 / DrivetrainHevP4_P.Ji * rtb_Subtract1_p;

    /* SignalConversion: '<S133>/Signal Conversion1' */
    *rty_EngSpd = rtb_InertiaRatio;

    /* Merge: '<S126>/Merge2' incorporates:
     *  SignalConversion: '<S133>/Signal Conversion2'
     */
    localB->SpdRatio = rtb_Switch2;

    /* Merge generated from: '<S126>/Merge4' incorporates:
     *  Product: '<S133>/Product2'
     *  SignalConversion generated from: '<S133>/Signal Conversion4'
     */
    localB->PwrStoredImp = rtb_Subtract1_p * rtb_InertiaRatio;

    /* Merge generated from: '<S126>/Merge4' incorporates:
     *  Product: '<S133>/Product3'
     *  SignalConversion generated from: '<S133>/Signal Conversion4'
     */
    localB->PwrStoredTurb = rtb_OutputSum * rtb_OutputDamping;

    /* Gain: '<S133>/Turbine Inertia' */
    localB->TurbineInertia = 1.0 / DrivetrainHevP4_P.Jt * rtb_OutputSum;

    /* End of Outputs for SubSystem: '<S126>/Unlocked' */
    break;
  }

  /* Product: '<S127>/Product' */
  rtb_Subtract1_p = *rtu_EngTrq * *rty_EngSpd;

  /* Product: '<S127>/Product1' incorporates:
   *  UnaryMinus: '<S86>/Unary Minus'
   */
  rtb_TorqueConversion = -rtb_Subtract1 * rtb_OutputDamping;

  /* Saturate: '<S135>/Saturation1' incorporates:
   *  UnaryMinus: '<S135>/Unary Minus'
   */
  if (rtb_Subtract1_p > DrivetrainHevP4_P.Saturation1_UpperSat_k) {
    rtb_Subtract1_p = DrivetrainHevP4_P.Saturation1_UpperSat_k;
  } else if (rtb_Subtract1_p < DrivetrainHevP4_P.Saturation1_LowerSat_h) {
    rtb_Subtract1_p = DrivetrainHevP4_P.Saturation1_LowerSat_h;
  }

  if (rtb_TorqueConversion > DrivetrainHevP4_P.Saturation1_UpperSat_k) {
    rtb_TorqueConversion = DrivetrainHevP4_P.Saturation1_UpperSat_k;
  } else if (rtb_TorqueConversion < DrivetrainHevP4_P.Saturation1_LowerSat_h) {
    rtb_TorqueConversion = DrivetrainHevP4_P.Saturation1_LowerSat_h;
  }

  if (-localB->PwrStoredImp > DrivetrainHevP4_P.Saturation1_UpperSat_k) {
    rtb_uniclutch = DrivetrainHevP4_P.Saturation1_UpperSat_k;
  } else if (-localB->PwrStoredImp < DrivetrainHevP4_P.Saturation1_LowerSat_h) {
    rtb_uniclutch = DrivetrainHevP4_P.Saturation1_LowerSat_h;
  } else {
    rtb_uniclutch = -localB->PwrStoredImp;
  }

  if (-localB->PwrStoredTurb > DrivetrainHevP4_P.Saturation1_UpperSat_k) {
    rtb_InertiaRatio = DrivetrainHevP4_P.Saturation1_UpperSat_k;
  } else if (-localB->PwrStoredTurb < DrivetrainHevP4_P.Saturation1_LowerSat_h)
  {
    rtb_InertiaRatio = DrivetrainHevP4_P.Saturation1_LowerSat_h;
  } else {
    rtb_InertiaRatio = -localB->PwrStoredTurb;
  }

  /* End of Saturate: '<S135>/Saturation1' */

  /* Sum: '<S135>/Sum of Elements1' */
  localB->SumofElements1 = ((rtb_Subtract1_p + rtb_TorqueConversion) +
    rtb_uniclutch) + rtb_InertiaRatio;

  /* Abs: '<S135>/Abs' */
  if (ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS)) {
    localDW->Abs_MODE = (localB->SumofElements1 >= 0.0);
  }

  /* End of Abs: '<S135>/Abs' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Gain: '<S149>/Hz2rad' incorporates:
     *  Constant: '<S149>/Constant1'
     *  Product: '<S149>/s2hz'
     */
    localB->Hz2rad = 1.0 / DrivetrainHevP4_P.tauC *
      DrivetrainHevP4_P.Hz2rad_Gain;
  }

  /* Relay: '<S149>/Relay1' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    localDW->Relay1_Mode = ((*rty_EngSpd >= DrivetrainHevP4_P.omegal) ||
      ((!(*rty_EngSpd <= DrivetrainHevP4_P.omegau)) && localDW->Relay1_Mode));
  }

  if (localDW->Relay1_Mode) {
    rtb_Logic = DrivetrainHevP4_P.Relay1_YOn;
  } else {
    rtb_Logic = DrivetrainHevP4_P.Relay1_YOff;
  }

  /* End of Relay: '<S149>/Relay1' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* RelationalOperator: '<S149>/Relational Operator' incorporates:
     *  Constant: '<S149>/Constant'
     */
    if (ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS)) {
      localDW->RelationalOperator_Mode = (localB->SpdRatio >=
        DrivetrainHevP4_P.philu);
    }

    /* DataTypeConversion: '<S149>/Data Type Conversion' incorporates:
     *  Logic: '<S149>/Logic'
     *  RelationalOperator: '<S149>/Relational Operator'
     */
    localB->DataTypeConversion = (rtb_Logic && localDW->RelationalOperator_Mode);
  }

  /* Switch: '<S150>/Switch' */
  if (!(localB->Memory_b != 0.0)) {
    rtb_Sum = localB->Constant2_pr;
  }

  /* End of Switch: '<S150>/Switch' */

  /* Product: '<S150>/Product' incorporates:
   *  Sum: '<S150>/Sum'
   */
  localB->Product = (localB->DataTypeConversion - rtb_Sum) * localB->Hz2rad;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S2>/Constant' */
    localB->Constant_cv = DrivetrainHevP4_P.Temp_bpts[0];

    /* Gain: '<S94>/2*pi' incorporates:
     *  Constant: '<S94>/Constant'
     *  Product: '<S94>/Product'
     */
    localB->upi = 1.0 / DrivetrainHevP4_P.tau_s * DrivetrainHevP4_P.upi_Gain;

    /* Constant: '<S94>/Constant1' */
    localB->Constant1 = DrivetrainHevP4_P.IdealFixedGearTransmission_G_o;

    /* Memory: '<S96>/Memory' */
    localB->Memory_o = localDW->Memory_PreviousInput_j;
  }

  /* Integrator: '<S96>/Integrator' */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_m,
                       (localB->Memory_o));
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_n != 0)) {
      localX->Integrator_CSTATE_h1 = localB->Constant1;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    *rty_TransGear = localX->Integrator_CSTATE_h1;
  } else {
    *rty_TransGear = localX->Integrator_CSTATE_h1;
  }

  /* End of Integrator: '<S96>/Integrator' */

  /* Switch: '<S96>/Switch' */
  if (localB->Memory_o != 0.0) {
    /* Switch: '<S96>/Switch' */
    localB->Switch_p = *rty_TransGear;
  } else {
    /* Switch: '<S96>/Switch' */
    localB->Switch_p = localB->Constant1;
  }

  /* End of Switch: '<S96>/Switch' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S97>/Constant' */
    localB->Constant_p = DrivetrainHevP4_P.omega_o;

    /* InitialCondition: '<S97>/IC' */
    if (localDW->IC_FirstOutputTime_k) {
      localDW->IC_FirstOutputTime_k = false;

      /* InitialCondition: '<S97>/IC' */
      localB->IC_f = DrivetrainHevP4_P.IC_Value_k;
    } else {
      /* InitialCondition: '<S97>/IC' incorporates:
       *  Constant: '<S97>/Constant1'
       */
      localB->IC_f = DrivetrainHevP4_P.Constant1_Value_f;
    }

    /* End of InitialCondition: '<S97>/IC' */

    /* Memory: '<S78>/Memory' */
    localB->Memory_ku = localDW->Memory_PreviousInput_h;

    /* Constant: '<S77>/domega_o' */
    localB->domega_o_j = DrivetrainHevP4_P.domega_o;
  }

  /* Switch: '<S97>/Switch' */
  if (localB->IC_f > DrivetrainHevP4_P.Switch_Threshold_il) {
    /* Switch: '<S97>/Switch' */
    localB->Switch_a = localX->we;
  } else {
    /* Switch: '<S97>/Switch' */
    localB->Switch_a = localB->Constant_p;
  }

  /* End of Switch: '<S97>/Switch' */

  /* Integrator: '<S78>/Integrator' */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_fz,
                       (localB->Memory_ku));
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_l != 0)) {
      localX->Integrator_CSTATE_j = localB->domega_o_j;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    rtb_TorqueConversion = localX->Integrator_CSTATE_j;
  } else {
    rtb_TorqueConversion = localX->Integrator_CSTATE_j;
  }

  /* End of Integrator: '<S78>/Integrator' */

  /* Sum: '<S77>/Subtract1' incorporates:
   *  Gain: '<S77>/Gain1'
   *  Gain: '<S77>/Gain2'
   *  Integrator: '<S77>/Integrator'
   */
  rtb_Subtract1_p = DrivetrainHevP4_P.b * rtb_TorqueConversion +
    DrivetrainHevP4_P.k * localX->Integrator_CSTATE_g4;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* InitialCondition: '<S101>/IC' */
    if (localDW->IC_FirstOutputTime_f) {
      localDW->IC_FirstOutputTime_f = false;

      /* InitialCondition: '<S101>/IC' */
      localB->IC_b = DrivetrainHevP4_P.IC_Value_b;
    } else {
      /* InitialCondition: '<S101>/IC' incorporates:
       *  Constant: '<S101>/Constant1'
       */
      localB->IC_b = DrivetrainHevP4_P.Constant1_Value_g;
    }

    /* End of InitialCondition: '<S101>/IC' */

    /* Constant: '<S101>/Constant' */
    localB->Constant_cg = DrivetrainHevP4_P.omega_o;

    /* InitialCondition: '<S99>/IC' */
    if (localDW->IC_FirstOutputTime_j) {
      localDW->IC_FirstOutputTime_j = false;

      /* InitialCondition: '<S99>/IC' */
      localB->IC_a = DrivetrainHevP4_P.IC_Value_bb;
    } else {
      /* InitialCondition: '<S99>/IC' incorporates:
       *  Constant: '<S99>/Constant1'
       */
      localB->IC_a = DrivetrainHevP4_P.Constant1_Value_ou;
    }

    /* End of InitialCondition: '<S99>/IC' */

    /* Constant: '<S99>/Constant' */
    localB->Constant_ml = DrivetrainHevP4_P.IdealFixedGearTransmission_omegaN_o;
  }

  /* Switch: '<S101>/Switch' */
  if (localB->IC_b > DrivetrainHevP4_P.Switch_Threshold_gl) {
    /* Switch: '<S101>/Switch' */
    localB->Switch_ht = localX->w;
  } else {
    /* Switch: '<S101>/Switch' */
    localB->Switch_ht = localB->Constant_cg;
  }

  /* End of Switch: '<S101>/Switch' */

  /* Switch: '<S99>/Switch' */
  if (localB->IC_a > DrivetrainHevP4_P.Switch_Threshold_l2) {
    /* Switch: '<S99>/Switch' */
    localB->Switch_px = localX->w;
  } else {
    /* Switch: '<S99>/Switch' */
    localB->Switch_px = localB->Constant_ml;
  }

  /* End of Switch: '<S99>/Switch' */

  /* If: '<S94>/If' incorporates:
   *  Constant: '<S100>/First'
   *  Constant: '<S100>/Neutral'
   *  Constant: '<S100>/No Input Torque'
   *  Constant: '<S109>/Constant'
   *  Constant: '<S110>/Constant'
   *  Constant: '<S114>/Constant'
   *  Constant: '<S115>/Constant'
   *  Constant: '<S118>/Constant'
   *  Constant: '<S122>/Constant'
   *  Constant: '<S123>/Constant'
   */
  rtPrevAction = localDW->If_ActiveSubsystem_b;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    rtAction = (int8_T)!(*rty_TransGear != 0.0);
    localDW->If_ActiveSubsystem_b = rtAction;
  } else {
    rtAction = localDW->If_ActiveSubsystem_b;
  }

  if (rtPrevAction != rtAction) {
    switch (rtPrevAction) {
     case 0:
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      localXdis->w = 1;
      break;

     case 1:
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      (void) memset(&(localXdis->we), 1,
                    2*sizeof(boolean_T));
      break;
    }
  }

  switch (rtAction) {
   case 0:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S94>/Locked' incorporates:
       *  ActionPort: '<S98>/Action'
       */
      /* InitializeConditions for If: '<S94>/If' incorporates:
       *  Integrator: '<S98>/x'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->w = 0.0;
      }

      localDW->x_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S94>/Locked' */

      /* Enable for IfAction SubSystem: '<S94>/Locked' incorporates:
       *  ActionPort: '<S98>/Action'
       */
      /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
       *  EnablePort: '<S156>/Enable'
       */
      /* Enable for If: '<S94>/If' */
      if (rtmGetTaskTime(DrivetrainHevP4_M, 0) != rtmGetTStart(DrivetrainHevP4_M))
      {
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }

      /* End of Outputs for SubSystem: '<S153>/LPF' */
      localXdis->w = 0;

      /* End of Enable for SubSystem: '<S94>/Locked' */
    }

    /* Outputs for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* Lookup_n-D: '<S112>/Gear2Ratios' */
    localB->N_c = look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.N, 6U);

    /* Abs: '<S98>/Abs' */
    if (ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS)) {
      localDW->Abs_MODE_g = (localB->N_c >= 0.0);
    }

    rtb_InertiaRatio = localDW->Abs_MODE_g > 0 ? localB->N_c : -localB->N_c;

    /* End of Abs: '<S98>/Abs' */

    /* Integrator: '<S98>/x' */
    rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
    if (rtb_Logic) {
      if (localDW->x_IWORK != 0) {
        localX->w = localB->Switch_a;
        ssSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->rtS);
      }

      rtb_xe = localX->w;
    } else {
      rtb_xe = localX->w;
    }

    /* End of Integrator: '<S98>/x' */

    /* Lookup_n-D: '<S117>/Eta 4D' incorporates:
     *  Constant: '<S2>/Constant'
     *  Integrator: '<S98>/x'
     *  Sum: '<S86>/Subtract1'
     */
    bpIndices[0U] = plook_binc(rtb_Subtract1, DrivetrainHevP4_P.Trq_bpts, 6U,
      &rtb_Sum);
    fractions[0U] = rtb_Sum;
    bpIndices[1U] = plook_binc(rtb_xe, DrivetrainHevP4_P.omega_bpts, 10U,
      &rtb_Sum);
    fractions[1U] = rtb_Sum;
    bpIndices[2U] = plook_binc(*rty_TransGear, DrivetrainHevP4_P.G, 6U, &rtb_Sum);
    fractions[2U] = rtb_Sum;
    bpIndices[3U] = plook_binc(localB->Constant_cv, DrivetrainHevP4_P.Temp_bpts,
      1U, &rtb_Sum);
    fractions[3U] = rtb_Sum;
    rtb_Sum = intrp4d_l_pw(bpIndices, fractions, DrivetrainHevP4_P.eta_tbl,
      DrivetrainHevP4_P.Eta4D_dimSizes);
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->Constant_ae = DrivetrainHevP4_P.Constant_Value;
    }

    /* Switch: '<S109>/Switch' incorporates:
     *  Constant: '<S109>/Constant'
     *  Product: '<S109>/Product1'
     */
    if (rtb_Subtract1 * rtb_xe > DrivetrainHevP4_P.Switch_Threshold_l) {
      rtb_u = rtb_Sum;
    } else {
      rtb_u = localB->Constant_ae;
    }

    /* End of Switch: '<S109>/Switch' */

    /* Product: '<S109>/Product4' */
    rtb_Subtract1 *= rtb_u;

    /* Product: '<S98>/Product5' incorporates:
     *  UnaryMinus: '<S77>/Unary Minus'
     */
    rtb_Switch2 = -rtb_Subtract1_p / localB->N_c;
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->Constant_cw = DrivetrainHevP4_P.Constant_Value_f;
      localB->Constant_ps = -DrivetrainHevP4_P.div0protectabspoly_thresh;
      localB->Constant_l5 = DrivetrainHevP4_P.div0protectabspoly_thresh;
    }

    /* Switch: '<S110>/Switch' incorporates:
     *  Constant: '<S110>/Constant'
     *  Constant: '<S114>/Constant'
     *  Constant: '<S115>/Constant'
     *  Product: '<S110>/Product1'
     */
    if (!(rtb_Switch2 * rtb_xe > DrivetrainHevP4_P.Switch_Threshold_a)) {
      rtb_Sum = localB->Constant_cw;
    }

    /* End of Switch: '<S110>/Switch' */

    /* Product: '<S98>/Product8' incorporates:
     *  Lookup_n-D: '<S112>/Gear2damping'
     *  Lookup_n-D: '<S112>/Gear2inertias'
     *  Product: '<S110>/Product4'
     *  Product: '<S98>/Product1'
     *  Product: '<S98>/Product3'
     *  Product: '<S98>/Product6'
     *  Sum: '<S98>/Sum'
     *  Sum: '<S98>/Sum1'
     */
    localB->Product8_e = ((rtb_Sum * rtb_Switch2 + rtb_Subtract1) - 1.0 /
                          rtb_InertiaRatio / rtb_InertiaRatio * look1_binlxpw
                          (*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.bout, 6U) * rtb_xe) * (1.0 / (look1_binlxpw
      (*rty_TransGear, DrivetrainHevP4_P.G, DrivetrainHevP4_P.Jout, 6U) /
      rtb_InertiaRatio / rtb_InertiaRatio));

    /* SignalConversion: '<S98>/Signal Conversion3' incorporates:
     *  Product: '<S98>/Product2'
     */
    rtb_Sum = rtb_xe / localB->N_c;

    /* End of Outputs for SubSystem: '<S94>/Locked' */
    break;

   case 1:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S94>/Unlocked' incorporates:
       *  ActionPort: '<S100>/Action'
       */
      /* InitializeConditions for If: '<S94>/If' incorporates:
       *  Integrator: '<S100>/xe'
       *  Integrator: '<S100>/xv'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->we = 0.0;
        localX->wv = 0.0;
      }

      localDW->xe_IWORK = 1;
      localDW->xv_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S94>/Unlocked' */

      /* Enable for IfAction SubSystem: '<S94>/Unlocked' incorporates:
       *  ActionPort: '<S100>/Action'
       */
      /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
       *  EnablePort: '<S156>/Enable'
       */
      /* Enable for If: '<S94>/If' */
      if (rtmGetTaskTime(DrivetrainHevP4_M, 0) != rtmGetTStart(DrivetrainHevP4_M))
      {
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }

      /* End of Outputs for SubSystem: '<S153>/LPF' */
      (void) memset(&(localXdis->we), 0,
                    2*sizeof(boolean_T));

      /* End of Enable for SubSystem: '<S94>/Unlocked' */
    }

    /* Outputs for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* Lookup_n-D: '<S120>/Gear2Ratios' */
    localB->N = look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.N, 6U);

    /* Abs: '<S100>/Abs' */
    if (ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS)) {
      localDW->Abs_MODE_n = (localB->N >= 0.0);
    }

    rtb_InertiaRatio = localDW->Abs_MODE_n > 0 ? localB->N : -localB->N;

    /* End of Abs: '<S100>/Abs' */

    /* Integrator: '<S100>/xe' */
    rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
    if (rtb_Logic) {
      if (localDW->xe_IWORK != 0) {
        localX->we = localB->Switch_ht;
        ssSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->rtS);
      }

      rtb_xe = localX->we;
    } else {
      rtb_xe = localX->we;
    }

    /* End of Integrator: '<S100>/xe' */
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->Neutral = DrivetrainHevP4_P.Neutral_Value;
    }

    /* Product: '<S100>/Product7' incorporates:
     *  Constant: '<S100>/Neutral'
     *  Lookup_n-D: '<S100>/Gear2damping'
     */
    rtb_Switch2 = DrivetrainHevP4_P.bout[plook_u32d_binckan(localB->Neutral,
      DrivetrainHevP4_P.G, 6U)] * rtb_xe;

    /* Product: '<S100>/Product1' incorporates:
     *  Lookup_n-D: '<S120>/Gear2damping'
     */
    rtb_OutputSum = 1.0 / rtb_InertiaRatio / rtb_InertiaRatio * look1_binlxpw
      (*rty_TransGear, DrivetrainHevP4_P.G, DrivetrainHevP4_P.bout, 6U);

    /* Integrator: '<S100>/xv' */
    rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
    if (rtb_Logic) {
      if (localDW->xv_IWORK != 0) {
        localX->wv = localB->Switch_px;
      }

      rtb_uniclutch = localX->wv;
    } else {
      rtb_uniclutch = localX->wv;
    }

    /* End of Integrator: '<S100>/xv' */
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->NoInputTorque = DrivetrainHevP4_P.NoInputTorque_Value;
    }

    /* Lookup_n-D: '<S125>/Eta 4D' incorporates:
     *  Constant: '<S100>/No Input Torque'
     *  Constant: '<S2>/Constant'
     *  Product: '<S100>/Product2'
     */
    bpIndices[0U] = plook_binc(localB->NoInputTorque, DrivetrainHevP4_P.Trq_bpts,
      6U, &rtb_Sum);
    fractions[0U] = rtb_Sum;
    bpIndices[1U] = plook_binc(rtb_uniclutch, DrivetrainHevP4_P.omega_bpts, 10U,
      &rtb_Sum);
    fractions[1U] = rtb_Sum;
    bpIndices[2U] = plook_binc(*rty_TransGear, DrivetrainHevP4_P.G, 6U, &rtb_Sum);
    fractions[2U] = rtb_Sum;
    bpIndices[3U] = plook_binc(localB->Constant_cv, DrivetrainHevP4_P.Temp_bpts,
      1U, &rtb_Sum);
    fractions[3U] = rtb_Sum;

    /* Product: '<S100>/Product5' incorporates:
     *  UnaryMinus: '<S77>/Unary Minus'
     */
    rtb_u = -rtb_Subtract1_p / localB->N;
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit
        (DrivetrainHevP4_M, 1, 0)) {
      localB->Constant_j5 = DrivetrainHevP4_P.Constant_Value_i;
      localB->First = DrivetrainHevP4_P.First_Value;
      localB->Constant_a = -DrivetrainHevP4_P.div0protectabspoly_thresh_k;
      localB->Constant_oj = DrivetrainHevP4_P.div0protectabspoly_thresh_k;
    }

    /* SignalConversion: '<S100>/Signal Conversion' incorporates:
     *  Constant: '<S100>/First'
     *  Constant: '<S118>/Constant'
     *  Constant: '<S122>/Constant'
     *  Constant: '<S123>/Constant'
     *  Product: '<S100>/Product2'
     */
    rtb_Sum = rtb_uniclutch / localB->N;

    /* Product: '<S100>/Product4' incorporates:
     *  Constant: '<S100>/First'
     *  Constant: '<S100>/Neutral'
     *  Lookup_n-D: '<S100>/Gear2inertias'
     *  Lookup_n-D: '<S100>/Gear2inertias1'
     *  Sum: '<S100>/Subtract'
     *  Sum: '<S100>/Sum1'
     */
    localB->Product4_a = 1.0 / (DrivetrainHevP4_P.Jout[plook_u32d_binckan
      (localB->First, DrivetrainHevP4_P.G, 6U)] -
      DrivetrainHevP4_P.Jout[plook_u32d_binckan(localB->Neutral,
      DrivetrainHevP4_P.G, 6U)]) * (rtb_Subtract1 - rtb_Switch2);

    /* Switch: '<S118>/Switch' incorporates:
     *  Lookup_n-D: '<S125>/Eta 4D'
     *  Product: '<S118>/Product1'
     */
    if (rtb_u * rtb_uniclutch > DrivetrainHevP4_P.Switch_Threshold_i) {
      rtb_Subtract1 = intrp4d_l_pw(bpIndices, fractions,
        DrivetrainHevP4_P.eta_tbl, DrivetrainHevP4_P.Eta4D_dimSizes_m);
    } else {
      rtb_Subtract1 = localB->Constant_j5;
    }

    /* End of Switch: '<S118>/Switch' */

    /* Product: '<S100>/Product8' incorporates:
     *  Lookup_n-D: '<S120>/Gear2inertias'
     *  Product: '<S100>/Product3'
     *  Product: '<S100>/Product6'
     *  Product: '<S118>/Product4'
     *  Sum: '<S100>/Sum'
     */
    localB->Product8 = 1.0 / (look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.Jout, 6U) / rtb_InertiaRatio / rtb_InertiaRatio) *
      (rtb_Subtract1 * rtb_u - rtb_OutputSum * rtb_uniclutch);

    /* End of Outputs for SubSystem: '<S94>/Unlocked' */
    break;
  }

  /* End of If: '<S94>/If' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S77>/omega_c' */
    localB->omega_c = DrivetrainHevP4_P.omega_c;

    /* Switch: '<S29>/Switch' incorporates:
     *  Constant: '<S29>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_d >
        DrivetrainHevP4_P.Switch_Threshold_c) {
      /* Switch: '<S29>/Switch' incorporates:
       *  Constant: '<S29>/Constant1'
       */
      localB->diffDir = DrivetrainHevP4_P.Constant1_Value_iv;
    } else {
      /* Switch: '<S29>/Switch' incorporates:
       *  Constant: '<S29>/Constant1'
       *  UnaryMinus: '<S29>/Unary Minus'
       */
      localB->diffDir = -DrivetrainHevP4_P.Constant1_Value_iv;
    }

    /* End of Switch: '<S29>/Switch' */

    /* Constant: '<S25>/Constant' */
    localB->VectorConcatenate[0] = DrivetrainHevP4_P.omegaw1o;

    /* Constant: '<S25>/Constant1' */
    localB->VectorConcatenate[1] = DrivetrainHevP4_P.omegaw2o;
  }

  /* Integrator: '<S25>/Integrator' */
  /* Limited  Integrator  */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    if (localDW->Integrator_IWORK_j != 0) {
      localX->Integrator_CSTATE_o[0] = localB->VectorConcatenate[0];
      localX->Integrator_CSTATE_o[1] = localB->VectorConcatenate[1];
    }

    if (localX->Integrator_CSTATE_o[0] >= DrivetrainHevP4_P.Integrator_UpperSat)
    {
      if (localX->Integrator_CSTATE_o[0] !=
          DrivetrainHevP4_P.Integrator_UpperSat) {
        localX->Integrator_CSTATE_o[0] = DrivetrainHevP4_P.Integrator_UpperSat;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
    } else if ((localX->Integrator_CSTATE_o[0] <=
                DrivetrainHevP4_P.Integrator_LowerSat) &&
               (localX->Integrator_CSTATE_o[0] !=
                DrivetrainHevP4_P.Integrator_LowerSat)) {
      localX->Integrator_CSTATE_o[0] = DrivetrainHevP4_P.Integrator_LowerSat;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    if (localX->Integrator_CSTATE_o[1] >= DrivetrainHevP4_P.Integrator_UpperSat)
    {
      if (localX->Integrator_CSTATE_o[1] !=
          DrivetrainHevP4_P.Integrator_UpperSat) {
        localX->Integrator_CSTATE_o[1] = DrivetrainHevP4_P.Integrator_UpperSat;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
    } else if ((localX->Integrator_CSTATE_o[1] <=
                DrivetrainHevP4_P.Integrator_LowerSat) &&
               (localX->Integrator_CSTATE_o[1] !=
                DrivetrainHevP4_P.Integrator_LowerSat)) {
      localX->Integrator_CSTATE_o[1] = DrivetrainHevP4_P.Integrator_LowerSat;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    /* Integrator: '<S25>/Integrator' */
    rtb_Integrator_g[0] = localX->Integrator_CSTATE_o[0];
    rtb_Integrator_g[1] = localX->Integrator_CSTATE_o[1];
  } else {
    if (localX->Integrator_CSTATE_o[0] >= DrivetrainHevP4_P.Integrator_UpperSat)
    {
      /* Integrator: '<S25>/Integrator' */
      rtb_Integrator_g[0] = DrivetrainHevP4_P.Integrator_UpperSat;
    } else if (localX->Integrator_CSTATE_o[0] <=
               DrivetrainHevP4_P.Integrator_LowerSat) {
      /* Integrator: '<S25>/Integrator' */
      rtb_Integrator_g[0] = DrivetrainHevP4_P.Integrator_LowerSat;
    } else {
      /* Integrator: '<S25>/Integrator' */
      rtb_Integrator_g[0] = localX->Integrator_CSTATE_o[0];
    }

    if (localX->Integrator_CSTATE_o[1] >= DrivetrainHevP4_P.Integrator_UpperSat)
    {
      /* Integrator: '<S25>/Integrator' */
      rtb_Integrator_g[1] = DrivetrainHevP4_P.Integrator_UpperSat;
    } else if (localX->Integrator_CSTATE_o[1] <=
               DrivetrainHevP4_P.Integrator_LowerSat) {
      /* Integrator: '<S25>/Integrator' */
      rtb_Integrator_g[1] = DrivetrainHevP4_P.Integrator_LowerSat;
    } else {
      /* Integrator: '<S25>/Integrator' */
      rtb_Integrator_g[1] = localX->Integrator_CSTATE_o[1];
    }
  }

  /* End of Integrator: '<S25>/Integrator' */

  /* Gain: '<S29>/Gain' */
  rtb_InertiaRatio = DrivetrainHevP4_P.Ndiff / 2.0;

  /* Sum: '<S29>/Sum of Elements' incorporates:
   *  Gain: '<S29>/Gain'
   *  Product: '<S29>/Product'
   */
  rtb_Subtract1 = localB->diffDir * rtb_Integrator_g[0] * rtb_InertiaRatio +
    localB->diffDir * rtb_Integrator_g[1] * rtb_InertiaRatio;

  /* Sum: '<S77>/Subtract' */
  localB->Subtract = rtb_Sum - rtb_Subtract1;

  /* Switch: '<S78>/Switch' */
  if (!(localB->Memory_ku != 0.0)) {
    rtb_TorqueConversion = localB->domega_o_j;
  }

  /* End of Switch: '<S78>/Switch' */

  /* Product: '<S78>/Product' incorporates:
   *  Sum: '<S78>/Sum'
   */
  localB->Product_d = (localB->Subtract - rtb_TorqueConversion) *
    localB->omega_c;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S86>/omega_c' */
    localB->omega_c_o = DrivetrainHevP4_P.omega_c;
  }

  /* Sum: '<S86>/Subtract' */
  localB->Subtract_n = rtb_OutputDamping - rtb_xe;

  /* Switch: '<S87>/Switch' */
  if (!(localB->Memory_k != 0.0)) {
    rtb_Switch = localB->domega_o_h;
  }

  /* End of Switch: '<S87>/Switch' */

  /* Product: '<S87>/Product' incorporates:
   *  Sum: '<S87>/Sum'
   */
  localB->Product_o = (localB->Subtract_n - rtb_Switch) * localB->omega_c_o;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* DataTypeConversion: '<Root>/Data Type Conversion' */
    *rty_Cltch1State = false;

    /* Constant: '<S58>/Constant' */
    localB->Constant_g = DrivetrainHevP4_P.eta_diff;

    /* Switch: '<S46>/Switch' incorporates:
     *  Constant: '<S46>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_nn >
        DrivetrainHevP4_P.Switch_Threshold_b) {
      /* Switch: '<S46>/Switch' incorporates:
       *  Constant: '<S46>/Constant1'
       */
      localB->diffDir_n = DrivetrainHevP4_P.Constant1_Value_m0;
    } else {
      /* Switch: '<S46>/Switch' incorporates:
       *  Constant: '<S46>/Constant1'
       *  UnaryMinus: '<S46>/Unary Minus'
       */
      localB->diffDir_n = -DrivetrainHevP4_P.Constant1_Value_m0;
    }

    /* End of Switch: '<S46>/Switch' */

    /* Constant: '<S42>/Constant' */
    localB->VectorConcatenate_b[0] = DrivetrainHevP4_P.omegaw1o;

    /* Constant: '<S42>/Constant1' */
    localB->VectorConcatenate_b[1] = DrivetrainHevP4_P.omegaw2o;
  }

  /* Integrator: '<S42>/Integrator' */
  /* Limited  Integrator  */
  rtb_Logic = ssGetIsOkayToUpdateMode(DrivetrainHevP4_M->rtS);
  if (rtb_Logic) {
    if (localDW->Integrator_IWORK_mn != 0) {
      localX->Integrator_CSTATE_n[0] = localB->VectorConcatenate_b[0];
      localX->Integrator_CSTATE_n[1] = localB->VectorConcatenate_b[1];
    }

    if (localX->Integrator_CSTATE_n[0] >=
        DrivetrainHevP4_P.Integrator_UpperSat_j) {
      if (localX->Integrator_CSTATE_n[0] !=
          DrivetrainHevP4_P.Integrator_UpperSat_j) {
        localX->Integrator_CSTATE_n[0] = DrivetrainHevP4_P.Integrator_UpperSat_j;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
    } else if ((localX->Integrator_CSTATE_n[0] <=
                DrivetrainHevP4_P.Integrator_LowerSat_o) &&
               (localX->Integrator_CSTATE_n[0] !=
                DrivetrainHevP4_P.Integrator_LowerSat_o)) {
      localX->Integrator_CSTATE_n[0] = DrivetrainHevP4_P.Integrator_LowerSat_o;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    if (localX->Integrator_CSTATE_n[1] >=
        DrivetrainHevP4_P.Integrator_UpperSat_j) {
      if (localX->Integrator_CSTATE_n[1] !=
          DrivetrainHevP4_P.Integrator_UpperSat_j) {
        localX->Integrator_CSTATE_n[1] = DrivetrainHevP4_P.Integrator_UpperSat_j;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
    } else if ((localX->Integrator_CSTATE_n[1] <=
                DrivetrainHevP4_P.Integrator_LowerSat_o) &&
               (localX->Integrator_CSTATE_n[1] !=
                DrivetrainHevP4_P.Integrator_LowerSat_o)) {
      localX->Integrator_CSTATE_n[1] = DrivetrainHevP4_P.Integrator_LowerSat_o;
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
    }

    /* Integrator: '<S42>/Integrator' */
    localB->Integrator_p[0] = localX->Integrator_CSTATE_n[0];
    localB->Integrator_p[1] = localX->Integrator_CSTATE_n[1];
  } else {
    if (localX->Integrator_CSTATE_n[0] >=
        DrivetrainHevP4_P.Integrator_UpperSat_j) {
      /* Integrator: '<S42>/Integrator' */
      localB->Integrator_p[0] = DrivetrainHevP4_P.Integrator_UpperSat_j;
    } else if (localX->Integrator_CSTATE_n[0] <=
               DrivetrainHevP4_P.Integrator_LowerSat_o) {
      /* Integrator: '<S42>/Integrator' */
      localB->Integrator_p[0] = DrivetrainHevP4_P.Integrator_LowerSat_o;
    } else {
      /* Integrator: '<S42>/Integrator' */
      localB->Integrator_p[0] = localX->Integrator_CSTATE_n[0];
    }

    if (localX->Integrator_CSTATE_n[1] >=
        DrivetrainHevP4_P.Integrator_UpperSat_j) {
      /* Integrator: '<S42>/Integrator' */
      localB->Integrator_p[1] = DrivetrainHevP4_P.Integrator_UpperSat_j;
    } else if (localX->Integrator_CSTATE_n[1] <=
               DrivetrainHevP4_P.Integrator_LowerSat_o) {
      /* Integrator: '<S42>/Integrator' */
      localB->Integrator_p[1] = DrivetrainHevP4_P.Integrator_LowerSat_o;
    } else {
      /* Integrator: '<S42>/Integrator' */
      localB->Integrator_p[1] = localX->Integrator_CSTATE_n[1];
    }
  }

  /* End of Integrator: '<S42>/Integrator' */

  /* Gain: '<S46>/Gain' */
  rtb_InertiaRatio = DrivetrainHevP4_P.Ndiff_P4 / 2.0;

  /* UnaryMinus: '<S46>/Unary Minus1' */
  localB->UnaryMinus1[0] = -localB->Integrator_p[0];
  localB->UnaryMinus1[1] = -localB->Integrator_p[1];

  /* Sum: '<S46>/Sum of Elements' incorporates:
   *  Gain: '<S46>/Gain'
   *  Product: '<S46>/Product'
   */
  *rty_MotSpd = localB->diffDir_n * localB->Integrator_p[0] * rtb_InertiaRatio +
    localB->diffDir_n * localB->Integrator_p[1] * rtb_InertiaRatio;

  /* SignalConversion generated from: '<S46>/Vector Concatenate' */
  localB->VectorConcatenate_o[0] = *rty_MotSpd;

  /* SignalConversion generated from: '<S46>/Vector Concatenate' */
  localB->VectorConcatenate_o[1] = localB->UnaryMinus1[0];

  /* SignalConversion generated from: '<S46>/Vector Concatenate' */
  localB->VectorConcatenate_o[2] = localB->UnaryMinus1[1];

  /* Sum: '<S46>/Add' incorporates:
   *  Gain: '<S46>/Gain1'
   */
  localB->VectorConcatenate_o[3] = DrivetrainHevP4_P.Gain1_Gain_f *
    localB->Integrator_p[0] - DrivetrainHevP4_P.Gain1_Gain_f *
    localB->Integrator_p[1];
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S56>/Constant' */
    localB->Constant_pg = DrivetrainHevP4_P.Constant_Value_e;

    /* Constant: '<S54>/Constant' */
    localB->Constant_cc = DrivetrainHevP4_P.Constant_Value_j;
  }

  /* Switch: '<S54>/Switch' incorporates:
   *  Product: '<S54>/Product1'
   *  UnaryMinus: '<S60>/Unary Minus'
   */
  if (-rtb_UnaryMinus1_p * localB->VectorConcatenate_o[1] >
      DrivetrainHevP4_P.Switch_Threshold_bp) {
    rtb_xe = localB->Constant_g;
  } else {
    rtb_xe = localB->Constant_cc;
  }

  /* End of Switch: '<S54>/Switch' */

  /* Product: '<S54>/Product4' incorporates:
   *  UnaryMinus: '<S60>/Unary Minus'
   */
  localB->Product4 = rtb_xe * -rtb_UnaryMinus1_p;

  /* UnaryMinus: '<S60>/Unary Minus1' */
  rtb_UnaryMinus1_p = -rtb_UnaryMinus1_p;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S55>/Constant' */
    localB->Constant_j = DrivetrainHevP4_P.Constant_Value_jy;
  }

  /* Switch: '<S55>/Switch' incorporates:
   *  Product: '<S55>/Product1'
   */
  if (rtb_UnaryMinus1_p * localB->VectorConcatenate_o[2] >
      DrivetrainHevP4_P.Switch_Threshold_au) {
    rtb_xe = localB->Constant_g;
  } else {
    rtb_xe = localB->Constant_j;
  }

  /* End of Switch: '<S55>/Switch' */

  /* Product: '<S55>/Product4' */
  localB->Product4_o = rtb_xe * rtb_UnaryMinus1_p;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S42>/bw1' */
    localB->bw1 = DrivetrainHevP4_P.bw1;

    /* Constant: '<S42>/bd' */
    localB->bd = DrivetrainHevP4_P.bd;

    /* Constant: '<S42>/bw2' */
    localB->bw2 = DrivetrainHevP4_P.bw2;

    /* Constant: '<S42>/Ndiff2' */
    localB->Ndiff2 = DrivetrainHevP4_P.Ndiff_P4;

    /* Constant: '<S42>/Jd' */
    localB->Jd = DrivetrainHevP4_P.Jd;

    /* Constant: '<S42>/Jw1' */
    localB->Jw1 = DrivetrainHevP4_P.Jw1;

    /* Constant: '<S42>/Jw3' */
    localB->Jw3 = DrivetrainHevP4_P.Jw2;

    /* Switch: '<S49>/Switch1' incorporates:
     *  Constant: '<S49>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_o >
        DrivetrainHevP4_P.Switch1_Threshold_b) {
      /* Switch: '<S49>/Switch1' incorporates:
       *  Constant: '<S49>/Constant6'
       */
      localB->diffDir_g = DrivetrainHevP4_P.Constant6_Value_f;
    } else {
      /* Switch: '<S49>/Switch1' incorporates:
       *  Constant: '<S49>/Constant6'
       *  UnaryMinus: '<S49>/Unary Minus'
       */
      localB->diffDir_g = -DrivetrainHevP4_P.Constant6_Value_f;
    }

    /* End of Switch: '<S49>/Switch1' */

    /* Constant: '<S13>/omega_c' */
    localB->omega_c_l = DrivetrainHevP4_P.omega_c;
  }

  /* UnaryMinus: '<S29>/Unary Minus1' */
  localB->UnaryMinus1_l[0] = -rtb_Integrator_g[0];
  localB->UnaryMinus1_l[1] = -rtb_Integrator_g[1];

  /* Switch: '<S14>/Switch' */
  if (localB->Memory != 0.0) {
    /* Switch: '<S14>/Switch' */
    localB->Switch_n = rtb_Integrator_o;
  } else {
    /* Switch: '<S14>/Switch' */
    localB->Switch_n = localB->domega_o;
  }

  /* End of Switch: '<S14>/Switch' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S41>/Constant' */
    localB->Constant_o = DrivetrainHevP4_P.eta_diff;

    /* Constant: '<S39>/Constant' */
    localB->Constant_dy = DrivetrainHevP4_P.Constant_Value_cg;
  }

  /* Product: '<S39>/Product1' incorporates:
   *  SignalConversion generated from: '<S29>/Vector Concatenate'
   */
  rtb_Subtract1 *= rtb_Subtract1_p;

  /* Switch: '<S39>/Switch' */
  if (rtb_Subtract1 > DrivetrainHevP4_P.Switch_Threshold_j) {
    rtb_Subtract1 = localB->Constant_o;
  } else {
    rtb_Subtract1 = localB->Constant_dy;
  }

  /* End of Switch: '<S39>/Switch' */

  /* Product: '<S39>/Product4' */
  rtb_Product4 = rtb_Subtract1 * rtb_Subtract1_p;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S37>/Constant' */
    localB->Constant_b = DrivetrainHevP4_P.Constant_Value_h;
  }

  /* Switch: '<S37>/Switch' incorporates:
   *  Product: '<S37>/Product1'
   *  SignalConversion generated from: '<S29>/Vector Concatenate'
   *  UnaryMinus: '<S13>/Unary Minus'
   */
  if (-rtb_UnaryMinus1 * localB->UnaryMinus1_l[0] >
      DrivetrainHevP4_P.Switch_Threshold_kx) {
    rtb_xe = localB->Constant_o;
  } else {
    rtb_xe = localB->Constant_b;
  }

  /* End of Switch: '<S37>/Switch' */

  /* Product: '<S37>/Product4' incorporates:
   *  UnaryMinus: '<S13>/Unary Minus'
   */
  rtb_Product4_p = rtb_xe * -rtb_UnaryMinus1;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S38>/Constant' */
    localB->Constant_cx = DrivetrainHevP4_P.Constant_Value_kx;
  }

  /* Switch: '<S38>/Switch' incorporates:
   *  Product: '<S38>/Product1'
   *  SignalConversion generated from: '<S29>/Vector Concatenate'
   *  UnaryMinus: '<S13>/Unary Minus'
   */
  if (-rtb_UnaryMinus1 * localB->UnaryMinus1_l[1] >
      DrivetrainHevP4_P.Switch_Threshold_mt) {
    rtb_Integrator_o = localB->Constant_o;
  } else {
    rtb_Integrator_o = localB->Constant_cx;
  }

  /* End of Switch: '<S38>/Switch' */

  /* Product: '<S38>/Product4' incorporates:
   *  UnaryMinus: '<S13>/Unary Minus'
   */
  rtb_Product4_o = rtb_Integrator_o * -rtb_UnaryMinus1;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Constant: '<S25>/bw1' */
    localB->bw1_j = DrivetrainHevP4_P.bw1;

    /* Constant: '<S25>/bd' */
    localB->bd_o = DrivetrainHevP4_P.bd;

    /* Constant: '<S25>/bw2' */
    localB->bw2_b = DrivetrainHevP4_P.bw2;

    /* Constant: '<S25>/Ndiff2' */
    localB->Ndiff2_c = DrivetrainHevP4_P.Ndiff;

    /* Constant: '<S25>/Jd' */
    localB->Jd_m = DrivetrainHevP4_P.Jd;

    /* Constant: '<S25>/Jw1' */
    localB->Jw1_n = DrivetrainHevP4_P.Jw1;

    /* Constant: '<S25>/Jw3' */
    localB->Jw3_h = DrivetrainHevP4_P.Jw2;
  }

  /* MATLAB Function: '<S25>/Open Differential' */
  DrivetrainHevP4_OpenDifferential(rtb_Product4, rtb_Product4_p, rtb_Product4_o,
    localB->bw1_j, localB->bd_o, localB->bw2_b, localB->Ndiff2_c, localB->Jd_m,
    localB->Jw1_n, localB->Jw3_h, rtb_Integrator_g, &localB->sf_OpenDifferential,
    &DrivetrainHevP4_P.sf_OpenDifferential);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Switch: '<S32>/Switch1' incorporates:
     *  Constant: '<S32>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_jq >
        DrivetrainHevP4_P.Switch1_Threshold_n) {
      /* Switch: '<S32>/Switch1' incorporates:
       *  Constant: '<S32>/Constant6'
       */
      localB->diffDir_o = DrivetrainHevP4_P.Constant6_Value_fv;
    } else {
      /* Switch: '<S32>/Switch1' incorporates:
       *  Constant: '<S32>/Constant6'
       *  UnaryMinus: '<S32>/Unary Minus'
       */
      localB->diffDir_o = -DrivetrainHevP4_P.Constant6_Value_fv;
    }

    /* End of Switch: '<S32>/Switch1' */

    /* Constant: '<S60>/omega_c' */
    localB->omega_c_n = DrivetrainHevP4_P.omega_c;

    /* Constant: '<S230>/Constant2' */
    localB->Constant2_f = DrivetrainHevP4_P.Lrel;

    /* Constant: '<S248>/Constant' */
    localB->Constant_h = -DrivetrainHevP4_P.VXLOW;

    /* Constant: '<S249>/Constant' */
    localB->Constant_hu = DrivetrainHevP4_P.VXLOW;

    /* Constant: '<S272>/Constant2' */
    localB->Constant2_m = DrivetrainHevP4_P.Lrel;

    /* Constant: '<S290>/Constant' incorporates:
     *  Constant: '<S248>/Constant'
     */
    localB->Constant_pk = -DrivetrainHevP4_P.VXLOW;

    /* Constant: '<S291>/Constant' */
    localB->Constant_jn = DrivetrainHevP4_P.VXLOW;
  }

  /* Switch: '<S61>/Switch' */
  if (localB->Memory_f != 0.0) {
    /* Switch: '<S61>/Switch' */
    localB->Switch_c = rtb_Integrator_l;
  } else {
    /* Switch: '<S61>/Switch' */
    localB->Switch_c = localB->domega_o_m;
  }

  /* End of Switch: '<S61>/Switch' */
}

/* Update for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Update(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  const real_T *rtu_MotTrq, const real_T *rtu_Grade, const real_T *rtu_WindVel,
  const real_T *rtu_BrkCmd, const real_T *rtu_GearCmd, boolean_T
  *rty_Cltch2State, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, X_DrivetrainHevP4_n_T *localX, XDis_DrivetrainHevP4_n_T *localXdis)
{
  /* local block i/o variables */
  real_T rtb_Product4_d;
  real_T VectorConcatenate4_tmp;
  real_T VectorConcatenate_m_tmp;
  int32_T i;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[0].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[0].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[0].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[0].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[0].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[0].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[1].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[1].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[1].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[1].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[1].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[1].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[2].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[2].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[2].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[2].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[2].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[2].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[3].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[3].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[3].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[3].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[3].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[3].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[4].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[4].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[4].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[4].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[4].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[4].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[5].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[5].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[5].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[5].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[5].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[5].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[6].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[6].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[6].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[6].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[6].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[6].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[7].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[7].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[7].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[7].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[7].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[7].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[8].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[8].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[8].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[8].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[8].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[8].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[9].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[9].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[9].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[9].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[9].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[9].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[10].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[10].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[10].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[10].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[10].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[10].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[11].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[11].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[11].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[11].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[11].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[11].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[12].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[12].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[12].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[12].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[12].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[12].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[13].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[13].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[13].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[13].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[13].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[13].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[14].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[14].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[14].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[14].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[14].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[14].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[15].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[15].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[15].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[15].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[15].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[15].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[16].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[16].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[16].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[16].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[16].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[16].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[17].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[17].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[17].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[17].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[17].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[17].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[18].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[18].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[18].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[18].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[18].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[18].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[19].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[19].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[19].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[19].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[19].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[19].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[20].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[20].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[20].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[20].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[20].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[20].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }

    if (memcmp(DrivetrainHevP4_M->nonContDerivSignal[21].pCurrVal,
               DrivetrainHevP4_M->nonContDerivSignal[21].pPrevVal,
               DrivetrainHevP4_M->nonContDerivSignal[21].sizeInBytes) != 0) {
      (void) memcpy(DrivetrainHevP4_M->nonContDerivSignal[21].pPrevVal,
                    DrivetrainHevP4_M->nonContDerivSignal[21].pCurrVal,
                    DrivetrainHevP4_M->nonContDerivSignal[21].sizeInBytes);
      ssSetSolverNeedsReset(DrivetrainHevP4_M->rtS);
    }
  }

  /* Gain: '<S5>/Gain' */
  localB->Gain_c = DrivetrainHevP4_P.Gain_Gain * *rtu_BrkCmd;

  /* Product: '<S232>/product' */
  localB->product = localB->Gain_c * localB->TorqueConversion1 *
    localB->Diskbrakeactuatorbore * localB->Numberofbrakepads;

  /* Saturate: '<S232>/Disallow Negative Brake Torque' */
  if (localB->product > DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat)
  {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat;
  } else if (localB->product <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat) {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat;
  } else {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque = localB->product;
  }

  /* End of Saturate: '<S232>/Disallow Negative Brake Torque' */

  /* Gain: '<S232>/Torque Conversion' */
  localB->TorqueConversion = DrivetrainHevP4_P.Rm * DrivetrainHevP4_P.mu_kinetic
    * localB->DisallowNegativeBrakeTorque;

  /* Gain: '<S229>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion;

  /* Outputs for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention,
    localB->Ratioofstatictokinetic, localB->TorqueConversion,
    &localB->ImpAsg_InsertedFor_Omega_at_inport_0_i, &localB->Clutch,
    &localDW->Clutch, &DrivetrainHevP4_P.Clutch, &localX->Clutch);

  /* End of Outputs for SubSystem: '<S217>/Clutch' */

  /* MATLAB Function: '<S213>/Simple Magic Tire' */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation, localB->Integrator1,
    localB->ImpAsg_InsertedFor_Omega_at_inport_0_i, localB->VectorConcatenate2[0],
    localB->D, localB->C, localB->B, localB->E, localB->lam_muxConstant,
    localB->Constant2, localB->kappaFx, localB->FzFx, localB->FxMap,
    localB->TirePrsConstant, localB->FNOMIN, localB->NOMPRES, localB->QSY1,
    localB->QSY2, localB->QSY3, localB->QSY4, localB->QSY5, localB->QSY6,
    localB->QSY7, localB->QSY8, localB->gamma, localB->lam_My,
    localB->UNLOADED_RADIUS, localB->PRESMIN, localB->PRESMAX, localB->VxMy,
    localB->FzMy, localB->MyMap, 0.0, localB->FxType, localB->rollType,
    localB->vertType, &localB->sf_SimpleMagicTire);

  /* Sum: '<S5>/Add' */
  localB->Fx = localB->sf_SimpleMagicTire.Fx + localB->sf_SimpleMagicTire.Fx;

  /* SignalConversion generated from: '<S169>/Vector Concatenate2' */
  localB->VectorConcatenate4[0] = localB->Fx;

  /* Gain: '<S5>/Gain1' */
  localB->Gain1 = DrivetrainHevP4_P.Gain1_Gain * *rtu_BrkCmd;

  /* Product: '<S274>/product' */
  localB->product_p = localB->Gain1 * localB->TorqueConversion1_b *
    localB->Diskbrakeactuatorbore_j * localB->Numberofbrakepads_f;

  /* Saturate: '<S274>/Disallow Negative Brake Torque' */
  if (localB->product_p >
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o) {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o;
  } else if (localB->product_p <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o) {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o;
  } else {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m = localB->product_p;
  }

  /* End of Saturate: '<S274>/Disallow Negative Brake Torque' */

  /* Gain: '<S274>/Torque Conversion' */
  localB->TorqueConversion_b = DrivetrainHevP4_P.Rm *
    DrivetrainHevP4_P.mu_kinetic * localB->DisallowNegativeBrakeTorque_m;

  /* Gain: '<S271>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic_i = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion_b;

  /* Outputs for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention_o,
    localB->Ratioofstatictokinetic_i, localB->TorqueConversion_b,
    &localB->ImpAsg_InsertedFor_Omega_at_inport_0, &localB->Clutch_e,
    &localDW->Clutch_e, &DrivetrainHevP4_P.Clutch_e, &localX->Clutch_e);

  /* End of Outputs for SubSystem: '<S259>/Clutch' */

  /* MATLAB Function: '<S255>/Simple Magic Tire' */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation_f, localB->Integrator1_d,
    localB->ImpAsg_InsertedFor_Omega_at_inport_0, localB->VectorConcatenate2[0],
    localB->D_c, localB->C_g, localB->B_d, localB->E_a,
    localB->lam_muxConstant_h, localB->Constant2_p, localB->kappaFx_j,
    localB->FzFx_l, localB->FxMap_h, localB->TirePrsConstant_a, localB->FNOMIN_m,
    localB->NOMPRES_h, localB->QSY1_k, localB->QSY2_g, localB->QSY3_h,
    localB->QSY4_k, localB->QSY5_p, localB->QSY6_i, localB->QSY7_j,
    localB->QSY8_d, localB->gamma_e, localB->lam_My_a, localB->UNLOADED_RADIUS_k,
    localB->PRESMIN_g, localB->PRESMAX_c, localB->VxMy_k, localB->FzMy_g,
    localB->MyMap_d, 0.0, localB->FxType_b, localB->rollType_m,
    localB->vertType_o, &localB->sf_SimpleMagicTire_c);

  /* Sum: '<S5>/Add1' */
  localB->Fx_o = localB->sf_SimpleMagicTire_c.Fx +
    localB->sf_SimpleMagicTire_c.Fx;

  /* SignalConversion generated from: '<S169>/Vector Concatenate2' */
  localB->VectorConcatenate4[1] = localB->Fx_o;

  /* SignalConversion generated from: '<S207>/Vector Concatenate5' */
  localB->VectorConcatenate5_e[0] = *rtu_WindVel;

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[0] = -localB->VectorConcatenate5_e[0];

  /* Sum: '<S206>/Add1' */
  localB->Add1[0] = localB->VectorConcatenate5[0] - localB->UnaryMinus[0];

  /* Product: '<S206>/Product' */
  localB->Product_g[0] = localB->Add1[0] * localB->Add1[0];

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[1] = -localB->VectorConcatenate5_e[1];

  /* Sum: '<S206>/Add1' */
  localB->Add1[1] = localB->VectorConcatenate5[1] - localB->UnaryMinus[1];

  /* Product: '<S206>/Product' */
  localB->Product_g[1] = localB->Add1[1] * localB->Add1[1];

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[2] = -localB->VectorConcatenate5_e[2];

  /* Sum: '<S206>/Add1' */
  localB->Add1[2] = localB->VectorConcatenate5[2] - localB->UnaryMinus[2];

  /* Product: '<S206>/Product' */
  localB->Product_g[2] = localB->Add1[2] * localB->Add1[2];

  /* Sum: '<S206>/Sum of Elements' */
  localB->SumofElements = (localB->Product_g[0] + localB->Product_g[1]) +
    localB->Product_g[2];

  /* Sqrt: '<S206>/Sqrt' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    if (localDW->Sqrt_DWORK1 != 0) {
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      localDW->Sqrt_DWORK1 = 0;
    }

    /* Sqrt: '<S206>/Sqrt' */
    localB->Sqrt = sqrt(localB->SumofElements);
  } else {
    if (localB->SumofElements < 0.0) {
      /* Sqrt: '<S206>/Sqrt' */
      localB->Sqrt = -sqrt(fabs(localB->SumofElements));
    } else {
      /* Sqrt: '<S206>/Sqrt' */
      localB->Sqrt = sqrt(localB->SumofElements);
    }

    if (localB->SumofElements < 0.0) {
      localDW->Sqrt_DWORK1 = 1;
    }
  }

  /* End of Sqrt: '<S206>/Sqrt' */

  /* Product: '<S206>/Product2' */
  localB->Product2 = localB->Sqrt * localB->Sqrt;

  /* Trigonometry: '<S206>/Trigonometric Function' */
  localB->TrigonometricFunction = rt_atan2d_snf(localB->Add1[1], localB->Add1[0]);

  /* Lookup_n-D: '<S206>/Cs' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[1] = look1_binlcpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cs, 1U);

  /* Lookup_n-D: '<S206>/Crm' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[3] = look1_binlxpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.Crm_bp01Data, DrivetrainHevP4_P.Crm_tableData, 1U);

  /* Gain: '<S206>/4' */
  localB->u[0] = DrivetrainHevP4_P.u_Gain[0] * localB->Add1[0];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[0] = tanh(localB->u[0]);

  /* Gain: '<S206>/4' */
  localB->u[1] = DrivetrainHevP4_P.u_Gain[1] * localB->Add1[1];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[1] = tanh(localB->u[1]);

  /* Gain: '<S206>/4' */
  localB->u[2] = DrivetrainHevP4_P.u_Gain[2] * localB->Add1[2];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[2] = tanh(localB->u[2]);

  /* Product: '<S206>/Product5' */
  localB->VectorConcatenate_n[4] = localB->Tanh[0] * localB->Constant2_n;

  /* Lookup_n-D: '<S206>/Cym' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[5] = look1_binlxpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cym, 1U);

  /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' */
  VectorConcatenate4_tmp = 0.5 * DrivetrainHevP4_P.Af * DrivetrainHevP4_P.Pabs /
    DrivetrainHevP4_P.DragForce_R;
  for (i = 0; i < 6; i++) {
    /* Product: '<S206>/Product1' */
    localB->Product1[i] = localB->Product2 * localB->VectorConcatenate_n[i] /
      localB->AirTempConstant;

    /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' */
    localB->uAPabsRT[i] = VectorConcatenate4_tmp * localB->Product1[i];
  }

  /* UnitConversion: '<S166>/Unit Conversion' */
  /* Unit Conversion - from: deg to: rad
     Expression: output = (0.0174533*input) + (0) */
  localB->UnitConversion = 0.017453292519943295 * *rtu_Grade;

  /* Trigonometry: '<S169>/Trigonometric Function2' */
  localB->TrigonometricFunction2_o1 = sin(localB->UnitConversion);

  /* Trigonometry: '<S169>/Trigonometric Function2' */
  localB->TrigonometricFunction2_o2 = cos(localB->UnitConversion);

  /* Product: '<S169>/Product2' */
  localB->Product2_a = localB->TrigonometricFunction2_o2 * localB->Fz;

  /* Product: '<S206>/Product4' */
  localB->Product4_k[0] = localB->uAPabsRT[3] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[0] = localB->Tanh[0] * localB->uAPabsRT[0];

  /* Product: '<S206>/Product4' */
  localB->Product4_k[1] = localB->uAPabsRT[4] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[1] = localB->Tanh[1] * localB->uAPabsRT[1];

  /* Product: '<S206>/Product4' */
  localB->Product4_k[2] = localB->uAPabsRT[5] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[2] = localB->Tanh[2] * localB->uAPabsRT[2];

  /* Sum: '<S169>/Add6' */
  localB->Add6 = localB->Product4_k[1] + localB->MExtConstant[1];

  /* Sum: '<S169>/Add1' */
  localB->Add1_p = (localB->Product2_a + localB->FExtConstant[2]) +
    localB->Product3[2];

  /* Gain: '<S169>/b' */
  localB->b = DrivetrainHevP4_P.b_CG * localB->Add1_p;

  /* Product: '<S169>/Product1' */
  localB->Product1_l = localB->TrigonometricFunction2_o1 * localB->Fz;

  /* Sum: '<S169>/Add' */
  localB->Add = (((localB->FExtConstant[0] - localB->Product1_l) + localB->Fx) +
                 localB->Fx_o) - localB->Product3[0];

  /* Sum: '<S169>/Add3' */
  localB->Add3 = ((localB->Product3[0] - localB->FExtConstant[0]) +
                  localB->Product1_l) + localB->Add;

  /* Gain: '<S169>/h' */
  localB->h = DrivetrainHevP4_P.h * localB->Add3;

  /* Sum: '<S169>/Add2' */
  localB->Add2 = (localB->b - localB->Add6) - localB->h;

  /* Gain: '<S169>/1//(a+b)' incorporates:
   *  Gain: '<S169>/1//(a+b) '
   */
  VectorConcatenate4_tmp = 1.0 / (DrivetrainHevP4_P.a_CG +
    DrivetrainHevP4_P.b_CG);
  localB->VectorConcatenate4[2] = VectorConcatenate4_tmp * localB->Add2;

  /* Gain: '<S169>/a' */
  localB->a = DrivetrainHevP4_P.a_CG * localB->Add1_p;

  /* Sum: '<S169>/Add4' */
  localB->Add4 = (localB->Add6 + localB->a) + localB->h;

  /* Gain: '<S169>/1//(a+b) ' */
  localB->VectorConcatenate4[3] = VectorConcatenate4_tmp * localB->Add4;

  /* Selector: '<S178>/Selector1' incorporates:
   *  Concatenate: '<S169>/Vector Concatenate4'
   */
  localB->Selector1[0] = localB->VectorConcatenate4[2];
  localB->Selector1[1] = localB->VectorConcatenate4[3];

  /* Gain: '<S178>/1//NR' */
  localB->Fz_a = 1.0 / DrivetrainHevP4_P.NR * localB->Selector1[1];

  /* Sum: '<S163>/Sum' */
  localB->Sum_c = localB->Fz_a - localB->Integrator1_d;

  /* Product: '<S163>/Divide' */
  localB->Divide = localB->Sum_c * localB->Constant;

  /* Gain: '<S178>/1//NF' */
  localB->Fz_f = 1.0 / DrivetrainHevP4_P.NF * localB->Selector1[0];

  /* Sum: '<S164>/Sum' */
  localB->Sum_l = localB->Fz_f - localB->Integrator1;

  /* Product: '<S164>/Divide' */
  localB->Divide_l = localB->Sum_l * localB->Constant_f;

  /* Sum: '<S174>/Add' */
  localB->Add_m = localB->UnitConversion;

  /* SignalConversion generated from: '<S197>/sincos' */
  localB->TmpSignalConversionAtsincosInport1[0] = localB->Constant_m;
  localB->TmpSignalConversionAtsincosInport1[1] = localB->Add_m;
  localB->TmpSignalConversionAtsincosInport1[2] = localB->Constant_m;

  /* Trigonometry: '<S197>/sincos' */
  localB->sincos_o1[0] = sin(localB->TmpSignalConversionAtsincosInport1[0]);
  localB->sincos_o2[0] = cos(localB->TmpSignalConversionAtsincosInport1[0]);
  localB->sincos_o1[1] = sin(localB->TmpSignalConversionAtsincosInport1[1]);
  localB->sincos_o2[1] = cos(localB->TmpSignalConversionAtsincosInport1[1]);
  localB->sincos_o1[2] = sin(localB->TmpSignalConversionAtsincosInport1[2]);
  localB->sincos_o2[2] = cos(localB->TmpSignalConversionAtsincosInport1[2]);

  /* Fcn: '<S197>/Fcn11' */
  localB->VectorConcatenate_m[0] = localB->sincos_o2[0] * localB->sincos_o2[1];

  /* Fcn: '<S197>/Fcn21' incorporates:
   *  Fcn: '<S197>/Fcn22'
   */
  VectorConcatenate4_tmp = localB->sincos_o1[1] * localB->sincos_o1[2];
  localB->VectorConcatenate_m[1] = VectorConcatenate4_tmp * localB->sincos_o2[0]
    - localB->sincos_o1[0] * localB->sincos_o2[2];

  /* Fcn: '<S197>/Fcn31' incorporates:
   *  Fcn: '<S197>/Fcn32'
   */
  VectorConcatenate_m_tmp = localB->sincos_o1[1] * localB->sincos_o2[2];
  localB->VectorConcatenate_m[2] = VectorConcatenate_m_tmp * localB->sincos_o2[0]
    + localB->sincos_o1[0] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn12' */
  localB->VectorConcatenate_m[3] = localB->sincos_o1[0] * localB->sincos_o2[1];

  /* Fcn: '<S197>/Fcn22' */
  localB->VectorConcatenate_m[4] = VectorConcatenate4_tmp * localB->sincos_o1[0]
    + localB->sincos_o2[0] * localB->sincos_o2[2];

  /* Fcn: '<S197>/Fcn32' */
  localB->VectorConcatenate_m[5] = VectorConcatenate_m_tmp * localB->sincos_o1[0]
    - localB->sincos_o2[0] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn13' */
  localB->VectorConcatenate_m[6] = -localB->sincos_o1[1];

  /* Fcn: '<S197>/Fcn23' */
  localB->VectorConcatenate_m[7] = localB->sincos_o2[1] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn33' */
  localB->VectorConcatenate_m[8] = localB->sincos_o2[1] * localB->sincos_o2[2];

  /* SignalConversion generated from: '<S166>/Vector Concatenate1' */
  localB->VectorConcatenate1[0] = localB->Add;

  /* SignalConversion generated from: '<S166>/Vector Concatenate4' */
  localB->VectorConcatenate4_l[0] = localB->Fx;

  /* SignalConversion generated from: '<S166>/Vector Concatenate4' */
  localB->VectorConcatenate4_l[1] = localB->Fx_o;

  /* SignalConversion generated from: '<S204>/sincos' */
  localB->TmpSignalConversionAtsincosInport1_n[0] = localB->Constant_c;
  localB->TmpSignalConversionAtsincosInport1_n[1] = localB->UnitConversion;
  localB->TmpSignalConversionAtsincosInport1_n[2] = localB->Constant_c;

  /* Trigonometry: '<S204>/sincos' */
  localB->sincos_o1_j[0] = sin(localB->TmpSignalConversionAtsincosInport1_n[0]);
  localB->sincos_o2_l[0] = cos(localB->TmpSignalConversionAtsincosInport1_n[0]);
  localB->sincos_o1_j[1] = sin(localB->TmpSignalConversionAtsincosInport1_n[1]);
  localB->sincos_o2_l[1] = cos(localB->TmpSignalConversionAtsincosInport1_n[1]);
  localB->sincos_o1_j[2] = sin(localB->TmpSignalConversionAtsincosInport1_n[2]);
  localB->sincos_o2_l[2] = cos(localB->TmpSignalConversionAtsincosInport1_n[2]);

  /* Fcn: '<S204>/Fcn11' */
  localB->VectorConcatenate_l[0] = localB->sincos_o2_l[0] * localB->sincos_o2_l
    [1];

  /* Fcn: '<S204>/Fcn21' incorporates:
   *  Fcn: '<S204>/Fcn22'
   */
  VectorConcatenate4_tmp = localB->sincos_o1_j[1] * localB->sincos_o1_j[2];
  localB->VectorConcatenate_l[1] = VectorConcatenate4_tmp * localB->sincos_o2_l
    [0] - localB->sincos_o1_j[0] * localB->sincos_o2_l[2];

  /* Fcn: '<S204>/Fcn31' incorporates:
   *  Fcn: '<S204>/Fcn32'
   */
  VectorConcatenate_m_tmp = localB->sincos_o1_j[1] * localB->sincos_o2_l[2];
  localB->VectorConcatenate_l[2] = VectorConcatenate_m_tmp * localB->
    sincos_o2_l[0] + localB->sincos_o1_j[0] * localB->sincos_o1_j[2];

  /* Fcn: '<S204>/Fcn12' */
  localB->VectorConcatenate_l[3] = localB->sincos_o1_j[0] * localB->sincos_o2_l
    [1];

  /* Fcn: '<S204>/Fcn22' */
  localB->VectorConcatenate_l[4] = VectorConcatenate4_tmp * localB->sincos_o1_j
    [0] + localB->sincos_o2_l[0] * localB->sincos_o2_l[2];

  /* Fcn: '<S204>/Fcn32' */
  localB->VectorConcatenate_l[5] = VectorConcatenate_m_tmp * localB->
    sincos_o1_j[0] - localB->sincos_o2_l[0] * localB->sincos_o1_j[2];

  /* Fcn: '<S204>/Fcn13' */
  localB->VectorConcatenate_l[6] = -localB->sincos_o1_j[1];

  /* Fcn: '<S204>/Fcn23' */
  localB->VectorConcatenate_l[7] = localB->sincos_o2_l[1] * localB->sincos_o1_j
    [2];

  /* Fcn: '<S204>/Fcn33' */
  localB->VectorConcatenate_l[8] = localB->sincos_o2_l[1] * localB->sincos_o2_l
    [2];
  for (i = 0; i < 3; i++) {
    /* Math: '<S168>/Transpose' incorporates:
     *  Concatenate: '<S205>/Vector Concatenate'
     */
    localB->Transpose[3 * i] = localB->VectorConcatenate_l[i];
    localB->Transpose[3 * i + 1] = localB->VectorConcatenate_l[i + 3];
    localB->Transpose[3 * i + 2] = localB->VectorConcatenate_l[i + 6];
  }

  for (i = 0; i < 3; i++) {
    /* Product: '<S168>/Product' incorporates:
     *  Math: '<S168>/Transpose'
     */
    localB->Product_fl[i] = 0.0;
    localB->Product_fl[i] += localB->Transpose[i] *
      localB->TmpSignalConversionAtProductInport2[0];
    localB->Product_fl[i] += localB->Transpose[i + 3] *
      localB->TmpSignalConversionAtProductInport2[1];
    localB->Product_fl[i] += localB->Transpose[i + 6] *
      localB->TmpSignalConversionAtProductInport2[2];
  }

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[0] = localB->Product_fl[0];

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[2] = localB->Product_fl[2];

  /* Gain: '<S169>/1//m' */
  localB->xddot = 1.0 / DrivetrainHevP4_P.Mass * localB->Add;

  /* SignalConversion generated from: '<S169>/Vector Concatenate1' */
  localB->VectorConcatenate1_f[0] = localB->Product1_l;

  /* SignalConversion generated from: '<S169>/Vector Concatenate1' */
  localB->VectorConcatenate1_f[1] = localB->Product2_a;

  /* Sum: '<S96>/Sum' */
  localB->Sum_j = *rtu_GearCmd - localB->Switch_p;

  /* Product: '<S96>/Product' */
  localB->Product_a = localB->upi * localB->Sum_j;

  /* Product: '<S56>/Product1' */
  localB->Product1_d = *rtu_MotTrq * localB->VectorConcatenate_o[0];

  /* Switch: '<S56>/Switch' */
  if (localB->Product1_d > DrivetrainHevP4_P.Switch_Threshold) {
    /* Switch: '<S56>/Switch' */
    localB->Switch_cp = localB->Constant_g;
  } else {
    /* Switch: '<S56>/Switch' */
    localB->Switch_cp = localB->Constant_pg;
  }

  /* End of Switch: '<S56>/Switch' */

  /* Product: '<S56>/Product4' */
  rtb_Product4_d = localB->Switch_cp * *rtu_MotTrq;

  /* MATLAB Function: '<S42>/Open Differential' */
  DrivetrainHevP4_OpenDifferential(rtb_Product4_d, localB->Product4,
    localB->Product4_o, localB->bw1, localB->bd, localB->bw2, localB->Ndiff2,
    localB->Jd, localB->Jw1, localB->Jw3, localB->Integrator_p,
    &localB->sf_OpenDifferential_l, &DrivetrainHevP4_P.sf_OpenDifferential_l);

  /* UnaryMinus: '<S49>/Unary Minus2' */
  localB->UnaryMinus2[0] = -localB->sf_OpenDifferential_l.xdot[0];
  localB->UnaryMinus2[1] = -localB->sf_OpenDifferential_l.xdot[1];

  /* SignalConversion generated from: '<S49>/Vector Concatenate' */
  localB->omegadot[1] = localB->UnaryMinus2[0];

  /* SignalConversion generated from: '<S49>/Vector Concatenate' */
  localB->omegadot[2] = localB->UnaryMinus2[1];

  /* Product: '<S49>/Product1' */
  localB->Product1_p[0] = localB->diffDir_g * localB->
    sf_OpenDifferential_l.xdot[0];
  localB->Product1_p[1] = localB->diffDir_g * localB->
    sf_OpenDifferential_l.xdot[1];

  /* Gain: '<S49>/Gain1' */
  VectorConcatenate4_tmp = DrivetrainHevP4_P.Ndiff_P4 / 2.0;

  /* Gain: '<S49>/Gain1' */
  localB->Gain1_h[0] = VectorConcatenate4_tmp * localB->Product1_p[0];
  localB->Gain1_h[1] = VectorConcatenate4_tmp * localB->Product1_p[1];

  /* Sum: '<S49>/Sum of Elements2' */
  localB->omegadot[0] = localB->Gain1_h[0] + localB->Gain1_h[1];

  /* Sum: '<S13>/Subtract' */
  localB->Subtract_l = localB->UnaryMinus1_l[0] -
    localB->ImpAsg_InsertedFor_Omega_at_inport_0_i;

  /* Sum: '<S14>/Sum' */
  localB->Sum_h = localB->Subtract_l - localB->Switch_n;

  /* Product: '<S14>/Product' */
  localB->Product_m = localB->omega_c_l * localB->Sum_h;

  /* Sum: '<S60>/Subtract' */
  localB->Subtract_e = localB->UnaryMinus1[0] -
    localB->ImpAsg_InsertedFor_Omega_at_inport_0;

  /* Sum: '<S61>/Sum' */
  localB->Sum_cw = localB->Subtract_e - localB->Switch_c;

  /* Product: '<S61>/Product' */
  localB->Product_b = localB->omega_c_n * localB->Sum_cw;

  /* Product: '<S230>/Product' */
  localB->Product_g3 = localB->sf_SimpleMagicTire.My / localB->Saturation;

  /* Sum: '<S230>/Add' */
  localB->Add_g = localB->sf_SimpleMagicTire.Fx + localB->Product_g3;

  /* Product: '<S230>/Product3' */
  localB->Product3_c = localB->ImpAsg_InsertedFor_Omega_at_inport_0_i *
    localB->Saturation;

  /* Fcn: '<S247>/Fcn' */
  localB->Fcn = 4.0 / (3.0 - rt_powd_snf(localB->Product3_c / 2.0, 2.0));

  /* RelationalOperator: '<S248>/Compare' */
  localB->Compare_i = (localB->Product3_c >= localB->Constant_h);

  /* RelationalOperator: '<S249>/Compare' */
  localB->Compare_a = (localB->Product3_c <= localB->Constant_hu);

  /* Logic: '<S247>/Logical Operator' */
  localB->LogicalOperator = (localB->Compare_i && localB->Compare_a);

  /* Abs: '<S247>/Abs' */
  localB->Abs = fabs(localB->Product3_c);

  /* Switch: '<S247>/Switch' */
  if (localB->LogicalOperator) {
    /* Switch: '<S247>/Switch' */
    localB->Switch_f = localB->Fcn;
  } else {
    /* Switch: '<S247>/Switch' */
    localB->Switch_f = localB->Abs;
  }

  /* End of Switch: '<S247>/Switch' */

  /* Product: '<S230>/Product2' */
  localB->Product2_o = localB->Switch_f / localB->Constant2_f;

  /* Sum: '<S246>/Sum' */
  localB->Sum_i = localB->Add_g - localB->Integrator_h;

  /* Product: '<S246>/Product' */
  localB->Product_o4 = localB->Product2_o * localB->Sum_i;

  /* Product: '<S272>/Product' */
  localB->Product_fv = localB->sf_SimpleMagicTire_c.My / localB->Saturation_f;

  /* Sum: '<S272>/Add' */
  localB->Add_a = localB->sf_SimpleMagicTire_c.Fx + localB->Product_fv;

  /* Product: '<S272>/Product3' */
  localB->Product3_a = localB->ImpAsg_InsertedFor_Omega_at_inport_0 *
    localB->Saturation_f;

  /* Fcn: '<S289>/Fcn' */
  localB->Fcn_b = 4.0 / (3.0 - rt_powd_snf(localB->Product3_a / 2.0, 2.0));

  /* RelationalOperator: '<S290>/Compare' */
  localB->Compare_e = (localB->Product3_a >= localB->Constant_pk);

  /* RelationalOperator: '<S291>/Compare' */
  localB->Compare_l = (localB->Product3_a <= localB->Constant_jn);

  /* Logic: '<S289>/Logical Operator' */
  localB->LogicalOperator_h = (localB->Compare_e && localB->Compare_l);

  /* Abs: '<S289>/Abs' */
  localB->Abs_f = fabs(localB->Product3_a);

  /* Switch: '<S289>/Switch' */
  if (localB->LogicalOperator_h) {
    /* Switch: '<S289>/Switch' */
    localB->Switch_m = localB->Fcn_b;
  } else {
    /* Switch: '<S289>/Switch' */
    localB->Switch_m = localB->Abs_f;
  }

  /* End of Switch: '<S289>/Switch' */

  /* Product: '<S272>/Product2' */
  localB->Product2_j = localB->Switch_m / localB->Constant2_m;

  /* Sum: '<S288>/Sum' */
  localB->Sum_e = localB->Add_a - localB->Integrator_f;

  /* Product: '<S288>/Product' */
  localB->Product_de = localB->Product2_j * localB->Sum_e;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Update for Memory: '<S14>/Memory' incorporates:
     *  Constant: '<S14>/Reset'
     */
    localDW->Memory_PreviousInput = DrivetrainHevP4_P.Reset_Value_e;

    /* Update for Memory: '<S61>/Memory' incorporates:
     *  Constant: '<S61>/Reset'
     */
    localDW->Memory_PreviousInput_f = DrivetrainHevP4_P.Reset_Value_l;
  }

  /* Update for Integrator: '<S14>/Integrator' */
  localDW->Integrator_IWORK = 0;

  /* Update for Integrator: '<S61>/Integrator' */
  localDW->Integrator_IWORK_m = 0;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Update for Memory: '<S87>/Memory' incorporates:
     *  Constant: '<S87>/Reset'
     */
    localDW->Memory_PreviousInput_e = DrivetrainHevP4_P.Reset_Value_g;

    /* Update for Memory: '<S150>/Memory' incorporates:
     *  Constant: '<S150>/Reset'
     */
    localDW->Memory_PreviousInput_d = DrivetrainHevP4_P.Reset_Value;
  }

  /* Update for Integrator: '<S87>/Integrator' */
  localDW->Integrator_IWORK_d = 0;

  /* Update for Integrator: '<S150>/Integrator' */
  localDW->Integrator_IWORK_h = 0;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Update for Memory: '<S145>/Memory' */
    localDW->Memory_PreviousInput_jb = *rty_Cltch2State;
  }

  /* Update for If: '<S126>/If' */
  switch (localDW->If_ActiveSubsystem) {
   case 0:
    /* Update for IfAction SubSystem: '<S126>/Locked' incorporates:
     *  ActionPort: '<S132>/Action'
     */
    /* Update for Integrator: '<S132>/Locked Shaft Integrator' */
    localDW->LockedShaftIntegrator_IWORK = 0;

    /* End of Update for SubSystem: '<S126>/Locked' */
    break;

   case 1:
    /* Update for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* Update for Integrator: '<S133>/Pump Integrator' */
    localDW->PumpIntegrator_IWORK = 0;
    switch (localDW->PumpIntegrator_MODE) {
     case 3:
      if (localB->ImpellerInertia < 0.0) {
        localDW->PumpIntegrator_MODE = 1;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
      break;

     case 4:
      if (localB->ImpellerInertia > 0.0) {
        localDW->PumpIntegrator_MODE = 2;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
      break;
    }

    localXdis->PumpIntegrator_CSTATE = ((localDW->PumpIntegrator_MODE == 3) ||
      (localDW->PumpIntegrator_MODE == 4));

    /* End of Update for Integrator: '<S133>/Pump Integrator' */

    /* Update for Integrator: '<S133>/Turbine Integrator' */
    localDW->TurbineIntegrator_IWORK = 0;
    switch (localDW->TurbineIntegrator_MODE) {
     case 3:
      if (localB->TurbineInertia < 0.0) {
        localDW->TurbineIntegrator_MODE = 1;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
      break;

     case 4:
      if (localB->TurbineInertia > 0.0) {
        localDW->TurbineIntegrator_MODE = 2;
        ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      }
      break;
    }

    localXdis->TurbineIntegrator_CSTATE = ((localDW->TurbineIntegrator_MODE == 3)
      || (localDW->TurbineIntegrator_MODE == 4));

    /* End of Update for Integrator: '<S133>/Turbine Integrator' */
    /* End of Update for SubSystem: '<S126>/Unlocked' */
    break;
  }

  /* End of Update for If: '<S126>/If' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M) && rtmIsSampleHit(DrivetrainHevP4_M,
       1, 0)) {
    /* Update for Memory: '<S96>/Memory' incorporates:
     *  Constant: '<S96>/Reset'
     */
    localDW->Memory_PreviousInput_j = DrivetrainHevP4_P.Reset_Value_m;

    /* Update for Memory: '<S78>/Memory' incorporates:
     *  Constant: '<S78>/Reset'
     */
    localDW->Memory_PreviousInput_h = DrivetrainHevP4_P.Reset_Value_i;
  }

  /* Update for Integrator: '<S96>/Integrator' */
  localDW->Integrator_IWORK_n = 0;

  /* Update for Integrator: '<S78>/Integrator' */
  localDW->Integrator_IWORK_l = 0;

  /* Update for If: '<S94>/If' */
  switch (localDW->If_ActiveSubsystem_b) {
   case 0:
    /* Update for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* Update for Integrator: '<S98>/x' */
    localDW->x_IWORK = 0;

    /* End of Update for SubSystem: '<S94>/Locked' */
    break;

   case 1:
    /* Update for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* Update for Integrator: '<S100>/xe' */
    localDW->xe_IWORK = 0;

    /* Update for Integrator: '<S100>/xv' */
    localDW->xv_IWORK = 0;

    /* End of Update for SubSystem: '<S94>/Unlocked' */
    break;
  }

  /* End of Update for If: '<S94>/If' */

  /* Update for Integrator: '<S25>/Integrator' */
  localDW->Integrator_IWORK_j = 0;

  /* Update for Integrator: '<S42>/Integrator' */
  localDW->Integrator_IWORK_mn = 0;
}

/* Derivatives for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Deriv(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  const real_T *rtu_MotTrq, const real_T *rtu_Grade, const real_T *rtu_WindVel,
  const real_T *rtu_BrkCmd, const real_T *rtu_GearCmd, B_DrivetrainHevP4_c_T
  *localB, DW_DrivetrainHevP4_f_T *localDW, X_DrivetrainHevP4_n_T *localX,
  XDis_DrivetrainHevP4_n_T *localXdis, XDot_DrivetrainHevP4_n_T *localXdot)
{
  /* local block i/o variables */
  real_T rtb_Product4_d;
  real_T VectorConcatenate4_tmp;
  real_T VectorConcatenate_m_tmp;
  int32_T i;

  /* Gain: '<S5>/Gain' */
  localB->Gain_c = DrivetrainHevP4_P.Gain_Gain * *rtu_BrkCmd;

  /* Product: '<S232>/product' */
  localB->product = localB->Gain_c * localB->TorqueConversion1 *
    localB->Diskbrakeactuatorbore * localB->Numberofbrakepads;

  /* Saturate: '<S232>/Disallow Negative Brake Torque' */
  if (localB->product > DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat)
  {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat;
  } else if (localB->product <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat) {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat;
  } else {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque = localB->product;
  }

  /* End of Saturate: '<S232>/Disallow Negative Brake Torque' */

  /* Gain: '<S232>/Torque Conversion' */
  localB->TorqueConversion = DrivetrainHevP4_P.Rm * DrivetrainHevP4_P.mu_kinetic
    * localB->DisallowNegativeBrakeTorque;

  /* Gain: '<S229>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion;

  /* Outputs for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention,
    localB->Ratioofstatictokinetic, localB->TorqueConversion,
    &localB->ImpAsg_InsertedFor_Omega_at_inport_0_i, &localB->Clutch,
    &localDW->Clutch, &DrivetrainHevP4_P.Clutch, &localX->Clutch);

  /* End of Outputs for SubSystem: '<S217>/Clutch' */

  /* MATLAB Function: '<S213>/Simple Magic Tire' */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation, localB->Integrator1,
    localB->ImpAsg_InsertedFor_Omega_at_inport_0_i, localB->VectorConcatenate2[0],
    localB->D, localB->C, localB->B, localB->E, localB->lam_muxConstant,
    localB->Constant2, localB->kappaFx, localB->FzFx, localB->FxMap,
    localB->TirePrsConstant, localB->FNOMIN, localB->NOMPRES, localB->QSY1,
    localB->QSY2, localB->QSY3, localB->QSY4, localB->QSY5, localB->QSY6,
    localB->QSY7, localB->QSY8, localB->gamma, localB->lam_My,
    localB->UNLOADED_RADIUS, localB->PRESMIN, localB->PRESMAX, localB->VxMy,
    localB->FzMy, localB->MyMap, 0.0, localB->FxType, localB->rollType,
    localB->vertType, &localB->sf_SimpleMagicTire);

  /* Sum: '<S5>/Add' */
  localB->Fx = localB->sf_SimpleMagicTire.Fx + localB->sf_SimpleMagicTire.Fx;

  /* SignalConversion generated from: '<S169>/Vector Concatenate2' */
  localB->VectorConcatenate4[0] = localB->Fx;

  /* Gain: '<S5>/Gain1' */
  localB->Gain1 = DrivetrainHevP4_P.Gain1_Gain * *rtu_BrkCmd;

  /* Product: '<S274>/product' */
  localB->product_p = localB->Gain1 * localB->TorqueConversion1_b *
    localB->Diskbrakeactuatorbore_j * localB->Numberofbrakepads_f;

  /* Saturate: '<S274>/Disallow Negative Brake Torque' */
  if (localB->product_p >
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o) {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o;
  } else if (localB->product_p <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o) {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o;
  } else {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m = localB->product_p;
  }

  /* End of Saturate: '<S274>/Disallow Negative Brake Torque' */

  /* Gain: '<S274>/Torque Conversion' */
  localB->TorqueConversion_b = DrivetrainHevP4_P.Rm *
    DrivetrainHevP4_P.mu_kinetic * localB->DisallowNegativeBrakeTorque_m;

  /* Gain: '<S271>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic_i = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion_b;

  /* Outputs for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention_o,
    localB->Ratioofstatictokinetic_i, localB->TorqueConversion_b,
    &localB->ImpAsg_InsertedFor_Omega_at_inport_0, &localB->Clutch_e,
    &localDW->Clutch_e, &DrivetrainHevP4_P.Clutch_e, &localX->Clutch_e);

  /* End of Outputs for SubSystem: '<S259>/Clutch' */

  /* MATLAB Function: '<S255>/Simple Magic Tire' */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation_f, localB->Integrator1_d,
    localB->ImpAsg_InsertedFor_Omega_at_inport_0, localB->VectorConcatenate2[0],
    localB->D_c, localB->C_g, localB->B_d, localB->E_a,
    localB->lam_muxConstant_h, localB->Constant2_p, localB->kappaFx_j,
    localB->FzFx_l, localB->FxMap_h, localB->TirePrsConstant_a, localB->FNOMIN_m,
    localB->NOMPRES_h, localB->QSY1_k, localB->QSY2_g, localB->QSY3_h,
    localB->QSY4_k, localB->QSY5_p, localB->QSY6_i, localB->QSY7_j,
    localB->QSY8_d, localB->gamma_e, localB->lam_My_a, localB->UNLOADED_RADIUS_k,
    localB->PRESMIN_g, localB->PRESMAX_c, localB->VxMy_k, localB->FzMy_g,
    localB->MyMap_d, 0.0, localB->FxType_b, localB->rollType_m,
    localB->vertType_o, &localB->sf_SimpleMagicTire_c);

  /* Sum: '<S5>/Add1' */
  localB->Fx_o = localB->sf_SimpleMagicTire_c.Fx +
    localB->sf_SimpleMagicTire_c.Fx;

  /* SignalConversion generated from: '<S169>/Vector Concatenate2' */
  localB->VectorConcatenate4[1] = localB->Fx_o;

  /* SignalConversion generated from: '<S207>/Vector Concatenate5' */
  localB->VectorConcatenate5_e[0] = *rtu_WindVel;

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[0] = -localB->VectorConcatenate5_e[0];

  /* Sum: '<S206>/Add1' */
  localB->Add1[0] = localB->VectorConcatenate5[0] - localB->UnaryMinus[0];

  /* Product: '<S206>/Product' */
  localB->Product_g[0] = localB->Add1[0] * localB->Add1[0];

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[1] = -localB->VectorConcatenate5_e[1];

  /* Sum: '<S206>/Add1' */
  localB->Add1[1] = localB->VectorConcatenate5[1] - localB->UnaryMinus[1];

  /* Product: '<S206>/Product' */
  localB->Product_g[1] = localB->Add1[1] * localB->Add1[1];

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[2] = -localB->VectorConcatenate5_e[2];

  /* Sum: '<S206>/Add1' */
  localB->Add1[2] = localB->VectorConcatenate5[2] - localB->UnaryMinus[2];

  /* Product: '<S206>/Product' */
  localB->Product_g[2] = localB->Add1[2] * localB->Add1[2];

  /* Sum: '<S206>/Sum of Elements' */
  localB->SumofElements = (localB->Product_g[0] + localB->Product_g[1]) +
    localB->Product_g[2];

  /* Sqrt: '<S206>/Sqrt' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    if (localDW->Sqrt_DWORK1 != 0) {
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      localDW->Sqrt_DWORK1 = 0;
    }

    /* Sqrt: '<S206>/Sqrt' */
    localB->Sqrt = sqrt(localB->SumofElements);
  } else {
    if (localB->SumofElements < 0.0) {
      /* Sqrt: '<S206>/Sqrt' */
      localB->Sqrt = -sqrt(fabs(localB->SumofElements));
    } else {
      /* Sqrt: '<S206>/Sqrt' */
      localB->Sqrt = sqrt(localB->SumofElements);
    }

    if (localB->SumofElements < 0.0) {
      localDW->Sqrt_DWORK1 = 1;
    }
  }

  /* End of Sqrt: '<S206>/Sqrt' */

  /* Product: '<S206>/Product2' */
  localB->Product2 = localB->Sqrt * localB->Sqrt;

  /* Trigonometry: '<S206>/Trigonometric Function' */
  localB->TrigonometricFunction = rt_atan2d_snf(localB->Add1[1], localB->Add1[0]);

  /* Lookup_n-D: '<S206>/Cs' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[1] = look1_binlcpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cs, 1U);

  /* Lookup_n-D: '<S206>/Crm' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[3] = look1_binlxpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.Crm_bp01Data, DrivetrainHevP4_P.Crm_tableData, 1U);

  /* Gain: '<S206>/4' */
  localB->u[0] = DrivetrainHevP4_P.u_Gain[0] * localB->Add1[0];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[0] = tanh(localB->u[0]);

  /* Gain: '<S206>/4' */
  localB->u[1] = DrivetrainHevP4_P.u_Gain[1] * localB->Add1[1];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[1] = tanh(localB->u[1]);

  /* Gain: '<S206>/4' */
  localB->u[2] = DrivetrainHevP4_P.u_Gain[2] * localB->Add1[2];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[2] = tanh(localB->u[2]);

  /* Product: '<S206>/Product5' */
  localB->VectorConcatenate_n[4] = localB->Tanh[0] * localB->Constant2_n;

  /* Lookup_n-D: '<S206>/Cym' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[5] = look1_binlxpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cym, 1U);

  /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' */
  VectorConcatenate4_tmp = 0.5 * DrivetrainHevP4_P.Af * DrivetrainHevP4_P.Pabs /
    DrivetrainHevP4_P.DragForce_R;
  for (i = 0; i < 6; i++) {
    /* Product: '<S206>/Product1' */
    localB->Product1[i] = localB->Product2 * localB->VectorConcatenate_n[i] /
      localB->AirTempConstant;

    /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' */
    localB->uAPabsRT[i] = VectorConcatenate4_tmp * localB->Product1[i];
  }

  /* UnitConversion: '<S166>/Unit Conversion' */
  /* Unit Conversion - from: deg to: rad
     Expression: output = (0.0174533*input) + (0) */
  localB->UnitConversion = 0.017453292519943295 * *rtu_Grade;

  /* Trigonometry: '<S169>/Trigonometric Function2' */
  localB->TrigonometricFunction2_o1 = sin(localB->UnitConversion);

  /* Trigonometry: '<S169>/Trigonometric Function2' */
  localB->TrigonometricFunction2_o2 = cos(localB->UnitConversion);

  /* Product: '<S169>/Product2' */
  localB->Product2_a = localB->TrigonometricFunction2_o2 * localB->Fz;

  /* Product: '<S206>/Product4' */
  localB->Product4_k[0] = localB->uAPabsRT[3] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[0] = localB->Tanh[0] * localB->uAPabsRT[0];

  /* Product: '<S206>/Product4' */
  localB->Product4_k[1] = localB->uAPabsRT[4] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[1] = localB->Tanh[1] * localB->uAPabsRT[1];

  /* Product: '<S206>/Product4' */
  localB->Product4_k[2] = localB->uAPabsRT[5] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[2] = localB->Tanh[2] * localB->uAPabsRT[2];

  /* Sum: '<S169>/Add6' */
  localB->Add6 = localB->Product4_k[1] + localB->MExtConstant[1];

  /* Sum: '<S169>/Add1' */
  localB->Add1_p = (localB->Product2_a + localB->FExtConstant[2]) +
    localB->Product3[2];

  /* Gain: '<S169>/b' */
  localB->b = DrivetrainHevP4_P.b_CG * localB->Add1_p;

  /* Product: '<S169>/Product1' */
  localB->Product1_l = localB->TrigonometricFunction2_o1 * localB->Fz;

  /* Sum: '<S169>/Add' */
  localB->Add = (((localB->FExtConstant[0] - localB->Product1_l) + localB->Fx) +
                 localB->Fx_o) - localB->Product3[0];

  /* Sum: '<S169>/Add3' */
  localB->Add3 = ((localB->Product3[0] - localB->FExtConstant[0]) +
                  localB->Product1_l) + localB->Add;

  /* Gain: '<S169>/h' */
  localB->h = DrivetrainHevP4_P.h * localB->Add3;

  /* Sum: '<S169>/Add2' */
  localB->Add2 = (localB->b - localB->Add6) - localB->h;

  /* Gain: '<S169>/1//(a+b)' incorporates:
   *  Gain: '<S169>/1//(a+b) '
   */
  VectorConcatenate4_tmp = 1.0 / (DrivetrainHevP4_P.a_CG +
    DrivetrainHevP4_P.b_CG);
  localB->VectorConcatenate4[2] = VectorConcatenate4_tmp * localB->Add2;

  /* Gain: '<S169>/a' */
  localB->a = DrivetrainHevP4_P.a_CG * localB->Add1_p;

  /* Sum: '<S169>/Add4' */
  localB->Add4 = (localB->Add6 + localB->a) + localB->h;

  /* Gain: '<S169>/1//(a+b) ' */
  localB->VectorConcatenate4[3] = VectorConcatenate4_tmp * localB->Add4;

  /* Selector: '<S178>/Selector1' incorporates:
   *  Concatenate: '<S169>/Vector Concatenate4'
   */
  localB->Selector1[0] = localB->VectorConcatenate4[2];
  localB->Selector1[1] = localB->VectorConcatenate4[3];

  /* Gain: '<S178>/1//NR' */
  localB->Fz_a = 1.0 / DrivetrainHevP4_P.NR * localB->Selector1[1];

  /* Sum: '<S163>/Sum' */
  localB->Sum_c = localB->Fz_a - localB->Integrator1_d;

  /* Product: '<S163>/Divide' */
  localB->Divide = localB->Sum_c * localB->Constant;

  /* Gain: '<S178>/1//NF' */
  localB->Fz_f = 1.0 / DrivetrainHevP4_P.NF * localB->Selector1[0];

  /* Sum: '<S164>/Sum' */
  localB->Sum_l = localB->Fz_f - localB->Integrator1;

  /* Product: '<S164>/Divide' */
  localB->Divide_l = localB->Sum_l * localB->Constant_f;

  /* Sum: '<S174>/Add' */
  localB->Add_m = localB->UnitConversion;

  /* SignalConversion generated from: '<S197>/sincos' */
  localB->TmpSignalConversionAtsincosInport1[0] = localB->Constant_m;
  localB->TmpSignalConversionAtsincosInport1[1] = localB->Add_m;
  localB->TmpSignalConversionAtsincosInport1[2] = localB->Constant_m;

  /* Trigonometry: '<S197>/sincos' */
  localB->sincos_o1[0] = sin(localB->TmpSignalConversionAtsincosInport1[0]);
  localB->sincos_o2[0] = cos(localB->TmpSignalConversionAtsincosInport1[0]);
  localB->sincos_o1[1] = sin(localB->TmpSignalConversionAtsincosInport1[1]);
  localB->sincos_o2[1] = cos(localB->TmpSignalConversionAtsincosInport1[1]);
  localB->sincos_o1[2] = sin(localB->TmpSignalConversionAtsincosInport1[2]);
  localB->sincos_o2[2] = cos(localB->TmpSignalConversionAtsincosInport1[2]);

  /* Fcn: '<S197>/Fcn11' */
  localB->VectorConcatenate_m[0] = localB->sincos_o2[0] * localB->sincos_o2[1];

  /* Fcn: '<S197>/Fcn21' incorporates:
   *  Fcn: '<S197>/Fcn22'
   */
  VectorConcatenate4_tmp = localB->sincos_o1[1] * localB->sincos_o1[2];
  localB->VectorConcatenate_m[1] = VectorConcatenate4_tmp * localB->sincos_o2[0]
    - localB->sincos_o1[0] * localB->sincos_o2[2];

  /* Fcn: '<S197>/Fcn31' incorporates:
   *  Fcn: '<S197>/Fcn32'
   */
  VectorConcatenate_m_tmp = localB->sincos_o1[1] * localB->sincos_o2[2];
  localB->VectorConcatenate_m[2] = VectorConcatenate_m_tmp * localB->sincos_o2[0]
    + localB->sincos_o1[0] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn12' */
  localB->VectorConcatenate_m[3] = localB->sincos_o1[0] * localB->sincos_o2[1];

  /* Fcn: '<S197>/Fcn22' */
  localB->VectorConcatenate_m[4] = VectorConcatenate4_tmp * localB->sincos_o1[0]
    + localB->sincos_o2[0] * localB->sincos_o2[2];

  /* Fcn: '<S197>/Fcn32' */
  localB->VectorConcatenate_m[5] = VectorConcatenate_m_tmp * localB->sincos_o1[0]
    - localB->sincos_o2[0] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn13' */
  localB->VectorConcatenate_m[6] = -localB->sincos_o1[1];

  /* Fcn: '<S197>/Fcn23' */
  localB->VectorConcatenate_m[7] = localB->sincos_o2[1] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn33' */
  localB->VectorConcatenate_m[8] = localB->sincos_o2[1] * localB->sincos_o2[2];

  /* SignalConversion generated from: '<S166>/Vector Concatenate1' */
  localB->VectorConcatenate1[0] = localB->Add;

  /* SignalConversion generated from: '<S166>/Vector Concatenate4' */
  localB->VectorConcatenate4_l[0] = localB->Fx;

  /* SignalConversion generated from: '<S166>/Vector Concatenate4' */
  localB->VectorConcatenate4_l[1] = localB->Fx_o;

  /* SignalConversion generated from: '<S204>/sincos' */
  localB->TmpSignalConversionAtsincosInport1_n[0] = localB->Constant_c;
  localB->TmpSignalConversionAtsincosInport1_n[1] = localB->UnitConversion;
  localB->TmpSignalConversionAtsincosInport1_n[2] = localB->Constant_c;

  /* Trigonometry: '<S204>/sincos' */
  localB->sincos_o1_j[0] = sin(localB->TmpSignalConversionAtsincosInport1_n[0]);
  localB->sincos_o2_l[0] = cos(localB->TmpSignalConversionAtsincosInport1_n[0]);
  localB->sincos_o1_j[1] = sin(localB->TmpSignalConversionAtsincosInport1_n[1]);
  localB->sincos_o2_l[1] = cos(localB->TmpSignalConversionAtsincosInport1_n[1]);
  localB->sincos_o1_j[2] = sin(localB->TmpSignalConversionAtsincosInport1_n[2]);
  localB->sincos_o2_l[2] = cos(localB->TmpSignalConversionAtsincosInport1_n[2]);

  /* Fcn: '<S204>/Fcn11' */
  localB->VectorConcatenate_l[0] = localB->sincos_o2_l[0] * localB->sincos_o2_l
    [1];

  /* Fcn: '<S204>/Fcn21' incorporates:
   *  Fcn: '<S204>/Fcn22'
   */
  VectorConcatenate4_tmp = localB->sincos_o1_j[1] * localB->sincos_o1_j[2];
  localB->VectorConcatenate_l[1] = VectorConcatenate4_tmp * localB->sincos_o2_l
    [0] - localB->sincos_o1_j[0] * localB->sincos_o2_l[2];

  /* Fcn: '<S204>/Fcn31' incorporates:
   *  Fcn: '<S204>/Fcn32'
   */
  VectorConcatenate_m_tmp = localB->sincos_o1_j[1] * localB->sincos_o2_l[2];
  localB->VectorConcatenate_l[2] = VectorConcatenate_m_tmp * localB->
    sincos_o2_l[0] + localB->sincos_o1_j[0] * localB->sincos_o1_j[2];

  /* Fcn: '<S204>/Fcn12' */
  localB->VectorConcatenate_l[3] = localB->sincos_o1_j[0] * localB->sincos_o2_l
    [1];

  /* Fcn: '<S204>/Fcn22' */
  localB->VectorConcatenate_l[4] = VectorConcatenate4_tmp * localB->sincos_o1_j
    [0] + localB->sincos_o2_l[0] * localB->sincos_o2_l[2];

  /* Fcn: '<S204>/Fcn32' */
  localB->VectorConcatenate_l[5] = VectorConcatenate_m_tmp * localB->
    sincos_o1_j[0] - localB->sincos_o2_l[0] * localB->sincos_o1_j[2];

  /* Fcn: '<S204>/Fcn13' */
  localB->VectorConcatenate_l[6] = -localB->sincos_o1_j[1];

  /* Fcn: '<S204>/Fcn23' */
  localB->VectorConcatenate_l[7] = localB->sincos_o2_l[1] * localB->sincos_o1_j
    [2];

  /* Fcn: '<S204>/Fcn33' */
  localB->VectorConcatenate_l[8] = localB->sincos_o2_l[1] * localB->sincos_o2_l
    [2];
  for (i = 0; i < 3; i++) {
    /* Math: '<S168>/Transpose' incorporates:
     *  Concatenate: '<S205>/Vector Concatenate'
     */
    localB->Transpose[3 * i] = localB->VectorConcatenate_l[i];
    localB->Transpose[3 * i + 1] = localB->VectorConcatenate_l[i + 3];
    localB->Transpose[3 * i + 2] = localB->VectorConcatenate_l[i + 6];
  }

  for (i = 0; i < 3; i++) {
    /* Product: '<S168>/Product' incorporates:
     *  Math: '<S168>/Transpose'
     */
    localB->Product_fl[i] = 0.0;
    localB->Product_fl[i] += localB->Transpose[i] *
      localB->TmpSignalConversionAtProductInport2[0];
    localB->Product_fl[i] += localB->Transpose[i + 3] *
      localB->TmpSignalConversionAtProductInport2[1];
    localB->Product_fl[i] += localB->Transpose[i + 6] *
      localB->TmpSignalConversionAtProductInport2[2];
  }

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[0] = localB->Product_fl[0];

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[2] = localB->Product_fl[2];

  /* Gain: '<S169>/1//m' */
  localB->xddot = 1.0 / DrivetrainHevP4_P.Mass * localB->Add;

  /* SignalConversion generated from: '<S169>/Vector Concatenate1' */
  localB->VectorConcatenate1_f[0] = localB->Product1_l;

  /* SignalConversion generated from: '<S169>/Vector Concatenate1' */
  localB->VectorConcatenate1_f[1] = localB->Product2_a;

  /* Sum: '<S96>/Sum' */
  localB->Sum_j = *rtu_GearCmd - localB->Switch_p;

  /* Product: '<S96>/Product' */
  localB->Product_a = localB->upi * localB->Sum_j;

  /* Product: '<S56>/Product1' */
  localB->Product1_d = *rtu_MotTrq * localB->VectorConcatenate_o[0];

  /* Switch: '<S56>/Switch' */
  if (localB->Product1_d > DrivetrainHevP4_P.Switch_Threshold) {
    /* Switch: '<S56>/Switch' */
    localB->Switch_cp = localB->Constant_g;
  } else {
    /* Switch: '<S56>/Switch' */
    localB->Switch_cp = localB->Constant_pg;
  }

  /* End of Switch: '<S56>/Switch' */

  /* Product: '<S56>/Product4' */
  rtb_Product4_d = localB->Switch_cp * *rtu_MotTrq;

  /* MATLAB Function: '<S42>/Open Differential' */
  DrivetrainHevP4_OpenDifferential(rtb_Product4_d, localB->Product4,
    localB->Product4_o, localB->bw1, localB->bd, localB->bw2, localB->Ndiff2,
    localB->Jd, localB->Jw1, localB->Jw3, localB->Integrator_p,
    &localB->sf_OpenDifferential_l, &DrivetrainHevP4_P.sf_OpenDifferential_l);

  /* UnaryMinus: '<S49>/Unary Minus2' */
  localB->UnaryMinus2[0] = -localB->sf_OpenDifferential_l.xdot[0];
  localB->UnaryMinus2[1] = -localB->sf_OpenDifferential_l.xdot[1];

  /* SignalConversion generated from: '<S49>/Vector Concatenate' */
  localB->omegadot[1] = localB->UnaryMinus2[0];

  /* SignalConversion generated from: '<S49>/Vector Concatenate' */
  localB->omegadot[2] = localB->UnaryMinus2[1];

  /* Product: '<S49>/Product1' */
  localB->Product1_p[0] = localB->diffDir_g * localB->
    sf_OpenDifferential_l.xdot[0];
  localB->Product1_p[1] = localB->diffDir_g * localB->
    sf_OpenDifferential_l.xdot[1];

  /* Gain: '<S49>/Gain1' */
  VectorConcatenate4_tmp = DrivetrainHevP4_P.Ndiff_P4 / 2.0;

  /* Gain: '<S49>/Gain1' */
  localB->Gain1_h[0] = VectorConcatenate4_tmp * localB->Product1_p[0];
  localB->Gain1_h[1] = VectorConcatenate4_tmp * localB->Product1_p[1];

  /* Sum: '<S49>/Sum of Elements2' */
  localB->omegadot[0] = localB->Gain1_h[0] + localB->Gain1_h[1];

  /* Sum: '<S13>/Subtract' */
  localB->Subtract_l = localB->UnaryMinus1_l[0] -
    localB->ImpAsg_InsertedFor_Omega_at_inport_0_i;

  /* Sum: '<S14>/Sum' */
  localB->Sum_h = localB->Subtract_l - localB->Switch_n;

  /* Product: '<S14>/Product' */
  localB->Product_m = localB->omega_c_l * localB->Sum_h;

  /* Sum: '<S60>/Subtract' */
  localB->Subtract_e = localB->UnaryMinus1[0] -
    localB->ImpAsg_InsertedFor_Omega_at_inport_0;

  /* Sum: '<S61>/Sum' */
  localB->Sum_cw = localB->Subtract_e - localB->Switch_c;

  /* Product: '<S61>/Product' */
  localB->Product_b = localB->omega_c_n * localB->Sum_cw;

  /* Product: '<S230>/Product' */
  localB->Product_g3 = localB->sf_SimpleMagicTire.My / localB->Saturation;

  /* Sum: '<S230>/Add' */
  localB->Add_g = localB->sf_SimpleMagicTire.Fx + localB->Product_g3;

  /* Product: '<S230>/Product3' */
  localB->Product3_c = localB->ImpAsg_InsertedFor_Omega_at_inport_0_i *
    localB->Saturation;

  /* Fcn: '<S247>/Fcn' */
  localB->Fcn = 4.0 / (3.0 - rt_powd_snf(localB->Product3_c / 2.0, 2.0));

  /* RelationalOperator: '<S248>/Compare' */
  localB->Compare_i = (localB->Product3_c >= localB->Constant_h);

  /* RelationalOperator: '<S249>/Compare' */
  localB->Compare_a = (localB->Product3_c <= localB->Constant_hu);

  /* Logic: '<S247>/Logical Operator' */
  localB->LogicalOperator = (localB->Compare_i && localB->Compare_a);

  /* Abs: '<S247>/Abs' */
  localB->Abs = fabs(localB->Product3_c);

  /* Switch: '<S247>/Switch' */
  if (localB->LogicalOperator) {
    /* Switch: '<S247>/Switch' */
    localB->Switch_f = localB->Fcn;
  } else {
    /* Switch: '<S247>/Switch' */
    localB->Switch_f = localB->Abs;
  }

  /* End of Switch: '<S247>/Switch' */

  /* Product: '<S230>/Product2' */
  localB->Product2_o = localB->Switch_f / localB->Constant2_f;

  /* Sum: '<S246>/Sum' */
  localB->Sum_i = localB->Add_g - localB->Integrator_h;

  /* Product: '<S246>/Product' */
  localB->Product_o4 = localB->Product2_o * localB->Sum_i;

  /* Product: '<S272>/Product' */
  localB->Product_fv = localB->sf_SimpleMagicTire_c.My / localB->Saturation_f;

  /* Sum: '<S272>/Add' */
  localB->Add_a = localB->sf_SimpleMagicTire_c.Fx + localB->Product_fv;

  /* Product: '<S272>/Product3' */
  localB->Product3_a = localB->ImpAsg_InsertedFor_Omega_at_inport_0 *
    localB->Saturation_f;

  /* Fcn: '<S289>/Fcn' */
  localB->Fcn_b = 4.0 / (3.0 - rt_powd_snf(localB->Product3_a / 2.0, 2.0));

  /* RelationalOperator: '<S290>/Compare' */
  localB->Compare_e = (localB->Product3_a >= localB->Constant_pk);

  /* RelationalOperator: '<S291>/Compare' */
  localB->Compare_l = (localB->Product3_a <= localB->Constant_jn);

  /* Logic: '<S289>/Logical Operator' */
  localB->LogicalOperator_h = (localB->Compare_e && localB->Compare_l);

  /* Abs: '<S289>/Abs' */
  localB->Abs_f = fabs(localB->Product3_a);

  /* Switch: '<S289>/Switch' */
  if (localB->LogicalOperator_h) {
    /* Switch: '<S289>/Switch' */
    localB->Switch_m = localB->Fcn_b;
  } else {
    /* Switch: '<S289>/Switch' */
    localB->Switch_m = localB->Abs_f;
  }

  /* End of Switch: '<S289>/Switch' */

  /* Product: '<S272>/Product2' */
  localB->Product2_j = localB->Switch_m / localB->Constant2_m;

  /* Sum: '<S288>/Sum' */
  localB->Sum_e = localB->Add_a - localB->Integrator_f;

  /* Product: '<S288>/Product' */
  localB->Product_de = localB->Product2_j * localB->Sum_e;

  /* Derivatives for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_d_Deriv(localB->Signconvention,
    localB->Ratioofstatictokinetic, localB->TorqueConversion, &localB->Clutch,
    &localDW->Clutch, &localXdot->Clutch);

  /* End of Derivatives for SubSystem: '<S217>/Clutch' */

  /* Derivatives for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_d_Deriv(localB->Signconvention_o,
    localB->Ratioofstatictokinetic_i, localB->TorqueConversion_b,
    &localB->Clutch_e, &localDW->Clutch_e, &localXdot->Clutch_e);

  /* End of Derivatives for SubSystem: '<S259>/Clutch' */

  /* Derivatives for Integrator: '<S169>/Integrator' */
  localXdot->Integrator_CSTATE = localB->xddot;

  /* Derivatives for Integrator: '<S164>/Integrator1' */
  localXdot->Integrator1_CSTATE = localB->Divide_l;

  /* Derivatives for Integrator: '<S14>/Integrator' */
  localXdot->Integrator_CSTATE_a = localB->Product_m;

  /* Derivatives for Integrator: '<S13>/Integrator' */
  localXdot->Integrator_CSTATE_c = localB->Subtract_l;

  /* Derivatives for Integrator: '<S246>/Integrator' */
  localXdot->Integrator_CSTATE_h = localB->Product_o4;

  /* Derivatives for Integrator: '<S163>/Integrator1' */
  localXdot->Integrator1_CSTATE_g = localB->Divide;

  /* Derivatives for Integrator: '<S61>/Integrator' */
  localXdot->Integrator_CSTATE_l = localB->Product_b;

  /* Derivatives for Integrator: '<S60>/Integrator' */
  localXdot->Integrator_CSTATE_i = localB->Subtract_e;

  /* Derivatives for Integrator: '<S288>/Integrator' */
  localXdot->Integrator_CSTATE_hm = localB->Product_de;

  /* Derivatives for Integrator: '<S3>/Integrator' */
  localXdot->Integrator_CSTATE_d[0] =
    localB->TmpSignalConversionAtIntegratorInport1[0];
  localXdot->Integrator_CSTATE_d[1] =
    localB->TmpSignalConversionAtIntegratorInport1[1];

  /* Derivatives for Integrator: '<S177>/Integrator3' */
  localXdot->Integrator3_CSTATE = localB->VectorConcatenate2[0];

  /* Derivatives for Integrator: '<S166>/Integrator1' */
  localXdot->Integrator1_CSTATE_f = localB->Integrator;

  /* Derivatives for Integrator: '<S87>/Integrator' */
  localXdot->Integrator_CSTATE_de = localB->Product_o;

  /* Derivatives for Integrator: '<S86>/Integrator' */
  localXdot->Integrator_CSTATE_g = localB->Subtract_n;

  /* Derivatives for Integrator: '<S150>/Integrator' */
  localXdot->Integrator_CSTATE_b = localB->Product;

  /* Derivatives for If: '<S126>/If' */
  localXdot->LockedShaftIntegrator_CSTATE = 0.0;

  {
    real_T *dx;
    int_T i;
    dx = &(localXdot->PumpIntegrator_CSTATE);
    for (i=0; i < 3; i++) {
      dx[i] = 0.0;
    }
  }

  switch (localDW->If_ActiveSubsystem) {
   case 0:
    /* Derivatives for IfAction SubSystem: '<S126>/Locked' incorporates:
     *  ActionPort: '<S132>/Action'
     */
    /* Derivatives for Integrator: '<S132>/Locked Shaft Integrator' */
    if (((localX->LockedShaftIntegrator_CSTATE >
          DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat) &&
         (localX->LockedShaftIntegrator_CSTATE <
          DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat)) ||
        ((localX->LockedShaftIntegrator_CSTATE <=
          DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat) && (localB->Inertia >
          0.0)) || ((localX->LockedShaftIntegrator_CSTATE >=
                     DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat) &&
                    (localB->Inertia < 0.0))) {
      localXdot->LockedShaftIntegrator_CSTATE = localB->Inertia;
    } else {
      localXdot->LockedShaftIntegrator_CSTATE = 0.0;
    }

    /* End of Derivatives for Integrator: '<S132>/Locked Shaft Integrator' */
    /* End of Derivatives for SubSystem: '<S126>/Locked' */
    break;

   case 1:
    /* Derivatives for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* Derivatives for Integrator: '<S133>/Pump Integrator' */
    if (localXdis->PumpIntegrator_CSTATE) {
      localXdot->PumpIntegrator_CSTATE = 0.0;
    } else {
      localXdot->PumpIntegrator_CSTATE = localB->ImpellerInertia;
    }

    /* End of Derivatives for Integrator: '<S133>/Pump Integrator' */

    /* Derivatives for Integrator: '<S133>/Turbine Integrator' */
    if (localXdis->TurbineIntegrator_CSTATE) {
      localXdot->TurbineIntegrator_CSTATE = 0.0;
    } else {
      localXdot->TurbineIntegrator_CSTATE = localB->TurbineInertia;
    }

    /* End of Derivatives for Integrator: '<S133>/Turbine Integrator' */

    /* Derivatives for Enabled SubSystem: '<S153>/LPF' */
    if (localDW->LPF_MODE) {
      /* Derivatives for Integrator: '<S157>/Integrator' */
      localXdot->Integrator_CSTATE_e = localB->Product_f;
    } else {
      localXdot->Integrator_CSTATE_e = 0.0;
    }

    /* End of Derivatives for SubSystem: '<S153>/LPF' */
    /* End of Derivatives for SubSystem: '<S126>/Unlocked' */
    break;
  }

  /* End of Derivatives for If: '<S126>/If' */

  /* Derivatives for Integrator: '<S96>/Integrator' */
  localXdot->Integrator_CSTATE_h1 = localB->Product_a;

  /* Derivatives for Integrator: '<S78>/Integrator' */
  localXdot->Integrator_CSTATE_j = localB->Product_d;

  /* Derivatives for Integrator: '<S77>/Integrator' */
  localXdot->Integrator_CSTATE_g4 = localB->Subtract;

  /* Derivatives for If: '<S94>/If' */
  localXdot->w = 0.0;

  {
    real_T *dx;
    int_T i;
    dx = &(localXdot->we);
    for (i=0; i < 2; i++) {
      dx[i] = 0.0;
    }
  }

  switch (localDW->If_ActiveSubsystem_b) {
   case 0:
    /* Derivatives for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* Derivatives for Integrator: '<S98>/x' */
    localXdot->w = localB->Product8_e;

    /* End of Derivatives for SubSystem: '<S94>/Locked' */
    break;

   case 1:
    /* Derivatives for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* Derivatives for Integrator: '<S100>/xe' */
    localXdot->we = localB->Product4_a;

    /* Derivatives for Integrator: '<S100>/xv' */
    localXdot->wv = localB->Product8;

    /* End of Derivatives for SubSystem: '<S94>/Unlocked' */
    break;
  }

  /* End of Derivatives for If: '<S94>/If' */

  /* Derivatives for Integrator: '<S25>/Integrator' */
  if (((localX->Integrator_CSTATE_o[0] > DrivetrainHevP4_P.Integrator_LowerSat) &&
       (localX->Integrator_CSTATE_o[0] < DrivetrainHevP4_P.Integrator_UpperSat))
      || ((localX->Integrator_CSTATE_o[0] <=
           DrivetrainHevP4_P.Integrator_LowerSat) &&
          (localB->sf_OpenDifferential.xdot[0] > 0.0)) ||
      ((localX->Integrator_CSTATE_o[0] >= DrivetrainHevP4_P.Integrator_UpperSat)
       && (localB->sf_OpenDifferential.xdot[0] < 0.0))) {
    localXdot->Integrator_CSTATE_o[0] = localB->sf_OpenDifferential.xdot[0];
  } else {
    localXdot->Integrator_CSTATE_o[0] = 0.0;
  }

  if (((localX->Integrator_CSTATE_o[1] > DrivetrainHevP4_P.Integrator_LowerSat) &&
       (localX->Integrator_CSTATE_o[1] < DrivetrainHevP4_P.Integrator_UpperSat))
      || ((localX->Integrator_CSTATE_o[1] <=
           DrivetrainHevP4_P.Integrator_LowerSat) &&
          (localB->sf_OpenDifferential.xdot[1] > 0.0)) ||
      ((localX->Integrator_CSTATE_o[1] >= DrivetrainHevP4_P.Integrator_UpperSat)
       && (localB->sf_OpenDifferential.xdot[1] < 0.0))) {
    localXdot->Integrator_CSTATE_o[1] = localB->sf_OpenDifferential.xdot[1];
  } else {
    localXdot->Integrator_CSTATE_o[1] = 0.0;
  }

  /* End of Derivatives for Integrator: '<S25>/Integrator' */

  /* Derivatives for Integrator: '<S42>/Integrator' */
  if (((localX->Integrator_CSTATE_n[0] > DrivetrainHevP4_P.Integrator_LowerSat_o)
       && (localX->Integrator_CSTATE_n[0] <
           DrivetrainHevP4_P.Integrator_UpperSat_j)) ||
      ((localX->Integrator_CSTATE_n[0] <=
        DrivetrainHevP4_P.Integrator_LowerSat_o) &&
       (localB->sf_OpenDifferential_l.xdot[0] > 0.0)) ||
      ((localX->Integrator_CSTATE_n[0] >=
        DrivetrainHevP4_P.Integrator_UpperSat_j) &&
       (localB->sf_OpenDifferential_l.xdot[0] < 0.0))) {
    localXdot->Integrator_CSTATE_n[0] = localB->sf_OpenDifferential_l.xdot[0];
  } else {
    localXdot->Integrator_CSTATE_n[0] = 0.0;
  }

  if (((localX->Integrator_CSTATE_n[1] > DrivetrainHevP4_P.Integrator_LowerSat_o)
       && (localX->Integrator_CSTATE_n[1] <
           DrivetrainHevP4_P.Integrator_UpperSat_j)) ||
      ((localX->Integrator_CSTATE_n[1] <=
        DrivetrainHevP4_P.Integrator_LowerSat_o) &&
       (localB->sf_OpenDifferential_l.xdot[1] > 0.0)) ||
      ((localX->Integrator_CSTATE_n[1] >=
        DrivetrainHevP4_P.Integrator_UpperSat_j) &&
       (localB->sf_OpenDifferential_l.xdot[1] < 0.0))) {
    localXdot->Integrator_CSTATE_n[1] = localB->sf_OpenDifferential_l.xdot[1];
  } else {
    localXdot->Integrator_CSTATE_n[1] = 0.0;
  }

  /* End of Derivatives for Integrator: '<S42>/Integrator' */
}

/* ZeroCrossings for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_ZC(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  const real_T *rtu_MotTrq, const real_T *rtu_Grade, const real_T *rtu_WindVel,
  const real_T *rtu_BrkCmd, const real_T *rtu_GearCmd, real_T *rty_EngSpd,
  real_T *rty_TransGear, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, X_DrivetrainHevP4_n_T *localX, ZCV_DrivetrainHevP4_g_T *localZCSV)
{
  /* local block i/o variables */
  real_T rtb_Product4_d;
  real_T VectorConcatenate_m_tmp;
  real_T maxV;
  int32_T i;

  /* Gain: '<S5>/Gain' */
  localB->Gain_c = DrivetrainHevP4_P.Gain_Gain * *rtu_BrkCmd;

  /* Product: '<S232>/product' */
  localB->product = localB->Gain_c * localB->TorqueConversion1 *
    localB->Diskbrakeactuatorbore * localB->Numberofbrakepads;

  /* Saturate: '<S232>/Disallow Negative Brake Torque' */
  if (localB->product > DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat)
  {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat;
  } else if (localB->product <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat) {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat;
  } else {
    /* Saturate: '<S232>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque = localB->product;
  }

  /* End of Saturate: '<S232>/Disallow Negative Brake Torque' */

  /* Gain: '<S232>/Torque Conversion' */
  localB->TorqueConversion = DrivetrainHevP4_P.Rm * DrivetrainHevP4_P.mu_kinetic
    * localB->DisallowNegativeBrakeTorque;

  /* Gain: '<S229>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion;

  /* Outputs for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention,
    localB->Ratioofstatictokinetic, localB->TorqueConversion,
    &localB->ImpAsg_InsertedFor_Omega_at_inport_0_i, &localB->Clutch,
    &localDW->Clutch, &DrivetrainHevP4_P.Clutch, &localX->Clutch);

  /* End of Outputs for SubSystem: '<S217>/Clutch' */

  /* MATLAB Function: '<S213>/Simple Magic Tire' */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation, localB->Integrator1,
    localB->ImpAsg_InsertedFor_Omega_at_inport_0_i, localB->VectorConcatenate2[0],
    localB->D, localB->C, localB->B, localB->E, localB->lam_muxConstant,
    localB->Constant2, localB->kappaFx, localB->FzFx, localB->FxMap,
    localB->TirePrsConstant, localB->FNOMIN, localB->NOMPRES, localB->QSY1,
    localB->QSY2, localB->QSY3, localB->QSY4, localB->QSY5, localB->QSY6,
    localB->QSY7, localB->QSY8, localB->gamma, localB->lam_My,
    localB->UNLOADED_RADIUS, localB->PRESMIN, localB->PRESMAX, localB->VxMy,
    localB->FzMy, localB->MyMap, 0.0, localB->FxType, localB->rollType,
    localB->vertType, &localB->sf_SimpleMagicTire);

  /* Sum: '<S5>/Add' */
  localB->Fx = localB->sf_SimpleMagicTire.Fx + localB->sf_SimpleMagicTire.Fx;

  /* SignalConversion generated from: '<S169>/Vector Concatenate2' */
  localB->VectorConcatenate4[0] = localB->Fx;

  /* Gain: '<S5>/Gain1' */
  localB->Gain1 = DrivetrainHevP4_P.Gain1_Gain * *rtu_BrkCmd;

  /* Product: '<S274>/product' */
  localB->product_p = localB->Gain1 * localB->TorqueConversion1_b *
    localB->Diskbrakeactuatorbore_j * localB->Numberofbrakepads_f;

  /* Saturate: '<S274>/Disallow Negative Brake Torque' */
  if (localB->product_p >
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o) {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o;
  } else if (localB->product_p <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o) {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m =
      DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o;
  } else {
    /* Saturate: '<S274>/Disallow Negative Brake Torque' */
    localB->DisallowNegativeBrakeTorque_m = localB->product_p;
  }

  /* End of Saturate: '<S274>/Disallow Negative Brake Torque' */

  /* Gain: '<S274>/Torque Conversion' */
  localB->TorqueConversion_b = DrivetrainHevP4_P.Rm *
    DrivetrainHevP4_P.mu_kinetic * localB->DisallowNegativeBrakeTorque_m;

  /* Gain: '<S271>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic_i = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion_b;

  /* Outputs for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention_o,
    localB->Ratioofstatictokinetic_i, localB->TorqueConversion_b,
    &localB->ImpAsg_InsertedFor_Omega_at_inport_0, &localB->Clutch_e,
    &localDW->Clutch_e, &DrivetrainHevP4_P.Clutch_e, &localX->Clutch_e);

  /* End of Outputs for SubSystem: '<S259>/Clutch' */

  /* MATLAB Function: '<S255>/Simple Magic Tire' */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation_f, localB->Integrator1_d,
    localB->ImpAsg_InsertedFor_Omega_at_inport_0, localB->VectorConcatenate2[0],
    localB->D_c, localB->C_g, localB->B_d, localB->E_a,
    localB->lam_muxConstant_h, localB->Constant2_p, localB->kappaFx_j,
    localB->FzFx_l, localB->FxMap_h, localB->TirePrsConstant_a, localB->FNOMIN_m,
    localB->NOMPRES_h, localB->QSY1_k, localB->QSY2_g, localB->QSY3_h,
    localB->QSY4_k, localB->QSY5_p, localB->QSY6_i, localB->QSY7_j,
    localB->QSY8_d, localB->gamma_e, localB->lam_My_a, localB->UNLOADED_RADIUS_k,
    localB->PRESMIN_g, localB->PRESMAX_c, localB->VxMy_k, localB->FzMy_g,
    localB->MyMap_d, 0.0, localB->FxType_b, localB->rollType_m,
    localB->vertType_o, &localB->sf_SimpleMagicTire_c);

  /* Sum: '<S5>/Add1' */
  localB->Fx_o = localB->sf_SimpleMagicTire_c.Fx +
    localB->sf_SimpleMagicTire_c.Fx;

  /* SignalConversion generated from: '<S169>/Vector Concatenate2' */
  localB->VectorConcatenate4[1] = localB->Fx_o;

  /* SignalConversion generated from: '<S207>/Vector Concatenate5' */
  localB->VectorConcatenate5_e[0] = *rtu_WindVel;

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[0] = -localB->VectorConcatenate5_e[0];

  /* Sum: '<S206>/Add1' */
  localB->Add1[0] = localB->VectorConcatenate5[0] - localB->UnaryMinus[0];

  /* Product: '<S206>/Product' */
  localB->Product_g[0] = localB->Add1[0] * localB->Add1[0];

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[1] = -localB->VectorConcatenate5_e[1];

  /* Sum: '<S206>/Add1' */
  localB->Add1[1] = localB->VectorConcatenate5[1] - localB->UnaryMinus[1];

  /* Product: '<S206>/Product' */
  localB->Product_g[1] = localB->Add1[1] * localB->Add1[1];

  /* UnaryMinus: '<S169>/Unary Minus' */
  localB->UnaryMinus[2] = -localB->VectorConcatenate5_e[2];

  /* Sum: '<S206>/Add1' */
  localB->Add1[2] = localB->VectorConcatenate5[2] - localB->UnaryMinus[2];

  /* Product: '<S206>/Product' */
  localB->Product_g[2] = localB->Add1[2] * localB->Add1[2];

  /* Sum: '<S206>/Sum of Elements' */
  localB->SumofElements = (localB->Product_g[0] + localB->Product_g[1]) +
    localB->Product_g[2];

  /* Sqrt: '<S206>/Sqrt' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    if (localDW->Sqrt_DWORK1 != 0) {
      ssSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->rtS);
      localDW->Sqrt_DWORK1 = 0;
    }

    /* Sqrt: '<S206>/Sqrt' */
    localB->Sqrt = sqrt(localB->SumofElements);
  } else {
    if (localB->SumofElements < 0.0) {
      /* Sqrt: '<S206>/Sqrt' */
      localB->Sqrt = -sqrt(fabs(localB->SumofElements));
    } else {
      /* Sqrt: '<S206>/Sqrt' */
      localB->Sqrt = sqrt(localB->SumofElements);
    }

    if (localB->SumofElements < 0.0) {
      localDW->Sqrt_DWORK1 = 1;
    }
  }

  /* End of Sqrt: '<S206>/Sqrt' */

  /* Product: '<S206>/Product2' */
  localB->Product2 = localB->Sqrt * localB->Sqrt;

  /* Trigonometry: '<S206>/Trigonometric Function' */
  localB->TrigonometricFunction = rt_atan2d_snf(localB->Add1[1], localB->Add1[0]);

  /* Lookup_n-D: '<S206>/Cs' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[1] = look1_binlcpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cs, 1U);

  /* Lookup_n-D: '<S206>/Crm' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[3] = look1_binlxpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.Crm_bp01Data, DrivetrainHevP4_P.Crm_tableData, 1U);

  /* Gain: '<S206>/4' */
  localB->u[0] = DrivetrainHevP4_P.u_Gain[0] * localB->Add1[0];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[0] = tanh(localB->u[0]);

  /* Gain: '<S206>/4' */
  localB->u[1] = DrivetrainHevP4_P.u_Gain[1] * localB->Add1[1];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[1] = tanh(localB->u[1]);

  /* Gain: '<S206>/4' */
  localB->u[2] = DrivetrainHevP4_P.u_Gain[2] * localB->Add1[2];

  /* Trigonometry: '<S206>/Tanh' */
  localB->Tanh[2] = tanh(localB->u[2]);

  /* Product: '<S206>/Product5' */
  localB->VectorConcatenate_n[4] = localB->Tanh[0] * localB->Constant2_n;

  /* Lookup_n-D: '<S206>/Cym' incorporates:
   *  Trigonometry: '<S206>/Trigonometric Function'
   */
  localB->VectorConcatenate_n[5] = look1_binlxpw(localB->TrigonometricFunction,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cym, 1U);

  /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' */
  maxV = 0.5 * DrivetrainHevP4_P.Af * DrivetrainHevP4_P.Pabs /
    DrivetrainHevP4_P.DragForce_R;
  for (i = 0; i < 6; i++) {
    /* Product: '<S206>/Product1' */
    localB->Product1[i] = localB->Product2 * localB->VectorConcatenate_n[i] /
      localB->AirTempConstant;

    /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' */
    localB->uAPabsRT[i] = maxV * localB->Product1[i];
  }

  /* UnitConversion: '<S166>/Unit Conversion' */
  /* Unit Conversion - from: deg to: rad
     Expression: output = (0.0174533*input) + (0) */
  localB->UnitConversion = 0.017453292519943295 * *rtu_Grade;

  /* Trigonometry: '<S169>/Trigonometric Function2' */
  localB->TrigonometricFunction2_o1 = sin(localB->UnitConversion);

  /* Trigonometry: '<S169>/Trigonometric Function2' */
  localB->TrigonometricFunction2_o2 = cos(localB->UnitConversion);

  /* Product: '<S169>/Product2' */
  localB->Product2_a = localB->TrigonometricFunction2_o2 * localB->Fz;

  /* Product: '<S206>/Product4' */
  localB->Product4_k[0] = localB->uAPabsRT[3] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[0] = localB->Tanh[0] * localB->uAPabsRT[0];

  /* Product: '<S206>/Product4' */
  localB->Product4_k[1] = localB->uAPabsRT[4] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[1] = localB->Tanh[1] * localB->uAPabsRT[1];

  /* Product: '<S206>/Product4' */
  localB->Product4_k[2] = localB->uAPabsRT[5] * localB->Constant3;

  /* Product: '<S206>/Product3' */
  localB->Product3[2] = localB->Tanh[2] * localB->uAPabsRT[2];

  /* Sum: '<S169>/Add6' */
  localB->Add6 = localB->Product4_k[1] + localB->MExtConstant[1];

  /* Sum: '<S169>/Add1' */
  localB->Add1_p = (localB->Product2_a + localB->FExtConstant[2]) +
    localB->Product3[2];

  /* Gain: '<S169>/b' */
  localB->b = DrivetrainHevP4_P.b_CG * localB->Add1_p;

  /* Product: '<S169>/Product1' */
  localB->Product1_l = localB->TrigonometricFunction2_o1 * localB->Fz;

  /* Sum: '<S169>/Add' */
  localB->Add = (((localB->FExtConstant[0] - localB->Product1_l) + localB->Fx) +
                 localB->Fx_o) - localB->Product3[0];

  /* Sum: '<S169>/Add3' */
  localB->Add3 = ((localB->Product3[0] - localB->FExtConstant[0]) +
                  localB->Product1_l) + localB->Add;

  /* Gain: '<S169>/h' */
  localB->h = DrivetrainHevP4_P.h * localB->Add3;

  /* Sum: '<S169>/Add2' */
  localB->Add2 = (localB->b - localB->Add6) - localB->h;

  /* Gain: '<S169>/1//(a+b)' incorporates:
   *  Gain: '<S169>/1//(a+b) '
   */
  maxV = 1.0 / (DrivetrainHevP4_P.a_CG + DrivetrainHevP4_P.b_CG);
  localB->VectorConcatenate4[2] = maxV * localB->Add2;

  /* Gain: '<S169>/a' */
  localB->a = DrivetrainHevP4_P.a_CG * localB->Add1_p;

  /* Sum: '<S169>/Add4' */
  localB->Add4 = (localB->Add6 + localB->a) + localB->h;

  /* Gain: '<S169>/1//(a+b) ' */
  localB->VectorConcatenate4[3] = maxV * localB->Add4;

  /* Selector: '<S178>/Selector1' incorporates:
   *  Concatenate: '<S169>/Vector Concatenate4'
   */
  localB->Selector1[0] = localB->VectorConcatenate4[2];
  localB->Selector1[1] = localB->VectorConcatenate4[3];

  /* Gain: '<S178>/1//NR' */
  localB->Fz_a = 1.0 / DrivetrainHevP4_P.NR * localB->Selector1[1];

  /* Sum: '<S163>/Sum' */
  localB->Sum_c = localB->Fz_a - localB->Integrator1_d;

  /* Product: '<S163>/Divide' */
  localB->Divide = localB->Sum_c * localB->Constant;

  /* Gain: '<S178>/1//NF' */
  localB->Fz_f = 1.0 / DrivetrainHevP4_P.NF * localB->Selector1[0];

  /* Sum: '<S164>/Sum' */
  localB->Sum_l = localB->Fz_f - localB->Integrator1;

  /* Product: '<S164>/Divide' */
  localB->Divide_l = localB->Sum_l * localB->Constant_f;

  /* Sum: '<S174>/Add' */
  localB->Add_m = localB->UnitConversion;

  /* SignalConversion generated from: '<S197>/sincos' */
  localB->TmpSignalConversionAtsincosInport1[0] = localB->Constant_m;
  localB->TmpSignalConversionAtsincosInport1[1] = localB->Add_m;
  localB->TmpSignalConversionAtsincosInport1[2] = localB->Constant_m;

  /* Trigonometry: '<S197>/sincos' */
  localB->sincos_o1[0] = sin(localB->TmpSignalConversionAtsincosInport1[0]);
  localB->sincos_o2[0] = cos(localB->TmpSignalConversionAtsincosInport1[0]);
  localB->sincos_o1[1] = sin(localB->TmpSignalConversionAtsincosInport1[1]);
  localB->sincos_o2[1] = cos(localB->TmpSignalConversionAtsincosInport1[1]);
  localB->sincos_o1[2] = sin(localB->TmpSignalConversionAtsincosInport1[2]);
  localB->sincos_o2[2] = cos(localB->TmpSignalConversionAtsincosInport1[2]);

  /* Fcn: '<S197>/Fcn11' */
  localB->VectorConcatenate_m[0] = localB->sincos_o2[0] * localB->sincos_o2[1];

  /* Fcn: '<S197>/Fcn21' incorporates:
   *  Fcn: '<S197>/Fcn22'
   */
  maxV = localB->sincos_o1[1] * localB->sincos_o1[2];
  localB->VectorConcatenate_m[1] = maxV * localB->sincos_o2[0] -
    localB->sincos_o1[0] * localB->sincos_o2[2];

  /* Fcn: '<S197>/Fcn31' incorporates:
   *  Fcn: '<S197>/Fcn32'
   */
  VectorConcatenate_m_tmp = localB->sincos_o1[1] * localB->sincos_o2[2];
  localB->VectorConcatenate_m[2] = VectorConcatenate_m_tmp * localB->sincos_o2[0]
    + localB->sincos_o1[0] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn12' */
  localB->VectorConcatenate_m[3] = localB->sincos_o1[0] * localB->sincos_o2[1];

  /* Fcn: '<S197>/Fcn22' */
  localB->VectorConcatenate_m[4] = maxV * localB->sincos_o1[0] +
    localB->sincos_o2[0] * localB->sincos_o2[2];

  /* Fcn: '<S197>/Fcn32' */
  localB->VectorConcatenate_m[5] = VectorConcatenate_m_tmp * localB->sincos_o1[0]
    - localB->sincos_o2[0] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn13' */
  localB->VectorConcatenate_m[6] = -localB->sincos_o1[1];

  /* Fcn: '<S197>/Fcn23' */
  localB->VectorConcatenate_m[7] = localB->sincos_o2[1] * localB->sincos_o1[2];

  /* Fcn: '<S197>/Fcn33' */
  localB->VectorConcatenate_m[8] = localB->sincos_o2[1] * localB->sincos_o2[2];

  /* SignalConversion generated from: '<S166>/Vector Concatenate1' */
  localB->VectorConcatenate1[0] = localB->Add;

  /* SignalConversion generated from: '<S166>/Vector Concatenate4' */
  localB->VectorConcatenate4_l[0] = localB->Fx;

  /* SignalConversion generated from: '<S166>/Vector Concatenate4' */
  localB->VectorConcatenate4_l[1] = localB->Fx_o;

  /* SignalConversion generated from: '<S204>/sincos' */
  localB->TmpSignalConversionAtsincosInport1_n[0] = localB->Constant_c;
  localB->TmpSignalConversionAtsincosInport1_n[1] = localB->UnitConversion;
  localB->TmpSignalConversionAtsincosInport1_n[2] = localB->Constant_c;

  /* Trigonometry: '<S204>/sincos' */
  localB->sincos_o1_j[0] = sin(localB->TmpSignalConversionAtsincosInport1_n[0]);
  localB->sincos_o2_l[0] = cos(localB->TmpSignalConversionAtsincosInport1_n[0]);
  localB->sincos_o1_j[1] = sin(localB->TmpSignalConversionAtsincosInport1_n[1]);
  localB->sincos_o2_l[1] = cos(localB->TmpSignalConversionAtsincosInport1_n[1]);
  localB->sincos_o1_j[2] = sin(localB->TmpSignalConversionAtsincosInport1_n[2]);
  localB->sincos_o2_l[2] = cos(localB->TmpSignalConversionAtsincosInport1_n[2]);

  /* Fcn: '<S204>/Fcn11' */
  localB->VectorConcatenate_l[0] = localB->sincos_o2_l[0] * localB->sincos_o2_l
    [1];

  /* Fcn: '<S204>/Fcn21' incorporates:
   *  Fcn: '<S204>/Fcn22'
   */
  maxV = localB->sincos_o1_j[1] * localB->sincos_o1_j[2];
  localB->VectorConcatenate_l[1] = maxV * localB->sincos_o2_l[0] -
    localB->sincos_o1_j[0] * localB->sincos_o2_l[2];

  /* Fcn: '<S204>/Fcn31' incorporates:
   *  Fcn: '<S204>/Fcn32'
   */
  VectorConcatenate_m_tmp = localB->sincos_o1_j[1] * localB->sincos_o2_l[2];
  localB->VectorConcatenate_l[2] = VectorConcatenate_m_tmp * localB->
    sincos_o2_l[0] + localB->sincos_o1_j[0] * localB->sincos_o1_j[2];

  /* Fcn: '<S204>/Fcn12' */
  localB->VectorConcatenate_l[3] = localB->sincos_o1_j[0] * localB->sincos_o2_l
    [1];

  /* Fcn: '<S204>/Fcn22' */
  localB->VectorConcatenate_l[4] = maxV * localB->sincos_o1_j[0] +
    localB->sincos_o2_l[0] * localB->sincos_o2_l[2];

  /* Fcn: '<S204>/Fcn32' */
  localB->VectorConcatenate_l[5] = VectorConcatenate_m_tmp * localB->
    sincos_o1_j[0] - localB->sincos_o2_l[0] * localB->sincos_o1_j[2];

  /* Fcn: '<S204>/Fcn13' */
  localB->VectorConcatenate_l[6] = -localB->sincos_o1_j[1];

  /* Fcn: '<S204>/Fcn23' */
  localB->VectorConcatenate_l[7] = localB->sincos_o2_l[1] * localB->sincos_o1_j
    [2];

  /* Fcn: '<S204>/Fcn33' */
  localB->VectorConcatenate_l[8] = localB->sincos_o2_l[1] * localB->sincos_o2_l
    [2];
  for (i = 0; i < 3; i++) {
    /* Math: '<S168>/Transpose' incorporates:
     *  Concatenate: '<S205>/Vector Concatenate'
     */
    localB->Transpose[3 * i] = localB->VectorConcatenate_l[i];
    localB->Transpose[3 * i + 1] = localB->VectorConcatenate_l[i + 3];
    localB->Transpose[3 * i + 2] = localB->VectorConcatenate_l[i + 6];
  }

  for (i = 0; i < 3; i++) {
    /* Product: '<S168>/Product' incorporates:
     *  Math: '<S168>/Transpose'
     */
    localB->Product_fl[i] = 0.0;
    localB->Product_fl[i] += localB->Transpose[i] *
      localB->TmpSignalConversionAtProductInport2[0];
    localB->Product_fl[i] += localB->Transpose[i + 3] *
      localB->TmpSignalConversionAtProductInport2[1];
    localB->Product_fl[i] += localB->Transpose[i + 6] *
      localB->TmpSignalConversionAtProductInport2[2];
  }

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[0] = localB->Product_fl[0];

  /* SignalConversion generated from: '<S166>/Vector Concatenate6' */
  localB->VectorConcatenate6[2] = localB->Product_fl[2];

  /* Gain: '<S169>/1//m' */
  localB->xddot = 1.0 / DrivetrainHevP4_P.Mass * localB->Add;

  /* SignalConversion generated from: '<S169>/Vector Concatenate1' */
  localB->VectorConcatenate1_f[0] = localB->Product1_l;

  /* SignalConversion generated from: '<S169>/Vector Concatenate1' */
  localB->VectorConcatenate1_f[1] = localB->Product2_a;

  /* Sum: '<S96>/Sum' */
  localB->Sum_j = *rtu_GearCmd - localB->Switch_p;

  /* Product: '<S96>/Product' */
  localB->Product_a = localB->upi * localB->Sum_j;

  /* Product: '<S56>/Product1' */
  localB->Product1_d = *rtu_MotTrq * localB->VectorConcatenate_o[0];

  /* Switch: '<S56>/Switch' */
  if (localB->Product1_d > DrivetrainHevP4_P.Switch_Threshold) {
    /* Switch: '<S56>/Switch' */
    localB->Switch_cp = localB->Constant_g;
  } else {
    /* Switch: '<S56>/Switch' */
    localB->Switch_cp = localB->Constant_pg;
  }

  /* End of Switch: '<S56>/Switch' */

  /* Product: '<S56>/Product4' */
  rtb_Product4_d = localB->Switch_cp * *rtu_MotTrq;

  /* MATLAB Function: '<S42>/Open Differential' */
  DrivetrainHevP4_OpenDifferential(rtb_Product4_d, localB->Product4,
    localB->Product4_o, localB->bw1, localB->bd, localB->bw2, localB->Ndiff2,
    localB->Jd, localB->Jw1, localB->Jw3, localB->Integrator_p,
    &localB->sf_OpenDifferential_l, &DrivetrainHevP4_P.sf_OpenDifferential_l);

  /* UnaryMinus: '<S49>/Unary Minus2' */
  localB->UnaryMinus2[0] = -localB->sf_OpenDifferential_l.xdot[0];
  localB->UnaryMinus2[1] = -localB->sf_OpenDifferential_l.xdot[1];

  /* SignalConversion generated from: '<S49>/Vector Concatenate' */
  localB->omegadot[1] = localB->UnaryMinus2[0];

  /* SignalConversion generated from: '<S49>/Vector Concatenate' */
  localB->omegadot[2] = localB->UnaryMinus2[1];

  /* Product: '<S49>/Product1' */
  localB->Product1_p[0] = localB->diffDir_g * localB->
    sf_OpenDifferential_l.xdot[0];
  localB->Product1_p[1] = localB->diffDir_g * localB->
    sf_OpenDifferential_l.xdot[1];

  /* Gain: '<S49>/Gain1' */
  maxV = DrivetrainHevP4_P.Ndiff_P4 / 2.0;

  /* Gain: '<S49>/Gain1' */
  localB->Gain1_h[0] = maxV * localB->Product1_p[0];
  localB->Gain1_h[1] = maxV * localB->Product1_p[1];

  /* Sum: '<S49>/Sum of Elements2' */
  localB->omegadot[0] = localB->Gain1_h[0] + localB->Gain1_h[1];

  /* Sum: '<S13>/Subtract' */
  localB->Subtract_l = localB->UnaryMinus1_l[0] -
    localB->ImpAsg_InsertedFor_Omega_at_inport_0_i;

  /* Sum: '<S14>/Sum' */
  localB->Sum_h = localB->Subtract_l - localB->Switch_n;

  /* Product: '<S14>/Product' */
  localB->Product_m = localB->omega_c_l * localB->Sum_h;

  /* Sum: '<S60>/Subtract' */
  localB->Subtract_e = localB->UnaryMinus1[0] -
    localB->ImpAsg_InsertedFor_Omega_at_inport_0;

  /* Sum: '<S61>/Sum' */
  localB->Sum_cw = localB->Subtract_e - localB->Switch_c;

  /* Product: '<S61>/Product' */
  localB->Product_b = localB->omega_c_n * localB->Sum_cw;

  /* Product: '<S230>/Product' */
  localB->Product_g3 = localB->sf_SimpleMagicTire.My / localB->Saturation;

  /* Sum: '<S230>/Add' */
  localB->Add_g = localB->sf_SimpleMagicTire.Fx + localB->Product_g3;

  /* Product: '<S230>/Product3' */
  localB->Product3_c = localB->ImpAsg_InsertedFor_Omega_at_inport_0_i *
    localB->Saturation;

  /* Fcn: '<S247>/Fcn' */
  localB->Fcn = 4.0 / (3.0 - rt_powd_snf(localB->Product3_c / 2.0, 2.0));

  /* RelationalOperator: '<S248>/Compare' */
  localB->Compare_i = (localB->Product3_c >= localB->Constant_h);

  /* RelationalOperator: '<S249>/Compare' */
  localB->Compare_a = (localB->Product3_c <= localB->Constant_hu);

  /* Logic: '<S247>/Logical Operator' */
  localB->LogicalOperator = (localB->Compare_i && localB->Compare_a);

  /* Abs: '<S247>/Abs' */
  localB->Abs = fabs(localB->Product3_c);

  /* Switch: '<S247>/Switch' */
  if (localB->LogicalOperator) {
    /* Switch: '<S247>/Switch' */
    localB->Switch_f = localB->Fcn;
  } else {
    /* Switch: '<S247>/Switch' */
    localB->Switch_f = localB->Abs;
  }

  /* End of Switch: '<S247>/Switch' */

  /* Product: '<S230>/Product2' */
  localB->Product2_o = localB->Switch_f / localB->Constant2_f;

  /* Sum: '<S246>/Sum' */
  localB->Sum_i = localB->Add_g - localB->Integrator_h;

  /* Product: '<S246>/Product' */
  localB->Product_o4 = localB->Product2_o * localB->Sum_i;

  /* Product: '<S272>/Product' */
  localB->Product_fv = localB->sf_SimpleMagicTire_c.My / localB->Saturation_f;

  /* Sum: '<S272>/Add' */
  localB->Add_a = localB->sf_SimpleMagicTire_c.Fx + localB->Product_fv;

  /* Product: '<S272>/Product3' */
  localB->Product3_a = localB->ImpAsg_InsertedFor_Omega_at_inport_0 *
    localB->Saturation_f;

  /* Fcn: '<S289>/Fcn' */
  localB->Fcn_b = 4.0 / (3.0 - rt_powd_snf(localB->Product3_a / 2.0, 2.0));

  /* RelationalOperator: '<S290>/Compare' */
  localB->Compare_e = (localB->Product3_a >= localB->Constant_pk);

  /* RelationalOperator: '<S291>/Compare' */
  localB->Compare_l = (localB->Product3_a <= localB->Constant_jn);

  /* Logic: '<S289>/Logical Operator' */
  localB->LogicalOperator_h = (localB->Compare_e && localB->Compare_l);

  /* Abs: '<S289>/Abs' */
  localB->Abs_f = fabs(localB->Product3_a);

  /* Switch: '<S289>/Switch' */
  if (localB->LogicalOperator_h) {
    /* Switch: '<S289>/Switch' */
    localB->Switch_m = localB->Fcn_b;
  } else {
    /* Switch: '<S289>/Switch' */
    localB->Switch_m = localB->Abs_f;
  }

  /* End of Switch: '<S289>/Switch' */

  /* Product: '<S272>/Product2' */
  localB->Product2_j = localB->Switch_m / localB->Constant2_m;

  /* Sum: '<S288>/Sum' */
  localB->Sum_e = localB->Add_a - localB->Integrator_f;

  /* Product: '<S288>/Product' */
  localB->Product_de = localB->Product2_j * localB->Sum_e;

  /* ZeroCrossings for Saturate: '<S151>/Saturation' */
  localZCSV->Saturation_UprLim_ZC = localB->ClutchGain -
    DrivetrainHevP4_P.Saturation_UpperSat_h;
  localZCSV->Saturation_LwrLim_ZC = localB->ClutchGain -
    DrivetrainHevP4_P.Saturation_LowerSat_f;

  /* ZeroCrossings for If: '<S126>/If' */
  {
    real_T* zcsv = &(localZCSV->PumpIntegrator_IntgUpLimit_ZC);
    int_T i;
    for (i=0; i < 9; i++) {
      zcsv[i] = 0.0;
    }
  }

  if (localDW->If_ActiveSubsystem == 1) {
    /* ZeroCrossings for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* ZeroCrossings for Integrator: '<S133>/Pump Integrator' */
    switch (localDW->PumpIntegrator_MODE) {
     case 1:
      localZCSV->PumpIntegrator_IntgUpLimit_ZC = 0.0;
      localZCSV->PumpIntegrator_IntgLoLimit_ZC =
        DrivetrainHevP4_P.PumpIntegrator_UpperSat -
        DrivetrainHevP4_P.PumpIntegrator_LowerSat;
      break;

     case 2:
      localZCSV->PumpIntegrator_IntgUpLimit_ZC =
        DrivetrainHevP4_P.PumpIntegrator_LowerSat -
        DrivetrainHevP4_P.PumpIntegrator_UpperSat;
      localZCSV->PumpIntegrator_IntgLoLimit_ZC = 0.0;
      break;

     default:
      localZCSV->PumpIntegrator_IntgUpLimit_ZC = localX->PumpIntegrator_CSTATE -
        DrivetrainHevP4_P.PumpIntegrator_UpperSat;
      localZCSV->PumpIntegrator_IntgLoLimit_ZC = localX->PumpIntegrator_CSTATE -
        DrivetrainHevP4_P.PumpIntegrator_LowerSat;
      break;
    }

    if ((localDW->PumpIntegrator_MODE == 3) || (localDW->PumpIntegrator_MODE ==
         4)) {
      localZCSV->PumpIntegrator_LeaveSaturate_ZC = localB->ImpellerInertia;
    } else {
      localZCSV->PumpIntegrator_LeaveSaturate_ZC = 0.0;
    }

    /* End of ZeroCrossings for Integrator: '<S133>/Pump Integrator' */

    /* ZeroCrossings for Integrator: '<S133>/Turbine Integrator' */
    switch (localDW->TurbineIntegrator_MODE) {
     case 1:
      localZCSV->TurbineIntegrator_IntgUpLimit_ZC = 0.0;
      localZCSV->TurbineIntegrator_IntgLoLimit_ZC =
        DrivetrainHevP4_P.TurbineIntegrator_UpperSat -
        DrivetrainHevP4_P.TurbineIntegrator_LowerSat;
      break;

     case 2:
      localZCSV->TurbineIntegrator_IntgUpLimit_ZC =
        DrivetrainHevP4_P.TurbineIntegrator_LowerSat -
        DrivetrainHevP4_P.TurbineIntegrator_UpperSat;
      localZCSV->TurbineIntegrator_IntgLoLimit_ZC = 0.0;
      break;

     default:
      localZCSV->TurbineIntegrator_IntgUpLimit_ZC =
        localX->TurbineIntegrator_CSTATE -
        DrivetrainHevP4_P.TurbineIntegrator_UpperSat;
      localZCSV->TurbineIntegrator_IntgLoLimit_ZC =
        localX->TurbineIntegrator_CSTATE -
        DrivetrainHevP4_P.TurbineIntegrator_LowerSat;
      break;
    }

    if ((localDW->TurbineIntegrator_MODE == 3) ||
        (localDW->TurbineIntegrator_MODE == 4)) {
      localZCSV->TurbineIntegrator_LeaveSaturate_ZC = localB->TurbineInertia;
    } else {
      localZCSV->TurbineIntegrator_LeaveSaturate_ZC = 0.0;
    }

    /* End of ZeroCrossings for Integrator: '<S133>/Turbine Integrator' */

    /* ZeroCrossings for MinMax: '<S154>/MinMax' */
    maxV = localB->VectorConcatenate_a[0];
    for (i = 0; i < 10; i++) {
      VectorConcatenate_m_tmp = localB->VectorConcatenate_a[i + 1];
      if ((VectorConcatenate_m_tmp > maxV) || rtIsNaN(maxV)) {
        maxV = VectorConcatenate_m_tmp;
      }
    }

    localZCSV->MinMax_MinmaxInput_ZC = maxV - localB->
      VectorConcatenate_a[localDW->MinMax_MODE];

    /* End of ZeroCrossings for MinMax: '<S154>/MinMax' */

    /* ZeroCrossings for RelationalOperator: '<S159>/LowerRelop1' */
    localZCSV->LowerRelop1_RelopInput_ZC = localB->phi - localB->MinMax;

    /* ZeroCrossings for RelationalOperator: '<S159>/UpperRelop' */
    localZCSV->UpperRelop_RelopInput_ZC = localB->phi - localB->Gain;

    /* End of ZeroCrossings for SubSystem: '<S126>/Unlocked' */
  }

  /* End of ZeroCrossings for If: '<S126>/If' */

  /* ZeroCrossings for Abs: '<S135>/Abs' */
  localZCSV->Abs_AbsZc_ZC = localB->SumofElements1;

  /* ZeroCrossings for Relay: '<S149>/Relay1' */
  if (localDW->Relay1_Mode) {
    localZCSV->Relay1_RelayZC_ZC = *rty_EngSpd - DrivetrainHevP4_P.omegau;
  } else {
    localZCSV->Relay1_RelayZC_ZC = *rty_EngSpd - DrivetrainHevP4_P.omegal;
  }

  /* End of ZeroCrossings for Relay: '<S149>/Relay1' */

  /* ZeroCrossings for RelationalOperator: '<S149>/Relational Operator' incorporates:
   *  Constant: '<S149>/Constant'
   */
  localZCSV->RelationalOperator_RelopInput_ZC = localB->SpdRatio -
    DrivetrainHevP4_P.philu;

  /* ZeroCrossings for If: '<S94>/If' */
  localZCSV->If_IfInput_ZC = 0.0;
  if (*rty_TransGear != 0.0) {
    localZCSV->If_IfInput_ZC = 1.0;
  }

  {
    localZCSV->Abs_AbsZc_ZC_d = 0.0;
  }

  if (localDW->If_ActiveSubsystem_b == 0) {
    /* ZeroCrossings for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* ZeroCrossings for Abs: '<S98>/Abs' */
    localZCSV->Abs_AbsZc_ZC_d = localB->N_c;

    /* End of ZeroCrossings for SubSystem: '<S94>/Locked' */
  }

  {
    localZCSV->Abs_AbsZc_ZC_o = 0.0;
  }

  if (localDW->If_ActiveSubsystem_b == 1) {
    /* ZeroCrossings for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* ZeroCrossings for Abs: '<S100>/Abs' */
    localZCSV->Abs_AbsZc_ZC_o = localB->N;

    /* End of ZeroCrossings for SubSystem: '<S94>/Unlocked' */
  }

  /* End of ZeroCrossings for If: '<S94>/If' */
}

/* Model initialize function */
void DrivetrainHevP4_initialize(SimStruct *const rtS,
  ssNonContDerivSigFeedingOutports **mr_nonContOutputArray, int_T mdlref_TID0,
  int_T mdlref_TID1, RT_MODEL_DrivetrainHevP4_T *const DrivetrainHevP4_M,
  B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  X_DrivetrainHevP4_n_T *localX, ZCE_DrivetrainHevP4_T *localZCE,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat = rtInf;
  DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o = rtInf;
  DrivetrainHevP4_P.Saturation1_LowerSat = rtMinusInf;
  DrivetrainHevP4_P.Saturation2_UpperSat = rtInf;
  DrivetrainHevP4_P.Saturation1_LowerSat_k = rtMinusInf;
  DrivetrainHevP4_P.Saturation2_UpperSat_b = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_b = rtInf;
  DrivetrainHevP4_P.uniclutch_UpperSat = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_f = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_p = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_h = rtInf;
  DrivetrainHevP4_P.Saturation1_LowerSat_h = rtMinusInf;

  /* initialize real-time model */
  (void) memset((void *)DrivetrainHevP4_M, 0,
                sizeof(RT_MODEL_DrivetrainHevP4_T));

  /* setup the global timing engine */
  DrivetrainHevP4_M->Timing.mdlref_GlobalTID[0] = mdlref_TID0;
  DrivetrainHevP4_M->Timing.mdlref_GlobalTID[1] = mdlref_TID1;
  DrivetrainHevP4_M->rtS = (rtS);

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_DrivetrainHevP4_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_DrivetrainHevP4_f_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  {
    DrivetrainHevP4_InitializeDataMapInfo(DrivetrainHevP4_M, localB);
  }

  /* Initialize Parent model MMI */
  if ((rt_ParentMMI != (NULL)) && (rt_ChildPath != (NULL))) {
    rtwCAPI_SetChildMMI(*rt_ParentMMI, rt_ChildMMIIdx,
                        &(DrivetrainHevP4_M->DataMapInfo.mmi));
    rtwCAPI_SetPath(DrivetrainHevP4_M->DataMapInfo.mmi, rt_ChildPath);
    rtwCAPI_MMISetContStateStartIndex(DrivetrainHevP4_M->DataMapInfo.mmi,
      rt_CSTATEIdx);
  }

  DrivetrainHevP4_M->nonContDerivSignal[0].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig0;
  DrivetrainHevP4_M->nonContDerivSignal[0].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[0].pCurrVal = (char_T *)
    (&localB->diffDir_n);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[1].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig1;
  DrivetrainHevP4_M->nonContDerivSignal[1].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[1].pCurrVal = (char_T *)
    (&localB->diffDir);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[2].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig2;
  DrivetrainHevP4_M->nonContDerivSignal[2].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[2].pCurrVal = (char_T *)
    (&localB->Memory_ku);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[3].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig3;
  DrivetrainHevP4_M->nonContDerivSignal[3].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[3].pCurrVal = (char_T *)
    (&localB->Memory_o);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[4].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig4;
  DrivetrainHevP4_M->nonContDerivSignal[4].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[4].pCurrVal = (char_T *)(&localB->upi);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[5].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig5;
  DrivetrainHevP4_M->nonContDerivSignal[5].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[5].pCurrVal = (char_T *)
    (&localB->DataTypeConversion);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[6].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig6;
  DrivetrainHevP4_M->nonContDerivSignal[6].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[6].pCurrVal = (char_T *)(&localB->Hz2rad);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[7].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig7;
  DrivetrainHevP4_M->nonContDerivSignal[7].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[7].pCurrVal = (char_T *)
    (&localB->Memory_b);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[8].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig8;
  DrivetrainHevP4_M->nonContDerivSignal[8].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[8].pCurrVal = (char_T *)
    (&localB->Memory_k);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[9].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig9;
  DrivetrainHevP4_M->nonContDerivSignal[9].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[9].pCurrVal = (char_T *)(&localB->Fz);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[10].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig10;
  DrivetrainHevP4_M->nonContDerivSignal[10].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[10].pCurrVal = (char_T *)
    (&localB->TorqueConversion1_b);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[11].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig11;
  DrivetrainHevP4_M->nonContDerivSignal[11].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[11].pCurrVal = (char_T *)
    (&localB->Memory_f);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[12].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig12;
  DrivetrainHevP4_M->nonContDerivSignal[12].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[12].pCurrVal = (char_T *)
    (&localB->Saturation_f);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[13].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig13;
  DrivetrainHevP4_M->nonContDerivSignal[13].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[13].pCurrVal = (char_T *)
    (&localB->TorqueConversion1);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[14].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig14;
  DrivetrainHevP4_M->nonContDerivSignal[14].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[14].pCurrVal = (char_T *)
    (&localB->Memory);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[15].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig15;
  DrivetrainHevP4_M->nonContDerivSignal[15].sizeInBytes = (1*sizeof(real_T));
  DrivetrainHevP4_M->nonContDerivSignal[15].pCurrVal = (char_T *)
    (&localB->Saturation);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[16].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig16;
  DrivetrainHevP4_M->nonContDerivSignal[16].sizeInBytes = (1*sizeof(boolean_T));
  DrivetrainHevP4_M->nonContDerivSignal[16].pCurrVal = (char_T *)
    (&localB->UpperRelop);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[17].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig17;
  DrivetrainHevP4_M->nonContDerivSignal[17].sizeInBytes = (1*sizeof(boolean_T));
  DrivetrainHevP4_M->nonContDerivSignal[17].pCurrVal = (char_T *)
    (&localB->LowerRelop1);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[18].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig18;
  DrivetrainHevP4_M->nonContDerivSignal[18].sizeInBytes = (1*sizeof(boolean_T));
  DrivetrainHevP4_M->nonContDerivSignal[18].pCurrVal = (char_T *)
    (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.RelationalOperator);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[19].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig19;
  DrivetrainHevP4_M->nonContDerivSignal[19].sizeInBytes = (1*sizeof(boolean_T));
  DrivetrainHevP4_M->nonContDerivSignal[19].pCurrVal = (char_T *)
    (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.CombinatorialLogic);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[20].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig20;
  DrivetrainHevP4_M->nonContDerivSignal[20].sizeInBytes = (1*sizeof(boolean_T));
  DrivetrainHevP4_M->nonContDerivSignal[20].pCurrVal = (char_T *)
    (&localB->Clutch.CoreSubsys[0].sf_Clutch.RelationalOperator);
  ;
  DrivetrainHevP4_M->nonContDerivSignal[21].pPrevVal = (char_T *)
    DrivetrainHevP4_M->NonContDerivMemory.mr_nonContSig21;
  DrivetrainHevP4_M->nonContDerivSignal[21].sizeInBytes = (1*sizeof(boolean_T));
  DrivetrainHevP4_M->nonContDerivSignal[21].pCurrVal = (char_T *)
    (&localB->Clutch.CoreSubsys[0].sf_Clutch.CombinatorialLogic);
  ;
  if (mr_nonContOutputArray[3] != (NULL)) {
    mr_nonContOutputArray[3][0].sizeInBytes = 1*sizeof(boolean_T);
    mr_nonContOutputArray[3][0].currVal = (char_T *)&localB->Memory_kc;
    mr_nonContOutputArray[3][0].next = &(mr_nonContOutputArray[3][1]);
  }

  if (mr_nonContOutputArray[3] != (NULL)) {
    mr_nonContOutputArray[3][1].sizeInBytes = 1*sizeof(boolean_T);
    mr_nonContOutputArray[3][1].currVal = (char_T *)&localB->VelocitiesMatch;
    mr_nonContOutputArray[3][1].next = (NULL);
  }

  if (mr_nonContOutputArray[4] != (NULL)) {
    mr_nonContOutputArray[4][0].sizeInBytes = 1*sizeof(real_T);
    mr_nonContOutputArray[4][0].currVal = (char_T *)&localB->diffDir_n;
    mr_nonContOutputArray[4][0].next = (NULL);
  }

  localZCE->Integrator_Reset_ZCE = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_a = UNINITIALIZED_ZCSIG;
  localZCE->VelocitiesMatch_Input_ZCE = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_j = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_f = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_m = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_fz = UNINITIALIZED_ZCSIG;
}
