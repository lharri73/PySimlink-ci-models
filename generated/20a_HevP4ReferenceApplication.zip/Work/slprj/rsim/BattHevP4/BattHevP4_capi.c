/*
 * BattHevP4_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "BattHevP4".
 *
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Sat Jul 23 23:54:01 2022
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "BattHevP4_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "BattHevP4.h"
#include "BattHevP4_capi.h"
#include "BattHevP4_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 1, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Output Filter/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 1, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Output Filter/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 2, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/MaxLdPwr"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 3, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 4, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 5, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 6, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 7, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Divide1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 8, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 9, 1, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Unary Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 10, 1, TARGET_STRING(
    "BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 11, 1, TARGET_STRING(
    "BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 12, 1, TARGET_STRING(
    "BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/State of Charge Capacity/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 13, 1, TARGET_STRING(
    "BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly/Compare To Constant/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 14, 1, TARGET_STRING(
    "BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly/Compare To Constant1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 15, 1, TARGET_STRING(
    "BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Compare To Constant/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 16, 1, TARGET_STRING(
    "BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Compare To Constant1/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 17, TARGET_STRING("BattHevP4/SOC Ratio to %1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 18, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 19, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 20, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 21, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 22, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 23, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 24, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 25, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 26, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 27, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Integrator Limited"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 28, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Voltage and Power Calculation/R"),
    TARGET_STRING("maxIndex"), 1, 1, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 29, TARGET_STRING("BattCapInit"), 0, 0, 0 },

  { 30, TARGET_STRING("BattChargeMax"), 0, 0, 0 },

  { 31, TARGET_STRING("BattTempBp"), 0, 2, 0 },

  { 32, TARGET_STRING("CapLUTBp"), 0, 3, 0 },

  { 33, TARGET_STRING("CapSOCBp"), 0, 4, 0 },

  { 34, TARGET_STRING("Em"), 0, 3, 0 },

  { 35, TARGET_STRING("Np"), 0, 0, 0 },

  { 36, TARGET_STRING("Ns"), 0, 0, 0 },

  { 37, TARGET_STRING("Plimit"), 0, 0, 0 },

  { 38, TARGET_STRING("RInt"), 0, 5, 0 },

  { 39, TARGET_STRING("Tc"), 0, 0, 0 },

  { 40, TARGET_STRING("Vinit"), 0, 0, 0 },

  { 41, TARGET_STRING("eff"), 0, 0, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void BattHevP4_InitializeDataAddr(void* dataAddr[], B_BattHevP4_c_T
  *localB)
{
  dataAddr[0] = (void*) (&localB->Product);
  dataAddr[1] = (void*) (&localB->Sum_i);
  dataAddr[2] = (void*) (&localB->MaxLdPwr);
  dataAddr[3] = (void*) (&localB->Gain2);
  dataAddr[4] = (void*) (&localB->Sum);
  dataAddr[5] = (void*) (&localB->Switch);
  dataAddr[6] = (void*) (&localB->Divide);
  dataAddr[7] = (void*) (&localB->Divide1);
  dataAddr[8] = (void*) (&localB->Constant_l);
  dataAddr[9] = (void*) (&localB->UnaryMinus);
  dataAddr[10] = (void*) (&localB->Gain1);
  dataAddr[11] = (void*) (&localB->Switch_i);
  dataAddr[12] = (void*) (&localB->Constant1);
  dataAddr[13] = (void*) (&localB->Constant);
  dataAddr[14] = (void*) (&localB->Constant_o);
  dataAddr[15] = (void*) (&localB->Constant_i);
  dataAddr[16] = (void*) (&localB->Constant_on);
  dataAddr[17] = (void*) (&BattHevP4_P.SOCRatioto1_Gain);
  dataAddr[18] = (void*) (&BattHevP4_P.div0protectabspoly_thresh);
  dataAddr[19] = (void*) (&BattHevP4_P.Constant_Value);
  dataAddr[20] = (void*) (&BattHevP4_P.Switch_Threshold);
  dataAddr[21] = (void*) (&BattHevP4_P.div0protectpoly_thresh);
  dataAddr[22] = (void*) (&BattHevP4_P.Constant1_Value);
  dataAddr[23] = (void*) (&BattHevP4_P.Constant2_Value);
  dataAddr[24] = (void*) (&BattHevP4_P.Switch_Threshold_d);
  dataAddr[25] = (void*) (&BattHevP4_P.Constant_Value_j);
  dataAddr[26] = (void*) (&BattHevP4_P.Switch1_Threshold);
  dataAddr[27] = (void*) (&BattHevP4_P.IntegratorLimited_LowerSat);
  dataAddr[28] = (void*) (&BattHevP4_P.R_maxIndex[0]);
  dataAddr[29] = (void*) (&BattHevP4_P.BattCapInit);
  dataAddr[30] = (void*) (&BattHevP4_P.BattChargeMax);
  dataAddr[31] = (void*) (&BattHevP4_P.BattTempBp[0]);
  dataAddr[32] = (void*) (&BattHevP4_P.CapLUTBp[0]);
  dataAddr[33] = (void*) (&BattHevP4_P.CapSOCBp[0]);
  dataAddr[34] = (void*) (&BattHevP4_P.Em[0]);
  dataAddr[35] = (void*) (&BattHevP4_P.Np);
  dataAddr[36] = (void*) (&BattHevP4_P.Ns);
  dataAddr[37] = (void*) (&BattHevP4_P.Plimit);
  dataAddr[38] = (void*) (&BattHevP4_P.RInt[0]);
  dataAddr[39] = (void*) (&BattHevP4_P.Tc);
  dataAddr[40] = (void*) (&BattHevP4_P.Vinit);
  dataAddr[41] = (void*) (&BattHevP4_P.eff);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void BattHevP4_InitializeVarDimsAddr(int32_T* vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void BattHevP4_InitializeLoggingFunctions(RTWLoggingFcnPtr loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
  loggingPtrs[14] = (NULL);
  loggingPtrs[15] = (NULL);
  loggingPtrs[16] = (NULL);
  loggingPtrs[17] = (NULL);
  loggingPtrs[18] = (NULL);
  loggingPtrs[19] = (NULL);
  loggingPtrs[20] = (NULL);
  loggingPtrs[21] = (NULL);
  loggingPtrs[22] = (NULL);
  loggingPtrs[23] = (NULL);
  loggingPtrs[24] = (NULL);
  loggingPtrs[25] = (NULL);
  loggingPtrs[26] = (NULL);
  loggingPtrs[27] = (NULL);
  loggingPtrs[28] = (NULL);
  loggingPtrs[29] = (NULL);
  loggingPtrs[30] = (NULL);
  loggingPtrs[31] = (NULL);
  loggingPtrs[32] = (NULL);
  loggingPtrs[33] = (NULL);
  loggingPtrs[34] = (NULL);
  loggingPtrs[35] = (NULL);
  loggingPtrs[36] = (NULL);
  loggingPtrs[37] = (NULL);
  loggingPtrs[38] = (NULL);
  loggingPtrs[39] = (NULL);
  loggingPtrs[40] = (NULL);
  loggingPtrs[41] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  2,                                   /* 2 */
  1,                                   /* 3 */
  1,                                   /* 4 */
  7,                                   /* 5 */
  1,                                   /* 6 */
  101,                                 /* 7 */
  1,                                   /* 8 */
  6,                                   /* 9 */
  7,                                   /* 10 */
  6                                    /* 11 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0, 1.0
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[0],
    0, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 17,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 12,
    rtModelParameters, 13 },

  { (NULL), 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 4100167833U,
    3401363007U,
    2024867776U,
    4265624905U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  BattHevP4_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void BattHevP4_InitializeDataMapInfo(RT_MODEL_BattHevP4_T *const BattHevP4_M,
  B_BattHevP4_c_T *localB)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(BattHevP4_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(BattHevP4_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(BattHevP4_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  BattHevP4_InitializeDataAddr(BattHevP4_M->DataMapInfo.dataAddress, localB);
  rtwCAPI_SetDataAddressMap(BattHevP4_M->DataMapInfo.mmi,
    BattHevP4_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  BattHevP4_InitializeVarDimsAddr(BattHevP4_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(BattHevP4_M->DataMapInfo.mmi,
    BattHevP4_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(BattHevP4_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(BattHevP4_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  BattHevP4_InitializeLoggingFunctions(BattHevP4_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(BattHevP4_M->DataMapInfo.mmi,
    BattHevP4_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(BattHevP4_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(BattHevP4_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(BattHevP4_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void BattHevP4_host_InitializeDataMapInfo(BattHevP4_host_DataMapInfo_T
    *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: BattHevP4_capi.c */
