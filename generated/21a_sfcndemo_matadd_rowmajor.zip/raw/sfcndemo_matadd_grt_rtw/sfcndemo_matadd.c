/*
 * sfcndemo_matadd.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sfcndemo_matadd".
 *
 * Model version              : 5.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 19:31:30 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "sfcndemo_matadd_capi.h"
#include "sfcndemo_matadd.h"
#include "sfcndemo_matadd_private.h"

/* Block signals (default storage) */
B_sfcndemo_matadd_T sfcndemo_matadd_B;

/* Real-time model */
static RT_MODEL_sfcndemo_matadd_T sfcndemo_matadd_M_;
RT_MODEL_sfcndemo_matadd_T *const sfcndemo_matadd_M = &sfcndemo_matadd_M_;

/* Model step function */
void sfcndemo_matadd_step(void)
{
  /* S-Function (sfun_matadd): '<Root>/Scalar param' incorporates:
   *  Constant: '<Root>/Constant'
   */
  /* S-Function Block: <Root>/Scalar param */
  sfcndemo_matadd_B.Scalarparam = sfcndemo_matadd_P.Constant_Value +
    sfcndemo_matadd_P.Scalarparam_Operand;

  /* S-Function (sfun_matadd): '<Root>/Matrix param2' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  /* S-Function Block: <Root>/Matrix param2 */
  {
    int_T i1;
    const real_T *u0 = &sfcndemo_matadd_P.Constant1_Value[0];
    real_T *y0 = &sfcndemo_matadd_B.Matrixparam2[0];
    const real_T *p_Matrixparam2_Operand =
      sfcndemo_matadd_P.Matrixparam2_Operand;
    for (i1=0; i1 < 8; i1++) {
      y0[i1] = u0[i1] + p_Matrixparam2_Operand[i1];
    }
  }

  ;

  /* S-Function (sfun_matadd): '<Root>/Matrix param' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  /* S-Function Block: <Root>/Matrix param */
  sfcndemo_matadd_B.Matrixparam[0] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[0];
  sfcndemo_matadd_B.Matrixparam[1] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[1];
  sfcndemo_matadd_B.Matrixparam[2] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[2];
  sfcndemo_matadd_B.Matrixparam[3] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[3];

  /* S-Function (sfun_matadd): '<Root>/Scalar param1' incorporates:
   *  Constant: '<Root>/Constant3'
   */
  /* S-Function Block: <Root>/Scalar param1 */
  sfcndemo_matadd_B.Scalarparam1[0] = sfcndemo_matadd_P.Constant3_Value[0] +
    sfcndemo_matadd_P.Scalarparam1_Operand;
  sfcndemo_matadd_B.Scalarparam1[1] = sfcndemo_matadd_P.Constant3_Value[1] +
    sfcndemo_matadd_P.Scalarparam1_Operand;
  ;

  /* S-Function (sfun_matadd): '<Root>/Matrix param1' incorporates:
   *  Constant: '<Root>/Constant5'
   */
  /* S-Function Block: <Root>/Matrix param1 */
  {
    int_T i1;
    const real_T *u0 = &sfcndemo_matadd_P.Constant5_Value[0];
    real_T *y0 = &sfcndemo_matadd_B.Matrixparam1[0];
    const real_T *p_Matrixparam1_Operand =
      sfcndemo_matadd_P.Matrixparam1_Operand;
    for (i1=0; i1 < 6; i1++) {
      y0[i1] = u0[i1] + p_Matrixparam1_Operand[i1];
    }
  }

  ;
}

/* Model initialize function */
void sfcndemo_matadd_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)sfcndemo_matadd_M, 0,
                sizeof(RT_MODEL_sfcndemo_matadd_T));

  /* block I/O */
  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      sfcndemo_matadd_B.Matrixparam2[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      sfcndemo_matadd_B.Matrixparam1[i] = 0.0;
    }

    sfcndemo_matadd_B.Scalarparam = 0.0;
    sfcndemo_matadd_B.Matrixparam[0] = 0.0;
    sfcndemo_matadd_B.Matrixparam[1] = 0.0;
    sfcndemo_matadd_B.Matrixparam[2] = 0.0;
    sfcndemo_matadd_B.Matrixparam[3] = 0.0;
    sfcndemo_matadd_B.Scalarparam1[0] = 0.0;
    sfcndemo_matadd_B.Scalarparam1[1] = 0.0;
  }

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  sfcndemo_matadd_InitializeDataMapInfo();
}

/* Model terminate function */
void sfcndemo_matadd_terminate(void)
{
  /* (no terminate code required) */
}
