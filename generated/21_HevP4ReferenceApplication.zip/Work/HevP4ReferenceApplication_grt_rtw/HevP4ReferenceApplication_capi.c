/*
 * HevP4ReferenceApplication_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4ReferenceApplication".
 *
 * Model version              : 2.47
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:42 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "HevP4ReferenceApplication_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "HevP4ReferenceApplication.h"
#include "HevP4ReferenceApplication_capi.h"
#include "HevP4ReferenceApplication_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 0, TARGET_STRING("HevP4ReferenceApplication/Visualization/m//s to mph"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 0, TARGET_STRING("HevP4ReferenceApplication/Visualization/rad//s to rpm"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 2, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition"),
    TARGET_STRING("AccelPdl"), 0, 0, 1, 0, 1 },

  { 3, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition13"),
    TARGET_STRING("BattV"), 0, 0, 1, 0, 1 },

  { 4, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition15"),
    TARGET_STRING("MotSpd"), 0, 0, 1, 0, 1 },

  { 5, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition16"),
    TARGET_STRING("VehSpdFdbk"), 0, 0, 1, 0, 1 },

  { 6, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition17"),
    TARGET_STRING("EngSpd"), 0, 0, 1, 0, 1 },

  { 7, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition18"),
    TARGET_STRING("TransGear"), 0, 0, 1, 0, 1 },

  { 8, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition19"),
    TARGET_STRING("BattSoc"), 0, 0, 1, 0, 1 },

  { 9, 0, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition8"),
    TARGET_STRING("DecelPdl"), 0, 0, 1, 0, 1 },

  { 10, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 11, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 1, 0, 1, 0, 2 },

  { 12, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 2, 0, 1, 0, 2 },

  { 13, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 3, 0, 1, 0, 2 },

  { 14, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 4, 0, 1, 0, 2 },

  { 15, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 5, 0, 1, 0, 2 },

  { 16, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 6, 0, 1, 0, 2 },

  { 17, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 7, 0, 1, 0, 2 },

  { 18, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 8, 0, 1, 0, 2 },

  { 19, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 9, 0, 1, 0, 2 },

  { 20, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 10, 0, 1, 0, 2 },

  { 21, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 11, 0, 1, 0, 2 },

  { 22, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 12, 0, 1, 0, 2 },

  { 23, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 13, 0, 1, 0, 2 },

  { 24, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController"),
    TARGET_STRING(""), 14, 0, 1, 0, 2 },

  { 25, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Transmission Control Module (TCM)"),
    TARGET_STRING("GearCmd"), 0, 0, 1, 0, 1 },

  { 26, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Manual Switch"),
    TARGET_STRING("IgSw"), 0, 1, 1, 0, 0 },

  { 27, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain/Drivetrain"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 28, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain/Drivetrain"),
    TARGET_STRING(""), 1, 0, 1, 0, 0 },

  { 29, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain/Drivetrain"),
    TARGET_STRING(""), 3, 1, 1, 0, 0 },

  { 30, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain/Drivetrain"),
    TARGET_STRING(""), 4, 0, 1, 0, 0 },

  { 31, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain/Drivetrain"),
    TARGET_STRING(""), 5, 0, 1, 0, 0 },

  { 32, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/Transfer Fcn"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 33, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold"),
    TARGET_STRING("Cltch1Cmd"), 0, 0, 1, 0, 0 },

  { 34, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold1"),
    TARGET_STRING("BrkCmd"), 0, 0, 1, 0, 0 },

  { 35, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold2"),
    TARGET_STRING("GearCmd"), 0, 0, 1, 0, 0 },

  { 36, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery"),
    TARGET_STRING("BattSoc"), 0, 0, 1, 0, 0 },

  { 37, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery"),
    TARGET_STRING("BattV"), 1, 0, 1, 0, 0 },

  { 38, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery"),
    TARGET_STRING("BattCrnt"), 2, 0, 1, 0, 0 },

  { 39, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery"),
    TARGET_STRING(""), 3, 0, 1, 0, 0 },

  { 40, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery Discharge Dynamics"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 41, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Motor Coupling Dynamics"),
    TARGET_STRING("MotTrq"), 0, 0, 1, 0, 0 },

  { 42, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant Input/First Order Hold"),
    TARGET_STRING("MotTrqCmd"), 0, 0, 1, 0, 0 },

  { 43, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 44, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 1, 0, 1, 0, 0 },

  { 45, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 4, 0, 1, 0, 0 },

  { 46, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 5, 0, 1, 0, 0 },

  { 47, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 6, 0, 1, 0, 0 },

  { 48, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 7, 0, 1, 0, 0 },

  { 49, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 8, 0, 1, 0, 0 },

  { 50, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 9, 0, 1, 0, 0 },

  { 51, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 10, 0, 1, 0, 0 },

  { 52, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 11, 0, 1, 0, 0 },

  { 53, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 12, 0, 1, 0, 0 },

  { 54, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 13, 0, 1, 0, 0 },

  { 55, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 19, 0, 1, 0, 0 },

  { 56, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 30, 0, 1, 0, 0 },

  { 57, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 31, 0, 1, 0, 0 },

  { 58, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 32, 0, 1, 0, 0 },

  { 59, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 33, 0, 1, 0, 0 },

  { 60, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine"),
    TARGET_STRING(""), 35, 0, 1, 0, 2 },

  { 61, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 62, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold1"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 63, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold10"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 64, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold11"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 65, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold12"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 66, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold13"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 67, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold14"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 68, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold2"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 69, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold3"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 70, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold4"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 71, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold5"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 72, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold6"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 73, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold7"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 74, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold8"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 75, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold9"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 76, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/Unit Conversion15"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 77, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/L//100 Km Calc"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 78, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/L//100 Km Calc1"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 79, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/L//100 Km Calc2"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 80, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/L//100 Km Calc3"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 81, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Performance Calculations/US MPG Calc"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 82, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Performance Calculations/Add"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 83, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Performance Calculations/Sqrt"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 84, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 0, 0, 1, 0, 1 },

  { 85, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 1, 0, 1, 0, 1 },

  { 86, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 2, 0, 1, 0, 1 },

  { 87, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 3, 0, 1, 0, 1 },

  { 88, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 4, 0, 1, 0, 1 },

  { 89, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 5, 0, 1, 0, 1 },

  { 90, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal"),
    TARGET_STRING(""), 6, 0, 1, 0, 1 },

  { 91, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/Digital Clock"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 92, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/1-D Lookup Table"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 93, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/Add1"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 94, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Electric Machine/MotMapped"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 95, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Electric Machine/MotMapped"),
    TARGET_STRING(""), 1, 0, 1, 0, 0 },

  { 96, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Gain"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 97, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Product"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 98, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 99, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Unit Delay"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 100, 13, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Shift Controller"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 101, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Logical Operator2"),
    TARGET_STRING(""), 0, 1, 1, 0, 2 },

  { 102, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Cont LPF/Divide"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 103, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Logical Operator2"),
    TARGET_STRING(""), 0, 1, 1, 0, 2 },

  { 104, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 105, 2, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Signal Hold/Pass Through"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 106, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Signal Hold/NOT"),
    TARGET_STRING(""), 0, 1, 1, 0, 2 },

  { 107, 5, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Signal Hold/Pass Through"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 108, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Signal Hold/NOT"),
    TARGET_STRING(""), 0, 1, 1, 0, 2 },

  { 109, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Compare To Zero1/Compare"),
    TARGET_STRING(""), 0, 1, 1, 0, 2 },

  { 110, 2, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Signal Hold/Pass Through/u"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 111, 5, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Signal Hold/Pass Through/u"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 112, TARGET_STRING("HevP4ReferenceApplication/Environment/Constant2"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 113, TARGET_STRING("HevP4ReferenceApplication/Environment/Constant3"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 114, TARGET_STRING("HevP4ReferenceApplication/Environment/Constant6"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 115, TARGET_STRING("HevP4ReferenceApplication/Environment/Constant7"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 116, TARGET_STRING("HevP4ReferenceApplication/Visualization/m//s to mph"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 117, TARGET_STRING("HevP4ReferenceApplication/Visualization/rad//s to rpm"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 118, TARGET_STRING("HevP4ReferenceApplication/Controllers/PCM Input/Rate Transition1"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 119, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("m"), 0, 1, 0 },

  { 120, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("Kpt"), 0, 1, 0 },

  { 121, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("tau"), 0, 1, 0 },

  { 122, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("L"), 0, 1, 0 },

  { 123, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("aR"), 0, 1, 0 },

  { 124, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("bR"), 0, 1, 0 },

  { 125, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("cR"), 0, 1, 0 },

  { 126, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("g"), 0, 1, 0 },

  { 127, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("GearInit"), 0, 1, 0 },

  { 128, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver"),
    TARGET_STRING("tShift"), 0, 1, 0 },

  { 129, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Constant"),
    TARGET_STRING("Value"), 1, 1, 0 },

  { 130, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Manual Switch"),
    TARGET_STRING("CurrentSetting"), 2, 1, 0 },

  { 131, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/Transfer Fcn"),
    TARGET_STRING("A"), 0, 1, 0 },

  { 132, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/Transfer Fcn"),
    TARGET_STRING("C"), 0, 1, 0 },

  { 133, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 134, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 135, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold1"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 136, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold1"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 137, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold2"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 138, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/First Order Hold2"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 139, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery Discharge Dynamics"),
    TARGET_STRING("A"), 0, 1, 0 },

  { 140, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery Discharge Dynamics"),
    TARGET_STRING("C"), 0, 1, 0 },

  { 141, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Electric Plant/Motor Coupling Dynamics"),
    TARGET_STRING("A"), 0, 1, 0 },

  { 142, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Electric Plant/Motor Coupling Dynamics"),
    TARGET_STRING("C"), 0, 1, 0 },

  { 143, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Electric Plant Input/First Order Hold"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 144, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Electric Plant Input/First Order Hold"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 145, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/Sensor Dynamics"),
    TARGET_STRING("A"), 0, 1, 0 },

  { 146, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/Sensor Dynamics"),
    TARGET_STRING("C"), 0, 1, 0 },

  { 147, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 148, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 149, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold1"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 150, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold1"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 151, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold10"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 152, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold10"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 153, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold11"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 154, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold11"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 155, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold12"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 156, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold12"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 157, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold13"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 158, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold13"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 159, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold14"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 160, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold14"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 161, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold2"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 162, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold2"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 163, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold3"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 164, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold3"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 165, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold4"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 166, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold4"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 167, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold5"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 168, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold5"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 169, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold6"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 170, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold6"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 171, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold7"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 172, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold7"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 173, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold8"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 174, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold8"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 175, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold9"),
    TARGET_STRING("InitialOutput"), 0, 1, 0 },

  { 176, TARGET_STRING("HevP4ReferenceApplication/Passenger Car/Engine Plant Input/First Order Hold9"),
    TARGET_STRING("ErrorTolerance"), 0, 1, 0 },

  { 177, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Kg to g"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 178, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Kg to g "),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 179, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Kg to g  "),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 180, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Kg to g   "),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 181, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/m to km"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 182, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/m to mi"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 183, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 184, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 185, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator2"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 186, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator3"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 187, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator4"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 188, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 189, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 190, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 191, TARGET_STRING("HevP4ReferenceApplication/Visualization/Emission Calculations/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 192, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/US EPA kwh//USgal equivalent"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 193, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/s per h"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 194, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/w per kw"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 195, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/m to mile"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 196, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/m^3 per gal"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 197, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/m^3 to US Gal"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 198, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 199, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 200, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 201, TARGET_STRING("HevP4ReferenceApplication/Visualization/Performance Calculations/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 202, TARGET_STRING("HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/repeat"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 203, TARGET_STRING("HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/tFinal"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 204, TARGET_STRING("HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/Hit  Crossing"),
    TARGET_STRING("HitCrossingOffset"), 0, 1, 0 },

  { 205, TARGET_STRING("HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/1-D Lookup Table"),
    TARGET_STRING("Table"), 0, 2, 0 },

  { 206, TARGET_STRING("HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/1-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 2, 0 },

  { 207, TARGET_STRING("HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/Switch"),
    TARGET_STRING("Threshold"), 0, 1, 0 },

  { 208, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Integrator2"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 209, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 3, 0 },

  { 210, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Signal Hold"),
    TARGET_STRING("IC"), 0, 1, 0 },

  { 211, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 212, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/0~1"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 213, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/0~1"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 214, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 215, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 216, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Cont LPF/Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 217, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Signal Hold"),
    TARGET_STRING("IC"), 0, 1, 0 },

  { 218, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 219, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/-1~0"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 220, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/-1~0"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 221, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 1, 0 },

  { 222, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 1, 0 },

  { 223, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 224, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Constant1"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 225, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 226, TARGET_STRING("HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Compare To Zero1/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static const rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 227, 0, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input/Transfer Fcn"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 228, 49, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery Discharge Dynamics"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 229, 1, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Electric Plant/Motor Coupling Dynamics"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 230, 34, TARGET_STRING(
    "HevP4ReferenceApplication/Passenger Car/Engine Plant Input/Sensor Dynamics"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 231, 55, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 232, 56, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 233, 57, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator2"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 234, 58, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator3"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 235, 59, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Emission Calculations/Integrator4"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 236, 53, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Performance Calculations/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 237, 54, TARGET_STRING(
    "HevP4ReferenceApplication/Visualization/Performance Calculations/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 238, 61, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Integrator2"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 239, -1, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics/Unit Delay"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 2, 0, -1, 0 },

  { 240, 60, TARGET_STRING(
    "HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Cont LPF/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Root Inputs information */
static const rtwCAPI_Signals rtRootInputs[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

/* Root Outputs information */
static const rtwCAPI_Signals rtRootOutputs[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &HevP4ReferenceApplication_B.mstomph[0],/* 0: Signal */
  &HevP4ReferenceApplication_B.radstorpm,/* 1: Signal */
  &HevP4ReferenceApplication_B.AccelPdl,/* 2: Signal */
  &HevP4ReferenceApplication_B.BattV_k,/* 3: Signal */
  &HevP4ReferenceApplication_B.MotSpd, /* 4: Signal */
  &HevP4ReferenceApplication_B.VehSpdFdbk,/* 5: Signal */
  &HevP4ReferenceApplication_B.EngSpd_d,/* 6: Signal */
  &HevP4ReferenceApplication_B.TransGear,/* 7: Signal */
  &HevP4ReferenceApplication_B.BattSoc_l,/* 8: Signal */
  &HevP4ReferenceApplication_B.DecelPdl,/* 9: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o1,/* 10: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o2,/* 11: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o3,/* 12: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o4,/* 13: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o5,/* 14: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o6,/* 15: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o7,/* 16: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o8,/* 17: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o9,/* 18: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o10,/* 19: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o11,/* 20: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o12,/* 21: Signal */
  &HevP4ReferenceApplication_B.ClsdLpFuelMult,/* 22: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o14,/* 23: Signal */
  &HevP4ReferenceApplication_B.SiEngineController_o15,/* 24: Signal */
  &HevP4ReferenceApplication_B.GearCmd_a,/* 25: Signal */
  &HevP4ReferenceApplication_B.IgSw,   /* 26: Signal */
  &HevP4ReferenceApplication_B.xdot,   /* 27: Signal */
  &HevP4ReferenceApplication_B.Drivetrain_o2,/* 28: Signal */
  &HevP4ReferenceApplication_B.Drivetrain_o4,/* 29: Signal */
  &HevP4ReferenceApplication_B.Drivetrain_o5,/* 30: Signal */
  &HevP4ReferenceApplication_B.Drivetrain_o6,/* 31: Signal */
  &HevP4ReferenceApplication_B.TransferFcn,/* 32: Signal */
  &HevP4ReferenceApplication_B.Cltch1Cmd_j,/* 33: Signal */
  &HevP4ReferenceApplication_B.BrkCmd, /* 34: Signal */
  &HevP4ReferenceApplication_B.GearCmd,/* 35: Signal */
  &HevP4ReferenceApplication_B.BattSoc,/* 36: Signal */
  &HevP4ReferenceApplication_B.BattV,  /* 37: Signal */
  &HevP4ReferenceApplication_B.BattCrnt,/* 38: Signal */
  &HevP4ReferenceApplication_B.Battery_o4,/* 39: Signal */
  &HevP4ReferenceApplication_B.BatteryDischargeDynamics,/* 40: Signal */
  &HevP4ReferenceApplication_B.MotTrq, /* 41: Signal */
  &HevP4ReferenceApplication_B.MotTrqCmd,/* 42: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o1,/* 43: Signal */
  &HevP4ReferenceApplication_B.EngSpd, /* 44: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o5,/* 45: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o6,/* 46: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o7,/* 47: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o8,/* 48: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o9,/* 49: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o10,/* 50: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o11,/* 51: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o12,/* 52: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o13,/* 53: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o14,/* 54: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o20,/* 55: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o31,/* 56: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o32,/* 57: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o33,/* 58: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o34,/* 59: Signal */
  &HevP4ReferenceApplication_B.SiMappedEngine_o36,/* 60: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold,/* 61: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold1,/* 62: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold10,/* 63: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold11,/* 64: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold12,/* 65: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold13,/* 66: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold14,/* 67: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold2,/* 68: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold3,/* 69: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold4,/* 70: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold5,/* 71: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold6,/* 72: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold7,/* 73: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold8,/* 74: Signal */
  &HevP4ReferenceApplication_B.FirstOrderHold9,/* 75: Signal */
  &HevP4ReferenceApplication_B.UnitConversion15,/* 76: Signal */
  &HevP4ReferenceApplication_B.L100KmCalc,/* 77: Signal */
  &HevP4ReferenceApplication_B.L100KmCalc1,/* 78: Signal */
  &HevP4ReferenceApplication_B.L100KmCalc2,/* 79: Signal */
  &HevP4ReferenceApplication_B.L100KmCalc3,/* 80: Signal */
  &HevP4ReferenceApplication_B.USMPGCalc,/* 81: Signal */
  &HevP4ReferenceApplication_B.Add,    /* 82: Signal */
  &HevP4ReferenceApplication_B.Sqrt,   /* 83: Signal */
  &HevP4ReferenceApplication_B.EngTrqCmd,/* 84: Signal */
  &HevP4ReferenceApplication_B.MtrTrqCmd,/* 85: Signal */
  &HevP4ReferenceApplication_B.BrkCmd_b,/* 86: Signal */
  &HevP4ReferenceApplication_B.Cltch1Cmd,/* 87: Signal */
  &HevP4ReferenceApplication_B.StartCmd,/* 88: Signal */
  &HevP4ReferenceApplication_B.Neutral,/* 89: Signal */
  &HevP4ReferenceApplication_B.WhlTrqCmd,/* 90: Signal */
  &HevP4ReferenceApplication_B.DigitalClock,/* 91: Signal */
  &HevP4ReferenceApplication_B.uDLookupTable,/* 92: Signal */
  &HevP4ReferenceApplication_B.Add1,   /* 93: Signal */
  &HevP4ReferenceApplication_B.MotMapped_o1,/* 94: Signal */
  &HevP4ReferenceApplication_B.MotMapped_o2,/* 95: Signal */
  &HevP4ReferenceApplication_B.Gain,   /* 96: Signal */
  &HevP4ReferenceApplication_B.Product,/* 97: Signal */
  &HevP4ReferenceApplication_B.Switch_c[0],/* 98: Signal */
  &HevP4ReferenceApplication_B.UnitDelay[0],/* 99: Signal */
  &HevP4ReferenceApplication_B.Gear,   /* 100: Signal */
  &HevP4ReferenceApplication_B.LogicalOperator2,/* 101: Signal */
  &HevP4ReferenceApplication_B.Divide, /* 102: Signal */
  &HevP4ReferenceApplication_B.LogicalOperator2_o,/* 103: Signal */
  &HevP4ReferenceApplication_B.Switch[0],/* 104: Signal */
  &HevP4ReferenceApplication_B.PassThrough.u,/* 105: Signal */
  &HevP4ReferenceApplication_B.NOT,    /* 106: Signal */
  &HevP4ReferenceApplication_B.PassThrough_b.u,/* 107: Signal */
  &HevP4ReferenceApplication_B.NOT_n,  /* 108: Signal */
  &HevP4ReferenceApplication_B.Compare,/* 109: Signal */
  &HevP4ReferenceApplication_B.PassThrough.u,/* 110: Signal */
  &HevP4ReferenceApplication_B.PassThrough_b.u,/* 111: Signal */
  &HevP4ReferenceApplication_P.Constant2_Value,/* 112: Block Parameter */
  &HevP4ReferenceApplication_P.Constant3_Value,/* 113: Block Parameter */
  &HevP4ReferenceApplication_P.Constant6_Value,/* 114: Block Parameter */
  &HevP4ReferenceApplication_P.Constant7_Value,/* 115: Block Parameter */
  &HevP4ReferenceApplication_P.mstomph_Gain,/* 116: Block Parameter */
  &HevP4ReferenceApplication_P.radstorpm_Gain,/* 117: Block Parameter */
  &HevP4ReferenceApplication_P.RateTransition1_InitialCondition,/* 118: Block Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_m,/* 119: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_Kpt,/* 120: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_tau,/* 121: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_L,/* 122: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_aR,/* 123: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_bR,/* 124: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_cR,/* 125: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_g,/* 126: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_GearInit,/* 127: Mask Parameter */
  &HevP4ReferenceApplication_P.LongitudinalDriver_tShift,/* 128: Mask Parameter */
  &HevP4ReferenceApplication_P.Constant_Value_e,/* 129: Block Parameter */
  &HevP4ReferenceApplication_P.ManualSwitch_CurrentSetting,/* 130: Block Parameter */
  &HevP4ReferenceApplication_P.TransferFcn_A,/* 131: Block Parameter */
  &HevP4ReferenceApplication_P.TransferFcn_C,/* 132: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold_IniOut_e,/* 133: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold_ErrTol_m,/* 134: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold1_IniOut,/* 135: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold1_ErrTol,/* 136: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold2_IniOut,/* 137: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold2_ErrTol,/* 138: Block Parameter */
  &HevP4ReferenceApplication_P.BatteryDischargeDynamics_A,/* 139: Block Parameter */
  &HevP4ReferenceApplication_P.BatteryDischargeDynamics_C,/* 140: Block Parameter */
  &HevP4ReferenceApplication_P.MotorCouplingDynamics_A,/* 141: Block Parameter */
  &HevP4ReferenceApplication_P.MotorCouplingDynamics_C,/* 142: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold_IniOut_o,/* 143: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold_ErrTol_f,/* 144: Block Parameter */
  &HevP4ReferenceApplication_P.SensorDynamics_A,/* 145: Block Parameter */
  &HevP4ReferenceApplication_P.SensorDynamics_C,/* 146: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold_IniOut,/* 147: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold_ErrTol,/* 148: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold1_IniOut_d,/* 149: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold1_ErrTol_j,/* 150: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold10_IniOut,/* 151: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold10_ErrTol,/* 152: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold11_IniOut,/* 153: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold11_ErrTol,/* 154: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold12_IniOut,/* 155: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold12_ErrTol,/* 156: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold13_IniOut,/* 157: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold13_ErrTol,/* 158: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold14_IniOut,/* 159: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold14_ErrTol,/* 160: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold2_IniOut_g,/* 161: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold2_ErrTol_f,/* 162: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold3_IniOut,/* 163: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold3_ErrTol,/* 164: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold4_IniOut,/* 165: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold4_ErrTol,/* 166: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold5_IniOut,/* 167: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold5_ErrTol,/* 168: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold6_IniOut,/* 169: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold6_ErrTol,/* 170: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold7_IniOut,/* 171: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold7_ErrTol,/* 172: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold8_IniOut,/* 173: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold8_ErrTol,/* 174: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold9_IniOut,/* 175: Block Parameter */
  &HevP4ReferenceApplication_P.FirstOrderHold9_ErrTol,/* 176: Block Parameter */
  &HevP4ReferenceApplication_P.Kgtog_Gain,/* 177: Block Parameter */
  &HevP4ReferenceApplication_P.Kgtog_Gain_l,/* 178: Block Parameter */
  &HevP4ReferenceApplication_P.Kgtog_Gain_f,/* 179: Block Parameter */
  &HevP4ReferenceApplication_P.Kgtog_Gain_c,/* 180: Block Parameter */
  &HevP4ReferenceApplication_P.mtokm_Gain,/* 181: Block Parameter */
  &HevP4ReferenceApplication_P.mtomi_Gain,/* 182: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator_IC_p,/* 183: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator1_IC_k,/* 184: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator2_IC,/* 185: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator3_IC,/* 186: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator4_IC,/* 187: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation_UpperSat,/* 188: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation_LowerSat,/* 189: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation1_UpperSat_h,/* 190: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation1_LowerSat_d,/* 191: Block Parameter */
  &HevP4ReferenceApplication_P.USEPAkwhUSgalequivalent_Value,/* 192: Block Parameter */
  &HevP4ReferenceApplication_P.sperh_Value,/* 193: Block Parameter */
  &HevP4ReferenceApplication_P.wperkw_Value,/* 194: Block Parameter */
  &HevP4ReferenceApplication_P.mtomile_Gain,/* 195: Block Parameter */
  &HevP4ReferenceApplication_P.m3pergal_Gain,/* 196: Block Parameter */
  &HevP4ReferenceApplication_P.m3toUSGal_Gain,/* 197: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator_IC,/* 198: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator1_IC,/* 199: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation1_UpperSat,/* 200: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation1_LowerSat,/* 201: Block Parameter */
  &HevP4ReferenceApplication_P.repeat_Value,/* 202: Block Parameter */
  &HevP4ReferenceApplication_P.tFinal_Value,/* 203: Block Parameter */
  &HevP4ReferenceApplication_P.HitCrossing_Offset,/* 204: Block Parameter */
  &HevP4ReferenceApplication_P.uDLookupTable_tableData[0],/* 205: Block Parameter */
  &HevP4ReferenceApplication_P.uDLookupTable_bp01Data[0],/* 206: Block Parameter */
  &HevP4ReferenceApplication_P.Switch_Threshold,/* 207: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator2_IC_o,/* 208: Block Parameter */
  &HevP4ReferenceApplication_P.UnitDelay_InitialCondition[0],/* 209: Block Parameter */
  &HevP4ReferenceApplication_P.SignalHold_IC,/* 210: Mask Parameter */
  &HevP4ReferenceApplication_P.Constant_Value_f,/* 211: Block Parameter */
  &HevP4ReferenceApplication_P.u1_UpperSat,/* 212: Block Parameter */
  &HevP4ReferenceApplication_P.u1_LowerSat,/* 213: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation_UpperSat_j,/* 214: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation_LowerSat_f,/* 215: Block Parameter */
  &HevP4ReferenceApplication_P.Integrator1_IC_f,/* 216: Block Parameter */
  &HevP4ReferenceApplication_P.SignalHold_IC_b,/* 217: Mask Parameter */
  &HevP4ReferenceApplication_P.Constant_Value_fg,/* 218: Block Parameter */
  &HevP4ReferenceApplication_P.u0_UpperSat,/* 219: Block Parameter */
  &HevP4ReferenceApplication_P.u0_LowerSat,/* 220: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation_UpperSat_o,/* 221: Block Parameter */
  &HevP4ReferenceApplication_P.Saturation_LowerSat_n,/* 222: Block Parameter */
  &HevP4ReferenceApplication_P.Constant_Value_a,/* 223: Block Parameter */
  &HevP4ReferenceApplication_P.Constant1_Value,/* 224: Block Parameter */
  &HevP4ReferenceApplication_P.Constant_Value,/* 225: Block Parameter */
  &HevP4ReferenceApplication_P.Constant_Value_l,/* 226: Block Parameter */
  &HevP4ReferenceApplication_X.TransferFcn_CSTATE,/* 227: Continuous State */
  &HevP4ReferenceApplication_X.BatteryDischargeDynamics_CSTATE,/* 228: Continuous State */
  &HevP4ReferenceApplication_X.MotorCouplingDynamics_CSTATE,/* 229: Continuous State */
  &HevP4ReferenceApplication_X.SensorDynamics_CSTATE,/* 230: Continuous State */
  &HevP4ReferenceApplication_X.Integrator_CSTATE_m,/* 231: Continuous State */
  &HevP4ReferenceApplication_X.Integrator1_CSTATE_a,/* 232: Continuous State */
  &HevP4ReferenceApplication_X.Integrator2_CSTATE,/* 233: Continuous State */
  &HevP4ReferenceApplication_X.Integrator3_CSTATE,/* 234: Continuous State */
  &HevP4ReferenceApplication_X.Integrator4_CSTATE,/* 235: Continuous State */
  &HevP4ReferenceApplication_X.Integrator_CSTATE,/* 236: Continuous State */
  &HevP4ReferenceApplication_X.Integrator1_CSTATE,/* 237: Continuous State */
  &HevP4ReferenceApplication_X.Integrator2_CSTATE_m,/* 238: Continuous State */
  &HevP4ReferenceApplication_DW.UnitDelay_DSTATE[0],/* 239: Discrete State */
  &HevP4ReferenceApplication_X.Integrator1_CSTATE_o,/* 240: Continuous State */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0, 0 },

  { "unsigned char", "uint8_T", 0, 0, sizeof(uint8_T), SS_UINT8, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_VECTOR, 0, 2, 0 },

  { rtwCAPI_SCALAR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  2,                                   /* 0 */
  1,                                   /* 1 */
  1,                                   /* 2 */
  1,                                   /* 3 */
  2474,                                /* 4 */
  1,                                   /* 5 */
  1,                                   /* 6 */
  2                                    /* 7 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0, 0.01, 0.0001, 0.5
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[0],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[0],
    2, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[0],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[3], (const void *) &rtcapiStoredFloats[0],
    4, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 112,
    rtRootInputs, 0,
    rtRootOutputs, 0 },

  { rtBlockParameters, 115,
    rtModelParameters, 0 },

  { rtBlockStates, 14 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 1528459157U,
    3268827771U,
    3049678933U,
    1881524938U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  HevP4ReferenceApplication_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void HevP4ReferenceApplication_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(HevP4ReferenceApplication_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(HevP4ReferenceApplication_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(HevP4ReferenceApplication_M->DataMapInfo.mmi,
    (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(HevP4ReferenceApplication_M->DataMapInfo.mmi,
    rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(HevP4ReferenceApplication_M->DataMapInfo.mmi,
    rtVarDimsAddrMap);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(HevP4ReferenceApplication_M->DataMapInfo.mmi,
    (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(HevP4ReferenceApplication_M->DataMapInfo.mmi,
    HevP4ReferenceApplication_M->DataMapInfo.childMMI);
  rtwCAPI_SetChildMMIArrayLen(HevP4ReferenceApplication_M->DataMapInfo.mmi, 7);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void HevP4ReferenceApplication_host_InitializeDataMapInfo
    (HevP4ReferenceApplication_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    dataMap->childMMI[0] = &(dataMap->child0.mmi);
    HevP4OptimalController_host_InitializeDataMapInfo(&(dataMap->child0),
      "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)/Hybrid Control Module (HCM) - Optimal");
    dataMap->childMMI[1] = &(dataMap->child1.mmi);
    SiEngineController_host_InitializeDataMapInfo(&(dataMap->child1),
      "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/SiEngineController");
    dataMap->childMMI[2] = &(dataMap->child2.mmi);
    HevP4TransmissionController_host_InitializeDataMapInfo(&(dataMap->child2),
      "HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Transmission Control Module (TCM)");
    dataMap->childMMI[3] = &(dataMap->child3.mmi);
    DrivetrainHevP4_host_InitializeDataMapInfo(&(dataMap->child3),
      "HevP4ReferenceApplication/Passenger Car/Drivetrain/Drivetrain");
    dataMap->childMMI[4] = &(dataMap->child4.mmi);
    BattHevP4_host_InitializeDataMapInfo(&(dataMap->child4),
      "HevP4ReferenceApplication/Passenger Car/Electric Plant/Battery");
    dataMap->childMMI[5] = &(dataMap->child5.mmi);
    MotMappedP4_host_InitializeDataMapInfo(&(dataMap->child5),
      "HevP4ReferenceApplication/Passenger Car/Electric Plant/Electric Machine/MotMapped");
    dataMap->childMMI[6] = &(dataMap->child6.mmi);
    SiMappedEngine_host_InitializeDataMapInfo(&(dataMap->child6),
      "HevP4ReferenceApplication/Passenger Car/Engine/SiMappedEngine");
    rtwCAPI_SetChildMMIArray(dataMap->mmi, dataMap->childMMI);
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 7);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: HevP4ReferenceApplication_capi.c */
