/*
 * HevP4ReferenceApplication.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4ReferenceApplication".
 *
 * Model version              : 2.47
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:42 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HevP4ReferenceApplication_h_
#define RTW_HEADER_HevP4ReferenceApplication_h_
#include <math.h>
#include <string.h>
#include <float.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef HevP4ReferenceApplication_COMMON_INCLUDES_
#define HevP4ReferenceApplication_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                          /* HevP4ReferenceApplication_COMMON_INCLUDES_ */

#include "HevP4ReferenceApplication_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"

/* Child system includes */
#include "DrivetrainHevP4.h"
#include "SiMappedEngine.h"
#include "BattHevP4.h"
#include "SiEngineController.h"
#include "HevP4OptimalController.h"
#include "HevP4TransmissionController.h"
#include "MotMappedP4.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm)         ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val)    ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetErrorStatusPointer
#define rtmGetErrorStatusPointer(rtm)  ((const char_T **)(&((rtm)->errorStatus)))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals for system '<S35>/Pass Through' */
typedef struct {
  real_T u;                            /* '<S36>/u' */
} B_PassThrough_HevP4ReferenceApplication_T;

/* Block states (default storage) for system '<S35>/Pass Through' */
typedef struct {
  boolean_T PassThrough_MODE;          /* '<S35>/Pass Through' */
} DW_PassThrough_HevP4ReferenceApplication_T;

/* Block signals (default storage) */
typedef struct {
  real_T uDLookupTable;                /* '<S13>/1-D Lookup Table' */
  real_T TransferFcn;                  /* '<S49>/Transfer Fcn' */
  real_T MotTrq;                       /* '<S50>/Motor Coupling Dynamics' */
  real_T BrkCmd;                       /* '<S49>/First Order Hold1' */
  real_T GearCmd;                      /* '<S49>/First Order Hold2' */
  real_T xdot;                         /* '<S47>/Drivetrain' */
  real_T Drivetrain_o2;                /* '<S47>/Drivetrain' */
  real_T Drivetrain_o5;                /* '<S47>/Drivetrain' */
  real_T Drivetrain_o6;                /* '<S47>/Drivetrain' */
  real_T mstomph[2];                   /* '<S6>/m//s to mph' */
  real_T FirstOrderHold;               /* '<S54>/First Order Hold' */
  real_T FirstOrderHold1;              /* '<S54>/First Order Hold1' */
  real_T FirstOrderHold5;              /* '<S54>/First Order Hold5' */
  real_T FirstOrderHold6;              /* '<S54>/First Order Hold6' */
  real_T FirstOrderHold7;              /* '<S54>/First Order Hold7' */
  real_T FirstOrderHold8;              /* '<S54>/First Order Hold8' */
  real_T FirstOrderHold9;              /* '<S54>/First Order Hold9' */
  real_T FirstOrderHold10;             /* '<S54>/First Order Hold10' */
  real_T FirstOrderHold11;             /* '<S54>/First Order Hold11' */
  real_T FirstOrderHold12;             /* '<S54>/First Order Hold12' */
  real_T FirstOrderHold13;             /* '<S54>/First Order Hold13' */
  real_T FirstOrderHold14;             /* '<S54>/First Order Hold14' */
  real_T UnitConversion15;             /* '<S54>/Unit Conversion15' */
  real_T SiMappedEngine_o1;            /* '<S53>/SiMappedEngine' */
  real_T EngSpd;                       /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o5;            /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o6;            /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o7;            /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o8;            /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o9;            /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o10;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o11;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o12;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o13;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o14;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o20;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o31;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o32;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o33;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o34;           /* '<S53>/SiMappedEngine' */
  real_T SiMappedEngine_o36;           /* '<S53>/SiMappedEngine' */
  real_T radstorpm;                    /* '<S6>/rad//s to rpm' */
  real_T BatteryDischargeDynamics;     /* '<S50>/Battery Discharge Dynamics' */
  real_T BattSoc;                      /* '<S50>/Battery' */
  real_T BattV;                        /* '<S50>/Battery' */
  real_T BattCrnt;                     /* '<S50>/Battery' */
  real_T Battery_o4;                   /* '<S50>/Battery' */
  real_T USMPGCalc;                    /* '<S58>/US MPG Calc' */
  real_T L100KmCalc;                   /* '<S57>/L//100 Km Calc' */
  real_T L100KmCalc1;                  /* '<S57>/L//100 Km Calc1' */
  real_T L100KmCalc2;                  /* '<S57>/L//100 Km Calc2' */
  real_T L100KmCalc3;                  /* '<S57>/L//100 Km Calc3' */
  real_T Add;                          /* '<S58>/Add' */
  real_T Sqrt;                         /* '<S58>/Sqrt' */
  real_T BattV_k;                      /* '<S7>/Rate Transition13' */
  real_T MotSpd;                       /* '<S7>/Rate Transition15' */
  real_T VehSpdFdbk;                   /* '<S7>/Rate Transition16' */
  real_T EngSpd_d;                     /* '<S7>/Rate Transition17' */
  real_T TransGear;                    /* '<S7>/Rate Transition18' */
  real_T BattSoc_l;                    /* '<S7>/Rate Transition19' */
  real_T Gain;                         /* '<S28>/Gain' */
  real_T Switch[2];                    /* '<S43>/Switch' */
  real_T AccelPdl;                     /* '<S7>/Rate Transition' */
  real_T DecelPdl;                     /* '<S7>/Rate Transition8' */
  real_T SiEngineController_o1;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o2;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o3;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o4;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o5;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o6;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o7;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o8;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o9;        /* '<S9>/SiEngineController' */
  real_T SiEngineController_o10;       /* '<S9>/SiEngineController' */
  real_T SiEngineController_o11;       /* '<S9>/SiEngineController' */
  real_T SiEngineController_o12;       /* '<S9>/SiEngineController' */
  real_T ClsdLpFuelMult;               /* '<S9>/SiEngineController' */
  real_T SiEngineController_o14;       /* '<S9>/SiEngineController' */
  real_T SiEngineController_o15;       /* '<S9>/SiEngineController' */
  real_T EngTrqCmd;          /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T MtrTrqCmd;          /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T BrkCmd_b;           /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T Cltch1Cmd;          /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T StartCmd;           /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T Neutral;            /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T WhlTrqCmd;          /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  real_T GearCmd_a;               /* '<S9>/Transmission Control Module (TCM)' */
  real_T DigitalClock;                 /* '<S13>/Digital Clock' */
  real_T Add1;                         /* '<S13>/Add1' */
  real_T Divide;                       /* '<S30>/Divide' */
  real_T Product;                      /* '<S41>/Product' */
  real_T UnitDelay[2];                 /* '<S41>/Unit Delay' */
  real_T Switch_c[2];                  /* '<S41>/Switch' */
  real_T Cltch1Cmd_j;                  /* '<S49>/First Order Hold' */
  real_T MotTrqCmd;                    /* '<S51>/First Order Hold' */
  real_T MotMapped_o1;                 /* '<S56>/MotMapped' */
  real_T MotMapped_o2;                 /* '<S56>/MotMapped' */
  real_T FirstOrderHold2;              /* '<S54>/First Order Hold2' */
  real_T FirstOrderHold3;              /* '<S54>/First Order Hold3' */
  real_T FirstOrderHold4;              /* '<S54>/First Order Hold4' */
  real_T Gear;                         /* '<S42>/Shift Controller' */
  boolean_T Drivetrain_o4;             /* '<S47>/Drivetrain' */
  boolean_T LogicalOperator2;          /* '<S29>/Logical Operator2' */
  boolean_T NOT;                       /* '<S35>/NOT' */
  boolean_T LogicalOperator2_o;        /* '<S31>/Logical Operator2' */
  boolean_T NOT_n;                     /* '<S37>/NOT' */
  boolean_T Compare;                   /* '<S46>/Compare' */
  boolean_T IgSw;                      /* '<S19>/Manual Switch' */
  B_PassThrough_HevP4ReferenceApplication_T PassThrough_b;/* '<S37>/Pass Through' */
  B_PassThrough_HevP4ReferenceApplication_T PassThrough;/* '<S35>/Pass Through' */
} B_HevP4ReferenceApplication_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE[2];          /* '<S41>/Unit Delay' */
  real_T Tk;                           /* '<S49>/First Order Hold1' */
  real_T Ck;                           /* '<S49>/First Order Hold1' */
  real_T Mk;                           /* '<S49>/First Order Hold1' */
  real_T Uk;                           /* '<S49>/First Order Hold1' */
  real_T Tk_j;                         /* '<S49>/First Order Hold2' */
  real_T Ck_a;                         /* '<S49>/First Order Hold2' */
  real_T Mk_d;                         /* '<S49>/First Order Hold2' */
  real_T Uk_p;                         /* '<S49>/First Order Hold2' */
  volatile real_T RateTransition4_Buffer0[2];/* '<S6>/Rate Transition4' */
  real_T Tk_p;                         /* '<S54>/First Order Hold' */
  real_T Ck_h;                         /* '<S54>/First Order Hold' */
  real_T Mk_l;                         /* '<S54>/First Order Hold' */
  real_T Uk_n;                         /* '<S54>/First Order Hold' */
  real_T Tk_e;                         /* '<S54>/First Order Hold1' */
  real_T Ck_ht;                        /* '<S54>/First Order Hold1' */
  real_T Mk_k;                         /* '<S54>/First Order Hold1' */
  real_T Uk_c;                         /* '<S54>/First Order Hold1' */
  real_T Tk_ej;                        /* '<S54>/First Order Hold5' */
  real_T Ck_i;                         /* '<S54>/First Order Hold5' */
  real_T Mk_f;                         /* '<S54>/First Order Hold5' */
  real_T Uk_m;                         /* '<S54>/First Order Hold5' */
  real_T Tk_d;                         /* '<S54>/First Order Hold6' */
  real_T Ck_c;                         /* '<S54>/First Order Hold6' */
  real_T Mk_l5;                        /* '<S54>/First Order Hold6' */
  real_T Uk_o;                         /* '<S54>/First Order Hold6' */
  real_T Tk_b;                         /* '<S54>/First Order Hold7' */
  real_T Ck_m;                         /* '<S54>/First Order Hold7' */
  real_T Mk_kb;                        /* '<S54>/First Order Hold7' */
  real_T Uk_e;                         /* '<S54>/First Order Hold7' */
  real_T Tk_n;                         /* '<S54>/First Order Hold8' */
  real_T Ck_d;                         /* '<S54>/First Order Hold8' */
  real_T Mk_i;                         /* '<S54>/First Order Hold8' */
  real_T Uk_k;                         /* '<S54>/First Order Hold8' */
  real_T Tk_pr;                        /* '<S54>/First Order Hold9' */
  real_T Ck_p;                         /* '<S54>/First Order Hold9' */
  real_T Mk_j;                         /* '<S54>/First Order Hold9' */
  real_T Uk_g;                         /* '<S54>/First Order Hold9' */
  real_T Tk_bc;                        /* '<S54>/First Order Hold10' */
  real_T Ck_j;                         /* '<S54>/First Order Hold10' */
  real_T Mk_h;                         /* '<S54>/First Order Hold10' */
  real_T Uk_ok;                        /* '<S54>/First Order Hold10' */
  real_T Tk_f;                         /* '<S54>/First Order Hold11' */
  real_T Ck_aq;                        /* '<S54>/First Order Hold11' */
  real_T Mk_n;                         /* '<S54>/First Order Hold11' */
  real_T Uk_ol;                        /* '<S54>/First Order Hold11' */
  real_T Tk_a;                         /* '<S54>/First Order Hold12' */
  real_T Ck_f;                         /* '<S54>/First Order Hold12' */
  real_T Mk_lp;                        /* '<S54>/First Order Hold12' */
  real_T Uk_c1;                        /* '<S54>/First Order Hold12' */
  real_T Tk_i;                         /* '<S54>/First Order Hold13' */
  real_T Ck_ch;                        /* '<S54>/First Order Hold13' */
  real_T Mk_nu;                        /* '<S54>/First Order Hold13' */
  real_T Uk_l;                         /* '<S54>/First Order Hold13' */
  real_T Tk_o;                         /* '<S54>/First Order Hold14' */
  real_T Ck_o;                         /* '<S54>/First Order Hold14' */
  real_T Mk_d3;                        /* '<S54>/First Order Hold14' */
  real_T Uk_i;                         /* '<S54>/First Order Hold14' */
  volatile real_T RateTransition2_Buffer0;/* '<S6>/Rate Transition2' */
  volatile real_T RateTransition5_Buffer0;/* '<S6>/Rate Transition5' */
  volatile real_T RateTransition7_Buffer0;/* '<S6>/Rate Transition7' */
  volatile real_T RateTransition8_Buffer0;/* '<S6>/Rate Transition8' */
  volatile real_T RateTransition10_Buffer0;/* '<S6>/Rate Transition10' */
  volatile real_T RateTransition1_Buffer0;/* '<S6>/Rate Transition1' */
  volatile real_T RateTransition3_Buffer0;/* '<S58>/Rate Transition3' */
  volatile real_T RateTransition_Buffer0;/* '<S57>/Rate Transition' */
  volatile real_T RateTransition1_Buffer0_m;/* '<S57>/Rate Transition1' */
  volatile real_T RateTransition2_Buffer0_j;/* '<S57>/Rate Transition2' */
  volatile real_T RateTransition3_Buffer0_p;/* '<S57>/Rate Transition3' */
  volatile real_T RateTransition1_Buffer[2];/* '<S7>/Rate Transition1' */
  volatile real_T RateTransition13_Buffer0;/* '<S7>/Rate Transition13' */
  volatile real_T RateTransition15_Buffer0;/* '<S7>/Rate Transition15' */
  volatile real_T RateTransition16_Buffer0;/* '<S7>/Rate Transition16' */
  volatile real_T RateTransition17_Buffer0;/* '<S7>/Rate Transition17' */
  volatile real_T RateTransition18_Buffer0;/* '<S7>/Rate Transition18' */
  volatile real_T RateTransition19_Buffer0;/* '<S7>/Rate Transition19' */
  volatile real_T RateTransition_Buffer0_f;/* '<S7>/Rate Transition' */
  volatile real_T RateTransition8_Buffer0_a;/* '<S7>/Rate Transition8' */
  real_T Tk_m;                         /* '<S49>/First Order Hold' */
  real_T Ck_cm;                        /* '<S49>/First Order Hold' */
  real_T Mk_hq;                        /* '<S49>/First Order Hold' */
  real_T Uk_if;                        /* '<S49>/First Order Hold' */
  real_T Tk_ob;                        /* '<S51>/First Order Hold' */
  real_T Ck_hu;                        /* '<S51>/First Order Hold' */
  real_T Mk_c;                         /* '<S51>/First Order Hold' */
  real_T Uk_nb;                        /* '<S51>/First Order Hold' */
  real_T Tk_g;                         /* '<S54>/First Order Hold2' */
  real_T Ck_pu;                        /* '<S54>/First Order Hold2' */
  real_T Mk_ie;                        /* '<S54>/First Order Hold2' */
  real_T Uk_pm;                        /* '<S54>/First Order Hold2' */
  real_T Tk_h;                         /* '<S54>/First Order Hold3' */
  real_T Ck_ff;                        /* '<S54>/First Order Hold3' */
  real_T Mk_a;                         /* '<S54>/First Order Hold3' */
  real_T Uk_iu;                        /* '<S54>/First Order Hold3' */
  real_T Tk_b2;                        /* '<S54>/First Order Hold4' */
  real_T Ck_g;                         /* '<S54>/First Order Hold4' */
  real_T Mk_dk;                        /* '<S54>/First Order Hold4' */
  real_T Uk_g4;                        /* '<S54>/First Order Hold4' */
  real_T GearState;                    /* '<S42>/Shift Controller' */
  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK;                      /* '<S20>/FromWs' */

  uint32_T m_bpIndex;                  /* '<S13>/1-D Lookup Table' */
  uint32_T temporalCounter_i1;         /* '<S42>/Shift Controller' */
  struct {
    int_T PrevIndex;
  } FromWs_IWORK;                      /* '<S20>/FromWs' */

  volatile int8_T RateTransition4_semaphoreTaken;/* '<S6>/Rate Transition4' */
  volatile int8_T RateTransition2_semaphoreTaken;/* '<S6>/Rate Transition2' */
  volatile int8_T RateTransition5_semaphoreTaken;/* '<S6>/Rate Transition5' */
  volatile int8_T RateTransition7_semaphoreTaken;/* '<S6>/Rate Transition7' */
  volatile int8_T RateTransition8_semaphoreTaken;/* '<S6>/Rate Transition8' */
  volatile int8_T RateTransition10_semaphoreTaken;/* '<S6>/Rate Transition10' */
  volatile int8_T RateTransition1_semaphoreTaken;/* '<S6>/Rate Transition1' */
  volatile int8_T RateTransition3_semaphoreTaken;/* '<S58>/Rate Transition3' */
  volatile int8_T RateTransition_semaphoreTaken;/* '<S57>/Rate Transition' */
  volatile int8_T RateTransition1_semaphoreTaken_h;/* '<S57>/Rate Transition1' */
  volatile int8_T RateTransition2_semaphoreTaken_j;/* '<S57>/Rate Transition2' */
  volatile int8_T RateTransition3_semaphoreTaken_l;/* '<S57>/Rate Transition3' */
  volatile int8_T RateTransition1_ActiveBufIdx;/* '<S7>/Rate Transition1' */
  volatile int8_T RateTransition13_semaphoreTaken;/* '<S7>/Rate Transition13' */
  volatile int8_T RateTransition15_semaphoreTaken;/* '<S7>/Rate Transition15' */
  volatile int8_T RateTransition16_semaphoreTaken;/* '<S7>/Rate Transition16' */
  volatile int8_T RateTransition17_semaphoreTaken;/* '<S7>/Rate Transition17' */
  volatile int8_T RateTransition18_semaphoreTaken;/* '<S7>/Rate Transition18' */
  volatile int8_T RateTransition19_semaphoreTaken;/* '<S7>/Rate Transition19' */
  volatile int8_T RateTransition_semaphoreTaken_k;/* '<S7>/Rate Transition' */
  volatile int8_T RateTransition8_semaphoreTaken_k;/* '<S7>/Rate Transition8' */
  uint8_T is_active_c6_autolibsharedcommon;/* '<S42>/Shift Controller' */
  uint8_T is_GearSelect;               /* '<S42>/Shift Controller' */
  MdlrefDW_DrivetrainHevP4_T Drivetrain_InstanceData;/* '<S47>/Drivetrain' */
  MdlrefDW_SiMappedEngine_T SiMappedEngine_InstanceData;/* '<S53>/SiMappedEngine' */
  MdlrefDW_BattHevP4_T Battery_InstanceData;/* '<S50>/Battery' */
  MdlrefDW_SiEngineController_T SiEngineController_InstanceData;/* '<S9>/SiEngineController' */
  MdlrefDW_HevP4OptimalController_T HybridControlModuleHCMOptimal_InstanceData;
                             /* '<S10>/Hybrid Control Module (HCM) - Optimal' */
  MdlrefDW_HevP4TransmissionController_T
    TransmissionControlModuleTCM_InstanceData;
                                  /* '<S9>/Transmission Control Module (TCM)' */
  MdlrefDW_MotMappedP4_T MotMapped_InstanceData;/* '<S56>/MotMapped' */
  DW_PassThrough_HevP4ReferenceApplication_T PassThrough_b;/* '<S37>/Pass Through' */
  DW_PassThrough_HevP4ReferenceApplication_T PassThrough;/* '<S35>/Pass Through' */
} DW_HevP4ReferenceApplication_T;

/* Continuous states (default storage) */
typedef struct {
  real_T TransferFcn_CSTATE;           /* '<S49>/Transfer Fcn' */
  real_T MotorCouplingDynamics_CSTATE; /* '<S50>/Motor Coupling Dynamics' */
  X_DrivetrainHevP4_n_T Drivetrain_CSTATE;/* '<S47>/Drivetrain' */
  real_T SensorDynamics_CSTATE;        /* '<S54>/Sensor Dynamics' */
  X_SiMappedEngine_n_T SiMappedEngine_CSTATE;/* '<S53>/SiMappedEngine' */
  real_T BatteryDischargeDynamics_CSTATE;/* '<S50>/Battery Discharge Dynamics' */
  X_BattHevP4_n_T Battery_CSTATE;      /* '<S50>/Battery' */
  real_T Integrator_CSTATE;            /* '<S58>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S58>/Integrator1' */
  real_T Integrator_CSTATE_m;          /* '<S57>/Integrator' */
  real_T Integrator1_CSTATE_a;         /* '<S57>/Integrator1' */
  real_T Integrator2_CSTATE;           /* '<S57>/Integrator2' */
  real_T Integrator3_CSTATE;           /* '<S57>/Integrator3' */
  real_T Integrator4_CSTATE;           /* '<S57>/Integrator4' */
  real_T Integrator1_CSTATE_o;         /* '<S30>/Integrator1' */
  real_T Integrator2_CSTATE_m;         /* '<S41>/Integrator2' */
  X_MotMappedP4_n_T MotMapped_CSTATE;  /* '<S56>/MotMapped' */
} X_HevP4ReferenceApplication_T;

/* Periodic continuous state vector (global) */
typedef int_T PeriodicIndX_HevP4ReferenceApplication_T[1];
typedef real_T PeriodicRngX_HevP4ReferenceApplication_T[2];

/* State derivatives (default storage) */
typedef struct {
  real_T TransferFcn_CSTATE;           /* '<S49>/Transfer Fcn' */
  real_T MotorCouplingDynamics_CSTATE; /* '<S50>/Motor Coupling Dynamics' */
  XDot_DrivetrainHevP4_n_T Drivetrain_CSTATE;/* '<S47>/Drivetrain' */
  real_T SensorDynamics_CSTATE;        /* '<S54>/Sensor Dynamics' */
  XDot_SiMappedEngine_n_T SiMappedEngine_CSTATE;/* '<S53>/SiMappedEngine' */
  real_T BatteryDischargeDynamics_CSTATE;/* '<S50>/Battery Discharge Dynamics' */
  XDot_BattHevP4_n_T Battery_CSTATE;   /* '<S50>/Battery' */
  real_T Integrator_CSTATE;            /* '<S58>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<S58>/Integrator1' */
  real_T Integrator_CSTATE_m;          /* '<S57>/Integrator' */
  real_T Integrator1_CSTATE_a;         /* '<S57>/Integrator1' */
  real_T Integrator2_CSTATE;           /* '<S57>/Integrator2' */
  real_T Integrator3_CSTATE;           /* '<S57>/Integrator3' */
  real_T Integrator4_CSTATE;           /* '<S57>/Integrator4' */
  real_T Integrator1_CSTATE_o;         /* '<S30>/Integrator1' */
  real_T Integrator2_CSTATE_m;         /* '<S41>/Integrator2' */
  XDot_MotMappedP4_n_T MotMapped_CSTATE;/* '<S56>/MotMapped' */
} XDot_HevP4ReferenceApplication_T;

/* State disabled  */
typedef struct {
  boolean_T TransferFcn_CSTATE;        /* '<S49>/Transfer Fcn' */
  boolean_T MotorCouplingDynamics_CSTATE;/* '<S50>/Motor Coupling Dynamics' */
  XDis_DrivetrainHevP4_n_T Drivetrain_CSTATE;/* '<S47>/Drivetrain' */
  boolean_T SensorDynamics_CSTATE;     /* '<S54>/Sensor Dynamics' */
  XDis_SiMappedEngine_n_T SiMappedEngine_CSTATE;/* '<S53>/SiMappedEngine' */
  boolean_T BatteryDischargeDynamics_CSTATE;/* '<S50>/Battery Discharge Dynamics' */
  XDis_BattHevP4_n_T Battery_CSTATE;   /* '<S50>/Battery' */
  boolean_T Integrator_CSTATE;         /* '<S58>/Integrator' */
  boolean_T Integrator1_CSTATE;        /* '<S58>/Integrator1' */
  boolean_T Integrator_CSTATE_m;       /* '<S57>/Integrator' */
  boolean_T Integrator1_CSTATE_a;      /* '<S57>/Integrator1' */
  boolean_T Integrator2_CSTATE;        /* '<S57>/Integrator2' */
  boolean_T Integrator3_CSTATE;        /* '<S57>/Integrator3' */
  boolean_T Integrator4_CSTATE;        /* '<S57>/Integrator4' */
  boolean_T Integrator1_CSTATE_o;      /* '<S30>/Integrator1' */
  boolean_T Integrator2_CSTATE_m;      /* '<S41>/Integrator2' */
  XDis_MotMappedP4_n_T MotMapped_CSTATE;/* '<S56>/MotMapped' */
} XDis_HevP4ReferenceApplication_T;

#ifndef ODE4_INTG
#define ODE4_INTG

/* ODE4 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[4];                        /* derivatives */
} ODE4_IntgData;

#endif

/* Parameters (default storage) */
struct P_HevP4ReferenceApplication_T_ {
  real_T LongitudinalDriver_GearInit;
                                  /* Mask Parameter: LongitudinalDriver_GearInit
                                   * Referenced by: '<S42>/Shift Controller'
                                   */
  real_T SignalHold_IC;                /* Mask Parameter: SignalHold_IC
                                        * Referenced by: '<S35>/Pass Through'
                                        */
  real_T SignalHold_IC_b;              /* Mask Parameter: SignalHold_IC_b
                                        * Referenced by: '<S37>/Pass Through'
                                        */
  real_T LongitudinalDriver_Kpt;       /* Mask Parameter: LongitudinalDriver_Kpt
                                        * Referenced by:
                                        *   '<S28>/Setup'
                                        *   '<S28>/Gain'
                                        */
  real_T LongitudinalDriver_L;         /* Mask Parameter: LongitudinalDriver_L
                                        * Referenced by: '<S28>/Setup'
                                        */
  real_T LongitudinalDriver_aR;        /* Mask Parameter: LongitudinalDriver_aR
                                        * Referenced by: '<S28>/Setup'
                                        */
  real_T LongitudinalDriver_bR;        /* Mask Parameter: LongitudinalDriver_bR
                                        * Referenced by: '<S28>/Setup'
                                        */
  real_T LongitudinalDriver_cR;        /* Mask Parameter: LongitudinalDriver_cR
                                        * Referenced by: '<S28>/Setup'
                                        */
  real_T LongitudinalDriver_g;         /* Mask Parameter: LongitudinalDriver_g
                                        * Referenced by: '<S28>/Gain'
                                        */
  real_T LongitudinalDriver_m;         /* Mask Parameter: LongitudinalDriver_m
                                        * Referenced by:
                                        *   '<S28>/Setup'
                                        *   '<S28>/Gain'
                                        */
  real_T LongitudinalDriver_tShift; /* Mask Parameter: LongitudinalDriver_tShift
                                     * Referenced by: '<S42>/Shift Controller'
                                     */
  real_T LongitudinalDriver_tau;       /* Mask Parameter: LongitudinalDriver_tau
                                        * Referenced by:
                                        *   '<S28>/Setup'
                                        *   '<S30>/Constant'
                                        */
  real_T u1_UpperSat;                  /* Expression: 1
                                        * Referenced by: '<S29>/0~1'
                                        */
  real_T u1_LowerSat;                  /* Expression: 0
                                        * Referenced by: '<S29>/0~1'
                                        */
  real_T u0_UpperSat;                  /* Expression: 0
                                        * Referenced by: '<S31>/-1~0'
                                        */
  real_T u0_LowerSat;                  /* Expression: -1
                                        * Referenced by: '<S31>/-1~0'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S45>/Constant'
                                        */
  real_T Constant_Value_l;             /* Expression: 0
                                        * Referenced by: '<S46>/Constant'
                                        */
  real_T tFinal_Value;                 /* Expression: DriveCycle.Time(end)
                                        * Referenced by: '<S13>/tFinal'
                                        */
  real_T repeat_Value;                 /* Expression: cycleRepeat
                                        * Referenced by: '<S13>/repeat'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S13>/Switch'
                                        */
  real_T uDLookupTable_tableData[2474];/* Expression: DriveCycle.Data
                                        * Referenced by: '<S13>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[2474]; /* Expression: DriveCycle.Time
                                        * Referenced by: '<S13>/1-D Lookup Table'
                                        */
  real_T TransferFcn_A;                /* Computed Parameter: TransferFcn_A
                                        * Referenced by: '<S49>/Transfer Fcn'
                                        */
  real_T TransferFcn_C;                /* Computed Parameter: TransferFcn_C
                                        * Referenced by: '<S49>/Transfer Fcn'
                                        */
  real_T MotorCouplingDynamics_A; /* Computed Parameter: MotorCouplingDynamics_A
                                   * Referenced by: '<S50>/Motor Coupling Dynamics'
                                   */
  real_T MotorCouplingDynamics_C; /* Computed Parameter: MotorCouplingDynamics_C
                                   * Referenced by: '<S50>/Motor Coupling Dynamics'
                                   */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant3'
                                        */
  real_T FirstOrderHold1_IniOut;       /* Expression: 0
                                        * Referenced by: '<S49>/First Order Hold1'
                                        */
  real_T FirstOrderHold1_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S49>/First Order Hold1'
                                        */
  real_T FirstOrderHold2_IniOut;       /* Expression: 0
                                        * Referenced by: '<S49>/First Order Hold2'
                                        */
  real_T FirstOrderHold2_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S49>/First Order Hold2'
                                        */
  real_T mstomph_Gain;                 /* Expression: 2.23694
                                        * Referenced by: '<S6>/m//s to mph'
                                        */
  real_T FirstOrderHold_IniOut;        /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold'
                                        */
  real_T FirstOrderHold_ErrTol;        /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold'
                                        */
  real_T FirstOrderHold1_IniOut_d;     /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold1'
                                        */
  real_T FirstOrderHold1_ErrTol_j;     /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold1'
                                        */
  real_T FirstOrderHold5_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold5'
                                        */
  real_T FirstOrderHold5_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold5'
                                        */
  real_T FirstOrderHold6_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold6'
                                        */
  real_T FirstOrderHold6_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold6'
                                        */
  real_T FirstOrderHold7_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold7'
                                        */
  real_T FirstOrderHold7_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold7'
                                        */
  real_T FirstOrderHold8_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold8'
                                        */
  real_T FirstOrderHold8_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold8'
                                        */
  real_T FirstOrderHold9_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold9'
                                        */
  real_T FirstOrderHold9_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold9'
                                        */
  real_T FirstOrderHold10_IniOut;      /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold10'
                                        */
  real_T FirstOrderHold10_ErrTol;      /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold10'
                                        */
  real_T FirstOrderHold11_IniOut;      /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold11'
                                        */
  real_T FirstOrderHold11_ErrTol;      /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold11'
                                        */
  real_T FirstOrderHold12_IniOut;      /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold12'
                                        */
  real_T FirstOrderHold12_ErrTol;      /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold12'
                                        */
  real_T FirstOrderHold13_IniOut;      /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold13'
                                        */
  real_T FirstOrderHold13_ErrTol;      /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold13'
                                        */
  real_T FirstOrderHold14_IniOut;      /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold14'
                                        */
  real_T FirstOrderHold14_ErrTol;      /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold14'
                                        */
  real_T SensorDynamics_A;             /* Computed Parameter: SensorDynamics_A
                                        * Referenced by: '<S54>/Sensor Dynamics'
                                        */
  real_T SensorDynamics_C;             /* Computed Parameter: SensorDynamics_C
                                        * Referenced by: '<S54>/Sensor Dynamics'
                                        */
  real_T radstorpm_Gain;               /* Expression: 30/pi
                                        * Referenced by: '<S6>/rad//s to rpm'
                                        */
  real_T BatteryDischargeDynamics_A;
                               /* Computed Parameter: BatteryDischargeDynamics_A
                                * Referenced by: '<S50>/Battery Discharge Dynamics'
                                */
  real_T BatteryDischargeDynamics_C;
                               /* Computed Parameter: BatteryDischargeDynamics_C
                                * Referenced by: '<S50>/Battery Discharge Dynamics'
                                */
  real_T Constant6_Value;              /* Expression: 300
                                        * Referenced by: '<S3>/Constant6'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S58>/Integrator'
                                        */
  real_T mtomile_Gain;                 /* Expression: 0.000621371
                                        * Referenced by: '<S58>/m to mile'
                                        */
  real_T Integrator1_IC;               /* Expression: 0
                                        * Referenced by: '<S58>/Integrator1'
                                        */
  real_T m3toUSGal_Gain;               /* Expression: 264.172
                                        * Referenced by: '<S58>/m^3 to US Gal'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: Inf
                                        * Referenced by: '<S58>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 1e-3
                                        * Referenced by: '<S58>/Saturation1'
                                        */
  real_T Integrator_IC_p;              /* Expression: 0
                                        * Referenced by: '<S57>/Integrator'
                                        */
  real_T mtomi_Gain;                   /* Expression: 0.000621371
                                        * Referenced by: '<S57>/m to mi'
                                        */
  real_T Saturation_UpperSat;          /* Expression: Inf
                                        * Referenced by: '<S57>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0.2
                                        * Referenced by: '<S57>/Saturation'
                                        */
  real_T Integrator1_IC_k;             /* Expression: 0
                                        * Referenced by: '<S57>/Integrator1'
                                        */
  real_T Kgtog_Gain;                   /* Expression: 1000
                                        * Referenced by: '<S57>/Kg to g'
                                        */
  real_T Integrator2_IC;               /* Expression: 0
                                        * Referenced by: '<S57>/Integrator2'
                                        */
  real_T Kgtog_Gain_l;                 /* Expression: 1000
                                        * Referenced by: '<S57>/Kg to g '
                                        */
  real_T Integrator3_IC;               /* Expression: 0
                                        * Referenced by: '<S57>/Integrator3'
                                        */
  real_T Kgtog_Gain_f;                 /* Expression: 1000
                                        * Referenced by: '<S57>/Kg to g  '
                                        */
  real_T mtokm_Gain;                   /* Expression: 0.001
                                        * Referenced by: '<S57>/m to km'
                                        */
  real_T Saturation1_UpperSat_h;       /* Expression: Inf
                                        * Referenced by: '<S57>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_d;       /* Expression: 1
                                        * Referenced by: '<S57>/Saturation1'
                                        */
  real_T Integrator4_IC;               /* Expression: 0
                                        * Referenced by: '<S57>/Integrator4'
                                        */
  real_T Kgtog_Gain_c;                 /* Expression: 1000
                                        * Referenced by: '<S57>/Kg to g   '
                                        */
  real_T wperkw_Value;                 /* Expression: 1000
                                        * Referenced by: '<S58>/w per kw'
                                        */
  real_T USEPAkwhUSgalequivalent_Value;/* Expression: 33.7
                                        * Referenced by: '<S58>/US EPA kwh//USgal equivalent'
                                        */
  real_T sperh_Value;                  /* Expression: 3600
                                        * Referenced by: '<S58>/s per h'
                                        */
  real_T m3pergal_Gain;                /* Expression: 0.00378541
                                        * Referenced by: '<S58>/m^3 per gal'
                                        */
  real_T RateTransition1_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S7>/Rate Transition1'
                                           */
  real_T Constant_Value_f;             /* Expression: 0
                                        * Referenced by: '<S29>/Constant'
                                        */
  real_T Integrator1_IC_f;             /* Expression: 0
                                        * Referenced by: '<S30>/Integrator1'
                                        */
  real_T Saturation_UpperSat_j;        /* Expression: 1
                                        * Referenced by: '<S29>/Saturation'
                                        */
  real_T Saturation_LowerSat_f;        /* Expression: 0
                                        * Referenced by: '<S29>/Saturation'
                                        */
  real_T Constant_Value_fg;            /* Expression: 0
                                        * Referenced by: '<S31>/Constant'
                                        */
  real_T Saturation_UpperSat_o;        /* Expression: 1
                                        * Referenced by: '<S31>/Saturation'
                                        */
  real_T Saturation_LowerSat_n;        /* Expression: 0
                                        * Referenced by: '<S31>/Saturation'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S43>/Constant1'
                                        */
  real_T Constant_Value_a;             /* Expression: 0
                                        * Referenced by: '<S43>/Constant'
                                        */
  real_T Constant7_Value;              /* Expression: 101325
                                        * Referenced by: '<S3>/Constant7'
                                        */
  real_T HitCrossing_Offset;
              /* Expression: min(0.5,(DriveCycle.Time(2)-DriveCycle.Time(1))./2)
               * Referenced by: '<S13>/Hit  Crossing'
               */
  real_T Integrator2_IC_o;             /* Expression: 0
                                        * Referenced by: '<S41>/Integrator2'
                                        */
  real_T UnitDelay_InitialCondition[2];/* Expression: [0,0]
                                        * Referenced by: '<S41>/Unit Delay'
                                        */
  real_T FirstOrderHold_IniOut_e;      /* Expression: 0
                                        * Referenced by: '<S49>/First Order Hold'
                                        */
  real_T FirstOrderHold_ErrTol_m;      /* Expression: inf
                                        * Referenced by: '<S49>/First Order Hold'
                                        */
  real_T FirstOrderHold_IniOut_o;      /* Expression: 0
                                        * Referenced by: '<S51>/First Order Hold'
                                        */
  real_T FirstOrderHold_ErrTol_f;      /* Expression: inf
                                        * Referenced by: '<S51>/First Order Hold'
                                        */
  real_T FirstOrderHold2_IniOut_g;     /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold2'
                                        */
  real_T FirstOrderHold2_ErrTol_f;     /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold2'
                                        */
  real_T FirstOrderHold3_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold3'
                                        */
  real_T FirstOrderHold3_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold3'
                                        */
  real_T FirstOrderHold4_IniOut;       /* Expression: 0
                                        * Referenced by: '<S54>/First Order Hold4'
                                        */
  real_T FirstOrderHold4_ErrTol;       /* Expression: inf
                                        * Referenced by: '<S54>/First Order Hold4'
                                        */
  boolean_T Constant_Value_e;          /* Expression: false
                                        * Referenced by: '<S19>/Constant'
                                        */
  uint8_T ManualSwitch_CurrentSetting;
                              /* Computed Parameter: ManualSwitch_CurrentSetting
                               * Referenced by: '<S19>/Manual Switch'
                               */
};

/* Real-time Model Data Structure */
struct tag_RTM_HevP4ReferenceApplication_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_HevP4ReferenceApplication_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[63];
  real_T odeF[4][63];
  ODE4_IntgData intgData;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    rtwCAPI_ModelMappingInfo* childMMI[7];
  } DataMapInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    uint32_T clockTick4;
    uint32_T clockTickH4;
    boolean_T firstInitCondFlag;
    struct {
      uint32_T TID[5];
    } TaskCounters;

    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[5];
  } Timing;
};

/* Block parameters (default storage) */
extern P_HevP4ReferenceApplication_T HevP4ReferenceApplication_P;

/* Block signals (default storage) */
extern B_HevP4ReferenceApplication_T HevP4ReferenceApplication_B;

/* Continuous states (default storage) */
extern X_HevP4ReferenceApplication_T HevP4ReferenceApplication_X;

/* Block states (default storage) */
extern DW_HevP4ReferenceApplication_T HevP4ReferenceApplication_DW;

/* Model entry point functions */
extern void HevP4ReferenceApplication_initialize(void);
extern void HevP4ReferenceApplication_step(void);
extern void HevP4ReferenceApplication_terminate(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  HevP4ReferenceApplication_GetCAPIStaticMap(void);

/* Real-time Model object */
extern RT_MODEL_HevP4ReferenceApplication_T *const HevP4ReferenceApplication_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HevP4ReferenceApplication'
 * '<S1>'   : 'HevP4ReferenceApplication/Controllers'
 * '<S2>'   : 'HevP4ReferenceApplication/Drive Cycle Source'
 * '<S3>'   : 'HevP4ReferenceApplication/Environment'
 * '<S4>'   : 'HevP4ReferenceApplication/Longitudinal Driver'
 * '<S5>'   : 'HevP4ReferenceApplication/Passenger Car'
 * '<S6>'   : 'HevP4ReferenceApplication/Visualization'
 * '<S7>'   : 'HevP4ReferenceApplication/Controllers/PCM Input'
 * '<S8>'   : 'HevP4ReferenceApplication/Controllers/PCM Output'
 * '<S9>'   : 'HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)'
 * '<S10>'  : 'HevP4ReferenceApplication/Controllers/Powertrain Control Module (PCM)/Hybrid Control Module (HCM)'
 * '<S11>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Signal Routing'
 * '<S12>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode'
 * '<S13>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous'
 * '<S14>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/FaultSystem'
 * '<S15>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/FaultSystem/Fault Mode'
 * '<S16>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/FaultSystem/TracePlot'
 * '<S17>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/FaultSystem/Fault Mode/Fault Off'
 * '<S18>'  : 'HevP4ReferenceApplication/Drive Cycle Source/Timing Mode/Continuous/FaultSystem/TracePlot/SimPlotOff'
 * '<S19>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop'
 * '<S20>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Ignition Switch Profile1'
 * '<S21>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver'
 * '<S22>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/External Action Routing'
 * '<S23>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver'
 * '<S24>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control'
 * '<S25>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/LPF'
 * '<S26>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing'
 * '<S27>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift'
 * '<S28>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive'
 * '<S29>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override'
 * '<S30>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Cont LPF'
 * '<S31>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override'
 * '<S32>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Powertrain Response'
 * '<S33>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Setup'
 * '<S34>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Vehicle'
 * '<S35>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Signal Hold'
 * '<S36>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Accel Override/Signal Hold/Pass Through'
 * '<S37>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Signal Hold'
 * '<S38>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Deccel Override/Signal Hold/Pass Through'
 * '<S39>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Control/Predictive/Powertrain Response/Unfiltered'
 * '<S40>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/LPF/pass'
 * '<S41>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Routing/Error Metrics'
 * '<S42>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic'
 * '<S43>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change'
 * '<S44>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Shift Controller'
 * '<S45>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Compare To Zero'
 * '<S46>'  : 'HevP4ReferenceApplication/Longitudinal Driver/Closed Loop/Longitudinal Driver/Longitudinal Driver/Shift/Basic/Reverse Change/Compare To Zero1'
 * '<S47>'  : 'HevP4ReferenceApplication/Passenger Car/Drivetrain'
 * '<S48>'  : 'HevP4ReferenceApplication/Passenger Car/Drivetrain Output'
 * '<S49>'  : 'HevP4ReferenceApplication/Passenger Car/Drivetrain Plant Input'
 * '<S50>'  : 'HevP4ReferenceApplication/Passenger Car/Electric Plant'
 * '<S51>'  : 'HevP4ReferenceApplication/Passenger Car/Electric Plant Input'
 * '<S52>'  : 'HevP4ReferenceApplication/Passenger Car/Electric Plant Output'
 * '<S53>'  : 'HevP4ReferenceApplication/Passenger Car/Engine'
 * '<S54>'  : 'HevP4ReferenceApplication/Passenger Car/Engine Plant Input'
 * '<S55>'  : 'HevP4ReferenceApplication/Passenger Car/Engine Plant Output'
 * '<S56>'  : 'HevP4ReferenceApplication/Passenger Car/Electric Plant/Electric Machine'
 * '<S57>'  : 'HevP4ReferenceApplication/Visualization/Emission Calculations'
 * '<S58>'  : 'HevP4ReferenceApplication/Visualization/Performance Calculations'
 */
#endif                             /* RTW_HEADER_HevP4ReferenceApplication_h_ */
