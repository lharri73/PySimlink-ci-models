/*
 * DrivetrainHevP4_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:03 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "DrivetrainHevP4_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "DrivetrainHevP4.h"
#include "DrivetrainHevP4_capi.h"
#include "DrivetrainHevP4_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 42, TARGET_STRING("DrivetrainHevP4/Vehicle/Cont LPF/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 42, TARGET_STRING("DrivetrainHevP4/Vehicle/Cont LPF1/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 2, 2, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Open Differential"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 3, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 1, 0, 1 },

  { 4, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 5, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 6, 5, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Open Differential"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 7, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 1, 0, 1 },

  { 8, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 9, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 10, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 11, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/2*pi"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 12, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 13, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 14, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Merge2"),
    TARGET_STRING("Spd Ratio"), 0, 0, 0, 0, 0 },

  { 15, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vector Concatenate2"),
    TARGET_STRING(""), 0, 0, 2, 0, 0 },

  { 16, 22, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Basic Magic Tire/Simple Magic Tire"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 17, 22, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Basic Magic Tire/Simple Magic Tire"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 18, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 19, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 20, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Sign convention"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 21, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 22, 32, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Basic Magic Tire/Simple Magic Tire"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 23, 32, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Basic Magic Tire/Simple Magic Tire"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 24, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 25, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 26, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Sign convention"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 27, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 28, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/domega_o"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 29, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Subtract"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 30, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/y/Switch"),
    TARGET_STRING("diffDir"), 0, 0, 0, 0, 1 },

  { 31, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/y/Switch"),
    TARGET_STRING("diffDir"), 0, 0, 0, 0, 1 },

  { 32, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/domega_o"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 33, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Subtract"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 34, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/domega_o"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 35, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Subtract"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 36, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/domega_o"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 37, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Subtract"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 38, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Cont LPF IC Dyn/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 39, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Cont LPF IC Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 40, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/IC tunable/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 41, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/IC tunable/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 42, 9, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Product8"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 43, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Neutral IC/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 44, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Neutral IC/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 45, 13, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Product4"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 46, 13, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Product8"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 47, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/input IC/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 48, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/input IC/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 49, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 50, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 51, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable1/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 52, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable1/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 53, 14, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Inertia"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 54, 21, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Impeller Inertia"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 55, 21, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Turbine Inertia"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 56, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Signal Conversion2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 57, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/output IC/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 58, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/output IC/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 59, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/1//m"),
    TARGET_STRING("xddot"), 0, 0, 0, 0, 0 },

  { 60, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/m"),
    TARGET_STRING("Fz"), 0, 0, 0, 0, 1 },

  { 61, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Integrator"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 62, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 63, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 64, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 65, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Friction Model/Ratio of static to kinetic"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 66, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 67, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 68, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 69, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Friction Model/Ratio of static to kinetic"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 70, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 71, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 72, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 73, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 74, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 75, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 76, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 77, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 78, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup Detection/Velocities Match"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 79, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup Detection/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 80, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup FSM/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 81, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Constant2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 82, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Hz2rad"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 83, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Relay1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 84, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 3, 0, 0 },

  { 85, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 86, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 87, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Crm"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 88, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Cs"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 89, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Cym"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 90, 42, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Product5"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 91, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 92, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 93, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 94, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Slipping"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 95, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Slipping"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 96, 27, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Slipping"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 97, 25, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 98, 26, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectSlip"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 99, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/Cont LPF Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 100, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 101, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 102, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 103, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Slipping"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 104, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Slipping"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 105, 37, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Slipping"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 106, 35, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 107, 36, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectSlip"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 108, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/Cont LPF Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 109, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Kinetic Power/Switch1"),
    TARGET_STRING("diffDir"), 0, 0, 0, 0, 1 },

  { 110, 42, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Kinetic Power/Switch1"),
    TARGET_STRING("diffDir"), 0, 0, 0, 0, 1 },

  { 111, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Cont LPF IC Dyn/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 112, 42, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Cont LPF IC Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 113, 16, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 114, 21, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 4, 0, 0 },

  { 115, 21, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 116, 21, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Constant2"),
    TARGET_STRING(""), 0, 0, 5, 0, 0 },

  { 117, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Torque Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 118, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Torque Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 119, 24, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Slipping/Output Inertia"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 120, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Torque Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 121, 42, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Torque Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 122, 34, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Slipping/Output Inertia"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 123, 21, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/Compare To Zero/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 124, 26, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectSlip/Break Apart Detection/Relational Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 125, 36, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectSlip/Break Apart Detection/Relational Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 126, 16, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Cont LPF Dyn/Integrator"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 127, 16, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Cont LPF Dyn/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 128, 25, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM/Combinatorial  Logic"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 129, 35, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM/Combinatorial  Logic"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 130, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission"),
    TARGET_STRING("G_o"), 0, 0, 0 },

  { 131, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission"),
    TARGET_STRING("omegaN_o"), 0, 0, 0 },

  { 132, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal"),
    TARGET_STRING("Cl"), 0, 0, 0 },

  { 133, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal"),
    TARGET_STRING("Cpm"), 0, 0, 0 },

  { 134, TARGET_STRING("DrivetrainHevP4/Vehicle/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 135, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 136, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 137, TARGET_STRING("DrivetrainHevP4/Vehicle/Cont LPF/Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 138, TARGET_STRING("DrivetrainHevP4/Vehicle/Cont LPF1/Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 139, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/FExtConstant"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 140, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/MExtConstant"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 141, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/FxType"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 142, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/rollType"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 143, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/vertType"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 144, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/FxType"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 145, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/rollType"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 146, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/vertType"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 147, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Open Differential"),
    TARGET_STRING("shaftSwitchMask"), 0, 0, 0 },

  { 148, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Integrator"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 149, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Integrator"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 150, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Open Differential"),
    TARGET_STRING("shaftSwitchMask"), 0, 0, 0 },

  { 151, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Integrator"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 152, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Integrator"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 153, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/2*pi"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 154, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Merge1"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 155, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Sign convention"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 156, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 157, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 158, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Sign convention"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 159, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 160, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 161, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/y/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 162, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/y/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 163, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/y/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 164, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/y/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 165, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/y/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 166, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/y/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 167, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/y/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 168, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/y/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 169, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Cont LPF IC Dyn/Reset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 170, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Cont LPF IC Dyn/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 171, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/IC tunable/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 172, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/IC tunable/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 173, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/IC tunable/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 174, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Neutral IC/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 175, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Neutral IC/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 176, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Neutral IC/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 177, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/First"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 178, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Neutral"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 179, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/No Input Torque"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 180, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/input IC/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 181, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/input IC/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 182, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/input IC/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 183, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 184, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 185, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 186, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable1/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 187, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable1/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 188, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/IC tunable1/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 189, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 190, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 191, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 192, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Locked Shaft Integrator"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 193, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Locked Shaft Integrator"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 194, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter"),
    TARGET_STRING("KType"), 0, 0, 0 },

  { 195, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 196, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Pump Integrator"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 197, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Pump Integrator"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 198, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Turbine Integrator"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 199, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Turbine Integrator"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 200, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/output IC/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 201, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/output IC/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 202, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/output IC/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 203, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Inertial Axes/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 204, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force"),
    TARGET_STRING("beta_w"), 0, 7, 0 },

  { 205, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force"),
    TARGET_STRING("Cs"), 0, 7, 0 },

  { 206, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force"),
    TARGET_STRING("Cym"), 0, 7, 0 },

  { 207, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force"),
    TARGET_STRING("R"), 0, 0, 0 },

  { 208, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 209, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 210, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant12"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 211, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant14"),
    TARGET_STRING("Value"), 0, 8, 0 },

  { 212, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant19"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 213, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant2"),
    TARGET_STRING("Value"), 0, 9, 0 },

  { 214, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 215, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Longitudinal Parameters/Magic Formula Peak Value/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 216, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 217, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 218, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant11"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 219, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant12"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 220, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant14"),
    TARGET_STRING("Value"), 0, 8, 0 },

  { 221, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant16"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 222, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant19"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 223, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 224, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 225, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 226, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 227, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Rolling Parameters/Simple/Constant9"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 228, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 229, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 230, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant11"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 231, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant13"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 232, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant14"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 233, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant15"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 234, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant16"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 235, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant17"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 236, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant18"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 237, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant19"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 238, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 239, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant20"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 240, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant21"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 241, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant22"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 242, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant23"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 243, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant24"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 244, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 245, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant4"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 246, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 247, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 248, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 249, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant8"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 250, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Vertical DOF/None/Constant9"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 251, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 252, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 253, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant12"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 254, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant14"),
    TARGET_STRING("Value"), 0, 8, 0 },

  { 255, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant19"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 256, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant2"),
    TARGET_STRING("Value"), 0, 9, 0 },

  { 257, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 258, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Longitudinal Parameters/Magic Formula Peak Value/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 259, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 260, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 261, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant11"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 262, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant12"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 263, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant14"),
    TARGET_STRING("Value"), 0, 8, 0 },

  { 264, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant16"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 265, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant19"),
    TARGET_STRING("Value"), 0, 6, 0 },

  { 266, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 267, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 268, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 269, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 270, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Rolling Parameters/Simple/Constant9"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 271, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 272, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 273, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant11"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 274, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant13"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 275, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant14"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 276, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant15"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 277, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant16"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 278, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant17"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 279, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant18"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 280, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant19"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 281, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 282, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant20"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 283, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant21"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 284, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant22"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 285, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant23"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 286, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant24"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 287, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 288, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant4"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 289, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 290, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 291, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 292, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant8"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 293, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Vertical DOF/None/Constant9"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 294, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Reset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 295, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 296, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Axle 1 Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 297, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Axle 1 Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 298, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Axle 2 Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 299, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Axle 2 Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 300, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Drive Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 301, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Efficiency/Drive Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 302, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Axle 1 Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 303, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Axle 1 Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 304, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Axle 2 Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 305, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Axle 2 Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 306, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Drive Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 307, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Efficiency/Drive Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 308, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Reset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 309, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 310, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Reset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 311, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 312, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Reset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 313, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 314, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Apply Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 315, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Apply Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 316, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Apply Efficiency /Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 317, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Apply Efficiency /Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 318, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/div0protect - abs poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 319, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 320, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 321, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 322, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 323, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 324, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Saturation2"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 325, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/Mechanical Efficiency/Saturation2"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 326, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Apply Efficiency/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 327, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Apply Efficiency/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 328, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/div0protect - abs poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 329, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 330, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 331, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 332, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 333, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 334, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Saturation2"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 335, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/Mechanical Efficiency/Saturation2"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 336, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup Detection/Velocities Match"),
    TARGET_STRING("HitCrossingOffset"), 0, 0, 0 },

  { 337, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup FSM/Combinatorial  Logic"),
    TARGET_STRING("TruthTable"), 1, 10, 0 },

  { 338, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Friction Mode Logic/Lockup FSM/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 339, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 340, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Hz2rad"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 341, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Relay1"),
    TARGET_STRING("OnOutputValue"), 1, 0, 0 },

  { 342, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Relay1"),
    TARGET_STRING("OffOutputValue"), 1, 0, 0 },

  { 343, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Capacity, K-factor Interpolation"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 344, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Ratio zeta Interpolation"),
    TARGET_STRING("maxIndex"), 2, 0, 0 },

  { 345, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/uniclutch"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 346, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/uniclutch"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 347, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 348, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 349, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 350, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/4"),
    TARGET_STRING("Gain"), 0, 2, 0 },

  { 351, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Crm"),
    TARGET_STRING("Table"), 0, 7, 0 },

  { 352, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Drag Force/Crm"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 353, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/Cont LPF Dyn/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 354, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/Cont LPF Dyn/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 355, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Kinetic Power/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 356, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Kinetic Power/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 357, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Bus Creation/Power/Kinetic Power/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 358, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Kinetic Power/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 359, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Kinetic Power/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 360, TARGET_STRING("DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Bus Creation/Power/Kinetic Power/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 361, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Cont LPF IC Dyn/Reset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 362, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Cont LPF IC Dyn/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 363, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Friction Model/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 364, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Friction Model/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 365, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 366, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 367, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/div0protect - poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 368, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 369, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 370, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 371, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Front"),
    TARGET_STRING("R_T2"), 0, 0, 0 },

  { 372, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Frame Routing/Longitudinal 1DOF/Hard Point Coordinate Transform Rear"),
    TARGET_STRING("R_T2"), 0, 0, 0 },

  { 373, TARGET_STRING("DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Inertial Frame/Inertial Axes/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 374, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Torque Conversion1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 375, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Disallow Negative Brake Torque"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 376, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Disallow Negative Brake Torque"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 377, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked/locked"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 378, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked/locked1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 379, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Locked/locked2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 380, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/Slipping/-4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 381, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/yn"),
    TARGET_STRING("InitialOutput"), 1, 0, 0 },

  { 382, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 383, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectSlip/yn"),
    TARGET_STRING("InitialOutput"), 1, 0, 0 },

  { 384, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Torque Conversion1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 385, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Disallow Negative Brake Torque"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 386, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Brakes/Disk Brake/Disk Brake/Disallow Negative Brake Torque"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 387, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked/locked"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 388, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked/locked1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 389, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Locked/locked2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 390, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/Slipping/-4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 391, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/yn"),
    TARGET_STRING("InitialOutput"), 1, 0, 0 },

  { 392, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 393, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectSlip/yn"),
    TARGET_STRING("InitialOutput"), 1, 0, 0 },

  { 394, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/gear2props/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("maxIndex"), 2, 11, 0 },

  { 395, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/gear2props/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("dimSizes"), 2, 11, 0 },

  { 396, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/gear2props/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("maxIndex"), 2, 11, 0 },

  { 397, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/gear2props/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("dimSizes"), 2, 11, 0 },

  { 398, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 399, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Out1"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 400, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 401, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 402, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 403, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/div0protect - poly/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 404, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/speed ratio/div0protect - poly/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 405, TARGET_STRING("DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Cont LPF Dyn/Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 406, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM/Combinatorial  Logic"),
    TARGET_STRING("TruthTable"), 1, 10, 0 },

  { 407, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM/Unit Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 408, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM/Combinatorial  Logic"),
    TARGET_STRING("TruthTable"), 1, 10, 0 },

  { 409, TARGET_STRING("DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/Clutch/Clutch/detectLockup/Friction Mode Logic/Lockup FSM/Unit Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 410, 9, TARGET_STRING("DrivetrainHevP4/Vehicle/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 411, 5, TARGET_STRING("DrivetrainHevP4/Vehicle/Cont LPF/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 412, 1, TARGET_STRING("DrivetrainHevP4/Vehicle/Cont LPF1/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 413, 19, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential/Open Differential/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 414, 21, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Open Differential1/Open Differential/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 0, 1, -1, 0 },

  { 415, 12, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 416, 3, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 417, 7, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 418, 18, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 419, 14, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 420, 16, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Cont LPF IC Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 421, 31, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Locked/x"),
    TARGET_STRING("w"),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 422, 29, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/xe"),
    TARGET_STRING("we"),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 423, 30, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Ideal Fixed Gear Transmission/Ideal Fixed Gear Transmission/Unlocked/xv"),
    TARGET_STRING("wv"),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 424, 28, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Locked/Locked Shaft\nIntegrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 425, 25, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Pump\nIntegrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 426, 26, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Turbine\nIntegrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 427, 0, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Vehicle/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 428, 2, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Front Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 429, 6, TARGET_STRING(
    "DrivetrainHevP4/Differential and Compliance/Rear Axle Compliance 1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 430, 17, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 431, 13, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Driveshaft Compliance1/Torsional Compliance Linear 2way/Torsional Compliance Linear/Cont LPF IC Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 432, 4, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Front 1/Wheel Module/relaxation/Cont LPF Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 433, 8, TARGET_STRING(
    "DrivetrainHevP4/Wheels and Brakes/Longitudinal Wheel - Rear 1/Wheel Module/relaxation/Cont LPF Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 434, 15, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Lock-up Type/Internal/Cont LPF IC Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 435, 11, TARGET_STRING(
    "DrivetrainHevP4/Vehicle/Vehicle Body 1DOF Longitudinal/Vehicle Body 1 DOF/Bus Creation/Body Frame/Longitudinal 1DOF/Integrator3"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  { 436, 27, TARGET_STRING(
    "DrivetrainHevP4/Torque Converter Automatic Transmission/Torque Converter/Torque Converter With Lock-up/Unlocked/Torque Converter/Torque Response/LPF/Cont LPF Dyn/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 0, 1, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 437, TARGET_STRING("Af"), 0, 0, 0 },

  { 438, TARGET_STRING("Cd"), 0, 0, 0 },

  { 439, TARGET_STRING("FZMAX"), 0, 0, 0 },

  { 440, TARGET_STRING("FZMIN"), 0, 0, 0 },

  { 441, TARGET_STRING("G"), 0, 12, 0 },

  { 442, TARGET_STRING("Iyy_Whl"), 0, 0, 0 },

  { 443, TARGET_STRING("Jd"), 0, 0, 0 },

  { 444, TARGET_STRING("Ji"), 0, 0, 0 },

  { 445, TARGET_STRING("Jout"), 0, 12, 0 },

  { 446, TARGET_STRING("Jt"), 0, 0, 0 },

  { 447, TARGET_STRING("Jw1"), 0, 0, 0 },

  { 448, TARGET_STRING("Jw2"), 0, 0, 0 },

  { 449, TARGET_STRING("K_c"), 0, 0, 0 },

  { 450, TARGET_STRING("Lrel"), 0, 0, 0 },

  { 451, TARGET_STRING("Mass"), 0, 0, 0 },

  { 452, TARGET_STRING("N"), 0, 12, 0 },

  { 453, TARGET_STRING("NF"), 0, 0, 0 },

  { 454, TARGET_STRING("NR"), 0, 0, 0 },

  { 455, TARGET_STRING("Ndiff"), 0, 0, 0 },

  { 456, TARGET_STRING("Ndiff_P4"), 0, 0, 0 },

  { 457, TARGET_STRING("Pabs"), 0, 0, 0 },

  { 458, TARGET_STRING("Re"), 0, 0, 0 },

  { 459, TARGET_STRING("Reff"), 0, 0, 0 },

  { 460, TARGET_STRING("Rm"), 0, 0, 0 },

  { 461, TARGET_STRING("T"), 0, 0, 0 },

  { 462, TARGET_STRING("Temp_bpts"), 0, 7, 0 },

  { 463, TARGET_STRING("Trq_bpts"), 0, 12, 0 },

  { 464, TARGET_STRING("UNLOADED_RADIUS"), 0, 0, 0 },

  { 465, TARGET_STRING("VXLOW"), 0, 0, 0 },

  { 466, TARGET_STRING("aMy"), 0, 0, 0 },

  { 467, TARGET_STRING("a_CG"), 0, 0, 0 },

  { 468, TARGET_STRING("alphaMy"), 0, 0, 0 },

  { 469, TARGET_STRING("b"), 0, 0, 0 },

  { 470, TARGET_STRING("bMy"), 0, 0, 0 },

  { 471, TARGET_STRING("b_CG"), 0, 0, 0 },

  { 472, TARGET_STRING("bd"), 0, 0, 0 },

  { 473, TARGET_STRING("betaMy"), 0, 0, 0 },

  { 474, TARGET_STRING("bi"), 0, 0, 0 },

  { 475, TARGET_STRING("bout"), 0, 12, 0 },

  { 476, TARGET_STRING("br"), 0, 0, 0 },

  { 477, TARGET_STRING("bt"), 0, 0, 0 },

  { 478, TARGET_STRING("bw1"), 0, 0, 0 },

  { 479, TARGET_STRING("bw2"), 0, 0, 0 },

  { 480, TARGET_STRING("cMy"), 0, 0, 0 },

  { 481, TARGET_STRING("disk_abore"), 0, 0, 0 },

  { 482, TARGET_STRING("domega_o"), 0, 0, 0 },

  { 483, TARGET_STRING("eta_diff"), 0, 0, 0 },

  { 484, TARGET_STRING("eta_tbl"), 0, 13, 0 },

  { 485, TARGET_STRING("g"), 0, 0, 0 },

  { 486, TARGET_STRING("h"), 0, 0, 0 },

  { 487, TARGET_STRING("k"), 0, 0, 0 },

  { 488, TARGET_STRING("kappamax"), 0, 0, 0 },

  { 489, TARGET_STRING("lam_x"), 0, 0, 0 },

  { 490, TARGET_STRING("mu_kinetic"), 0, 0, 0 },

  { 491, TARGET_STRING("mu_static"), 0, 0, 0 },

  { 492, TARGET_STRING("muk"), 0, 0, 0 },

  { 493, TARGET_STRING("mus"), 0, 0, 0 },

  { 494, TARGET_STRING("num_pads"), 0, 0, 0 },

  { 495, TARGET_STRING("omega_bpts"), 0, 14, 0 },

  { 496, TARGET_STRING("omega_c"), 0, 0, 0 },

  { 497, TARGET_STRING("omega_o"), 0, 0, 0 },

  { 498, TARGET_STRING("omegai_o"), 0, 0, 0 },

  { 499, TARGET_STRING("omegal"), 0, 0, 0 },

  { 500, TARGET_STRING("omegao"), 0, 0, 0 },

  { 501, TARGET_STRING("omegat_o"), 0, 0, 0 },

  { 502, TARGET_STRING("omegau"), 0, 0, 0 },

  { 503, TARGET_STRING("omegaw1o"), 0, 0, 0 },

  { 504, TARGET_STRING("omegaw2o"), 0, 0, 0 },

  { 505, TARGET_STRING("phi"), 0, 5, 0 },

  { 506, TARGET_STRING("philu"), 0, 0, 0 },

  { 507, TARGET_STRING("press"), 0, 0, 0 },

  { 508, TARGET_STRING("psi"), 0, 5, 0 },

  { 509, TARGET_STRING("tauC"), 0, 0, 0 },

  { 510, TARGET_STRING("tauTC"), 0, 0, 0 },

  { 511, TARGET_STRING("tau_s"), 0, 0, 0 },

  { 512, TARGET_STRING("theta_o"), 0, 0, 0 },

  { 513, TARGET_STRING("wc"), 0, 0, 0 },

  { 514, TARGET_STRING("x_o"), 0, 0, 0 },

  { 515, TARGET_STRING("xdot_o"), 0, 0, 0 },

  { 516, TARGET_STRING("zeta"), 0, 5, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void DrivetrainHevP4_InitializeDataAddr(void* dataAddr[],
  B_DrivetrainHevP4_c_T *localB, X_DrivetrainHevP4_n_T *localX)
{
  dataAddr[0] = (void*) (&localB->Divide);
  dataAddr[1] = (void*) (&localB->Divide_l);
  dataAddr[2] = (void*) (&localB->sf_OpenDifferential.xdot[0]);
  dataAddr[3] = (void*) (&localB->VectorConcatenate_l[0]);
  dataAddr[4] = (void*) (&localB->VectorConcatenate_l[0]);
  dataAddr[5] = (void*) (( &localB->VectorConcatenate_l[0] + 1));
  dataAddr[6] = (void*) (&localB->sf_OpenDifferential_l.xdot[0]);
  dataAddr[7] = (void*) (&localB->VectorConcatenate_b[0]);
  dataAddr[8] = (void*) (&localB->VectorConcatenate_b[0]);
  dataAddr[9] = (void*) (( &localB->VectorConcatenate_b[0] + 1));
  dataAddr[10] = (void*) (&localB->Constant1);
  dataAddr[11] = (void*) (&localB->upi);
  dataAddr[12] = (void*) (&localB->SpdRatio);
  dataAddr[13] = (void*) (&localB->SpdRatio);
  dataAddr[14] = (void*) (&localB->SpdRatio);
  dataAddr[15] = (void*) (&localB->VectorConcatenate2[0]);
  dataAddr[16] = (void*) (&localB->sf_SimpleMagicTire.Fx);
  dataAddr[17] = (void*) (&localB->sf_SimpleMagicTire.My);
  dataAddr[18] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[19] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[20] = (void*) (&localB->Signconvention);
  dataAddr[21] = (void*) (&localB->Saturation);
  dataAddr[22] = (void*) (&localB->sf_SimpleMagicTire_c.Fx);
  dataAddr[23] = (void*) (&localB->sf_SimpleMagicTire_c.My);
  dataAddr[24] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[25] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[26] = (void*) (&localB->Signconvention_o);
  dataAddr[27] = (void*) (&localB->Saturation_f);
  dataAddr[28] = (void*) (&localB->domega_o);
  dataAddr[29] = (void*) (&localB->Subtract_l);
  dataAddr[30] = (void*) (&localB->diffDir);
  dataAddr[31] = (void*) (&localB->diffDir_n);
  dataAddr[32] = (void*) (&localB->domega_o_m);
  dataAddr[33] = (void*) (&localB->Subtract_e);
  dataAddr[34] = (void*) (&localB->domega_o_j);
  dataAddr[35] = (void*) (&localB->Subtract);
  dataAddr[36] = (void*) (&localB->domega_o_h);
  dataAddr[37] = (void*) (&localB->Subtract_n);
  dataAddr[38] = (void*) (&localB->Memory_o);
  dataAddr[39] = (void*) (&localB->Product_a);
  dataAddr[40] = (void*) (&localB->IC_f);
  dataAddr[41] = (void*) (&localB->Switch_a);
  dataAddr[42] = (void*) (&localB->Product8_e);
  dataAddr[43] = (void*) (&localB->IC_a);
  dataAddr[44] = (void*) (&localB->Switch_p);
  dataAddr[45] = (void*) (&localB->Product4);
  dataAddr[46] = (void*) (&localB->Product8);
  dataAddr[47] = (void*) (&localB->IC_b);
  dataAddr[48] = (void*) (&localB->Switch_ht);
  dataAddr[49] = (void*) (&localB->IC);
  dataAddr[50] = (void*) (&localB->Switch);
  dataAddr[51] = (void*) (&localB->IC_i);
  dataAddr[52] = (void*) (&localB->Switch_k);
  dataAddr[53] = (void*) (&localB->Inertia);
  dataAddr[54] = (void*) (&localB->ImpellerInertia);
  dataAddr[55] = (void*) (&localB->TurbineInertia);
  dataAddr[56] = (void*) (&localB->SpdRatio);
  dataAddr[57] = (void*) (&localB->IC_p);
  dataAddr[58] = (void*) (&localB->Switch_h);
  dataAddr[59] = (void*) (&localB->xddot);
  dataAddr[60] = (void*) (&localB->Fz);
  dataAddr[61] = (void*) (&localB->Integrator);
  dataAddr[62] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omega);
  dataAddr[63] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[64] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[65] = (void*) (&localB->Ratioofstatictokinetic);
  dataAddr[66] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omega);
  dataAddr[67] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[68] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[69] = (void*) (&localB->Ratioofstatictokinetic_i);
  dataAddr[70] = (void*) (&localB->Memory);
  dataAddr[71] = (void*) (&localB->Product_m);
  dataAddr[72] = (void*) (&localB->Memory_f);
  dataAddr[73] = (void*) (&localB->Product_b);
  dataAddr[74] = (void*) (&localB->Memory_ku);
  dataAddr[75] = (void*) (&localB->Product_d);
  dataAddr[76] = (void*) (&localB->Memory_k);
  dataAddr[77] = (void*) (&localB->Product_o);
  dataAddr[78] = (void*) (&localB->VelocitiesMatch);
  dataAddr[79] = (void*) (&localB->Sum);
  dataAddr[80] = (void*) (&localB->Memory_kc);
  dataAddr[81] = (void*) (&localB->Constant2);
  dataAddr[82] = (void*) (&localB->Hz2rad);
  dataAddr[83] = (void*) (&localB->Relay1);
  dataAddr[84] = (void*) (&localB->VectorConcatenate[0]);
  dataAddr[85] = (void*) (&localB->VectorConcatenate[0]);
  dataAddr[86] = (void*) (( &localB->VectorConcatenate[0] + 2));
  dataAddr[87] = (void*) (( &localB->VectorConcatenate[0] + 3));
  dataAddr[88] = (void*) (( &localB->VectorConcatenate[0] + 1));
  dataAddr[89] = (void*) (( &localB->VectorConcatenate[0] + 5));
  dataAddr[90] = (void*) (( &localB->VectorConcatenate[0] + 4));
  dataAddr[91] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omega);
  dataAddr[92] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[93] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[94] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omega);
  dataAddr[95] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[96] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[97] = (void*) (&localB->Clutch.CoreSubsys[0].
    sf_Clutch.CombinatorialLogic);
  dataAddr[98] = (void*) (&localB->Clutch.CoreSubsys[0].
    sf_Clutch.RelationalOperator);
  dataAddr[99] = (void*) (&localB->Product_o4);
  dataAddr[100] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omega);
  dataAddr[101] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[102] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[103] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omega);
  dataAddr[104] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Omegadot);
  dataAddr[105] = (void*) (&localB->Clutch_e.CoreSubsys[0].sf_Clutch.Myb);
  dataAddr[106] = (void*) (&localB->Clutch_e.CoreSubsys[0].
    sf_Clutch.CombinatorialLogic);
  dataAddr[107] = (void*) (&localB->Clutch_e.CoreSubsys[0].
    sf_Clutch.RelationalOperator);
  dataAddr[108] = (void*) (&localB->Product_de);
  dataAddr[109] = (void*) (&localB->diffDir_o);
  dataAddr[110] = (void*) (&localB->diffDir_g);
  dataAddr[111] = (void*) (&localB->Memory_b);
  dataAddr[112] = (void*) (&localB->Product);
  dataAddr[113] = (void*) (&localB->Integrator_k);
  dataAddr[114] = (void*) (&localB->VectorConcatenate_a[0]);
  dataAddr[115] = (void*) (&localB->VectorConcatenate_a[0]);
  dataAddr[116] = (void*) (( &localB->VectorConcatenate_a[0] + 1));
  dataAddr[117] = (void*) (&localB->TorqueConversion);
  dataAddr[118] = (void*) (&localB->TorqueConversion1);
  dataAddr[119] = (void*) (&localB->Clutch.CoreSubsys[0].sf_Clutch.OutputInertia);
  dataAddr[120] = (void*) (&localB->TorqueConversion_b);
  dataAddr[121] = (void*) (&localB->TorqueConversion1_b);
  dataAddr[122] = (void*) (&localB->Clutch_e.CoreSubsys[0].
    sf_Clutch.OutputInertia);
  dataAddr[123] = (void*) (&localB->Compare);
  dataAddr[124] = (void*) (&localB->Clutch.CoreSubsys[0].
    sf_Clutch.RelationalOperator);
  dataAddr[125] = (void*) (&localB->Clutch_e.CoreSubsys[0].
    sf_Clutch.RelationalOperator);
  dataAddr[126] = (void*) (&localB->Integrator_k);
  dataAddr[127] = (void*) (&localB->Product_f);
  dataAddr[128] = (void*) (&localB->Clutch.CoreSubsys[0].
    sf_Clutch.CombinatorialLogic);
  dataAddr[129] = (void*) (&localB->Clutch_e.CoreSubsys[0].
    sf_Clutch.CombinatorialLogic);
  dataAddr[130] = (void*) (&DrivetrainHevP4_P.IdealFixedGearTransmission_G_o);
  dataAddr[131] = (void*)
    (&DrivetrainHevP4_P.IdealFixedGearTransmission_omegaN_o);
  dataAddr[132] = (void*) (&DrivetrainHevP4_P.VehicleBody1DOFLongitudinal_Cl);
  dataAddr[133] = (void*) (&DrivetrainHevP4_P.VehicleBody1DOFLongitudinal_Cpm);
  dataAddr[134] = (void*) (&DrivetrainHevP4_P.Integrator_IC_f);
  dataAddr[135] = (void*) (&DrivetrainHevP4_P.Gain_Gain_k);
  dataAddr[136] = (void*) (&DrivetrainHevP4_P.Gain1_Gain);
  dataAddr[137] = (void*) (&DrivetrainHevP4_P.Integrator1_IC_f);
  dataAddr[138] = (void*) (&DrivetrainHevP4_P.Integrator1_IC);
  dataAddr[139] = (void*) (&DrivetrainHevP4_P.FExtConstant_Value[0]);
  dataAddr[140] = (void*) (&DrivetrainHevP4_P.MExtConstant_Value[0]);
  dataAddr[141] = (void*) (&DrivetrainHevP4_P.FxType_Value);
  dataAddr[142] = (void*) (&DrivetrainHevP4_P.rollType_Value);
  dataAddr[143] = (void*) (&DrivetrainHevP4_P.vertType_Value);
  dataAddr[144] = (void*) (&DrivetrainHevP4_P.FxType_Value_m);
  dataAddr[145] = (void*) (&DrivetrainHevP4_P.rollType_Value_h);
  dataAddr[146] = (void*) (&DrivetrainHevP4_P.vertType_Value_e);
  dataAddr[147] = (void*)
    (&DrivetrainHevP4_P.sf_OpenDifferential.OpenDifferential_shaftSwitchMask);
  dataAddr[148] = (void*) (&DrivetrainHevP4_P.Integrator_UpperSat);
  dataAddr[149] = (void*) (&DrivetrainHevP4_P.Integrator_LowerSat);
  dataAddr[150] = (void*)
    (&DrivetrainHevP4_P.sf_OpenDifferential_l.OpenDifferential_shaftSwitchMask);
  dataAddr[151] = (void*) (&DrivetrainHevP4_P.Integrator_UpperSat_j);
  dataAddr[152] = (void*) (&DrivetrainHevP4_P.Integrator_LowerSat_o);
  dataAddr[153] = (void*) (&DrivetrainHevP4_P.upi_Gain);
  dataAddr[154] = (void*) (&DrivetrainHevP4_P.Merge1_InitialOutput);
  dataAddr[155] = (void*) (&DrivetrainHevP4_P.Signconvention_Gain);
  dataAddr[156] = (void*) (&DrivetrainHevP4_P.Saturation_UpperSat_f);
  dataAddr[157] = (void*) (&DrivetrainHevP4_P.Saturation_LowerSat_n);
  dataAddr[158] = (void*) (&DrivetrainHevP4_P.Signconvention_Gain_c);
  dataAddr[159] = (void*) (&DrivetrainHevP4_P.Saturation_UpperSat_p);
  dataAddr[160] = (void*) (&DrivetrainHevP4_P.Saturation_LowerSat_d);
  dataAddr[161] = (void*) (&DrivetrainHevP4_P.Constant_Value_d);
  dataAddr[162] = (void*) (&DrivetrainHevP4_P.Constant1_Value_iv);
  dataAddr[163] = (void*) (&DrivetrainHevP4_P.Gain1_Gain_a);
  dataAddr[164] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_c);
  dataAddr[165] = (void*) (&DrivetrainHevP4_P.Constant_Value_nn);
  dataAddr[166] = (void*) (&DrivetrainHevP4_P.Constant1_Value_m0);
  dataAddr[167] = (void*) (&DrivetrainHevP4_P.Gain1_Gain_f);
  dataAddr[168] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_b);
  dataAddr[169] = (void*) (&DrivetrainHevP4_P.Reset_Value_m);
  dataAddr[170] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition_b);
  dataAddr[171] = (void*) (&DrivetrainHevP4_P.Constant1_Value_f);
  dataAddr[172] = (void*) (&DrivetrainHevP4_P.IC_Value_k);
  dataAddr[173] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_il);
  dataAddr[174] = (void*) (&DrivetrainHevP4_P.Constant1_Value_ou);
  dataAddr[175] = (void*) (&DrivetrainHevP4_P.IC_Value_bb);
  dataAddr[176] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_l2);
  dataAddr[177] = (void*) (&DrivetrainHevP4_P.First_Value);
  dataAddr[178] = (void*) (&DrivetrainHevP4_P.Neutral_Value);
  dataAddr[179] = (void*) (&DrivetrainHevP4_P.NoInputTorque_Value);
  dataAddr[180] = (void*) (&DrivetrainHevP4_P.Constant1_Value_g);
  dataAddr[181] = (void*) (&DrivetrainHevP4_P.IC_Value_b);
  dataAddr[182] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_gl);
  dataAddr[183] = (void*) (&DrivetrainHevP4_P.Constant1_Value_bf);
  dataAddr[184] = (void*) (&DrivetrainHevP4_P.IC_Value);
  dataAddr[185] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_k);
  dataAddr[186] = (void*) (&DrivetrainHevP4_P.Constant1_Value_j);
  dataAddr[187] = (void*) (&DrivetrainHevP4_P.IC_Value_m);
  dataAddr[188] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_g);
  dataAddr[189] = (void*) (&DrivetrainHevP4_P.Constant_Value_a);
  dataAddr[190] = (void*) (&DrivetrainHevP4_P.Constant1_Value);
  dataAddr[191] = (void*) (&DrivetrainHevP4_P.Constant2_Value);
  dataAddr[192] = (void*) (&DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat);
  dataAddr[193] = (void*) (&DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat);
  dataAddr[194] = (void*) (&DrivetrainHevP4_P.TorqueConverter_KType);
  dataAddr[195] = (void*) (&DrivetrainHevP4_P.u_Gain);
  dataAddr[196] = (void*) (&DrivetrainHevP4_P.PumpIntegrator_UpperSat);
  dataAddr[197] = (void*) (&DrivetrainHevP4_P.PumpIntegrator_LowerSat);
  dataAddr[198] = (void*) (&DrivetrainHevP4_P.TurbineIntegrator_UpperSat);
  dataAddr[199] = (void*) (&DrivetrainHevP4_P.TurbineIntegrator_LowerSat);
  dataAddr[200] = (void*) (&DrivetrainHevP4_P.Constant1_Value_io);
  dataAddr[201] = (void*) (&DrivetrainHevP4_P.IC_Value_o);
  dataAddr[202] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_m);
  dataAddr[203] = (void*) (&DrivetrainHevP4_P.Constant_Value_l);
  dataAddr[204] = (void*) (&DrivetrainHevP4_P.DragForce_beta_w[0]);
  dataAddr[205] = (void*) (&DrivetrainHevP4_P.DragForce_Cs[0]);
  dataAddr[206] = (void*) (&DrivetrainHevP4_P.DragForce_Cym[0]);
  dataAddr[207] = (void*) (&DrivetrainHevP4_P.DragForce_R);
  dataAddr[208] = (void*) (&DrivetrainHevP4_P.Constant_Value_px);
  dataAddr[209] = (void*) (&DrivetrainHevP4_P.Constant1_Value_n);
  dataAddr[210] = (void*) (&DrivetrainHevP4_P.Constant12_Value[0]);
  dataAddr[211] = (void*) (&DrivetrainHevP4_P.Constant14_Value[0]);
  dataAddr[212] = (void*) (&DrivetrainHevP4_P.Constant19_Value[0]);
  dataAddr[213] = (void*) (&DrivetrainHevP4_P.Constant2_Value_i[0]);
  dataAddr[214] = (void*) (&DrivetrainHevP4_P.Constant6_Value);
  dataAddr[215] = (void*) (&DrivetrainHevP4_P.Constant7_Value);
  dataAddr[216] = (void*) (&DrivetrainHevP4_P.Constant1_Value_i);
  dataAddr[217] = (void*) (&DrivetrainHevP4_P.Constant10_Value);
  dataAddr[218] = (void*) (&DrivetrainHevP4_P.Constant11_Value);
  dataAddr[219] = (void*) (&DrivetrainHevP4_P.Constant12_Value_b[0]);
  dataAddr[220] = (void*) (&DrivetrainHevP4_P.Constant14_Value_m[0]);
  dataAddr[221] = (void*) (&DrivetrainHevP4_P.Constant16_Value);
  dataAddr[222] = (void*) (&DrivetrainHevP4_P.Constant19_Value_f[0]);
  dataAddr[223] = (void*) (&DrivetrainHevP4_P.Constant2_Value_c);
  dataAddr[224] = (void*) (&DrivetrainHevP4_P.Constant3_Value);
  dataAddr[225] = (void*) (&DrivetrainHevP4_P.Constant5_Value);
  dataAddr[226] = (void*) (&DrivetrainHevP4_P.Constant7_Value_o);
  dataAddr[227] = (void*) (&DrivetrainHevP4_P.Constant9_Value);
  dataAddr[228] = (void*) (&DrivetrainHevP4_P.Constant1_Value_m);
  dataAddr[229] = (void*) (&DrivetrainHevP4_P.Constant10_Value_a);
  dataAddr[230] = (void*) (&DrivetrainHevP4_P.Constant11_Value_f);
  dataAddr[231] = (void*) (&DrivetrainHevP4_P.Constant13_Value);
  dataAddr[232] = (void*) (&DrivetrainHevP4_P.Constant14_Value_h);
  dataAddr[233] = (void*) (&DrivetrainHevP4_P.Constant15_Value);
  dataAddr[234] = (void*) (&DrivetrainHevP4_P.Constant16_Value_i);
  dataAddr[235] = (void*) (&DrivetrainHevP4_P.Constant17_Value);
  dataAddr[236] = (void*) (&DrivetrainHevP4_P.Constant18_Value);
  dataAddr[237] = (void*) (&DrivetrainHevP4_P.Constant19_Value_h);
  dataAddr[238] = (void*) (&DrivetrainHevP4_P.Constant2_Value_f);
  dataAddr[239] = (void*) (&DrivetrainHevP4_P.Constant20_Value);
  dataAddr[240] = (void*) (&DrivetrainHevP4_P.Constant21_Value);
  dataAddr[241] = (void*) (&DrivetrainHevP4_P.Constant22_Value);
  dataAddr[242] = (void*) (&DrivetrainHevP4_P.Constant23_Value);
  dataAddr[243] = (void*) (&DrivetrainHevP4_P.Constant24_Value);
  dataAddr[244] = (void*) (&DrivetrainHevP4_P.Constant3_Value_a);
  dataAddr[245] = (void*) (&DrivetrainHevP4_P.Constant4_Value);
  dataAddr[246] = (void*) (&DrivetrainHevP4_P.Constant5_Value_e);
  dataAddr[247] = (void*) (&DrivetrainHevP4_P.Constant6_Value_i);
  dataAddr[248] = (void*) (&DrivetrainHevP4_P.Constant7_Value_l);
  dataAddr[249] = (void*) (&DrivetrainHevP4_P.Constant8_Value);
  dataAddr[250] = (void*) (&DrivetrainHevP4_P.Constant9_Value_m);
  dataAddr[251] = (void*) (&DrivetrainHevP4_P.Constant_Value_n);
  dataAddr[252] = (void*) (&DrivetrainHevP4_P.Constant1_Value_if);
  dataAddr[253] = (void*) (&DrivetrainHevP4_P.Constant12_Value_m[0]);
  dataAddr[254] = (void*) (&DrivetrainHevP4_P.Constant14_Value_n[0]);
  dataAddr[255] = (void*) (&DrivetrainHevP4_P.Constant19_Value_e[0]);
  dataAddr[256] = (void*) (&DrivetrainHevP4_P.Constant2_Value_f4[0]);
  dataAddr[257] = (void*) (&DrivetrainHevP4_P.Constant6_Value_k);
  dataAddr[258] = (void*) (&DrivetrainHevP4_P.Constant7_Value_i);
  dataAddr[259] = (void*) (&DrivetrainHevP4_P.Constant1_Value_o);
  dataAddr[260] = (void*) (&DrivetrainHevP4_P.Constant10_Value_g);
  dataAddr[261] = (void*) (&DrivetrainHevP4_P.Constant11_Value_b);
  dataAddr[262] = (void*) (&DrivetrainHevP4_P.Constant12_Value_g[0]);
  dataAddr[263] = (void*) (&DrivetrainHevP4_P.Constant14_Value_j[0]);
  dataAddr[264] = (void*) (&DrivetrainHevP4_P.Constant16_Value_g);
  dataAddr[265] = (void*) (&DrivetrainHevP4_P.Constant19_Value_b[0]);
  dataAddr[266] = (void*) (&DrivetrainHevP4_P.Constant2_Value_h);
  dataAddr[267] = (void*) (&DrivetrainHevP4_P.Constant3_Value_i);
  dataAddr[268] = (void*) (&DrivetrainHevP4_P.Constant5_Value_k);
  dataAddr[269] = (void*) (&DrivetrainHevP4_P.Constant7_Value_c);
  dataAddr[270] = (void*) (&DrivetrainHevP4_P.Constant9_Value_d);
  dataAddr[271] = (void*) (&DrivetrainHevP4_P.Constant1_Value_b);
  dataAddr[272] = (void*) (&DrivetrainHevP4_P.Constant10_Value_p);
  dataAddr[273] = (void*) (&DrivetrainHevP4_P.Constant11_Value_fj);
  dataAddr[274] = (void*) (&DrivetrainHevP4_P.Constant13_Value_i);
  dataAddr[275] = (void*) (&DrivetrainHevP4_P.Constant14_Value_b);
  dataAddr[276] = (void*) (&DrivetrainHevP4_P.Constant15_Value_l);
  dataAddr[277] = (void*) (&DrivetrainHevP4_P.Constant16_Value_p);
  dataAddr[278] = (void*) (&DrivetrainHevP4_P.Constant17_Value_a);
  dataAddr[279] = (void*) (&DrivetrainHevP4_P.Constant18_Value_e);
  dataAddr[280] = (void*) (&DrivetrainHevP4_P.Constant19_Value_j);
  dataAddr[281] = (void*) (&DrivetrainHevP4_P.Constant2_Value_o);
  dataAddr[282] = (void*) (&DrivetrainHevP4_P.Constant20_Value_a);
  dataAddr[283] = (void*) (&DrivetrainHevP4_P.Constant21_Value_m);
  dataAddr[284] = (void*) (&DrivetrainHevP4_P.Constant22_Value_n);
  dataAddr[285] = (void*) (&DrivetrainHevP4_P.Constant23_Value_n);
  dataAddr[286] = (void*) (&DrivetrainHevP4_P.Constant24_Value_n);
  dataAddr[287] = (void*) (&DrivetrainHevP4_P.Constant3_Value_f);
  dataAddr[288] = (void*) (&DrivetrainHevP4_P.Constant4_Value_h);
  dataAddr[289] = (void*) (&DrivetrainHevP4_P.Constant5_Value_h);
  dataAddr[290] = (void*) (&DrivetrainHevP4_P.Constant6_Value_h);
  dataAddr[291] = (void*) (&DrivetrainHevP4_P.Constant7_Value_k);
  dataAddr[292] = (void*) (&DrivetrainHevP4_P.Constant8_Value_d);
  dataAddr[293] = (void*) (&DrivetrainHevP4_P.Constant9_Value_dg);
  dataAddr[294] = (void*) (&DrivetrainHevP4_P.Reset_Value_e);
  dataAddr[295] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition);
  dataAddr[296] = (void*) (&DrivetrainHevP4_P.Constant_Value_h);
  dataAddr[297] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_kx);
  dataAddr[298] = (void*) (&DrivetrainHevP4_P.Constant_Value_kx);
  dataAddr[299] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_mt);
  dataAddr[300] = (void*) (&DrivetrainHevP4_P.Constant_Value_cg);
  dataAddr[301] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_j);
  dataAddr[302] = (void*) (&DrivetrainHevP4_P.Constant_Value_j);
  dataAddr[303] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_bp);
  dataAddr[304] = (void*) (&DrivetrainHevP4_P.Constant_Value_jy);
  dataAddr[305] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_au);
  dataAddr[306] = (void*) (&DrivetrainHevP4_P.Constant_Value_e);
  dataAddr[307] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_f);
  dataAddr[308] = (void*) (&DrivetrainHevP4_P.Reset_Value_l);
  dataAddr[309] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition_j);
  dataAddr[310] = (void*) (&DrivetrainHevP4_P.Reset_Value_i);
  dataAddr[311] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition_f);
  dataAddr[312] = (void*) (&DrivetrainHevP4_P.Reset_Value_g);
  dataAddr[313] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition_g);
  dataAddr[314] = (void*) (&DrivetrainHevP4_P.Constant_Value);
  dataAddr[315] = (void*) (&DrivetrainHevP4_P.Switch_Threshold);
  dataAddr[316] = (void*) (&DrivetrainHevP4_P.Constant_Value_f);
  dataAddr[317] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_a);
  dataAddr[318] = (void*) (&DrivetrainHevP4_P.div0protectabspoly_thresh);
  dataAddr[319] = (void*) (&DrivetrainHevP4_P.Gain_Gain);
  dataAddr[320] = (void*) (&DrivetrainHevP4_P.Saturation_UpperSat);
  dataAddr[321] = (void*) (&DrivetrainHevP4_P.Saturation_LowerSat);
  dataAddr[322] = (void*) (&DrivetrainHevP4_P.Saturation1_UpperSat);
  dataAddr[323] = (void*) (&DrivetrainHevP4_P.Saturation1_LowerSat);
  dataAddr[324] = (void*) (&DrivetrainHevP4_P.Saturation2_UpperSat);
  dataAddr[325] = (void*) (&DrivetrainHevP4_P.Saturation2_LowerSat);
  dataAddr[326] = (void*) (&DrivetrainHevP4_P.Constant_Value_i);
  dataAddr[327] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_i);
  dataAddr[328] = (void*) (&DrivetrainHevP4_P.div0protectabspoly_thresh_k);
  dataAddr[329] = (void*) (&DrivetrainHevP4_P.Gain_Gain_m);
  dataAddr[330] = (void*) (&DrivetrainHevP4_P.Saturation_UpperSat_i);
  dataAddr[331] = (void*) (&DrivetrainHevP4_P.Saturation_LowerSat_l);
  dataAddr[332] = (void*) (&DrivetrainHevP4_P.Saturation1_UpperSat_i);
  dataAddr[333] = (void*) (&DrivetrainHevP4_P.Saturation1_LowerSat_k);
  dataAddr[334] = (void*) (&DrivetrainHevP4_P.Saturation2_UpperSat_b);
  dataAddr[335] = (void*) (&DrivetrainHevP4_P.Saturation2_LowerSat_d);
  dataAddr[336] = (void*) (&DrivetrainHevP4_P.VelocitiesMatch_Offset);
  dataAddr[337] = (void*) (&DrivetrainHevP4_P.CombinatorialLogic_table[0]);
  dataAddr[338] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition_o);
  dataAddr[339] = (void*) (&DrivetrainHevP4_P.Constant2_Value_a);
  dataAddr[340] = (void*) (&DrivetrainHevP4_P.Hz2rad_Gain);
  dataAddr[341] = (void*) (&DrivetrainHevP4_P.Relay1_YOn);
  dataAddr[342] = (void*) (&DrivetrainHevP4_P.Relay1_YOff);
  dataAddr[343] = (void*)
    (&DrivetrainHevP4_P.CapacityKfactorInterpolation_maxIndex);
  dataAddr[344] = (void*)
    (&DrivetrainHevP4_P.TorqueRatiozetaInterpolation_maxIndex);
  dataAddr[345] = (void*) (&DrivetrainHevP4_P.uniclutch_UpperSat);
  dataAddr[346] = (void*) (&DrivetrainHevP4_P.uniclutch_LowerSat);
  dataAddr[347] = (void*) (&DrivetrainHevP4_P.Switch1_Threshold_f);
  dataAddr[348] = (void*) (&DrivetrainHevP4_P.Constant1_Value_bz);
  dataAddr[349] = (void*) (&DrivetrainHevP4_P.Constant2_Value_m);
  dataAddr[350] = (void*) (&DrivetrainHevP4_P.u_Gain_c[0]);
  dataAddr[351] = (void*) (&DrivetrainHevP4_P.Crm_tableData[0]);
  dataAddr[352] = (void*) (&DrivetrainHevP4_P.Crm_bp01Data[0]);
  dataAddr[353] = (void*) (&DrivetrainHevP4_P.Integrator_IC_c);
  dataAddr[354] = (void*) (&DrivetrainHevP4_P.Integrator_IC_h);
  dataAddr[355] = (void*) (&DrivetrainHevP4_P.Constant_Value_jq);
  dataAddr[356] = (void*) (&DrivetrainHevP4_P.Constant6_Value_fv);
  dataAddr[357] = (void*) (&DrivetrainHevP4_P.Switch1_Threshold_n);
  dataAddr[358] = (void*) (&DrivetrainHevP4_P.Constant_Value_o);
  dataAddr[359] = (void*) (&DrivetrainHevP4_P.Constant6_Value_f);
  dataAddr[360] = (void*) (&DrivetrainHevP4_P.Switch1_Threshold_b);
  dataAddr[361] = (void*) (&DrivetrainHevP4_P.Reset_Value);
  dataAddr[362] = (void*) (&DrivetrainHevP4_P.Memory_InitialCondition_e);
  dataAddr[363] = (void*) (&DrivetrainHevP4_P.Saturation_UpperSat_h);
  dataAddr[364] = (void*) (&DrivetrainHevP4_P.Saturation_LowerSat_f);
  dataAddr[365] = (void*) (&DrivetrainHevP4_P.Switch_Threshold_l);
  dataAddr[366] = (void*) (&DrivetrainHevP4_P.CompareToConstant2_const);
  dataAddr[367] = (void*) (&DrivetrainHevP4_P.div0protectpoly_thresh);
  dataAddr[368] = (void*) (&DrivetrainHevP4_P.Constant_Value_p);
  dataAddr[369] = (void*) (&DrivetrainHevP4_P.Constant1_Value_h);
  dataAddr[370] = (void*) (&DrivetrainHevP4_P.Gain_Gain_p);
  dataAddr[371] = (void*)
    (&DrivetrainHevP4_P.HardPointCoordinateTransformFront_R_T2);
  dataAddr[372] = (void*)
    (&DrivetrainHevP4_P.HardPointCoordinateTransformRear_R_T2);
  dataAddr[373] = (void*) (&DrivetrainHevP4_P.Constant_Value_cb);
  dataAddr[374] = (void*) (&DrivetrainHevP4_P.TorqueConversion1_Gain);
  dataAddr[375] = (void*)
    (&DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat);
  dataAddr[376] = (void*)
    (&DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat);
  dataAddr[377] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.locked_Value);
  dataAddr[378] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.locked1_Value);
  dataAddr[379] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.locked2_Value);
  dataAddr[380] = (void*) (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.u_Gain);
  dataAddr[381] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.yn_Y0_e);
  dataAddr[382] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.Constant_Value);
  dataAddr[383] = (void*) (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.yn_Y0);
  dataAddr[384] = (void*) (&DrivetrainHevP4_P.TorqueConversion1_Gain_b);
  dataAddr[385] = (void*)
    (&DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o);
  dataAddr[386] = (void*)
    (&DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o);
  dataAddr[387] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.locked_Value);
  dataAddr[388] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.locked1_Value);
  dataAddr[389] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.locked2_Value);
  dataAddr[390] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.u_Gain);
  dataAddr[391] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.yn_Y0_e);
  dataAddr[392] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.Constant_Value);
  dataAddr[393] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.yn_Y0);
  dataAddr[394] = (void*) (&DrivetrainHevP4_P.Eta4D_maxIndex[0]);
  dataAddr[395] = (void*) (&DrivetrainHevP4_P.Eta4D_dimSizes[0]);
  dataAddr[396] = (void*) (&DrivetrainHevP4_P.Eta4D_maxIndex_m[0]);
  dataAddr[397] = (void*) (&DrivetrainHevP4_P.Eta4D_dimSizes_m[0]);
  dataAddr[398] = (void*) (&DrivetrainHevP4_P.Constant_Value_k);
  dataAddr[399] = (void*) (&DrivetrainHevP4_P.Out1_Y0);
  dataAddr[400] = (void*) (&DrivetrainHevP4_P.Gain_Gain_d);
  dataAddr[401] = (void*) (&DrivetrainHevP4_P.Saturation_UpperSat_b);
  dataAddr[402] = (void*) (&DrivetrainHevP4_P.Saturation_LowerSat_o);
  dataAddr[403] = (void*) (&DrivetrainHevP4_P.Constant_Value_c);
  dataAddr[404] = (void*) (&DrivetrainHevP4_P.Switch1_Threshold);
  dataAddr[405] = (void*) (&DrivetrainHevP4_P.Integrator_IC);
  dataAddr[406] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.CombinatorialLogic_table[0]);
  dataAddr[407] = (void*)
    (&DrivetrainHevP4_P.Clutch.CoreSubsys.sf_Clutch.UnitDelay_InitialCondition);
  dataAddr[408] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.CombinatorialLogic_table[0]);
  dataAddr[409] = (void*)
    (&DrivetrainHevP4_P.Clutch_e.CoreSubsys.sf_Clutch.UnitDelay_InitialCondition);
  dataAddr[410] = (void*) (&localX->Integrator_CSTATE_d[0]);
  dataAddr[411] = (void*) (&localX->Integrator1_CSTATE_g);
  dataAddr[412] = (void*) (&localX->Integrator1_CSTATE);
  dataAddr[413] = (void*) (&localX->Integrator_CSTATE_o[0]);
  dataAddr[414] = (void*) (&localX->Integrator_CSTATE_n[0]);
  dataAddr[415] = (void*) (&localX->Integrator1_CSTATE_f);
  dataAddr[416] = (void*) (&localX->Integrator_CSTATE_c);
  dataAddr[417] = (void*) (&localX->Integrator_CSTATE_i);
  dataAddr[418] = (void*) (&localX->Integrator_CSTATE_g4);
  dataAddr[419] = (void*) (&localX->Integrator_CSTATE_g);
  dataAddr[420] = (void*) (&localX->Integrator_CSTATE_h1);
  dataAddr[421] = (void*) (&localX->w);
  dataAddr[422] = (void*) (&localX->we);
  dataAddr[423] = (void*) (&localX->wv);
  dataAddr[424] = (void*) (&localX->LockedShaftIntegrator_CSTATE);
  dataAddr[425] = (void*) (&localX->PumpIntegrator_CSTATE);
  dataAddr[426] = (void*) (&localX->TurbineIntegrator_CSTATE);
  dataAddr[427] = (void*) (&localX->Integrator_CSTATE);
  dataAddr[428] = (void*) (&localX->Integrator_CSTATE_a);
  dataAddr[429] = (void*) (&localX->Integrator_CSTATE_l);
  dataAddr[430] = (void*) (&localX->Integrator_CSTATE_j);
  dataAddr[431] = (void*) (&localX->Integrator_CSTATE_de);
  dataAddr[432] = (void*) (&localX->Integrator_CSTATE_h);
  dataAddr[433] = (void*) (&localX->Integrator_CSTATE_hm);
  dataAddr[434] = (void*) (&localX->Integrator_CSTATE_b);
  dataAddr[435] = (void*) (&localX->Integrator3_CSTATE);
  dataAddr[436] = (void*) (&localX->Integrator_CSTATE_e);
  dataAddr[437] = (void*) (&DrivetrainHevP4_P.Af);
  dataAddr[438] = (void*) (&DrivetrainHevP4_P.Cd);
  dataAddr[439] = (void*) (&DrivetrainHevP4_P.FZMAX);
  dataAddr[440] = (void*) (&DrivetrainHevP4_P.FZMIN);
  dataAddr[441] = (void*) (&DrivetrainHevP4_P.G[0]);
  dataAddr[442] = (void*) (&DrivetrainHevP4_P.Iyy_Whl);
  dataAddr[443] = (void*) (&DrivetrainHevP4_P.Jd);
  dataAddr[444] = (void*) (&DrivetrainHevP4_P.Ji);
  dataAddr[445] = (void*) (&DrivetrainHevP4_P.Jout[0]);
  dataAddr[446] = (void*) (&DrivetrainHevP4_P.Jt);
  dataAddr[447] = (void*) (&DrivetrainHevP4_P.Jw1);
  dataAddr[448] = (void*) (&DrivetrainHevP4_P.Jw2);
  dataAddr[449] = (void*) (&DrivetrainHevP4_P.K_c);
  dataAddr[450] = (void*) (&DrivetrainHevP4_P.Lrel);
  dataAddr[451] = (void*) (&DrivetrainHevP4_P.Mass);
  dataAddr[452] = (void*) (&DrivetrainHevP4_P.N[0]);
  dataAddr[453] = (void*) (&DrivetrainHevP4_P.NF);
  dataAddr[454] = (void*) (&DrivetrainHevP4_P.NR);
  dataAddr[455] = (void*) (&DrivetrainHevP4_P.Ndiff);
  dataAddr[456] = (void*) (&DrivetrainHevP4_P.Ndiff_P4);
  dataAddr[457] = (void*) (&DrivetrainHevP4_P.Pabs);
  dataAddr[458] = (void*) (&DrivetrainHevP4_P.Re);
  dataAddr[459] = (void*) (&DrivetrainHevP4_P.Reff);
  dataAddr[460] = (void*) (&DrivetrainHevP4_P.Rm);
  dataAddr[461] = (void*) (&DrivetrainHevP4_P.T);
  dataAddr[462] = (void*) (&DrivetrainHevP4_P.Temp_bpts[0]);
  dataAddr[463] = (void*) (&DrivetrainHevP4_P.Trq_bpts[0]);
  dataAddr[464] = (void*) (&DrivetrainHevP4_P.UNLOADED_RADIUS);
  dataAddr[465] = (void*) (&DrivetrainHevP4_P.VXLOW);
  dataAddr[466] = (void*) (&DrivetrainHevP4_P.aMy);
  dataAddr[467] = (void*) (&DrivetrainHevP4_P.a_CG);
  dataAddr[468] = (void*) (&DrivetrainHevP4_P.alphaMy);
  dataAddr[469] = (void*) (&DrivetrainHevP4_P.b);
  dataAddr[470] = (void*) (&DrivetrainHevP4_P.bMy);
  dataAddr[471] = (void*) (&DrivetrainHevP4_P.b_CG);
  dataAddr[472] = (void*) (&DrivetrainHevP4_P.bd);
  dataAddr[473] = (void*) (&DrivetrainHevP4_P.betaMy);
  dataAddr[474] = (void*) (&DrivetrainHevP4_P.bi);
  dataAddr[475] = (void*) (&DrivetrainHevP4_P.bout[0]);
  dataAddr[476] = (void*) (&DrivetrainHevP4_P.br);
  dataAddr[477] = (void*) (&DrivetrainHevP4_P.bt);
  dataAddr[478] = (void*) (&DrivetrainHevP4_P.bw1);
  dataAddr[479] = (void*) (&DrivetrainHevP4_P.bw2);
  dataAddr[480] = (void*) (&DrivetrainHevP4_P.cMy);
  dataAddr[481] = (void*) (&DrivetrainHevP4_P.disk_abore);
  dataAddr[482] = (void*) (&DrivetrainHevP4_P.domega_o);
  dataAddr[483] = (void*) (&DrivetrainHevP4_P.eta_diff);
  dataAddr[484] = (void*) (&DrivetrainHevP4_P.eta_tbl[0]);
  dataAddr[485] = (void*) (&DrivetrainHevP4_P.g);
  dataAddr[486] = (void*) (&DrivetrainHevP4_P.h);
  dataAddr[487] = (void*) (&DrivetrainHevP4_P.k);
  dataAddr[488] = (void*) (&DrivetrainHevP4_P.kappamax);
  dataAddr[489] = (void*) (&DrivetrainHevP4_P.lam_x);
  dataAddr[490] = (void*) (&DrivetrainHevP4_P.mu_kinetic);
  dataAddr[491] = (void*) (&DrivetrainHevP4_P.mu_static);
  dataAddr[492] = (void*) (&DrivetrainHevP4_P.muk);
  dataAddr[493] = (void*) (&DrivetrainHevP4_P.mus);
  dataAddr[494] = (void*) (&DrivetrainHevP4_P.num_pads);
  dataAddr[495] = (void*) (&DrivetrainHevP4_P.omega_bpts[0]);
  dataAddr[496] = (void*) (&DrivetrainHevP4_P.omega_c);
  dataAddr[497] = (void*) (&DrivetrainHevP4_P.omega_o);
  dataAddr[498] = (void*) (&DrivetrainHevP4_P.omegai_o);
  dataAddr[499] = (void*) (&DrivetrainHevP4_P.omegal);
  dataAddr[500] = (void*) (&DrivetrainHevP4_P.omegao);
  dataAddr[501] = (void*) (&DrivetrainHevP4_P.omegat_o);
  dataAddr[502] = (void*) (&DrivetrainHevP4_P.omegau);
  dataAddr[503] = (void*) (&DrivetrainHevP4_P.omegaw1o);
  dataAddr[504] = (void*) (&DrivetrainHevP4_P.omegaw2o);
  dataAddr[505] = (void*) (&DrivetrainHevP4_P.phi[0]);
  dataAddr[506] = (void*) (&DrivetrainHevP4_P.philu);
  dataAddr[507] = (void*) (&DrivetrainHevP4_P.press);
  dataAddr[508] = (void*) (&DrivetrainHevP4_P.psi[0]);
  dataAddr[509] = (void*) (&DrivetrainHevP4_P.tauC);
  dataAddr[510] = (void*) (&DrivetrainHevP4_P.tauTC);
  dataAddr[511] = (void*) (&DrivetrainHevP4_P.tau_s);
  dataAddr[512] = (void*) (&DrivetrainHevP4_P.theta_o);
  dataAddr[513] = (void*) (&DrivetrainHevP4_P.wc);
  dataAddr[514] = (void*) (&DrivetrainHevP4_P.x_o);
  dataAddr[515] = (void*) (&DrivetrainHevP4_P.xdot_o);
  dataAddr[516] = (void*) (&DrivetrainHevP4_P.zeta[0]);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void DrivetrainHevP4_InitializeVarDimsAddr(int32_T* vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void DrivetrainHevP4_InitializeLoggingFunctions(RTWLoggingFcnPtr
  loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
  loggingPtrs[14] = (NULL);
  loggingPtrs[15] = (NULL);
  loggingPtrs[16] = (NULL);
  loggingPtrs[17] = (NULL);
  loggingPtrs[18] = (NULL);
  loggingPtrs[19] = (NULL);
  loggingPtrs[20] = (NULL);
  loggingPtrs[21] = (NULL);
  loggingPtrs[22] = (NULL);
  loggingPtrs[23] = (NULL);
  loggingPtrs[24] = (NULL);
  loggingPtrs[25] = (NULL);
  loggingPtrs[26] = (NULL);
  loggingPtrs[27] = (NULL);
  loggingPtrs[28] = (NULL);
  loggingPtrs[29] = (NULL);
  loggingPtrs[30] = (NULL);
  loggingPtrs[31] = (NULL);
  loggingPtrs[32] = (NULL);
  loggingPtrs[33] = (NULL);
  loggingPtrs[34] = (NULL);
  loggingPtrs[35] = (NULL);
  loggingPtrs[36] = (NULL);
  loggingPtrs[37] = (NULL);
  loggingPtrs[38] = (NULL);
  loggingPtrs[39] = (NULL);
  loggingPtrs[40] = (NULL);
  loggingPtrs[41] = (NULL);
  loggingPtrs[42] = (NULL);
  loggingPtrs[43] = (NULL);
  loggingPtrs[44] = (NULL);
  loggingPtrs[45] = (NULL);
  loggingPtrs[46] = (NULL);
  loggingPtrs[47] = (NULL);
  loggingPtrs[48] = (NULL);
  loggingPtrs[49] = (NULL);
  loggingPtrs[50] = (NULL);
  loggingPtrs[51] = (NULL);
  loggingPtrs[52] = (NULL);
  loggingPtrs[53] = (NULL);
  loggingPtrs[54] = (NULL);
  loggingPtrs[55] = (NULL);
  loggingPtrs[56] = (NULL);
  loggingPtrs[57] = (NULL);
  loggingPtrs[58] = (NULL);
  loggingPtrs[59] = (NULL);
  loggingPtrs[60] = (NULL);
  loggingPtrs[61] = (NULL);
  loggingPtrs[62] = (NULL);
  loggingPtrs[63] = (NULL);
  loggingPtrs[64] = (NULL);
  loggingPtrs[65] = (NULL);
  loggingPtrs[66] = (NULL);
  loggingPtrs[67] = (NULL);
  loggingPtrs[68] = (NULL);
  loggingPtrs[69] = (NULL);
  loggingPtrs[70] = (NULL);
  loggingPtrs[71] = (NULL);
  loggingPtrs[72] = (NULL);
  loggingPtrs[73] = (NULL);
  loggingPtrs[74] = (NULL);
  loggingPtrs[75] = (NULL);
  loggingPtrs[76] = (NULL);
  loggingPtrs[77] = (NULL);
  loggingPtrs[78] = (NULL);
  loggingPtrs[79] = (NULL);
  loggingPtrs[80] = (NULL);
  loggingPtrs[81] = (NULL);
  loggingPtrs[82] = (NULL);
  loggingPtrs[83] = (NULL);
  loggingPtrs[84] = (NULL);
  loggingPtrs[85] = (NULL);
  loggingPtrs[86] = (NULL);
  loggingPtrs[87] = (NULL);
  loggingPtrs[88] = (NULL);
  loggingPtrs[89] = (NULL);
  loggingPtrs[90] = (NULL);
  loggingPtrs[91] = (NULL);
  loggingPtrs[92] = (NULL);
  loggingPtrs[93] = (NULL);
  loggingPtrs[94] = (NULL);
  loggingPtrs[95] = (NULL);
  loggingPtrs[96] = (NULL);
  loggingPtrs[97] = (NULL);
  loggingPtrs[98] = (NULL);
  loggingPtrs[99] = (NULL);
  loggingPtrs[100] = (NULL);
  loggingPtrs[101] = (NULL);
  loggingPtrs[102] = (NULL);
  loggingPtrs[103] = (NULL);
  loggingPtrs[104] = (NULL);
  loggingPtrs[105] = (NULL);
  loggingPtrs[106] = (NULL);
  loggingPtrs[107] = (NULL);
  loggingPtrs[108] = (NULL);
  loggingPtrs[109] = (NULL);
  loggingPtrs[110] = (NULL);
  loggingPtrs[111] = (NULL);
  loggingPtrs[112] = (NULL);
  loggingPtrs[113] = (NULL);
  loggingPtrs[114] = (NULL);
  loggingPtrs[115] = (NULL);
  loggingPtrs[116] = (NULL);
  loggingPtrs[117] = (NULL);
  loggingPtrs[118] = (NULL);
  loggingPtrs[119] = (NULL);
  loggingPtrs[120] = (NULL);
  loggingPtrs[121] = (NULL);
  loggingPtrs[122] = (NULL);
  loggingPtrs[123] = (NULL);
  loggingPtrs[124] = (NULL);
  loggingPtrs[125] = (NULL);
  loggingPtrs[126] = (NULL);
  loggingPtrs[127] = (NULL);
  loggingPtrs[128] = (NULL);
  loggingPtrs[129] = (NULL);
  loggingPtrs[130] = (NULL);
  loggingPtrs[131] = (NULL);
  loggingPtrs[132] = (NULL);
  loggingPtrs[133] = (NULL);
  loggingPtrs[134] = (NULL);
  loggingPtrs[135] = (NULL);
  loggingPtrs[136] = (NULL);
  loggingPtrs[137] = (NULL);
  loggingPtrs[138] = (NULL);
  loggingPtrs[139] = (NULL);
  loggingPtrs[140] = (NULL);
  loggingPtrs[141] = (NULL);
  loggingPtrs[142] = (NULL);
  loggingPtrs[143] = (NULL);
  loggingPtrs[144] = (NULL);
  loggingPtrs[145] = (NULL);
  loggingPtrs[146] = (NULL);
  loggingPtrs[147] = (NULL);
  loggingPtrs[148] = (NULL);
  loggingPtrs[149] = (NULL);
  loggingPtrs[150] = (NULL);
  loggingPtrs[151] = (NULL);
  loggingPtrs[152] = (NULL);
  loggingPtrs[153] = (NULL);
  loggingPtrs[154] = (NULL);
  loggingPtrs[155] = (NULL);
  loggingPtrs[156] = (NULL);
  loggingPtrs[157] = (NULL);
  loggingPtrs[158] = (NULL);
  loggingPtrs[159] = (NULL);
  loggingPtrs[160] = (NULL);
  loggingPtrs[161] = (NULL);
  loggingPtrs[162] = (NULL);
  loggingPtrs[163] = (NULL);
  loggingPtrs[164] = (NULL);
  loggingPtrs[165] = (NULL);
  loggingPtrs[166] = (NULL);
  loggingPtrs[167] = (NULL);
  loggingPtrs[168] = (NULL);
  loggingPtrs[169] = (NULL);
  loggingPtrs[170] = (NULL);
  loggingPtrs[171] = (NULL);
  loggingPtrs[172] = (NULL);
  loggingPtrs[173] = (NULL);
  loggingPtrs[174] = (NULL);
  loggingPtrs[175] = (NULL);
  loggingPtrs[176] = (NULL);
  loggingPtrs[177] = (NULL);
  loggingPtrs[178] = (NULL);
  loggingPtrs[179] = (NULL);
  loggingPtrs[180] = (NULL);
  loggingPtrs[181] = (NULL);
  loggingPtrs[182] = (NULL);
  loggingPtrs[183] = (NULL);
  loggingPtrs[184] = (NULL);
  loggingPtrs[185] = (NULL);
  loggingPtrs[186] = (NULL);
  loggingPtrs[187] = (NULL);
  loggingPtrs[188] = (NULL);
  loggingPtrs[189] = (NULL);
  loggingPtrs[190] = (NULL);
  loggingPtrs[191] = (NULL);
  loggingPtrs[192] = (NULL);
  loggingPtrs[193] = (NULL);
  loggingPtrs[194] = (NULL);
  loggingPtrs[195] = (NULL);
  loggingPtrs[196] = (NULL);
  loggingPtrs[197] = (NULL);
  loggingPtrs[198] = (NULL);
  loggingPtrs[199] = (NULL);
  loggingPtrs[200] = (NULL);
  loggingPtrs[201] = (NULL);
  loggingPtrs[202] = (NULL);
  loggingPtrs[203] = (NULL);
  loggingPtrs[204] = (NULL);
  loggingPtrs[205] = (NULL);
  loggingPtrs[206] = (NULL);
  loggingPtrs[207] = (NULL);
  loggingPtrs[208] = (NULL);
  loggingPtrs[209] = (NULL);
  loggingPtrs[210] = (NULL);
  loggingPtrs[211] = (NULL);
  loggingPtrs[212] = (NULL);
  loggingPtrs[213] = (NULL);
  loggingPtrs[214] = (NULL);
  loggingPtrs[215] = (NULL);
  loggingPtrs[216] = (NULL);
  loggingPtrs[217] = (NULL);
  loggingPtrs[218] = (NULL);
  loggingPtrs[219] = (NULL);
  loggingPtrs[220] = (NULL);
  loggingPtrs[221] = (NULL);
  loggingPtrs[222] = (NULL);
  loggingPtrs[223] = (NULL);
  loggingPtrs[224] = (NULL);
  loggingPtrs[225] = (NULL);
  loggingPtrs[226] = (NULL);
  loggingPtrs[227] = (NULL);
  loggingPtrs[228] = (NULL);
  loggingPtrs[229] = (NULL);
  loggingPtrs[230] = (NULL);
  loggingPtrs[231] = (NULL);
  loggingPtrs[232] = (NULL);
  loggingPtrs[233] = (NULL);
  loggingPtrs[234] = (NULL);
  loggingPtrs[235] = (NULL);
  loggingPtrs[236] = (NULL);
  loggingPtrs[237] = (NULL);
  loggingPtrs[238] = (NULL);
  loggingPtrs[239] = (NULL);
  loggingPtrs[240] = (NULL);
  loggingPtrs[241] = (NULL);
  loggingPtrs[242] = (NULL);
  loggingPtrs[243] = (NULL);
  loggingPtrs[244] = (NULL);
  loggingPtrs[245] = (NULL);
  loggingPtrs[246] = (NULL);
  loggingPtrs[247] = (NULL);
  loggingPtrs[248] = (NULL);
  loggingPtrs[249] = (NULL);
  loggingPtrs[250] = (NULL);
  loggingPtrs[251] = (NULL);
  loggingPtrs[252] = (NULL);
  loggingPtrs[253] = (NULL);
  loggingPtrs[254] = (NULL);
  loggingPtrs[255] = (NULL);
  loggingPtrs[256] = (NULL);
  loggingPtrs[257] = (NULL);
  loggingPtrs[258] = (NULL);
  loggingPtrs[259] = (NULL);
  loggingPtrs[260] = (NULL);
  loggingPtrs[261] = (NULL);
  loggingPtrs[262] = (NULL);
  loggingPtrs[263] = (NULL);
  loggingPtrs[264] = (NULL);
  loggingPtrs[265] = (NULL);
  loggingPtrs[266] = (NULL);
  loggingPtrs[267] = (NULL);
  loggingPtrs[268] = (NULL);
  loggingPtrs[269] = (NULL);
  loggingPtrs[270] = (NULL);
  loggingPtrs[271] = (NULL);
  loggingPtrs[272] = (NULL);
  loggingPtrs[273] = (NULL);
  loggingPtrs[274] = (NULL);
  loggingPtrs[275] = (NULL);
  loggingPtrs[276] = (NULL);
  loggingPtrs[277] = (NULL);
  loggingPtrs[278] = (NULL);
  loggingPtrs[279] = (NULL);
  loggingPtrs[280] = (NULL);
  loggingPtrs[281] = (NULL);
  loggingPtrs[282] = (NULL);
  loggingPtrs[283] = (NULL);
  loggingPtrs[284] = (NULL);
  loggingPtrs[285] = (NULL);
  loggingPtrs[286] = (NULL);
  loggingPtrs[287] = (NULL);
  loggingPtrs[288] = (NULL);
  loggingPtrs[289] = (NULL);
  loggingPtrs[290] = (NULL);
  loggingPtrs[291] = (NULL);
  loggingPtrs[292] = (NULL);
  loggingPtrs[293] = (NULL);
  loggingPtrs[294] = (NULL);
  loggingPtrs[295] = (NULL);
  loggingPtrs[296] = (NULL);
  loggingPtrs[297] = (NULL);
  loggingPtrs[298] = (NULL);
  loggingPtrs[299] = (NULL);
  loggingPtrs[300] = (NULL);
  loggingPtrs[301] = (NULL);
  loggingPtrs[302] = (NULL);
  loggingPtrs[303] = (NULL);
  loggingPtrs[304] = (NULL);
  loggingPtrs[305] = (NULL);
  loggingPtrs[306] = (NULL);
  loggingPtrs[307] = (NULL);
  loggingPtrs[308] = (NULL);
  loggingPtrs[309] = (NULL);
  loggingPtrs[310] = (NULL);
  loggingPtrs[311] = (NULL);
  loggingPtrs[312] = (NULL);
  loggingPtrs[313] = (NULL);
  loggingPtrs[314] = (NULL);
  loggingPtrs[315] = (NULL);
  loggingPtrs[316] = (NULL);
  loggingPtrs[317] = (NULL);
  loggingPtrs[318] = (NULL);
  loggingPtrs[319] = (NULL);
  loggingPtrs[320] = (NULL);
  loggingPtrs[321] = (NULL);
  loggingPtrs[322] = (NULL);
  loggingPtrs[323] = (NULL);
  loggingPtrs[324] = (NULL);
  loggingPtrs[325] = (NULL);
  loggingPtrs[326] = (NULL);
  loggingPtrs[327] = (NULL);
  loggingPtrs[328] = (NULL);
  loggingPtrs[329] = (NULL);
  loggingPtrs[330] = (NULL);
  loggingPtrs[331] = (NULL);
  loggingPtrs[332] = (NULL);
  loggingPtrs[333] = (NULL);
  loggingPtrs[334] = (NULL);
  loggingPtrs[335] = (NULL);
  loggingPtrs[336] = (NULL);
  loggingPtrs[337] = (NULL);
  loggingPtrs[338] = (NULL);
  loggingPtrs[339] = (NULL);
  loggingPtrs[340] = (NULL);
  loggingPtrs[341] = (NULL);
  loggingPtrs[342] = (NULL);
  loggingPtrs[343] = (NULL);
  loggingPtrs[344] = (NULL);
  loggingPtrs[345] = (NULL);
  loggingPtrs[346] = (NULL);
  loggingPtrs[347] = (NULL);
  loggingPtrs[348] = (NULL);
  loggingPtrs[349] = (NULL);
  loggingPtrs[350] = (NULL);
  loggingPtrs[351] = (NULL);
  loggingPtrs[352] = (NULL);
  loggingPtrs[353] = (NULL);
  loggingPtrs[354] = (NULL);
  loggingPtrs[355] = (NULL);
  loggingPtrs[356] = (NULL);
  loggingPtrs[357] = (NULL);
  loggingPtrs[358] = (NULL);
  loggingPtrs[359] = (NULL);
  loggingPtrs[360] = (NULL);
  loggingPtrs[361] = (NULL);
  loggingPtrs[362] = (NULL);
  loggingPtrs[363] = (NULL);
  loggingPtrs[364] = (NULL);
  loggingPtrs[365] = (NULL);
  loggingPtrs[366] = (NULL);
  loggingPtrs[367] = (NULL);
  loggingPtrs[368] = (NULL);
  loggingPtrs[369] = (NULL);
  loggingPtrs[370] = (NULL);
  loggingPtrs[371] = (NULL);
  loggingPtrs[372] = (NULL);
  loggingPtrs[373] = (NULL);
  loggingPtrs[374] = (NULL);
  loggingPtrs[375] = (NULL);
  loggingPtrs[376] = (NULL);
  loggingPtrs[377] = (NULL);
  loggingPtrs[378] = (NULL);
  loggingPtrs[379] = (NULL);
  loggingPtrs[380] = (NULL);
  loggingPtrs[381] = (NULL);
  loggingPtrs[382] = (NULL);
  loggingPtrs[383] = (NULL);
  loggingPtrs[384] = (NULL);
  loggingPtrs[385] = (NULL);
  loggingPtrs[386] = (NULL);
  loggingPtrs[387] = (NULL);
  loggingPtrs[388] = (NULL);
  loggingPtrs[389] = (NULL);
  loggingPtrs[390] = (NULL);
  loggingPtrs[391] = (NULL);
  loggingPtrs[392] = (NULL);
  loggingPtrs[393] = (NULL);
  loggingPtrs[394] = (NULL);
  loggingPtrs[395] = (NULL);
  loggingPtrs[396] = (NULL);
  loggingPtrs[397] = (NULL);
  loggingPtrs[398] = (NULL);
  loggingPtrs[399] = (NULL);
  loggingPtrs[400] = (NULL);
  loggingPtrs[401] = (NULL);
  loggingPtrs[402] = (NULL);
  loggingPtrs[403] = (NULL);
  loggingPtrs[404] = (NULL);
  loggingPtrs[405] = (NULL);
  loggingPtrs[406] = (NULL);
  loggingPtrs[407] = (NULL);
  loggingPtrs[408] = (NULL);
  loggingPtrs[409] = (NULL);
  loggingPtrs[410] = (NULL);
  loggingPtrs[411] = (NULL);
  loggingPtrs[412] = (NULL);
  loggingPtrs[413] = (NULL);
  loggingPtrs[414] = (NULL);
  loggingPtrs[415] = (NULL);
  loggingPtrs[416] = (NULL);
  loggingPtrs[417] = (NULL);
  loggingPtrs[418] = (NULL);
  loggingPtrs[419] = (NULL);
  loggingPtrs[420] = (NULL);
  loggingPtrs[421] = (NULL);
  loggingPtrs[422] = (NULL);
  loggingPtrs[423] = (NULL);
  loggingPtrs[424] = (NULL);
  loggingPtrs[425] = (NULL);
  loggingPtrs[426] = (NULL);
  loggingPtrs[427] = (NULL);
  loggingPtrs[428] = (NULL);
  loggingPtrs[429] = (NULL);
  loggingPtrs[430] = (NULL);
  loggingPtrs[431] = (NULL);
  loggingPtrs[432] = (NULL);
  loggingPtrs[433] = (NULL);
  loggingPtrs[434] = (NULL);
  loggingPtrs[435] = (NULL);
  loggingPtrs[436] = (NULL);
  loggingPtrs[437] = (NULL);
  loggingPtrs[438] = (NULL);
  loggingPtrs[439] = (NULL);
  loggingPtrs[440] = (NULL);
  loggingPtrs[441] = (NULL);
  loggingPtrs[442] = (NULL);
  loggingPtrs[443] = (NULL);
  loggingPtrs[444] = (NULL);
  loggingPtrs[445] = (NULL);
  loggingPtrs[446] = (NULL);
  loggingPtrs[447] = (NULL);
  loggingPtrs[448] = (NULL);
  loggingPtrs[449] = (NULL);
  loggingPtrs[450] = (NULL);
  loggingPtrs[451] = (NULL);
  loggingPtrs[452] = (NULL);
  loggingPtrs[453] = (NULL);
  loggingPtrs[454] = (NULL);
  loggingPtrs[455] = (NULL);
  loggingPtrs[456] = (NULL);
  loggingPtrs[457] = (NULL);
  loggingPtrs[458] = (NULL);
  loggingPtrs[459] = (NULL);
  loggingPtrs[460] = (NULL);
  loggingPtrs[461] = (NULL);
  loggingPtrs[462] = (NULL);
  loggingPtrs[463] = (NULL);
  loggingPtrs[464] = (NULL);
  loggingPtrs[465] = (NULL);
  loggingPtrs[466] = (NULL);
  loggingPtrs[467] = (NULL);
  loggingPtrs[468] = (NULL);
  loggingPtrs[469] = (NULL);
  loggingPtrs[470] = (NULL);
  loggingPtrs[471] = (NULL);
  loggingPtrs[472] = (NULL);
  loggingPtrs[473] = (NULL);
  loggingPtrs[474] = (NULL);
  loggingPtrs[475] = (NULL);
  loggingPtrs[476] = (NULL);
  loggingPtrs[477] = (NULL);
  loggingPtrs[478] = (NULL);
  loggingPtrs[479] = (NULL);
  loggingPtrs[480] = (NULL);
  loggingPtrs[481] = (NULL);
  loggingPtrs[482] = (NULL);
  loggingPtrs[483] = (NULL);
  loggingPtrs[484] = (NULL);
  loggingPtrs[485] = (NULL);
  loggingPtrs[486] = (NULL);
  loggingPtrs[487] = (NULL);
  loggingPtrs[488] = (NULL);
  loggingPtrs[489] = (NULL);
  loggingPtrs[490] = (NULL);
  loggingPtrs[491] = (NULL);
  loggingPtrs[492] = (NULL);
  loggingPtrs[493] = (NULL);
  loggingPtrs[494] = (NULL);
  loggingPtrs[495] = (NULL);
  loggingPtrs[496] = (NULL);
  loggingPtrs[497] = (NULL);
  loggingPtrs[498] = (NULL);
  loggingPtrs[499] = (NULL);
  loggingPtrs[500] = (NULL);
  loggingPtrs[501] = (NULL);
  loggingPtrs[502] = (NULL);
  loggingPtrs[503] = (NULL);
  loggingPtrs[504] = (NULL);
  loggingPtrs[505] = (NULL);
  loggingPtrs[506] = (NULL);
  loggingPtrs[507] = (NULL);
  loggingPtrs[508] = (NULL);
  loggingPtrs[509] = (NULL);
  loggingPtrs[510] = (NULL);
  loggingPtrs[511] = (NULL);
  loggingPtrs[512] = (NULL);
  loggingPtrs[513] = (NULL);
  loggingPtrs[514] = (NULL);
  loggingPtrs[515] = (NULL);
  loggingPtrs[516] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_VECTOR, 20, 2, 0 },

  { rtwCAPI_VECTOR, 22, 2, 0 },

  { rtwCAPI_VECTOR, 24, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR_ND, 26, 4, 0 },

  { rtwCAPI_VECTOR, 30, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  2,                                   /* 2 */
  1,                                   /* 3 */
  3,                                   /* 4 */
  1,                                   /* 5 */
  6,                                   /* 6 */
  1,                                   /* 7 */
  11,                                  /* 8 */
  1,                                   /* 9 */
  1,                                   /* 10 */
  10,                                  /* 11 */
  1,                                   /* 12 */
  3,                                   /* 13 */
  1,                                   /* 14 */
  2,                                   /* 15 */
  3,                                   /* 16 */
  3,                                   /* 17 */
  34,                                  /* 18 */
  1,                                   /* 19 */
  8,                                   /* 20 */
  1,                                   /* 21 */
  4,                                   /* 22 */
  1,                                   /* 23 */
  1,                                   /* 24 */
  7,                                   /* 25 */
  7,                                   /* 26 */
  11,                                  /* 27 */
  7,                                   /* 28 */
  2,                                   /* 29 */
  1,                                   /* 30 */
  11                                   /* 31 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0, 0.0001
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[0],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[0],
    1, 0 },

  { (NULL), (NULL), -1, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 130,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 280,
    rtModelParameters, 80 },

  { rtBlockStates, 27 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 1391365718U,
    4139017079U,
    2382526642U,
    2242692473U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  DrivetrainHevP4_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void DrivetrainHevP4_InitializeDataMapInfo(RT_MODEL_DrivetrainHevP4_T *const
  DrivetrainHevP4_M, B_DrivetrainHevP4_c_T *localB, X_DrivetrainHevP4_n_T
  *localX)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(DrivetrainHevP4_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(DrivetrainHevP4_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(DrivetrainHevP4_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  DrivetrainHevP4_InitializeDataAddr(DrivetrainHevP4_M->DataMapInfo.dataAddress,
    localB, localX);
  rtwCAPI_SetDataAddressMap(DrivetrainHevP4_M->DataMapInfo.mmi,
    DrivetrainHevP4_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  DrivetrainHevP4_InitializeVarDimsAddr
    (DrivetrainHevP4_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(DrivetrainHevP4_M->DataMapInfo.mmi,
    DrivetrainHevP4_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(DrivetrainHevP4_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(DrivetrainHevP4_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  DrivetrainHevP4_InitializeLoggingFunctions
    (DrivetrainHevP4_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(DrivetrainHevP4_M->DataMapInfo.mmi,
    DrivetrainHevP4_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(DrivetrainHevP4_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(DrivetrainHevP4_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(DrivetrainHevP4_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void DrivetrainHevP4_host_InitializeDataMapInfo
    (DrivetrainHevP4_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: DrivetrainHevP4_capi.c */
