/*
 * DrivetrainHevP4_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:03 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DrivetrainHevP4_capi_h
#define RTW_HEADER_DrivetrainHevP4_capi_h
#include "DrivetrainHevP4.h"

extern void DrivetrainHevP4_InitializeDataMapInfo(RT_MODEL_DrivetrainHevP4_T *
  const DrivetrainHevP4_M, B_DrivetrainHevP4_c_T *localB, X_DrivetrainHevP4_n_T *
  localX);

#endif                                 /* RTW_HEADER_DrivetrainHevP4_capi_h */

/* EOF: DrivetrainHevP4_capi.h */
