/*
 * Code generation for system model 'DrivetrainHevP4'
 *
 * Model                      : DrivetrainHevP4
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:03 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "DrivetrainHevP4_capi.h"
#include "DrivetrainHevP4.h"
#include "DrivetrainHevP4_private.h"
#include "automldiffopen_ZyWLRRPX.h"
#include "interp2_MZVr1hxC.h"
#include "intrp1d_la_pw.h"
#include "intrp4d_l_pw.h"
#include "look1_binlcpw.h"
#include "look1_binlxpw.h"
#include "plook_binc.h"
#include "plook_bincpa.h"
#include "plook_u32d_binckan.h"
#include "rt_atan2d_snf.h"
#include "rt_powd_snf.h"

/* Named constants for Chart: '<S228>/Clutch' */
#define DrivetrainHevP4_IN_Locked      ((uint8_T)1U)
#define DrivetrainHevP4_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define DrivetrainHevP4_IN_Slipping    ((uint8_T)2U)

P_DrivetrainHevP4_T DrivetrainHevP4_P = {
  2.46,
  0.25,
  6570.0,
  0.0,

  { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 },
  0.8,
  0.01,
  0.2,

  { 0.009, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01 },
  0.01,
  0.01,
  0.01,
  10000.0,
  0.15,
  1623.0,

  { 1.0, 4.212, 2.637, 1.8, 1.386, 1.0, 0.772 },
  2.0,
  2.0,
  3.32,
  4.1,
  101325.0,
  0.327,
  0.11,
  0.15,
  300.0,

  { 313.0, 358.0 },

  { 25.0, 50.0, 75.0, 100.0, 150.0, 200.0, 250.0 },
  0.336,
  2.0,
  0.01,
  1.09,
  0.0,
  400.0,
  0.0,
  1.7,
  0.001,
  1.0,
  0.001,

  { 0.003, 0.003, 0.003, 0.003, 0.003, 0.003, 0.003 },
  0.001,
  0.001,
  0.001,
  0.001,
  0.0,
  0.05,
  0.0,
  0.98,

  { 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766, 0.766,
    0.766, 0.766, 0.766, 0.766, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596,
    0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.4596, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504, 0.504,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.98119000000000012,
    0.98119000000000012, 0.98119000000000012, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.917,
    0.917, 0.917, 0.917, 0.917, 0.917, 0.917, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224, 0.9224,
    0.9224, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124,
    0.9124, 0.9124, 0.9124, 0.9124, 0.9124, 0.9124 },
  9.81,
  0.5,
  10000.0,
  1.5,
  1.0,
  0.35,
  0.45,
  0.4,
  0.45,
  2.0,

  { 500.38314108091896, 749.619781962827, 1002.6761414789406, 1250.9578527022975,
    1499.239563925654, 1747.5212751490108, 1995.8029863723675, 2501.915705404595,
    2998.479127851308, 4001.1552693302488, 5003.83141080919 },
  500.0,
  0.0,
  0.0,
  94.247779607693786,
  0.0,
  0.0,
  83.775804095727821,
  0.0,
  0.0,

  { 0.0, 0.5, 0.6, 0.7, 0.8, 0.87, 0.92, 0.94, 0.96, 0.97 },
  0.85,
  234400.0,

  { 12.2938, 12.8588, 13.1452, 13.6285, 14.6163, 16.2675, 19.3503, 22.1046,
    29.9986, 50.0 },
  0.6,
  0.1,
  0.08,
  0.0,
  10.0,
  0.0,
  0.0,

  { 2.232, 1.5462, 1.4058, 1.2746, 1.1528, 1.0732, 1.0192, 0.9983, 0.9983,
    0.9983 },
  0.0,
  0.0,

  { 0.0, 0.0 },

  { 0.0, 0.0 },
  0.0,
  1.0,
  287.058,
  0.0,
  0.0,

  { -1.0, 1.0 },
  1.0,
  0.0,
  1.0E-6,
  1.0E-6,
  1.0,
  1.0,
  0.0,
  1.0,
  0.0,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  1.0,
  -1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  5000.0,
  -5000.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.15915494309189535,
  0.0,
  2.2204460492503131E-16,
  -1.0,
  0.0,
  0.0,
  5000.0,
  -5000.0,
  5000.0,
  -5000.0,
  4.0,
  1.0,
  1.0,
  1.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  2.2204460492503131E-16,
  0.0,
  0.0,
  0.0,
  -1.0,
  0.6,
  0.78539816339744828,
  0.0,
  2.2204460492503131E-16,
  1.0,
  1.65,
  10.0,
  0.01,

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  10000.0,
  1.0E+6,

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  2.2204460492503131E-16,
  0.0,
  0.0,
  0.0,
  -1.0,
  0.4,
  0.78539816339744828,
  0.0,
  2.2204460492503131E-16,
  1.0,
  1.65,
  10.0,
  0.01,

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  10000.0,
  1.0E+6,

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,

  { 0.0, 0.0 },

  { -1.0, 1.0 },

  { 4.0, 4.0, 4.0 },

  { 0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0 },
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  2.2204460492503131E-16,
  1.0,
  0.0,
  0.0,
  6.2831853071795862,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  6.2831853071795862,
  0.0,
  1.0,
  1.0,
  0.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
  1.0,
  1.0,
  1.0,
  5000.0,
  -5000.0,
  1.0,
  1.0,
  1.0,
  1.0,
  1.0,
  5000.0,
  -5000.0,
  0.5,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  1.0,
  1.0,
  1.0,
  0.5,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  0.0,
  1.0,
  1.0,
  1.0,
  1.0,

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },

  { 6U, 10U, 6U, 1U },

  { 1U, 7U, 77U, 539U },
  9U,
  9U,
  false,

  { false, true, false, false, true, true, true, false },
  true,
  false,

  /* Start of '<S259>/Clutch' */
  {
    /* Start of '<S228>/CoreSubsys' */
    {
      /* Start of '<S228>/Clutch' */
      {
        0.0,
        0.0,
        0.0,
        0.0,
        -4.0,
        false,
        false,
        false,

        { false, true, false, false, true, true, true, false }
      }
      /* End of '<S228>/Clutch' */
    }
    /* End of '<S228>/CoreSubsys' */
  }
  ,

  /* End of '<S259>/Clutch' */

  /* Start of '<S217>/Clutch' */
  {
    /* Start of '<S228>/CoreSubsys' */
    {
      /* Start of '<S228>/Clutch' */
      {
        0.0,
        0.0,
        0.0,
        0.0,
        -4.0,
        false,
        false,
        false,

        { false, true, false, false, true, true, true, false }
      }
      /* End of '<S228>/Clutch' */
    }
    /* End of '<S228>/CoreSubsys' */
  }
  ,

  /* End of '<S217>/Clutch' */

  /* Start of '<S42>/Open Differential' */
  {
    1.0
  }
  ,

  /* End of '<S42>/Open Differential' */

  /* Start of '<S25>/Open Differential' */
  {
    1.0
  }
  /* End of '<S25>/Open Differential' */
};

/* Forward declaration for local functions */
static void DrivetrainHevP4_power(const real_T a_data[], const int32_T a_size[2],
  real_T y_data[], int32_T y_size[2]);
static real_T DrivetrainHevP4_automltirekappa(real_T Re, real_T omega, real_T Vx,
  real_T b_VXLOW, real_T b_kappamax);
static real_T DrivetrainHevP4_automltirepurelongFx(real_T kappa, real_T Vx,
  real_T Fz, real_T b_gamma, real_T LONGVL, real_T FNOMIN, real_T b_FZMIN,
  real_T b_FZMAX, real_T press, real_T NOMPRES, real_T PRESMIN, real_T PRESMAX,
  real_T PCX1, real_T PDX1, real_T PDX2, real_T PDX3, real_T PEX1, real_T PEX2,
  real_T PEX3, real_T PEX4, real_T PKX1, real_T PKX2, real_T PKX3, real_T PHX1,
  real_T PHX2, real_T PVX1, real_T PVX2, real_T PPX1, real_T PPX2, real_T PPX3,
  real_T PPX4, real_T lam_Fzo, real_T lam_muV, real_T lam_mux, real_T
  lam_Kxkappa, real_T lam_Cx, real_T lam_Ex, real_T lam_Hx, real_T lam_Vx);
static real_T DrivetrainHevP4_automltirelongFxMapped(real_T kappa, real_T Fz,
  const real_T kappaFx[3], const real_T FzFx[3], const real_T FxMap[9], real_T
  b_FZMIN, real_T b_FZMAX, real_T lam_mux);
static real_T DrivetrainHevP4_automltirelongMySAE(real_T Fz, real_T omega,
  real_T Vx, real_T press, real_T QSY1, real_T QSY2, real_T QSY3, real_T QSY7,
  real_T QSY8, real_T UNLOADED_RADIUS, real_T b_FZMIN, real_T b_FZMAX, real_T
  PRESMIN, real_T PRESMAX);
static real_T DrivetrainHevP4_automltirelongMyMapped(real_T omega, real_T Fz,
  real_T Vx, const real_T VxMy[3], const real_T FzMy[3], const real_T MyMap[9],
  real_T b_FZMAX);
static real_T DrivetrainHevP4_automltirelongMyISO(real_T Fz, real_T omega,
  real_T Tamb, real_T Fpl, real_T Cr, real_T Kt, real_T Tmeas, real_T Re, real_T
  b_FZMIN, real_T b_FZMAX, real_T TMIN, real_T TMAX);

/* Forward declaration for local functions */
static boolean_T DrivetrainHevP4_detectSlip(real_T Tout, real_T Tfmaxs,
  B_Clutch_DrivetrainHevP4_k_T *localB);
static boolean_T DrivetrainHevP4_detectLockup(real_T Tout, real_T Tfmaxs, real_T
  rtp_br, B_Clutch_DrivetrainHevP4_k_T *localB, DW_Clutch_DrivetrainHevP4_k_T
  *localDW, P_Clutch_DrivetrainHevP4_o_T *localP);

/*
 * Output and update for atomic system:
 *    '<S25>/Open Differential'
 *    '<S42>/Open Differential'
 */
void DrivetrainHevP4_OpenDifferential(real_T rtu_u, real_T rtu_u_m, real_T
  rtu_u_k, real_T rtu_bw1, real_T rtu_bd, real_T rtu_bw2, real_T rtu_Ndiff,
  real_T rtu_Jd, real_T rtu_Jw1, real_T rtu_Jw2, const real_T rtu_x[2],
  B_OpenDifferential_DrivetrainHevP4_T *localB,
  P_OpenDifferential_DrivetrainHevP4_T *localP)
{
  real_T a__2[3];
  real_T rtu_u_0[3];
  if (localP->OpenDifferential_shaftSwitchMask == 1.0) {
    /* SignalConversion generated from: '<S28>/ SFunction ' */
    rtu_u_0[0] = rtu_u;
    rtu_u_0[1] = rtu_u_m;
    rtu_u_0[2] = rtu_u_k;
    automldiffopen_ZyWLRRPX(rtu_u_0, rtu_bw1, rtu_bd, rtu_bw2, rtu_Ndiff, 1.0,
      rtu_Jd, rtu_Jw1, rtu_Jw2, rtu_x, a__2, localB->xdot);
  } else {
    /* SignalConversion generated from: '<S28>/ SFunction ' */
    rtu_u_0[0] = rtu_u;
    rtu_u_0[1] = rtu_u_m;
    rtu_u_0[2] = rtu_u_k;
    automldiffopen_ZyWLRRPX(rtu_u_0, rtu_bw1, rtu_bd, rtu_bw2, rtu_Ndiff, 0.0,
      rtu_Jd, rtu_Jw1, rtu_Jw2, rtu_x, a__2, localB->xdot);
  }
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static void DrivetrainHevP4_power(const real_T a_data[], const int32_T a_size[2],
  real_T y_data[], int32_T y_size[2])
{
  real_T y_data_tmp;
  y_size[0] = 1;
  y_size[1] = a_size[1];
  if (0 <= (int8_T)a_size[1] - 1) {
    y_data_tmp = a_data[0];
    y_data[0] = y_data_tmp * y_data_tmp;
  }
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirekappa(real_T Re, real_T omega, real_T Vx,
  real_T b_VXLOW, real_T b_kappamax)
{
  real_T Vxpabs;
  real_T Vxpabs_data;
  real_T kappa;
  real_T tmp_data;
  int32_T Vxpabs_size[2];
  int32_T tmp_size[2];
  int32_T b_trueCount;
  Vxpabs = fabs(Vx);
  b_trueCount = 0;
  if (Vxpabs < b_VXLOW) {
    b_trueCount = 1;
  }

  Vxpabs_size[0] = 1;
  Vxpabs_size[1] = b_trueCount;
  if (0 <= b_trueCount - 1) {
    Vxpabs_data = Vxpabs / b_VXLOW;
  }

  if (0 <= b_trueCount - 1) {
    DrivetrainHevP4_power(&Vxpabs_data, Vxpabs_size, &tmp_data, tmp_size);
    Vxpabs_data = 2.0 * b_VXLOW / (3.0 - tmp_data);
  }

  if (Vxpabs < b_VXLOW) {
    Vxpabs = Vxpabs_data;
  }

  kappa = (Re * omega - Vx) / Vxpabs;
  b_trueCount = 0;
  if (kappa < -b_kappamax) {
    b_trueCount = 1;
  }

  if (0 <= b_trueCount - 1) {
    kappa = -b_kappamax;
  }

  if (kappa > b_kappamax) {
    kappa = b_kappamax;
  }

  return kappa;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirepurelongFx(real_T kappa, real_T Vx,
  real_T Fz, real_T b_gamma, real_T LONGVL, real_T FNOMIN, real_T b_FZMIN,
  real_T b_FZMAX, real_T press, real_T NOMPRES, real_T PRESMIN, real_T PRESMAX,
  real_T PCX1, real_T PDX1, real_T PDX2, real_T PDX3, real_T PEX1, real_T PEX2,
  real_T PEX3, real_T PEX4, real_T PKX1, real_T PKX2, real_T PKX3, real_T PHX1,
  real_T PHX2, real_T PVX1, real_T PVX2, real_T PPX1, real_T PPX2, real_T PPX3,
  real_T PPX4, real_T lam_Fzo, real_T lam_muV, real_T lam_mux, real_T
  lam_Kxkappa, real_T lam_Cx, real_T lam_Ex, real_T lam_Hx, real_T lam_Vx)
{
  real_T Cx;
  real_T Cx_tmp;
  real_T Fxo;
  real_T Vsx;
  real_T a__1;
  real_T a__1_data;
  real_T b_idx_0;
  real_T dfz;
  real_T dpi;
  real_T f_idx_0;
  real_T g_idx_0;
  real_T h_idx_0;
  real_T kappa_x;
  real_T tmp_data;
  int32_T a__1_size[2];
  int32_T tmp_size[2];
  int32_T trueCount;
  b_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    b_idx_0 = b_FZMIN;
  }

  if (b_idx_0 > b_FZMAX) {
    b_idx_0 = b_FZMAX;
  }

  dfz = press;
  if (press < PRESMIN) {
    dfz = PRESMIN;
  }

  if (dfz > PRESMAX) {
    dfz = PRESMAX;
  }

  dpi = (dfz - NOMPRES) / NOMPRES;
  dfz = (b_idx_0 - FNOMIN * lam_Fzo) / FNOMIN * lam_Fzo;
  kappa_x = (PHX2 * dfz + PHX1) * lam_Hx + kappa;
  Vsx = -fabs(Vx) * kappa;
  Vsx = lam_mux / (sqrt(Vsx * Vsx) * lam_muV / LONGVL + 1.0);
  Cx = PCX1 * lam_Cx;
  f_idx_0 = Cx;
  if (Cx < 0.0) {
    f_idx_0 = 0.0;
  }

  Cx_tmp = dpi * dpi;
  Cx = ((PPX3 * dpi + 1.0) + Cx_tmp * PPX4) * (PDX2 * dfz + PDX1) * (1.0 -
    b_gamma * b_gamma * PDX3) * Vsx * b_idx_0;
  g_idx_0 = Cx;
  if (Cx < 0.0) {
    g_idx_0 = 0.0;
  }

  Cx = ((PEX2 * dfz + PEX1) + dfz * dfz * PEX3) * (1.0 - tanh(10.0 * kappa_x) *
    PEX4) * lam_Ex;
  h_idx_0 = Cx;
  if (Cx > 1.0) {
    h_idx_0 = 1.0;
  }

  Cx = f_idx_0 * g_idx_0;
  a__1 = fabs(Cx);
  trueCount = 0;
  if (a__1 < 0.1) {
    trueCount = 1;
  }

  a__1_size[0] = 1;
  a__1_size[1] = trueCount;
  if (0 <= trueCount - 1) {
    a__1_data = a__1 / 0.1;
  }

  if (0 <= trueCount - 1) {
    DrivetrainHevP4_power(&a__1_data, a__1_size, &tmp_data, tmp_size);
    a__1_data = 0.2 / (3.0 - tmp_data);
  }

  if (a__1 < 0.1) {
    a__1 = a__1_data;
  }

  trueCount = 0;
  if (Cx < 0.0) {
    trueCount = 1;
  }

  if (0 <= trueCount - 1) {
    a__1_data = -a__1;
  }

  if (Cx < 0.0) {
    a__1 = a__1_data;
  }

  dpi = (PKX2 * dfz + PKX1) * b_idx_0 * exp(PKX3 * dfz) * ((PPX1 * dpi + 1.0) +
    Cx_tmp * PPX2) * lam_Kxkappa / a__1 * kappa_x;
  Fxo = sin(atan(dpi - (dpi - atan(dpi)) * h_idx_0) * f_idx_0) * g_idx_0 + (PVX2
    * dfz + PVX1) * b_idx_0 * (Vsx * 10.0 / (9.0 * Vsx + 1.0)) * lam_Vx;
  return Fxo;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongFxMapped(real_T kappa, real_T Fz,
  const real_T kappaFx[3], const real_T FzFx[3], const real_T FxMap[9], real_T
  b_FZMIN, real_T b_FZMAX, real_T lam_mux)
{
  real_T FxMap_0[9];
  real_T Fx;
  real_T b_idx_0;
  int32_T i;
  b_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    b_idx_0 = b_FZMIN;
  }

  if (b_idx_0 > b_FZMAX) {
    b_idx_0 = b_FZMAX;
  }

  for (i = 0; i < 3; i++) {
    FxMap_0[3 * i] = FxMap[i];
    FxMap_0[3 * i + 1] = FxMap[i + 3];
    FxMap_0[3 * i + 2] = FxMap[i + 6];
  }

  Fx = interp2_MZVr1hxC(kappaFx, FzFx, FxMap_0, kappa, b_idx_0) * lam_mux;
  return Fx;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongMySAE(real_T Fz, real_T omega,
  real_T Vx, real_T press, real_T QSY1, real_T QSY2, real_T QSY3, real_T QSY7,
  real_T QSY8, real_T UNLOADED_RADIUS, real_T b_FZMIN, real_T b_FZMAX, real_T
  PRESMIN, real_T PRESMAX)
{
  real_T My;
  real_T b_idx_0;
  real_T d_idx_0;
  b_idx_0 = press;
  if (press < PRESMIN) {
    b_idx_0 = PRESMIN;
  }

  if (b_idx_0 > PRESMAX) {
    b_idx_0 = PRESMAX;
  }

  d_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    d_idx_0 = b_FZMIN;
  }

  if (d_idx_0 > b_FZMAX) {
    d_idx_0 = b_FZMAX;
  }

  My = ((QSY2 * fabs(Vx) + QSY1) + Vx * Vx * QSY3) * (tanh(omega) *
    UNLOADED_RADIUS) * (rt_powd_snf(d_idx_0, QSY7) * rt_powd_snf(b_idx_0, QSY8));
  return My;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongMyMapped(real_T omega, real_T Fz,
  real_T Vx, const real_T VxMy[3], const real_T FzMy[3], const real_T MyMap[9],
  real_T b_FZMAX)
{
  real_T MyMap_0[9];
  real_T My;
  real_T b_idx_0;
  int32_T i;
  b_idx_0 = Fz;
  if (Fz < 0.0) {
    b_idx_0 = 0.0;
  }

  if (b_idx_0 > b_FZMAX) {
    b_idx_0 = b_FZMAX;
  }

  for (i = 0; i < 3; i++) {
    MyMap_0[3 * i] = MyMap[i];
    MyMap_0[3 * i + 1] = MyMap[i + 3];
    MyMap_0[3 * i + 2] = MyMap[i + 6];
  }

  My = tanh(omega) * interp2_MZVr1hxC(VxMy, FzMy, MyMap_0, Vx, b_idx_0);
  return My;
}

/* Function for MATLAB Function: '<S213>/Simple Magic Tire' */
static real_T DrivetrainHevP4_automltirelongMyISO(real_T Fz, real_T omega,
  real_T Tamb, real_T Fpl, real_T Cr, real_T Kt, real_T Tmeas, real_T Re, real_T
  b_FZMIN, real_T b_FZMAX, real_T TMIN, real_T TMAX)
{
  real_T b_idx_0;
  real_T d_idx_0;
  b_idx_0 = Tamb;
  if (Tamb < TMIN) {
    b_idx_0 = TMIN;
  }

  if (b_idx_0 > TMAX) {
    b_idx_0 = TMAX;
  }

  d_idx_0 = Fz;
  if (Fz < b_FZMIN) {
    d_idx_0 = b_FZMIN;
  }

  if (d_idx_0 > b_FZMAX) {
    d_idx_0 = b_FZMAX;
  }

  return (d_idx_0 * Cr * 0.001 / ((b_idx_0 - Tmeas) * Kt + 1.0) + Fpl) * (-tanh
    (omega) * Re);
}

/*
 * Output and update for atomic system:
 *    '<S213>/Simple Magic Tire'
 *    '<S255>/Simple Magic Tire'
 */
void DrivetrainHevP4_SimpleMagicTire(real_T rtu_ReNom, real_T rtu_Fz, real_T
  rtu_Omega, real_T rtu_Vx, real_T rtu_MagicPeak, real_T rtu_MagicPeak_a, real_T
  rtu_MagicPeak_m, real_T rtu_MagicPeak_b, real_T rtu_MagicPeak_l, const real_T
  rtu_MagicFxo[34], const real_T rtu_kappaFx[3], const real_T rtu_FzFx[3], const
  real_T rtu_FxMap[9], real_T rtu_RollRes, real_T rtu_RollRes_f, real_T
  rtu_RollRes_m, real_T rtu_RollRes_k, real_T rtu_RollRes_b, real_T
  rtu_RollRes_km, real_T rtu_RollRes_l, real_T rtu_RollRes_ly, real_T
  rtu_RollRes_i, real_T rtu_RollRes_c, real_T rtu_RollRes_h, real_T
  rtu_RollRes_bu, real_T rtu_RollRes_d, real_T rtu_RollRes_is, real_T
  rtu_RollRes_im, real_T rtu_RollRes_ic, const real_T rtu_VxMy[3], const real_T
  rtu_FzMy[3], const real_T rtu_MyMap[9], real_T rtu_rho, real_T rtu_FxType,
  real_T rtu_rollingType, real_T rtu_vertType, real_T rtp_FZMAX, real_T
  rtp_FZMIN, real_T rtp_VXLOW, real_T rtp_kappamax,
  B_SimpleMagicTire_DrivetrainHevP4_T *localB)
{
  real_T Kappa;
  real_T Re;
  real_T c_idx_0;
  switch ((int32_T)rtu_vertType) {
   case 0:
    Re = rtu_ReNom;
    break;

   case 1:
    Re = 0.0 * fabs(rtu_Omega) + rtu_rho;
    if (Re < 0.001) {
      Re = 0.001;
    }
    break;

   case 2:
    Re = rtu_ReNom;
    break;

   default:
    Re = rtu_ReNom;
    break;
  }

  Kappa = DrivetrainHevP4_automltirekappa(rtu_ReNom, rtu_Omega, rtu_Vx,
    rtp_VXLOW, rtp_kappamax);
  switch ((int32_T)rtu_FxType) {
   case 0:
    c_idx_0 = rtu_Fz;
    if (rtu_Fz < rtp_FZMIN) {
      c_idx_0 = rtp_FZMIN;
    }

    if (c_idx_0 > rtp_FZMAX) {
      c_idx_0 = rtp_FZMAX;
    }

    /* SignalConversion generated from: '<S223>/ SFunction ' */
    Kappa *= rtu_MagicPeak_m;
    Kappa = sin(atan(Kappa - (Kappa - atan(Kappa)) * rtu_MagicPeak_b) *
                rtu_MagicPeak_a) * rtu_MagicPeak * (c_idx_0 * rtu_MagicPeak_l);
    break;

   case 2:
    Kappa = DrivetrainHevP4_automltirepurelongFx(Kappa, rtu_Vx, rtu_Fz,
      rtu_MagicFxo[0], rtu_MagicFxo[1], rtu_MagicFxo[2], rtp_FZMIN, rtp_FZMAX,
      rtu_MagicFxo[3], rtu_MagicFxo[4], rtu_MagicFxo[5], rtu_MagicFxo[6],
      rtu_MagicFxo[7], rtu_MagicFxo[8], rtu_MagicFxo[9], rtu_MagicFxo[10],
      rtu_MagicFxo[11], rtu_MagicFxo[12], rtu_MagicFxo[13], rtu_MagicFxo[14],
      rtu_MagicFxo[15], rtu_MagicFxo[16], rtu_MagicFxo[17], rtu_MagicFxo[18],
      rtu_MagicFxo[19], rtu_MagicFxo[20], rtu_MagicFxo[21], rtu_MagicFxo[22],
      rtu_MagicFxo[23], rtu_MagicFxo[24], rtu_MagicFxo[25], rtu_MagicFxo[26],
      rtu_MagicFxo[27], rtu_MagicFxo[28], rtu_MagicFxo[29], rtu_MagicFxo[30],
      rtu_MagicFxo[31], rtu_MagicFxo[32], rtu_MagicFxo[33]);
    break;

   case 3:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    Kappa = DrivetrainHevP4_automltirelongFxMapped(Kappa, rtu_Fz, rtu_kappaFx,
      rtu_FzFx, rtu_FxMap, rtp_FZMIN, rtp_FZMAX, rtu_MagicPeak_l);
    break;

   default:
    Kappa = 0.0;
    break;
  }

  switch ((int32_T)rtu_rollingType) {
   case 0:
    localB->My = 0.0;
    break;

   case 1:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    localB->My = DrivetrainHevP4_automltirelongMySAE(rtu_Fz, rtu_Omega, rtu_Vx,
      rtu_RollRes, rtu_RollRes_k, rtu_RollRes_b, rtu_RollRes_km, rtu_RollRes_c,
      rtu_RollRes_h, Re, rtp_FZMIN, rtp_FZMAX, rtu_RollRes_im, rtu_RollRes_ic);
    break;

   case 2:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    Re = rtu_RollRes;
    if (rtu_RollRes < rtu_RollRes_im) {
      Re = rtu_RollRes_im;
    }

    if (Re > rtu_RollRes_ic) {
      Re = rtu_RollRes_ic;
    }

    c_idx_0 = rtu_Fz;
    if (rtu_Fz < 0.0) {
      c_idx_0 = 0.0;
    }

    if (c_idx_0 > rtp_FZMAX) {
      c_idx_0 = rtp_FZMAX;
    }

    /* SignalConversion generated from: '<S223>/ SFunction ' */
    localB->My = ((((rtu_RollRes_b * Kappa / rtu_RollRes_f + rtu_RollRes_k) +
                    fabs(rtu_Vx / 16.7) * rtu_RollRes_km) + rt_powd_snf(rtu_Vx /
      16.7, 4.0) * rtu_RollRes_l) + (c_idx_0 * rtu_RollRes_i / rtu_RollRes_f +
      rtu_RollRes_ly) * (rtu_RollRes_bu * rtu_RollRes_bu)) * (tanh(rtu_Omega) *
      c_idx_0 * rtu_RollRes_is) * (rt_powd_snf(c_idx_0 / rtu_RollRes_f,
      rtu_RollRes_c) * rt_powd_snf(Re / rtu_RollRes_m, rtu_RollRes_h)) *
      rtu_RollRes_d;
    break;

   case 3:
    localB->My = -DrivetrainHevP4_automltirelongMyMapped(rtu_Omega, rtu_Fz,
      rtu_Vx, rtu_VxMy, rtu_FzMy, rtu_MyMap, rtp_FZMAX);
    break;

   case 4:
    /* SignalConversion generated from: '<S223>/ SFunction ' */
    localB->My = -DrivetrainHevP4_automltirelongMyISO(rtu_Fz, rtu_Omega,
      rtu_RollRes, rtu_RollRes_k, rtu_RollRes_b, rtu_RollRes_km, rtu_RollRes_l,
      Re, rtp_FZMIN, rtp_FZMAX, rtu_RollRes_im, rtu_RollRes_ic);
    break;

   default:
    localB->My = 0.0;
    break;
  }

  localB->Fx = Kappa;
}

/* Function for Chart: '<S228>/Clutch' */
static boolean_T DrivetrainHevP4_detectSlip(real_T Tout, real_T Tfmaxs,
  B_Clutch_DrivetrainHevP4_k_T *localB)
{
  localB->Tout = Tout;
  localB->Tfmaxs = Tfmaxs;

  /* Outputs for Function Call SubSystem: '<S233>/detectSlip' */
  /* RelationalOperator: '<S245>/Relational Operator' incorporates:
   *  Abs: '<S245>/Abs'
   */
  localB->RelationalOperator = (fabs(localB->Tout) >= localB->Tfmaxs);

  /* End of Outputs for SubSystem: '<S233>/detectSlip' */
  return localB->RelationalOperator;
}

/* Function for Chart: '<S228>/Clutch' */
static boolean_T DrivetrainHevP4_detectLockup(real_T Tout, real_T Tfmaxs, real_T
  rtp_br, B_Clutch_DrivetrainHevP4_k_T *localB, DW_Clutch_DrivetrainHevP4_k_T
  *localDW, P_Clutch_DrivetrainHevP4_o_T *localP)
{
  real_T rtb_Abs_f;
  localB->Tout_e = Tout;
  localB->Tfmaxs_p = Tfmaxs;

  /* Outputs for Function Call SubSystem: '<S233>/detectLockup' */
  /* Gain: '<S242>/Output Damping' incorporates:
   *  Constant: '<S236>/Constant'
   */
  rtb_Abs_f = rtp_br * localP->Constant_Value;

  /* CombinatorialLogic: '<S241>/Combinatorial  Logic' incorporates:
   *  Abs: '<S239>/Abs'
   *  Abs: '<S244>/Abs'
   *  RelationalOperator: '<S239>/Relational Operator'
   *  RelationalOperator: '<S244>/Relational Operator'
   *  Sum: '<S242>/Sum1'
   *  Sum: '<S242>/Sum2'
   *  UnaryMinus: '<S243>/Unary Minus'
   *  UnitDelay: '<S241>/Unit Delay'
   */
  localB->CombinatorialLogic = localP->CombinatorialLogic_table[(((fabs(((0.0 -
    localB->Tout_e) - rtb_Abs_f) + rtb_Abs_f) >= localB->Tfmaxs_p) + ((uint32_T)
    (fabs(-localB->Tout_e) <= localB->Tfmaxs_p) << 1)) << 1) +
    localDW->UnitDelay_DSTATE];

  /* Update for UnitDelay: '<S241>/Unit Delay' */
  localDW->UnitDelay_DSTATE = localB->CombinatorialLogic;

  /* End of Outputs for SubSystem: '<S233>/detectLockup' */
  return localB->CombinatorialLogic;
}

/*
 * System initialize for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Init(real_T rtp_omegao, B_Clutch_DrivetrainHevP4_k_T
  *localB, DW_Clutch_DrivetrainHevP4_k_T *localDW, P_Clutch_DrivetrainHevP4_o_T *
  localP, X_Clutch_DrivetrainHevP4_n_T *localX)
{
  localB->Tout = 0.0;
  localB->Tfmaxs = 0.0;
  localB->Tout_e = 0.0;
  localB->Tfmaxs_p = 0.0;
  localDW->is_active_c8_autolibshared = 0U;
  localDW->is_c8_autolibshared = DrivetrainHevP4_IN_NO_ACTIVE_CHILD;

  /* InitializeConditions for Merge: '<S233>/ Merge ' */
  localB->Omega = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 1' */
  localB->Omegadot = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 3' */
  localB->Myb = 0.0;

  /* SystemInitialize for Function Call SubSystem: '<S233>/detectSlip' */
  /* SystemInitialize for RelationalOperator: '<S245>/Relational Operator' incorporates:
   *  Outport: '<S237>/yn'
   */
  localB->RelationalOperator = localP->yn_Y0;

  /* End of SystemInitialize for SubSystem: '<S233>/detectSlip' */

  /* SystemInitialize for Function Call SubSystem: '<S233>/detectLockup' */
  /* InitializeConditions for UnitDelay: '<S241>/Unit Delay' */
  localDW->UnitDelay_DSTATE = localP->UnitDelay_InitialCondition;

  /* SystemInitialize for CombinatorialLogic: '<S241>/Combinatorial  Logic' incorporates:
   *  Outport: '<S236>/yn'
   */
  localB->CombinatorialLogic = localP->yn_Y0_e;

  /* End of SystemInitialize for SubSystem: '<S233>/detectLockup' */

  /* SystemInitialize for IfAction SubSystem: '<S233>/Slipping' */
  /* SystemInitialize for Gain: '<S235>/Output Inertia' */
  localB->OutputInertia = 0.0;

  /* InitializeConditions for Integrator: '<S235>/omega wheel' */
  localX->omegaWheel = rtp_omegao;

  /* End of SystemInitialize for SubSystem: '<S233>/Slipping' */
}

/*
 * System reset for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Reset(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, X_Clutch_DrivetrainHevP4_n_T *localX)
{
  localDW->is_active_c8_autolibshared = 0U;
  localDW->is_c8_autolibshared = DrivetrainHevP4_IN_NO_ACTIVE_CHILD;
  localX->omegaWheel = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge ' */
  localB->Omega = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 1' */
  localB->Omegadot = 0.0;

  /* InitializeConditions for Merge: '<S233>/ Merge 3' */
  localB->Myb = 0.0;
}

/*
 * Outputs for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  real_T rtu_Tout, real_T rtu_Tfmaxs, real_T rtu_Tfmaxk, real_T rtp_omegao,
  real_T rtp_br, real_T rtp_Iyy, real_T rtp_OmegaTol,
  B_Clutch_DrivetrainHevP4_k_T *localB, DW_Clutch_DrivetrainHevP4_k_T *localDW,
  P_Clutch_DrivetrainHevP4_o_T *localP, X_Clutch_DrivetrainHevP4_n_T *localX)
{
  real_T rtb_OutputSum_e;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    localDW->lastMajorTime = (*(DrivetrainHevP4_M->timingBridge->
      taskTime[DrivetrainHevP4_M->Timing.mdlref_GlobalTID[0]]));

    /* Chart: '<S228>/Clutch' */
    if (localDW->is_active_c8_autolibshared == 0U) {
      localDW->is_active_c8_autolibshared = 1U;
      localX->omegaWheel = rtp_omegao;
      localDW->is_c8_autolibshared = DrivetrainHevP4_IN_Slipping;

      /* Gain: '<S235>/Output Damping' incorporates:
       *  Integrator: '<S235>/omega wheel'
       */
      rtb_OutputSum_e = rtp_br * localX->omegaWheel;

      /* Merge: '<S233>/ Merge 3' incorporates:
       *  SignalConversion generated from: '<S235>/Myb'
       */
      localB->Myb = rtb_OutputSum_e;

      /* Merge: '<S233>/ Merge ' incorporates:
       *  Integrator: '<S235>/omega wheel'
       *  SignalConversion generated from: '<S235>/Omega'
       */
      localB->Omega = localX->omegaWheel;

      /* Gain: '<S235>/Output Inertia' incorporates:
       *  Gain: '<S235>/-4'
       *  Integrator: '<S235>/omega wheel'
       *  Product: '<S235>/Max Dynamic Friction Torque1'
       *  Sum: '<S235>/Output Sum'
       *  Trigonometry: '<S235>/Trigonometric Function'
       */
      localB->OutputInertia = ((tanh(localP->u_Gain * localX->omegaWheel) *
        rtu_Tfmaxk - rtu_Tout) - rtb_OutputSum_e) * (1.0 / rtp_Iyy);

      /* Merge: '<S233>/ Merge 1' incorporates:
       *  SignalConversion generated from: '<S235>/Omegadot'
       */
      localB->Omegadot = localB->OutputInertia;
      rtsiSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->solverInfo,
        true);
    } else if (localDW->is_c8_autolibshared == DrivetrainHevP4_IN_Locked) {
      if (DrivetrainHevP4_detectSlip(rtu_Tout, rtu_Tfmaxs, localB)) {
        localX->omegaWheel = 0.0;
        localDW->is_c8_autolibshared = DrivetrainHevP4_IN_Slipping;

        /* Gain: '<S235>/Output Damping' incorporates:
         *  Integrator: '<S235>/omega wheel'
         */
        rtb_OutputSum_e = rtp_br * localX->omegaWheel;

        /* Merge: '<S233>/ Merge 3' incorporates:
         *  SignalConversion generated from: '<S235>/Myb'
         */
        localB->Myb = rtb_OutputSum_e;

        /* Merge: '<S233>/ Merge ' incorporates:
         *  Integrator: '<S235>/omega wheel'
         *  SignalConversion generated from: '<S235>/Omega'
         */
        localB->Omega = localX->omegaWheel;

        /* Gain: '<S235>/Output Inertia' incorporates:
         *  Gain: '<S235>/-4'
         *  Integrator: '<S235>/omega wheel'
         *  Product: '<S235>/Max Dynamic Friction Torque1'
         *  Sum: '<S235>/Output Sum'
         *  Trigonometry: '<S235>/Trigonometric Function'
         */
        localB->OutputInertia = ((tanh(localP->u_Gain * localX->omegaWheel) *
          rtu_Tfmaxk - rtu_Tout) - rtb_OutputSum_e) * (1.0 / rtp_Iyy);

        /* Merge: '<S233>/ Merge 1' incorporates:
         *  SignalConversion generated from: '<S235>/Omegadot'
         */
        localB->Omegadot = localB->OutputInertia;
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      /* case IN_Slipping: */
    } else if (DrivetrainHevP4_detectLockup(rtu_Tout, rtu_Tfmaxs, rtp_br, localB,
                localDW, localP) && (fabs(localB->Omega) <= rtp_OmegaTol)) {
      localDW->is_c8_autolibshared = DrivetrainHevP4_IN_Locked;
      if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
        /* Merge: '<S233>/ Merge ' incorporates:
         *  Constant: '<S234>/locked'
         *  SignalConversion generated from: '<S234>/Omega'
         */
        localB->Omega = localP->locked_Value;

        /* Merge: '<S233>/ Merge 1' incorporates:
         *  Constant: '<S234>/locked1'
         *  SignalConversion generated from: '<S234>/Omegadot'
         */
        localB->Omegadot = localP->locked1_Value;

        /* Merge: '<S233>/ Merge 3' incorporates:
         *  Constant: '<S234>/locked2'
         *  SignalConversion generated from: '<S234>/Myb'
         */
        localB->Myb = localP->locked2_Value;
      }

      rtsiSetBlockStateForSolverChangedAtMajorStep(DrivetrainHevP4_M->solverInfo,
        true);
    }

    /* End of Chart: '<S228>/Clutch' */
  }

  if (localDW->is_c8_autolibshared == DrivetrainHevP4_IN_Locked) {
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
      /* Merge: '<S233>/ Merge ' incorporates:
       *  Constant: '<S234>/locked'
       *  SignalConversion generated from: '<S234>/Omega'
       */
      localB->Omega = localP->locked_Value;

      /* Merge: '<S233>/ Merge 1' incorporates:
       *  Constant: '<S234>/locked1'
       *  SignalConversion generated from: '<S234>/Omegadot'
       */
      localB->Omegadot = localP->locked1_Value;

      /* Merge: '<S233>/ Merge 3' incorporates:
       *  Constant: '<S234>/locked2'
       *  SignalConversion generated from: '<S234>/Myb'
       */
      localB->Myb = localP->locked2_Value;
    }
  } else {
    /* Gain: '<S235>/Output Damping' incorporates:
     *  Integrator: '<S235>/omega wheel'
     */
    /* case IN_Slipping: */
    rtb_OutputSum_e = rtp_br * localX->omegaWheel;

    /* Merge: '<S233>/ Merge 3' incorporates:
     *  SignalConversion generated from: '<S235>/Myb'
     */
    localB->Myb = rtb_OutputSum_e;

    /* Merge: '<S233>/ Merge ' incorporates:
     *  Integrator: '<S235>/omega wheel'
     *  SignalConversion generated from: '<S235>/Omega'
     */
    localB->Omega = localX->omegaWheel;

    /* Gain: '<S235>/Output Inertia' incorporates:
     *  Gain: '<S235>/-4'
     *  Integrator: '<S235>/omega wheel'
     *  Product: '<S235>/Max Dynamic Friction Torque1'
     *  Sum: '<S235>/Output Sum'
     *  Trigonometry: '<S235>/Trigonometric Function'
     */
    localB->OutputInertia = ((tanh(localP->u_Gain * localX->omegaWheel) *
      rtu_Tfmaxk - rtu_Tout) - rtb_OutputSum_e) * (1.0 / rtp_Iyy);

    /* Merge: '<S233>/ Merge 1' incorporates:
     *  SignalConversion generated from: '<S235>/Omegadot'
     */
    localB->Omegadot = localB->OutputInertia;
  }
}

/*
 * Derivatives for atomic system:
 *    '<S228>/Clutch'
 *    '<S270>/Clutch'
 */
void DrivetrainHevP4_Clutch_Deriv(B_Clutch_DrivetrainHevP4_k_T *localB,
  DW_Clutch_DrivetrainHevP4_k_T *localDW, XDot_Clutch_DrivetrainHevP4_p_T
  *localXdot)
{
  localXdot->omegaWheel = 0.0;
  if (localDW->is_c8_autolibshared == 2) {
    /* Derivatives for Integrator: '<S235>/omega wheel' */
    localXdot->omegaWheel = localB->OutputInertia;
  }
}

/*
 * System initialize for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_g_Init(real_T rtp_omegao, B_Clutch_DrivetrainHevP4_T
  *localB, DW_Clutch_DrivetrainHevP4_T *localDW, P_Clutch_DrivetrainHevP4_T
  *localP, X_Clutch_DrivetrainHevP4_T *localX)
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* SystemInitialize for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Init(rtp_omegao, &localB->CoreSubsys[ForEach_itr].
      sf_Clutch, &localDW->CoreSubsys[ForEach_itr].sf_Clutch,
      &localP->CoreSubsys.sf_Clutch, &localX->CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/*
 * System reset for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_b_Reset(B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, X_Clutch_DrivetrainHevP4_T *localX)
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* SystemReset for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Reset(&localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localX->
      CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/*
 * Outputs for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_l(RT_MODEL_DrivetrainHevP4_T * const
  DrivetrainHevP4_M, real_T rtu_Tout, real_T rtu_Tfmaxs, real_T rtu_Tfmaxk,
  real_T *rty_Omega, real_T rtp_omegao, real_T rtp_br, real_T rtp_Iyy, real_T
  rtp_VXLOW, real_T rtp_Re, B_Clutch_DrivetrainHevP4_T *localB,
  DW_Clutch_DrivetrainHevP4_T *localDW, P_Clutch_DrivetrainHevP4_T *localP,
  X_Clutch_DrivetrainHevP4_T *localX)
{
  /* local block i/o variables */
  real_T rtb_ImpSel_InsertedFor_Tout_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0;

  /* local scratch DWork variables */
  int32_T ForEach_itr;

  /* Outputs for Iterator SubSystem: '<S217>/Clutch' incorporates:
   *  ForEach: '<S228>/For Each'
   */
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* ForEachSliceSelector generated from: '<S228>/Tout' */
    rtb_ImpSel_InsertedFor_Tout_at_outport_0 = rtu_Tout;

    /* ForEachSliceSelector generated from: '<S228>/Tfmaxs' */
    rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0 = rtu_Tfmaxs;

    /* ForEachSliceSelector generated from: '<S228>/Tfmaxk' */
    rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0 = rtu_Tfmaxk;

    /* Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch(DrivetrainHevP4_M,
      rtb_ImpSel_InsertedFor_Tout_at_outport_0,
      rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0,
      rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0, rtp_omegao, rtp_br, rtp_Iyy,
      rtp_VXLOW * rtp_Re * 0.0, &localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localP->CoreSubsys.sf_Clutch,
      &localX->CoreSubsys[ForEach_itr].sf_Clutch);

    /* ForEachSliceAssignment generated from: '<S228>/Omega' */
    *rty_Omega = localB->CoreSubsys[ForEach_itr].sf_Clutch.Omega;
  }

  /* End of Outputs for SubSystem: '<S217>/Clutch' */
}

/*
 * Derivatives for iterator system:
 *    '<S217>/Clutch'
 *    '<S259>/Clutch'
 */
void DrivetrainHevP4_Clutch_d_Deriv(real_T rtu_Tout, real_T rtu_Tfmaxs, real_T
  rtu_Tfmaxk, B_Clutch_DrivetrainHevP4_T *localB, DW_Clutch_DrivetrainHevP4_T
  *localDW, XDot_Clutch_DrivetrainHevP4_T *localXdot)
{
  /* local block i/o variables */
  real_T rtb_ImpSel_InsertedFor_Tout_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0;
  real_T rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0;

  /* local scratch DWork variables */
  int32_T ForEach_itr;
  for (ForEach_itr = 0; ForEach_itr < 1; ForEach_itr++) {
    /* Derivatives for ForEachSliceSelector generated from: '<S228>/Tout' */
    rtb_ImpSel_InsertedFor_Tout_at_outport_0 = rtu_Tout;

    /* Derivatives for ForEachSliceSelector generated from: '<S228>/Tfmaxs' */
    rtb_ImpSel_InsertedFor_Tfmaxs_at_outport_0 = rtu_Tfmaxs;

    /* Derivatives for ForEachSliceSelector generated from: '<S228>/Tfmaxk' */
    rtb_ImpSel_InsertedFor_Tfmaxk_at_outport_0 = rtu_Tfmaxk;

    /* Derivatives for Chart: '<S228>/Clutch' */
    DrivetrainHevP4_Clutch_Deriv(&localB->CoreSubsys[ForEach_itr].sf_Clutch,
      &localDW->CoreSubsys[ForEach_itr].sf_Clutch, &localXdot->
      CoreSubsys[ForEach_itr].sf_Clutch);
  }
}

/* System initialize for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Init(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  real_T *rty_EngSpd, B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, X_DrivetrainHevP4_n_T *localX)
{
  /* Start for Constant: '<S13>/domega_o' */
  localB->domega_o = DrivetrainHevP4_P.domega_o;

  /* Start for Constant: '<S60>/domega_o' */
  localB->domega_o_m = DrivetrainHevP4_P.domega_o;

  /* Start for InitialCondition: '<S128>/IC' */
  localDW->IC_FirstOutputTime = true;

  /* Start for InitialCondition: '<S129>/IC' */
  localDW->IC_FirstOutputTime_e = true;

  /* Start for Constant: '<S86>/domega_o' */
  localB->domega_o_h = DrivetrainHevP4_P.domega_o;

  /* Start for Constant: '<S149>/Constant2' */
  localB->Constant2 = DrivetrainHevP4_P.Constant2_Value_a;

  /* Start for InitialCondition: '<S134>/IC' */
  localDW->IC_FirstOutputTime_d = true;

  /* Start for If: '<S126>/If' */
  localDW->If_ActiveSubsystem = -1;

  /* Start for Constant: '<S94>/Constant1' */
  localB->Constant1 = DrivetrainHevP4_P.IdealFixedGearTransmission_G_o;

  /* Start for InitialCondition: '<S97>/IC' */
  localDW->IC_FirstOutputTime_k = true;

  /* Start for Constant: '<S77>/domega_o' */
  localB->domega_o_j = DrivetrainHevP4_P.domega_o;

  /* Start for InitialCondition: '<S101>/IC' */
  localDW->IC_FirstOutputTime_f = true;

  /* Start for InitialCondition: '<S99>/IC' */
  localDW->IC_FirstOutputTime_j = true;

  /* Start for If: '<S94>/If' */
  localDW->If_ActiveSubsystem_b = -1;

  /* InitializeConditions for Integrator: '<S169>/Integrator' */
  localX->Integrator_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S164>/Integrator1' */
  localX->Integrator1_CSTATE = DrivetrainHevP4_P.Integrator1_IC;

  /* InitializeConditions for Memory: '<S14>/Memory' */
  localDW->Memory_PreviousInput = DrivetrainHevP4_P.Memory_InitialCondition;

  /* InitializeConditions for Integrator: '<S14>/Integrator' incorporates:
   *  Integrator: '<S61>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_a = 0.0;
    localX->Integrator_CSTATE_l = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S14>/Integrator' */

  /* InitializeConditions for Integrator: '<S13>/Integrator' */
  localX->Integrator_CSTATE_c = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S246>/Integrator' */
  localX->Integrator_CSTATE_h = DrivetrainHevP4_P.Integrator_IC_c;

  /* InitializeConditions for Integrator: '<S163>/Integrator1' */
  localX->Integrator1_CSTATE_g = DrivetrainHevP4_P.Integrator1_IC_f;

  /* InitializeConditions for Memory: '<S61>/Memory' */
  localDW->Memory_PreviousInput_f = DrivetrainHevP4_P.Memory_InitialCondition_j;

  /* InitializeConditions for Integrator: '<S61>/Integrator' */
  localDW->Integrator_IWORK_m = 1;

  /* InitializeConditions for Integrator: '<S60>/Integrator' */
  localX->Integrator_CSTATE_i = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S288>/Integrator' */
  localX->Integrator_CSTATE_hm = DrivetrainHevP4_P.Integrator_IC_h;

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  localX->Integrator_CSTATE_d[0] = DrivetrainHevP4_P.Integrator_IC_f;
  localX->Integrator_CSTATE_d[1] = DrivetrainHevP4_P.Integrator_IC_f;

  /* InitializeConditions for Integrator: '<S177>/Integrator3' */
  localX->Integrator3_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S166>/Integrator1' */
  localX->Integrator1_CSTATE_f = DrivetrainHevP4_P.x_o;

  /* InitializeConditions for Memory: '<S87>/Memory' */
  localDW->Memory_PreviousInput_e = DrivetrainHevP4_P.Memory_InitialCondition_g;

  /* InitializeConditions for Integrator: '<S87>/Integrator' incorporates:
   *  Integrator: '<S150>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_de = 0.0;
    localX->Integrator_CSTATE_b = 0.0;
  }

  localDW->Integrator_IWORK_d = 1;

  /* End of InitializeConditions for Integrator: '<S87>/Integrator' */

  /* InitializeConditions for Integrator: '<S86>/Integrator' */
  localX->Integrator_CSTATE_g = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Memory: '<S150>/Memory' */
  localDW->Memory_PreviousInput_d = DrivetrainHevP4_P.Memory_InitialCondition_e;

  /* InitializeConditions for Integrator: '<S150>/Integrator' */
  localDW->Integrator_IWORK_h = 1;

  /* InitializeConditions for Memory: '<S145>/Memory' */
  localDW->Memory_PreviousInput_jb = DrivetrainHevP4_P.Memory_InitialCondition_o;

  /* InitializeConditions for Memory: '<S96>/Memory' */
  localDW->Memory_PreviousInput_j = DrivetrainHevP4_P.Memory_InitialCondition_b;

  /* InitializeConditions for Integrator: '<S96>/Integrator' incorporates:
   *  Integrator: '<S78>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_h1 = 0.0;
    localX->Integrator_CSTATE_j = 0.0;
  }

  localDW->Integrator_IWORK_n = 1;

  /* End of InitializeConditions for Integrator: '<S96>/Integrator' */

  /* InitializeConditions for Memory: '<S78>/Memory' */
  localDW->Memory_PreviousInput_h = DrivetrainHevP4_P.Memory_InitialCondition_f;

  /* InitializeConditions for Integrator: '<S78>/Integrator' */
  localDW->Integrator_IWORK_l = 1;

  /* InitializeConditions for Integrator: '<S77>/Integrator' */
  localX->Integrator_CSTATE_g4 = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S25>/Integrator' incorporates:
   *  Integrator: '<S42>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_o[0] = 0.0;
    localX->Integrator_CSTATE_o[1] = 0.0;
    localX->Integrator_CSTATE_n[0] = 0.0;
    localX->Integrator_CSTATE_n[1] = 0.0;
  }

  localDW->Integrator_IWORK_j = 1;

  /* End of InitializeConditions for Integrator: '<S25>/Integrator' */

  /* InitializeConditions for Integrator: '<S42>/Integrator' */
  localDW->Integrator_IWORK_mn = 1;

  /* SystemInitialize for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_g_Init(DrivetrainHevP4_P.omegao, &localB->Clutch,
    &localDW->Clutch, &DrivetrainHevP4_P.Clutch, &localX->Clutch);

  /* End of SystemInitialize for SubSystem: '<S217>/Clutch' */

  /* SystemInitialize for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_g_Init(DrivetrainHevP4_P.omegao, &localB->Clutch_e,
    &localDW->Clutch_e, &DrivetrainHevP4_P.Clutch_e, &localX->Clutch_e);

  /* End of SystemInitialize for SubSystem: '<S259>/Clutch' */

  /* SystemInitialize for IfAction SubSystem: '<S126>/Unlocked' */
  /* SystemInitialize for IfAction SubSystem: '<S126>/Locked' */
  /* InitializeConditions for Integrator: '<S132>/Locked Shaft Integrator' incorporates:
   *  Integrator: '<S133>/Pump Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->LockedShaftIntegrator_CSTATE = 0.0;
    localX->PumpIntegrator_CSTATE = 0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S126>/Unlocked' */
  localDW->LockedShaftIntegrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S132>/Locked Shaft Integrator' */
  /* End of SystemInitialize for SubSystem: '<S126>/Locked' */

  /* SystemInitialize for IfAction SubSystem: '<S126>/Unlocked' */
  /* InitializeConditions for Integrator: '<S133>/Pump Integrator' */
  localDW->PumpIntegrator_IWORK = 1;

  /* SystemInitialize for IfAction SubSystem: '<S94>/Locked' */
  /* InitializeConditions for Integrator: '<S133>/Turbine Integrator' incorporates:
   *  Integrator: '<S98>/x'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->TurbineIntegrator_CSTATE = 0.0;
    localX->w = 0.0;
  }

  /* End of SystemInitialize for SubSystem: '<S94>/Locked' */
  localDW->TurbineIntegrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S133>/Turbine Integrator' */

  /* SystemInitialize for Enabled SubSystem: '<S153>/LPF' */
  /* InitializeConditions for Integrator: '<S157>/Integrator' */
  localX->Integrator_CSTATE_e = DrivetrainHevP4_P.Integrator_IC;

  /* SystemInitialize for Integrator: '<S157>/Integrator' incorporates:
   *  Outport: '<S156>/Out1'
   */
  localB->Integrator_k = DrivetrainHevP4_P.Out1_Y0;

  /* End of SystemInitialize for SubSystem: '<S153>/LPF' */
  /* End of SystemInitialize for SubSystem: '<S126>/Unlocked' */

  /* SystemInitialize for Merge: '<S126>/Merge1' */
  *rty_EngSpd = DrivetrainHevP4_P.Merge1_InitialOutput;

  /* SystemInitialize for IfAction SubSystem: '<S94>/Locked' */
  /* InitializeConditions for Integrator: '<S98>/x' */
  localDW->x_IWORK = 1;

  /* End of SystemInitialize for SubSystem: '<S94>/Locked' */

  /* SystemInitialize for IfAction SubSystem: '<S94>/Unlocked' */
  /* InitializeConditions for Integrator: '<S100>/xe' incorporates:
   *  Integrator: '<S100>/xv'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->we = 0.0;
    localX->wv = 0.0;
  }

  localDW->xe_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S100>/xe' */

  /* InitializeConditions for Integrator: '<S100>/xv' */
  localDW->xv_IWORK = 1;

  /* End of SystemInitialize for SubSystem: '<S94>/Unlocked' */
}

/* System reset for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Reset(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T *localDW,
  X_DrivetrainHevP4_n_T *localX)
{
  /* InitializeConditions for Integrator: '<S169>/Integrator' */
  localX->Integrator_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S164>/Integrator1' */
  localX->Integrator1_CSTATE = DrivetrainHevP4_P.Integrator1_IC;

  /* InitializeConditions for Memory: '<S14>/Memory' */
  localDW->Memory_PreviousInput = DrivetrainHevP4_P.Memory_InitialCondition;

  /* InitializeConditions for Integrator: '<S14>/Integrator' incorporates:
   *  Integrator: '<S61>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_a = 0.0;
    localX->Integrator_CSTATE_l = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S14>/Integrator' */

  /* InitializeConditions for Integrator: '<S13>/Integrator' */
  localX->Integrator_CSTATE_c = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S246>/Integrator' */
  localX->Integrator_CSTATE_h = DrivetrainHevP4_P.Integrator_IC_c;

  /* InitializeConditions for Integrator: '<S163>/Integrator1' */
  localX->Integrator1_CSTATE_g = DrivetrainHevP4_P.Integrator1_IC_f;

  /* InitializeConditions for Memory: '<S61>/Memory' */
  localDW->Memory_PreviousInput_f = DrivetrainHevP4_P.Memory_InitialCondition_j;

  /* InitializeConditions for Integrator: '<S61>/Integrator' */
  localDW->Integrator_IWORK_m = 1;

  /* InitializeConditions for Integrator: '<S60>/Integrator' */
  localX->Integrator_CSTATE_i = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S288>/Integrator' */
  localX->Integrator_CSTATE_hm = DrivetrainHevP4_P.Integrator_IC_h;

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  localX->Integrator_CSTATE_d[0] = DrivetrainHevP4_P.Integrator_IC_f;
  localX->Integrator_CSTATE_d[1] = DrivetrainHevP4_P.Integrator_IC_f;

  /* InitializeConditions for Integrator: '<S177>/Integrator3' */
  localX->Integrator3_CSTATE = DrivetrainHevP4_P.xdot_o;

  /* InitializeConditions for Integrator: '<S166>/Integrator1' */
  localX->Integrator1_CSTATE_f = DrivetrainHevP4_P.x_o;

  /* InitializeConditions for Memory: '<S87>/Memory' */
  localDW->Memory_PreviousInput_e = DrivetrainHevP4_P.Memory_InitialCondition_g;

  /* InitializeConditions for Integrator: '<S87>/Integrator' incorporates:
   *  Integrator: '<S150>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_de = 0.0;
    localX->Integrator_CSTATE_b = 0.0;
  }

  localDW->Integrator_IWORK_d = 1;

  /* End of InitializeConditions for Integrator: '<S87>/Integrator' */

  /* InitializeConditions for Integrator: '<S86>/Integrator' */
  localX->Integrator_CSTATE_g = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Memory: '<S150>/Memory' */
  localDW->Memory_PreviousInput_d = DrivetrainHevP4_P.Memory_InitialCondition_e;

  /* InitializeConditions for Integrator: '<S150>/Integrator' */
  localDW->Integrator_IWORK_h = 1;

  /* InitializeConditions for Memory: '<S145>/Memory' */
  localDW->Memory_PreviousInput_jb = DrivetrainHevP4_P.Memory_InitialCondition_o;

  /* InitializeConditions for Memory: '<S96>/Memory' */
  localDW->Memory_PreviousInput_j = DrivetrainHevP4_P.Memory_InitialCondition_b;

  /* InitializeConditions for Integrator: '<S96>/Integrator' incorporates:
   *  Integrator: '<S78>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_h1 = 0.0;
    localX->Integrator_CSTATE_j = 0.0;
  }

  localDW->Integrator_IWORK_n = 1;

  /* End of InitializeConditions for Integrator: '<S96>/Integrator' */

  /* InitializeConditions for Memory: '<S78>/Memory' */
  localDW->Memory_PreviousInput_h = DrivetrainHevP4_P.Memory_InitialCondition_f;

  /* InitializeConditions for Integrator: '<S78>/Integrator' */
  localDW->Integrator_IWORK_l = 1;

  /* InitializeConditions for Integrator: '<S77>/Integrator' */
  localX->Integrator_CSTATE_g4 = DrivetrainHevP4_P.theta_o;

  /* InitializeConditions for Integrator: '<S25>/Integrator' incorporates:
   *  Integrator: '<S42>/Integrator'
   */
  if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
    localX->Integrator_CSTATE_o[0] = 0.0;
    localX->Integrator_CSTATE_o[1] = 0.0;
    localX->Integrator_CSTATE_n[0] = 0.0;
    localX->Integrator_CSTATE_n[1] = 0.0;
  }

  localDW->Integrator_IWORK_j = 1;

  /* End of InitializeConditions for Integrator: '<S25>/Integrator' */

  /* InitializeConditions for Integrator: '<S42>/Integrator' */
  localDW->Integrator_IWORK_mn = 1;

  /* SystemReset for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_b_Reset(&localB->Clutch, &localDW->Clutch,
    &localX->Clutch);

  /* End of SystemReset for SubSystem: '<S217>/Clutch' */

  /* SystemReset for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_b_Reset(&localB->Clutch_e, &localDW->Clutch_e,
    &localX->Clutch_e);

  /* End of SystemReset for SubSystem: '<S259>/Clutch' */
}

/* Disable for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Disable(DW_DrivetrainHevP4_f_T *localDW)
{
  /* Disable for Enabled SubSystem: '<S153>/LPF' */
  /* Disable for If: '<S126>/If' */
  localDW->LPF_MODE = ((localDW->If_ActiveSubsystem != 1) && localDW->LPF_MODE);

  /* End of Disable for SubSystem: '<S153>/LPF' */
  localDW->If_ActiveSubsystem = -1;

  /* Disable for If: '<S94>/If' */
  localDW->If_ActiveSubsystem_b = -1;
}

/* Outputs for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M, const
                     real_T *rtu_EngTrq, const real_T *rtu_MotTrq, const real_T *
                     rtu_Grade, const real_T *rtu_WindVel, const real_T
                     *rtu_BrkCmd, const real_T *rtu_GearCmd, real_T *rty_VehSpd,
                     real_T *rty_EngSpd, boolean_T *rty_Cltch1State, boolean_T
                     *rty_Cltch2State, real_T *rty_MotSpd, real_T *rty_TransGear,
                     B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
                     *localDW, X_DrivetrainHevP4_n_T *localX,
                     ZCE_DrivetrainHevP4_T *localZCE)
{
  /* local block i/o variables */
  real_T rtb_Integrator1;
  real_T rtb_Integrator1_d;
  real_T rtb_Integrator_g[2];
  real_T rtb_Integrator_p[2];
  real_T rtb_Product4;
  real_T rtb_Product4_g;
  real_T rtb_Product4_o;
  real_T rtb_Product4_e;
  real_T rtb_Product4_p;
  real_T rtb_Product4_oe;
  real_T rtb_ImpAsg_InsertedFor_Omega_at_inport_0;
  real_T rtb_ImpAsg_InsertedFor_Omega_at_inport_0_i;
  real_T rtb_Switch1[10];
  real_T rtb_uAPabsRT[6];
  real_T fractions[4];
  real_T rtb_Fx;
  real_T rtb_Fx_o;
  real_T rtb_Gain;
  real_T rtb_Gain1_lh;
  real_T rtb_Integrator_b;
  real_T rtb_Merge;
  real_T rtb_Merge1;
  real_T rtb_Subtract1;
  real_T rtb_Sum_gs;
  real_T rtb_SumofElements_d;
  real_T rtb_Switch_a;
  real_T rtb_Switch_o;
  real_T rtb_TorqueRatiozetaInterpolation;
  real_T rtb_TurbineSpd;
  real_T rtb_UnaryMinus1_c;
  real_T rtb_UnaryMinus1_p;
  real_T rtb_uniclutch;
  int32_T i;
  uint32_T bpIndices[4];
  uint32_T rtb_speedratioPrelookup_o1;
  int8_T rtAction;
  int8_T rtPrevAction;
  boolean_T rtb_Logic;
  ZCEventType zcEvent;

  /* Integrator: '<S169>/Integrator' */
  localB->Integrator = localX->Integrator_CSTATE;

  /* SignalConversion generated from: '<S166>/Vector Concatenate2' */
  localB->VectorConcatenate2[0] = localB->Integrator;

  /* SignalConversion generated from: '<S166>/Vector Concatenate2' */
  localB->VectorConcatenate2[1] = 0.0;

  /* SignalConversion generated from: '<S166>/Vector Concatenate2' */
  localB->VectorConcatenate2[2] = 0.0;

  /* SignalConversion generated from: '<Root>/VehSpd' */
  *rty_VehSpd = localB->VectorConcatenate2[0];
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Saturate: '<S217>/Saturation' */
    if (DrivetrainHevP4_P.Re > DrivetrainHevP4_P.Saturation_UpperSat_f) {
      /* Saturate: '<S217>/Saturation' */
      localB->Saturation = DrivetrainHevP4_P.Saturation_UpperSat_f;
    } else if (DrivetrainHevP4_P.Re < DrivetrainHevP4_P.Saturation_LowerSat_n) {
      /* Saturate: '<S217>/Saturation' */
      localB->Saturation = DrivetrainHevP4_P.Saturation_LowerSat_n;
    } else {
      /* Saturate: '<S217>/Saturation' */
      localB->Saturation = DrivetrainHevP4_P.Re;
    }

    /* End of Saturate: '<S217>/Saturation' */

    /* Memory: '<S14>/Memory' */
    localB->Memory = localDW->Memory_PreviousInput;

    /* Constant: '<S13>/domega_o' */
    localB->domega_o = DrivetrainHevP4_P.domega_o;
  }

  /* Integrator: '<S164>/Integrator1' */
  rtb_Integrator1 = localX->Integrator1_CSTATE;

  /* Integrator: '<S14>/Integrator' */
  rtb_Logic = rtsiGetIsOkayToUpdateMode(DrivetrainHevP4_M->solverInfo);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE,
                       (localB->Memory));

    /* evaluate zero-crossings */
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK != 0)) {
      localX->Integrator_CSTATE_a = localB->domega_o;
    }
  }

  rtb_Switch_o = localX->Integrator_CSTATE_a;

  /* Sum: '<S13>/Subtract1' incorporates:
   *  Gain: '<S13>/Gain1'
   *  Gain: '<S13>/Gain2'
   *  Integrator: '<S13>/Integrator'
   *  Integrator: '<S14>/Integrator'
   */
  rtb_UnaryMinus1_c = DrivetrainHevP4_P.b * localX->Integrator_CSTATE_a +
    DrivetrainHevP4_P.k * localX->Integrator_CSTATE_c;

  /* Integrator: '<S246>/Integrator' */
  rtb_Integrator_b = localX->Integrator_CSTATE_h;

  /* Gain: '<S217>/Sign convention' incorporates:
   *  Integrator: '<S246>/Integrator'
   *  Product: '<S230>/Product1'
   *  Sum: '<S217>/Add1'
   */
  localB->Signconvention = (rtb_UnaryMinus1_c - localX->Integrator_CSTATE_h *
    localB->Saturation) * DrivetrainHevP4_P.Signconvention_Gain;

  /* Gain: '<S5>/Gain' */
  rtb_Gain = DrivetrainHevP4_P.Gain_Gain_k * *rtu_BrkCmd;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Gain: '<S232>/Torque Conversion1' incorporates:
     *  Constant: '<S232>/Disk brake actuator bore'
     */
    localB->TorqueConversion1 = DrivetrainHevP4_P.TorqueConversion1_Gain *
      DrivetrainHevP4_P.disk_abore;
  }

  /* Product: '<S232>/product' incorporates:
   *  Constant: '<S232>/Disk brake actuator bore'
   *  Constant: '<S232>/Number of brake pads'
   */
  rtb_TurbineSpd = rtb_Gain * localB->TorqueConversion1 *
    DrivetrainHevP4_P.disk_abore * DrivetrainHevP4_P.num_pads;

  /* Saturate: '<S232>/Disallow Negative Brake Torque' */
  if (rtb_TurbineSpd > DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat) {
    rtb_TurbineSpd = DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat;
  } else if (rtb_TurbineSpd <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat) {
    rtb_TurbineSpd = DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat;
  }

  /* End of Saturate: '<S232>/Disallow Negative Brake Torque' */

  /* Gain: '<S232>/Torque Conversion' */
  localB->TorqueConversion = DrivetrainHevP4_P.Rm * DrivetrainHevP4_P.mu_kinetic
    * rtb_TurbineSpd;

  /* Gain: '<S229>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion;

  /* Outputs for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention,
    localB->Ratioofstatictokinetic, localB->TorqueConversion,
    &rtb_ImpAsg_InsertedFor_Omega_at_inport_0_i, DrivetrainHevP4_P.omegao,
    DrivetrainHevP4_P.br, DrivetrainHevP4_P.Iyy_Whl, DrivetrainHevP4_P.VXLOW,
    DrivetrainHevP4_P.Re, &localB->Clutch, &localDW->Clutch,
    &DrivetrainHevP4_P.Clutch, &localX->Clutch);

  /* End of Outputs for SubSystem: '<S217>/Clutch' */

  /* MATLAB Function: '<S213>/Simple Magic Tire' incorporates:
   *  Constant: '<S208>/FxType'
   *  Constant: '<S208>/TirePrsConstant'
   *  Constant: '<S208>/lam_muxConstant'
   *  Constant: '<S208>/rollType'
   *  Constant: '<S208>/vertType'
   *  Constant: '<S224>/Constant'
   *  Constant: '<S224>/Constant1'
   *  Constant: '<S224>/Constant12'
   *  Constant: '<S224>/Constant14'
   *  Constant: '<S224>/Constant19'
   *  Constant: '<S224>/Constant2'
   *  Constant: '<S224>/Constant6'
   *  Constant: '<S224>/Constant7'
   *  Constant: '<S225>/Constant1'
   *  Constant: '<S225>/Constant10'
   *  Constant: '<S225>/Constant11'
   *  Constant: '<S225>/Constant12'
   *  Constant: '<S225>/Constant13'
   *  Constant: '<S225>/Constant14'
   *  Constant: '<S225>/Constant15'
   *  Constant: '<S225>/Constant16'
   *  Constant: '<S225>/Constant17'
   *  Constant: '<S225>/Constant18'
   *  Constant: '<S225>/Constant19'
   *  Constant: '<S225>/Constant2'
   *  Constant: '<S225>/Constant3'
   *  Constant: '<S225>/Constant4'
   *  Constant: '<S225>/Constant5'
   *  Constant: '<S225>/Constant7'
   *  Constant: '<S225>/Constant8'
   *  Constant: '<S225>/Constant9'
   *  Constant: '<S226>/Constant1'
   *  Constant: '<S226>/Constant10'
   *  Constant: '<S226>/Constant11'
   *  Constant: '<S226>/Constant13'
   *  Constant: '<S226>/Constant14'
   *  Constant: '<S226>/Constant15'
   *  Constant: '<S226>/Constant16'
   *  Constant: '<S226>/Constant17'
   *  Constant: '<S226>/Constant18'
   *  Constant: '<S226>/Constant19'
   *  Constant: '<S226>/Constant2'
   *  Constant: '<S226>/Constant20'
   *  Constant: '<S226>/Constant21'
   *  Constant: '<S226>/Constant22'
   *  Constant: '<S226>/Constant23'
   *  Constant: '<S226>/Constant24'
   *  Constant: '<S226>/Constant3'
   *  Constant: '<S226>/Constant4'
   *  Constant: '<S226>/Constant5'
   *  Constant: '<S226>/Constant6'
   *  Constant: '<S226>/Constant7'
   *  Constant: '<S226>/Constant8'
   *  Constant: '<S226>/Constant9'
   */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation, rtb_Integrator1,
    rtb_ImpAsg_InsertedFor_Omega_at_inport_0_i, localB->VectorConcatenate2[0],
    DrivetrainHevP4_P.Constant_Value_px, DrivetrainHevP4_P.Constant1_Value_n,
    DrivetrainHevP4_P.Constant7_Value, DrivetrainHevP4_P.Constant6_Value,
    DrivetrainHevP4_P.lam_x, DrivetrainHevP4_P.Constant2_Value_i,
    DrivetrainHevP4_P.Constant19_Value, DrivetrainHevP4_P.Constant12_Value,
    DrivetrainHevP4_P.Constant14_Value, DrivetrainHevP4_P.press,
    DrivetrainHevP4_P.Constant5_Value, DrivetrainHevP4_P.Constant2_Value_c,
    DrivetrainHevP4_P.aMy, DrivetrainHevP4_P.bMy, DrivetrainHevP4_P.cMy,
    DrivetrainHevP4_P.Constant16_Value, DrivetrainHevP4_P.Constant7_Value_o,
    DrivetrainHevP4_P.Constant9_Value, DrivetrainHevP4_P.betaMy,
    DrivetrainHevP4_P.alphaMy, DrivetrainHevP4_P.Constant11_Value,
    DrivetrainHevP4_P.Constant10_Value, DrivetrainHevP4_P.UNLOADED_RADIUS,
    DrivetrainHevP4_P.Constant1_Value_i, DrivetrainHevP4_P.Constant3_Value,
    DrivetrainHevP4_P.Constant19_Value_f, DrivetrainHevP4_P.Constant12_Value_b,
    DrivetrainHevP4_P.Constant14_Value_m, 0.0, DrivetrainHevP4_P.FxType_Value,
    DrivetrainHevP4_P.rollType_Value, DrivetrainHevP4_P.vertType_Value,
    DrivetrainHevP4_P.FZMAX, DrivetrainHevP4_P.FZMIN, DrivetrainHevP4_P.VXLOW,
    DrivetrainHevP4_P.kappamax, &localB->sf_SimpleMagicTire);

  /* Sum: '<S5>/Add' */
  rtb_Fx = localB->sf_SimpleMagicTire.Fx + localB->sf_SimpleMagicTire.Fx;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Saturate: '<S259>/Saturation' */
    if (DrivetrainHevP4_P.Re > DrivetrainHevP4_P.Saturation_UpperSat_p) {
      /* Saturate: '<S259>/Saturation' */
      localB->Saturation_f = DrivetrainHevP4_P.Saturation_UpperSat_p;
    } else if (DrivetrainHevP4_P.Re < DrivetrainHevP4_P.Saturation_LowerSat_d) {
      /* Saturate: '<S259>/Saturation' */
      localB->Saturation_f = DrivetrainHevP4_P.Saturation_LowerSat_d;
    } else {
      /* Saturate: '<S259>/Saturation' */
      localB->Saturation_f = DrivetrainHevP4_P.Re;
    }

    /* End of Saturate: '<S259>/Saturation' */

    /* Memory: '<S61>/Memory' */
    localB->Memory_f = localDW->Memory_PreviousInput_f;

    /* Constant: '<S60>/domega_o' */
    localB->domega_o_m = DrivetrainHevP4_P.domega_o;
  }

  /* Integrator: '<S163>/Integrator1' */
  rtb_Integrator1_d = localX->Integrator1_CSTATE_g;

  /* Integrator: '<S61>/Integrator' */
  rtb_Logic = rtsiGetIsOkayToUpdateMode(DrivetrainHevP4_M->solverInfo);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_a,
                       (localB->Memory_f));

    /* evaluate zero-crossings */
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_m != 0)) {
      localX->Integrator_CSTATE_l = localB->domega_o_m;
    }
  }

  rtb_Switch_a = localX->Integrator_CSTATE_l;

  /* Sum: '<S60>/Subtract1' incorporates:
   *  Gain: '<S60>/Gain1'
   *  Gain: '<S60>/Gain2'
   *  Integrator: '<S60>/Integrator'
   *  Integrator: '<S61>/Integrator'
   */
  rtb_UnaryMinus1_p = DrivetrainHevP4_P.b * localX->Integrator_CSTATE_l +
    DrivetrainHevP4_P.k * localX->Integrator_CSTATE_i;

  /* Integrator: '<S288>/Integrator' */
  rtb_Gain = localX->Integrator_CSTATE_hm;

  /* Gain: '<S259>/Sign convention' incorporates:
   *  Integrator: '<S288>/Integrator'
   *  Product: '<S272>/Product1'
   *  Sum: '<S259>/Add1'
   */
  localB->Signconvention_o = (rtb_UnaryMinus1_p - localX->Integrator_CSTATE_hm *
    localB->Saturation_f) * DrivetrainHevP4_P.Signconvention_Gain_c;

  /* Gain: '<S5>/Gain1' */
  rtb_Gain1_lh = DrivetrainHevP4_P.Gain1_Gain * *rtu_BrkCmd;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Gain: '<S274>/Torque Conversion1' incorporates:
     *  Constant: '<S274>/Disk brake actuator bore'
     */
    localB->TorqueConversion1_b = DrivetrainHevP4_P.TorqueConversion1_Gain_b *
      DrivetrainHevP4_P.disk_abore;
  }

  /* Product: '<S274>/product' incorporates:
   *  Constant: '<S274>/Disk brake actuator bore'
   *  Constant: '<S274>/Number of brake pads'
   */
  rtb_TurbineSpd = rtb_Gain1_lh * localB->TorqueConversion1_b *
    DrivetrainHevP4_P.disk_abore * DrivetrainHevP4_P.num_pads;

  /* Saturate: '<S274>/Disallow Negative Brake Torque' */
  if (rtb_TurbineSpd > DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o)
  {
    rtb_TurbineSpd = DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o;
  } else if (rtb_TurbineSpd <
             DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o) {
    rtb_TurbineSpd = DrivetrainHevP4_P.DisallowNegativeBrakeTorque_LowerSat_o;
  }

  /* End of Saturate: '<S274>/Disallow Negative Brake Torque' */

  /* Gain: '<S274>/Torque Conversion' */
  localB->TorqueConversion_b = DrivetrainHevP4_P.Rm *
    DrivetrainHevP4_P.mu_kinetic * rtb_TurbineSpd;

  /* Gain: '<S271>/Ratio of static to kinetic' */
  localB->Ratioofstatictokinetic_i = DrivetrainHevP4_P.mu_static /
    DrivetrainHevP4_P.mu_kinetic * localB->TorqueConversion_b;

  /* Outputs for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_l(DrivetrainHevP4_M, localB->Signconvention_o,
    localB->Ratioofstatictokinetic_i, localB->TorqueConversion_b,
    &rtb_ImpAsg_InsertedFor_Omega_at_inport_0, DrivetrainHevP4_P.omegao,
    DrivetrainHevP4_P.br, DrivetrainHevP4_P.Iyy_Whl, DrivetrainHevP4_P.VXLOW,
    DrivetrainHevP4_P.Re, &localB->Clutch_e, &localDW->Clutch_e,
    &DrivetrainHevP4_P.Clutch_e, &localX->Clutch_e);

  /* End of Outputs for SubSystem: '<S259>/Clutch' */

  /* MATLAB Function: '<S255>/Simple Magic Tire' incorporates:
   *  Constant: '<S210>/FxType'
   *  Constant: '<S210>/TirePrsConstant'
   *  Constant: '<S210>/lam_muxConstant'
   *  Constant: '<S210>/rollType'
   *  Constant: '<S210>/vertType'
   *  Constant: '<S266>/Constant'
   *  Constant: '<S266>/Constant1'
   *  Constant: '<S266>/Constant12'
   *  Constant: '<S266>/Constant14'
   *  Constant: '<S266>/Constant19'
   *  Constant: '<S266>/Constant2'
   *  Constant: '<S266>/Constant6'
   *  Constant: '<S266>/Constant7'
   *  Constant: '<S267>/Constant1'
   *  Constant: '<S267>/Constant10'
   *  Constant: '<S267>/Constant11'
   *  Constant: '<S267>/Constant12'
   *  Constant: '<S267>/Constant13'
   *  Constant: '<S267>/Constant14'
   *  Constant: '<S267>/Constant15'
   *  Constant: '<S267>/Constant16'
   *  Constant: '<S267>/Constant17'
   *  Constant: '<S267>/Constant18'
   *  Constant: '<S267>/Constant19'
   *  Constant: '<S267>/Constant2'
   *  Constant: '<S267>/Constant3'
   *  Constant: '<S267>/Constant4'
   *  Constant: '<S267>/Constant5'
   *  Constant: '<S267>/Constant7'
   *  Constant: '<S267>/Constant8'
   *  Constant: '<S267>/Constant9'
   *  Constant: '<S268>/Constant1'
   *  Constant: '<S268>/Constant10'
   *  Constant: '<S268>/Constant11'
   *  Constant: '<S268>/Constant13'
   *  Constant: '<S268>/Constant14'
   *  Constant: '<S268>/Constant15'
   *  Constant: '<S268>/Constant16'
   *  Constant: '<S268>/Constant17'
   *  Constant: '<S268>/Constant18'
   *  Constant: '<S268>/Constant19'
   *  Constant: '<S268>/Constant2'
   *  Constant: '<S268>/Constant20'
   *  Constant: '<S268>/Constant21'
   *  Constant: '<S268>/Constant22'
   *  Constant: '<S268>/Constant23'
   *  Constant: '<S268>/Constant24'
   *  Constant: '<S268>/Constant3'
   *  Constant: '<S268>/Constant4'
   *  Constant: '<S268>/Constant5'
   *  Constant: '<S268>/Constant6'
   *  Constant: '<S268>/Constant7'
   *  Constant: '<S268>/Constant8'
   *  Constant: '<S268>/Constant9'
   */
  DrivetrainHevP4_SimpleMagicTire(localB->Saturation_f, rtb_Integrator1_d,
    rtb_ImpAsg_InsertedFor_Omega_at_inport_0, localB->VectorConcatenate2[0],
    DrivetrainHevP4_P.Constant_Value_n, DrivetrainHevP4_P.Constant1_Value_if,
    DrivetrainHevP4_P.Constant7_Value_i, DrivetrainHevP4_P.Constant6_Value_k,
    DrivetrainHevP4_P.lam_x, DrivetrainHevP4_P.Constant2_Value_f4,
    DrivetrainHevP4_P.Constant19_Value_e, DrivetrainHevP4_P.Constant12_Value_m,
    DrivetrainHevP4_P.Constant14_Value_n, DrivetrainHevP4_P.press,
    DrivetrainHevP4_P.Constant5_Value_k, DrivetrainHevP4_P.Constant2_Value_h,
    DrivetrainHevP4_P.aMy, DrivetrainHevP4_P.bMy, DrivetrainHevP4_P.cMy,
    DrivetrainHevP4_P.Constant16_Value_g, DrivetrainHevP4_P.Constant7_Value_c,
    DrivetrainHevP4_P.Constant9_Value_d, DrivetrainHevP4_P.betaMy,
    DrivetrainHevP4_P.alphaMy, DrivetrainHevP4_P.Constant11_Value_b,
    DrivetrainHevP4_P.Constant10_Value_g, DrivetrainHevP4_P.UNLOADED_RADIUS,
    DrivetrainHevP4_P.Constant1_Value_o, DrivetrainHevP4_P.Constant3_Value_i,
    DrivetrainHevP4_P.Constant19_Value_b, DrivetrainHevP4_P.Constant12_Value_g,
    DrivetrainHevP4_P.Constant14_Value_j, 0.0, DrivetrainHevP4_P.FxType_Value_m,
    DrivetrainHevP4_P.rollType_Value_h, DrivetrainHevP4_P.vertType_Value_e,
    DrivetrainHevP4_P.FZMAX, DrivetrainHevP4_P.FZMIN, DrivetrainHevP4_P.VXLOW,
    DrivetrainHevP4_P.kappamax, &localB->sf_SimpleMagicTire_c);

  /* SignalConversion generated from: '<S207>/Vector Concatenate5' */
  rtb_Gain1_lh = *rtu_WindVel;

  /* Sum: '<S206>/Add1' incorporates:
   *  SignalConversion generated from: '<S169>/Vector Concatenate5'
   *  UnaryMinus: '<S169>/Unary Minus'
   */
  rtb_Sum_gs = localB->Integrator - (-rtb_Gain1_lh);

  /* Sqrt: '<S206>/Sqrt' incorporates:
   *  Product: '<S206>/Product'
   */
  rtb_SumofElements_d = sqrt(rtb_Sum_gs * rtb_Sum_gs);

  /* Product: '<S206>/Product2' */
  rtb_Gain1_lh = rtb_SumofElements_d * rtb_SumofElements_d;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Constant: '<S206>/Constant' */
    localB->VectorConcatenate[0] = DrivetrainHevP4_P.Cd;
  }

  /* Trigonometry: '<S206>/Trigonometric Function' */
  rtb_SumofElements_d = rt_atan2d_snf(0.0, rtb_Sum_gs);

  /* Lookup_n-D: '<S206>/Cs' incorporates:
   *  Sum: '<S29>/Sum of Elements'
   */
  localB->VectorConcatenate[1] = look1_binlcpw(rtb_SumofElements_d,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cs, 1U);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Constant: '<S206>/Constant1' */
    localB->VectorConcatenate[2] =
      DrivetrainHevP4_P.VehicleBody1DOFLongitudinal_Cl;
  }

  /* Lookup_n-D: '<S206>/Crm' incorporates:
   *  Sum: '<S29>/Sum of Elements'
   */
  localB->VectorConcatenate[3] = look1_binlxpw(rtb_SumofElements_d,
    DrivetrainHevP4_P.Crm_bp01Data, DrivetrainHevP4_P.Crm_tableData, 1U);

  /* Trigonometry: '<S206>/Tanh' incorporates:
   *  Gain: '<S206>/4'
   */
  rtb_Sum_gs = tanh(DrivetrainHevP4_P.u_Gain_c[0] * rtb_Sum_gs);

  /* Product: '<S206>/Product5' incorporates:
   *  Constant: '<S206>/Constant2'
   */
  localB->VectorConcatenate[4] = rtb_Sum_gs *
    DrivetrainHevP4_P.VehicleBody1DOFLongitudinal_Cpm;

  /* Lookup_n-D: '<S206>/Cym' incorporates:
   *  Sum: '<S29>/Sum of Elements'
   */
  localB->VectorConcatenate[5] = look1_binlxpw(rtb_SumofElements_d,
    DrivetrainHevP4_P.DragForce_beta_w, DrivetrainHevP4_P.DragForce_Cym, 1U);

  /* Gain: '<S206>/.5.*A.*Pabs.//R.//T' incorporates:
   *  Constant: '<S165>/AirTempConstant'
   *  Product: '<S206>/Product1'
   */
  rtb_Subtract1 = 0.5 * DrivetrainHevP4_P.Af * DrivetrainHevP4_P.Pabs /
    DrivetrainHevP4_P.DragForce_R;
  for (i = 0; i < 6; i++) {
    rtb_uAPabsRT[i] = rtb_Gain1_lh * localB->VectorConcatenate[i] /
      DrivetrainHevP4_P.T * rtb_Subtract1;
  }

  /* End of Gain: '<S206>/.5.*A.*Pabs.//R.//T' */

  /* Product: '<S206>/Product4' incorporates:
   *  Constant: '<S206>/Constant3'
   *  Gain: '<S169>/1//(a+b) '
   */
  rtb_Subtract1 = DrivetrainHevP4_P.a_CG + DrivetrainHevP4_P.b_CG;

  /* Sum: '<S169>/Add6' incorporates:
   *  Constant: '<S165>/MExtConstant'
   *  Constant: '<S206>/Constant3'
   *  Product: '<S206>/Product4'
   */
  rtb_SumofElements_d = rtb_Subtract1 * rtb_uAPabsRT[4] +
    DrivetrainHevP4_P.MExtConstant_Value[1];

  /* UnitConversion: '<S166>/Unit Conversion' */
  /* Unit Conversion - from: deg to: rad
     Expression: output = (0.0174533*input) + (0) */
  rtb_Merge1 = 0.017453292519943295 * *rtu_Grade;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Gain: '<S169>/m' incorporates:
     *  Constant: '<S169>/g'
     */
    localB->Fz = DrivetrainHevP4_P.Mass * DrivetrainHevP4_P.g;

    /* InitialCondition: '<S128>/IC' */
    if (localDW->IC_FirstOutputTime) {
      localDW->IC_FirstOutputTime = false;

      /* InitialCondition: '<S128>/IC' */
      localB->IC = DrivetrainHevP4_P.IC_Value;
    } else {
      /* InitialCondition: '<S128>/IC' incorporates:
       *  Constant: '<S128>/Constant1'
       */
      localB->IC = DrivetrainHevP4_P.Constant1_Value_bf;
    }

    /* End of InitialCondition: '<S128>/IC' */
  }

  /* Product: '<S169>/Product2' incorporates:
   *  Trigonometry: '<S169>/Trigonometric Function2'
   */
  rtb_Merge = cos(rtb_Merge1) * localB->Fz;

  /* Product: '<S206>/Product3' */
  rtb_Sum_gs *= rtb_uAPabsRT[0];

  /* Sum: '<S169>/Add1' incorporates:
   *  Constant: '<S165>/FExtConstant'
   *  Gain: '<S206>/4'
   *  Product: '<S206>/Product3'
   *  Trigonometry: '<S206>/Tanh'
   */
  rtb_TurbineSpd = tanh(DrivetrainHevP4_P.u_Gain_c[2] * 0.0) * rtb_uAPabsRT[2] +
    (rtb_Merge + DrivetrainHevP4_P.FExtConstant_Value[2]);

  /* Product: '<S169>/Product1' incorporates:
   *  Trigonometry: '<S169>/Trigonometric Function2'
   */
  rtb_Gain1_lh = sin(rtb_Merge1) * localB->Fz;

  /* Sum: '<S169>/Add' incorporates:
   *  Constant: '<S165>/FExtConstant'
   *  Sum: '<S5>/Add1'
   */
  rtb_Fx_o = (((DrivetrainHevP4_P.FExtConstant_Value[0] - rtb_Gain1_lh) + rtb_Fx)
              + (localB->sf_SimpleMagicTire_c.Fx +
                 localB->sf_SimpleMagicTire_c.Fx)) - rtb_Sum_gs;

  /* Gain: '<S169>/h' incorporates:
   *  Constant: '<S165>/FExtConstant'
   *  Sum: '<S169>/Add3'
   */
  rtb_Fx = (((rtb_Sum_gs - DrivetrainHevP4_P.FExtConstant_Value[0]) +
             rtb_Gain1_lh) + rtb_Fx_o) * DrivetrainHevP4_P.h;

  /* Gain: '<S169>/1//(a+b) ' incorporates:
   *  Gain: '<S169>/1//(a+b)'
   */
  rtb_Gain1_lh = 1.0 / rtb_Subtract1;

  /* Product: '<S163>/Divide' incorporates:
   *  Constant: '<S163>/Constant'
   *  Gain: '<S169>/1//(a+b) '
   *  Gain: '<S169>/a'
   *  Gain: '<S178>/1//NR'
   *  Sum: '<S163>/Sum'
   *  Sum: '<S169>/Add4'
   */
  localB->Divide = (((DrivetrainHevP4_P.a_CG * rtb_TurbineSpd +
                      rtb_SumofElements_d) + rtb_Fx) * rtb_Gain1_lh * (1.0 /
    DrivetrainHevP4_P.NR) - rtb_Integrator1_d) * DrivetrainHevP4_P.wc;

  /* Product: '<S164>/Divide' incorporates:
   *  Constant: '<S164>/Constant'
   *  Gain: '<S169>/1//(a+b)'
   *  Gain: '<S169>/b'
   *  Gain: '<S178>/1//NF'
   *  Sum: '<S164>/Sum'
   *  Sum: '<S169>/Add2'
   */
  localB->Divide_l = (((DrivetrainHevP4_P.b_CG * rtb_TurbineSpd -
                        rtb_SumofElements_d) - rtb_Fx) * rtb_Gain1_lh * (1.0 /
    DrivetrainHevP4_P.NF) - rtb_Integrator1) * DrivetrainHevP4_P.wc;

  /* SignalConversion generated from: '<S3>/Integrator' */
  localB->TmpSignalConversionAtIntegratorInport1[0] = 0.0;
  localB->TmpSignalConversionAtIntegratorInport1[1] = 0.0;

  /* Gain: '<S169>/1//m' */
  localB->xddot = 1.0 / DrivetrainHevP4_P.Mass * rtb_Fx_o;

  /* Switch: '<S128>/Switch' */
  if (localB->IC > DrivetrainHevP4_P.Switch_Threshold_k) {
    /* Switch: '<S128>/Switch' */
    localB->Switch = localX->PumpIntegrator_CSTATE;
  } else {
    /* Switch: '<S128>/Switch' incorporates:
     *  Constant: '<S128>/Constant'
     */
    localB->Switch = DrivetrainHevP4_P.omegai_o;
  }

  /* End of Switch: '<S128>/Switch' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* InitialCondition: '<S129>/IC' */
    if (localDW->IC_FirstOutputTime_e) {
      localDW->IC_FirstOutputTime_e = false;

      /* InitialCondition: '<S129>/IC' */
      localB->IC_i = DrivetrainHevP4_P.IC_Value_m;
    } else {
      /* InitialCondition: '<S129>/IC' incorporates:
       *  Constant: '<S129>/Constant1'
       */
      localB->IC_i = DrivetrainHevP4_P.Constant1_Value_j;
    }

    /* End of InitialCondition: '<S129>/IC' */
  }

  /* Switch: '<S129>/Switch' */
  if (localB->IC_i > DrivetrainHevP4_P.Switch_Threshold_g) {
    /* Switch: '<S129>/Switch' */
    localB->Switch_k = localX->LockedShaftIntegrator_CSTATE;
  } else {
    /* Switch: '<S129>/Switch' incorporates:
     *  Constant: '<S129>/Constant'
     */
    localB->Switch_k = DrivetrainHevP4_P.omegai_o;
  }

  /* End of Switch: '<S129>/Switch' */

  /* Sum: '<S144>/Sum' */
  localB->Sum = localX->PumpIntegrator_CSTATE - localX->TurbineIntegrator_CSTATE;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* HitCross: '<S144>/Velocities Match' */
    zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,&localZCE->VelocitiesMatch_Input_ZCE,
                       (localB->Sum - DrivetrainHevP4_P.VelocitiesMatch_Offset));
    if (localDW->VelocitiesMatch_MODE == 0) {
      if (zcEvent != NO_ZCEVENT) {
        /* HitCross: '<S144>/Velocities Match' */
        localB->VelocitiesMatch = !localB->VelocitiesMatch;
        localDW->VelocitiesMatch_MODE = 1;
      } else if (localB->VelocitiesMatch) {
        /* HitCross: '<S144>/Velocities Match' */
        localB->VelocitiesMatch = ((!(localB->Sum !=
          DrivetrainHevP4_P.VelocitiesMatch_Offset)) && localB->VelocitiesMatch);
      } else {
        /* HitCross: '<S144>/Velocities Match' */
        localB->VelocitiesMatch = ((localB->Sum ==
          DrivetrainHevP4_P.VelocitiesMatch_Offset) || localB->VelocitiesMatch);
      }
    } else {
      /* HitCross: '<S144>/Velocities Match' */
      localB->VelocitiesMatch = ((!(localB->Sum !=
        DrivetrainHevP4_P.VelocitiesMatch_Offset)) && localB->VelocitiesMatch);
      localDW->VelocitiesMatch_MODE = 0;
    }

    /* End of HitCross: '<S144>/Velocities Match' */

    /* Memory: '<S87>/Memory' */
    localB->Memory_k = localDW->Memory_PreviousInput_e;

    /* Constant: '<S86>/domega_o' */
    localB->domega_o_h = DrivetrainHevP4_P.domega_o;
  }

  /* Integrator: '<S87>/Integrator' */
  rtb_Logic = rtsiGetIsOkayToUpdateMode(DrivetrainHevP4_M->solverInfo);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_j,
                       (localB->Memory_k));

    /* evaluate zero-crossings */
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_d != 0)) {
      localX->Integrator_CSTATE_de = localB->domega_o_h;
    }
  }

  rtb_Fx = localX->Integrator_CSTATE_de;

  /* Sum: '<S86>/Subtract1' incorporates:
   *  Gain: '<S86>/Gain1'
   *  Gain: '<S86>/Gain2'
   *  Integrator: '<S86>/Integrator'
   *  Integrator: '<S87>/Integrator'
   */
  rtb_Subtract1 = DrivetrainHevP4_P.b * localX->Integrator_CSTATE_de +
    DrivetrainHevP4_P.k * localX->Integrator_CSTATE_g;

  /* Gain: '<S147>/Output Damping' */
  rtb_Fx_o = DrivetrainHevP4_P.bt * localX->PumpIntegrator_CSTATE;

  /* Outputs for IfAction SubSystem: '<S126>/Locked' incorporates:
   *  ActionPort: '<S132>/Action'
   */
  /* If: '<S126>/If' incorporates:
   *  Sum: '<S132>/Sum'
   *  Sum: '<S146>/Sum'
   *  Sum: '<S147>/Sum'
   *  UnaryMinus: '<S86>/Unary Minus'
   */
  rtb_Sum_gs = *rtu_EngTrq + -rtb_Subtract1;

  /* End of Outputs for SubSystem: '<S126>/Locked' */

  /* Abs: '<S148>/Abs' incorporates:
   *  Gain: '<S147>/Inertia Ratio'
   *  Gain: '<S147>/Input Damping'
   *  Sum: '<S147>/Sum'
   *  Sum: '<S147>/Sum1'
   */
  rtb_Fx_o = fabs(DrivetrainHevP4_P.Jt / (DrivetrainHevP4_P.Ji +
    DrivetrainHevP4_P.Jt) * ((rtb_Sum_gs - DrivetrainHevP4_P.bi *
    localX->PumpIntegrator_CSTATE) - rtb_Fx_o) + rtb_Fx_o);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Memory: '<S150>/Memory' */
    localB->Memory_b = localDW->Memory_PreviousInput_d;

    /* Constant: '<S149>/Constant2' */
    localB->Constant2 = DrivetrainHevP4_P.Constant2_Value_a;
  }

  /* Integrator: '<S150>/Integrator' */
  rtb_Logic = rtsiGetIsOkayToUpdateMode(DrivetrainHevP4_M->solverInfo);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_f,
                       (localB->Memory_b));

    /* evaluate zero-crossings */
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_h != 0)) {
      localX->Integrator_CSTATE_b = localB->Constant2;
    }
  }

  rtb_Gain1_lh = localX->Integrator_CSTATE_b;

  /* Gain: '<S149>/ClutchGain' incorporates:
   *  Integrator: '<S150>/Integrator'
   */
  rtb_TurbineSpd = DrivetrainHevP4_P.K_c * localX->Integrator_CSTATE_b;

  /* Saturate: '<S151>/Saturation' */
  if (rtb_TurbineSpd > DrivetrainHevP4_P.Saturation_UpperSat_h) {
    rtb_TurbineSpd = DrivetrainHevP4_P.Saturation_UpperSat_h;
  } else if (rtb_TurbineSpd < DrivetrainHevP4_P.Saturation_LowerSat_f) {
    rtb_TurbineSpd = DrivetrainHevP4_P.Saturation_LowerSat_f;
  }

  /* End of Saturate: '<S151>/Saturation' */

  /* Gain: '<S151>/Torque Conversion' */
  rtb_SumofElements_d = DrivetrainHevP4_P.Reff * DrivetrainHevP4_P.muk *
    rtb_TurbineSpd;

  /* Gain: '<S151>/Ratio of static to kinetic' */
  rtb_TurbineSpd = DrivetrainHevP4_P.mus / DrivetrainHevP4_P.muk *
    rtb_SumofElements_d;

  /* Logic: '<S144>/Logic' incorporates:
   *  RelationalOperator: '<S148>/Relational Operator'
   */
  rtb_Logic = (localB->VelocitiesMatch && (rtb_Fx_o <= rtb_TurbineSpd));

  /* Gain: '<S146>/Turbine Damping' */
  rtb_Fx_o = DrivetrainHevP4_P.bt * localX->LockedShaftIntegrator_CSTATE;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Memory: '<S145>/Memory' */
    localB->Memory_kc = localDW->Memory_PreviousInput_jb;

    /* InitialCondition: '<S134>/IC' */
    if (localDW->IC_FirstOutputTime_d) {
      localDW->IC_FirstOutputTime_d = false;

      /* InitialCondition: '<S134>/IC' */
      localB->IC_p = DrivetrainHevP4_P.IC_Value_o;
    } else {
      /* InitialCondition: '<S134>/IC' incorporates:
       *  Constant: '<S134>/Constant1'
       */
      localB->IC_p = DrivetrainHevP4_P.Constant1_Value_io;
    }

    /* End of InitialCondition: '<S134>/IC' */
  }

  /* CombinatorialLogic: '<S145>/Combinatorial  Logic' incorporates:
   *  Abs: '<S143>/Abs'
   *  Gain: '<S146>/Impeller Damping'
   *  Gain: '<S146>/Inertia Ratio'
   *  RelationalOperator: '<S143>/Relational Operator'
   *  Sum: '<S146>/Sum'
   *  Sum: '<S146>/Sum1'
   */
  *rty_Cltch2State = DrivetrainHevP4_P.CombinatorialLogic_table[(((fabs
    (DrivetrainHevP4_P.Jt / (DrivetrainHevP4_P.Ji + DrivetrainHevP4_P.Jt) *
     ((rtb_Sum_gs - DrivetrainHevP4_P.bi * localX->LockedShaftIntegrator_CSTATE)
      - rtb_Fx_o) + rtb_Fx_o) >= rtb_TurbineSpd) + ((uint32_T)rtb_Logic << 1)) <<
    1) + localB->Memory_kc];

  /* Switch: '<S134>/Switch' */
  if (localB->IC_p > DrivetrainHevP4_P.Switch_Threshold_m) {
    /* Switch: '<S134>/Switch' */
    localB->Switch_h = localX->LockedShaftIntegrator_CSTATE;
  } else {
    /* Switch: '<S134>/Switch' incorporates:
     *  Constant: '<S134>/Constant'
     */
    localB->Switch_h = DrivetrainHevP4_P.omegat_o;
  }

  /* End of Switch: '<S134>/Switch' */

  /* If: '<S126>/If' incorporates:
   *  Constant: '<S154>/Constant1'
   *  Constant: '<S154>/Constant2'
   */
  rtPrevAction = localDW->If_ActiveSubsystem;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    rtAction = (int8_T)!*rty_Cltch2State;
    localDW->If_ActiveSubsystem = rtAction;
  } else {
    rtAction = localDW->If_ActiveSubsystem;
  }

  if (rtPrevAction != rtAction) {
    /* Disable for Enabled SubSystem: '<S153>/LPF' */
    localDW->LPF_MODE = ((rtPrevAction != 1) && localDW->LPF_MODE);

    /* End of Disable for SubSystem: '<S153>/LPF' */
  }

  switch (rtAction) {
   case 0:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S126>/Locked' incorporates:
       *  ActionPort: '<S132>/Action'
       */
      /* InitializeConditions for If: '<S126>/If' incorporates:
       *  Integrator: '<S132>/Locked Shaft Integrator'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->LockedShaftIntegrator_CSTATE = 0.0;
      }

      localDW->LockedShaftIntegrator_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S126>/Locked' */
    }

    /* Outputs for IfAction SubSystem: '<S126>/Locked' incorporates:
     *  ActionPort: '<S132>/Action'
     */
    /* Integrator: '<S132>/Locked Shaft Integrator' */
    /* Limited  Integrator  */
    if (localDW->LockedShaftIntegrator_IWORK != 0) {
      localX->LockedShaftIntegrator_CSTATE = localB->Switch;
      rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
        (DrivetrainHevP4_M->solverInfo, true);
    }

    if (localX->LockedShaftIntegrator_CSTATE >=
        DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat) {
      if (localX->LockedShaftIntegrator_CSTATE !=
          DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
        rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      localX->LockedShaftIntegrator_CSTATE =
        DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat;
    } else if (localX->LockedShaftIntegrator_CSTATE <=
               DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat) {
      if (localX->LockedShaftIntegrator_CSTATE !=
          DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
        rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      localX->LockedShaftIntegrator_CSTATE =
        DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat;
    }

    /* Gain: '<S132>/Inertia' incorporates:
     *  Gain: '<S132>/Impeller Damping'
     *  Gain: '<S132>/Turbine Damping'
     *  Integrator: '<S132>/Locked Shaft Integrator'
     *  Sum: '<S132>/Add1'
     *  Sum: '<S132>/Sum'
     */
    localB->Inertia = 1.0 / (DrivetrainHevP4_P.Ji + DrivetrainHevP4_P.Jt) *
      (rtb_Sum_gs - (DrivetrainHevP4_P.bi * localX->LockedShaftIntegrator_CSTATE
                     + DrivetrainHevP4_P.bt *
                     localX->LockedShaftIntegrator_CSTATE));

    /* SignalConversion: '<S132>/Signal Conversion' incorporates:
     *  Integrator: '<S132>/Locked Shaft Integrator'
     */
    rtb_TurbineSpd = localX->LockedShaftIntegrator_CSTATE;

    /* SignalConversion: '<S132>/Signal Conversion1' incorporates:
     *  Integrator: '<S132>/Locked Shaft Integrator'
     */
    *rty_EngSpd = localX->LockedShaftIntegrator_CSTATE;
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
      /* Merge: '<S126>/Merge2' incorporates:
       *  Constant: '<S132>/Constant'
       *  SignalConversion generated from: '<S132>/Speed Ratio'
       */
      localB->SpdRatio = DrivetrainHevP4_P.Constant_Value_a;
    }

    /* End of Outputs for SubSystem: '<S126>/Locked' */
    break;

   case 1:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S126>/Unlocked' incorporates:
       *  ActionPort: '<S133>/Action'
       */
      /* InitializeConditions for If: '<S126>/If' incorporates:
       *  Integrator: '<S133>/Pump Integrator'
       *  Integrator: '<S133>/Turbine Integrator'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->PumpIntegrator_CSTATE = 0.0;
        localX->TurbineIntegrator_CSTATE = 0.0;
      }

      localDW->PumpIntegrator_IWORK = 1;
      localDW->TurbineIntegrator_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S126>/Unlocked' */
    }

    /* Outputs for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* Integrator: '<S133>/Pump Integrator' */
    /* Limited  Integrator  */
    if (localDW->PumpIntegrator_IWORK != 0) {
      localX->PumpIntegrator_CSTATE = localB->Switch_k;
      rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
        (DrivetrainHevP4_M->solverInfo, true);
    }

    if (localX->PumpIntegrator_CSTATE >=
        DrivetrainHevP4_P.PumpIntegrator_UpperSat) {
      if (localX->PumpIntegrator_CSTATE !=
          DrivetrainHevP4_P.PumpIntegrator_UpperSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
        rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      localX->PumpIntegrator_CSTATE = DrivetrainHevP4_P.PumpIntegrator_UpperSat;
    } else if (localX->PumpIntegrator_CSTATE <=
               DrivetrainHevP4_P.PumpIntegrator_LowerSat) {
      if (localX->PumpIntegrator_CSTATE !=
          DrivetrainHevP4_P.PumpIntegrator_LowerSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
        rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      localX->PumpIntegrator_CSTATE = DrivetrainHevP4_P.PumpIntegrator_LowerSat;
    }

    rtb_Fx_o = localX->PumpIntegrator_CSTATE;

    /* End of Integrator: '<S133>/Pump Integrator' */

    /* Integrator: '<S133>/Turbine Integrator' */
    /* Limited  Integrator  */
    if (localDW->TurbineIntegrator_IWORK != 0) {
      localX->TurbineIntegrator_CSTATE = localB->Switch_h;
      rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
        (DrivetrainHevP4_M->solverInfo, true);
    }

    if (localX->TurbineIntegrator_CSTATE >=
        DrivetrainHevP4_P.TurbineIntegrator_UpperSat) {
      if (localX->TurbineIntegrator_CSTATE !=
          DrivetrainHevP4_P.TurbineIntegrator_UpperSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
        rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      localX->TurbineIntegrator_CSTATE =
        DrivetrainHevP4_P.TurbineIntegrator_UpperSat;
    } else if (localX->TurbineIntegrator_CSTATE <=
               DrivetrainHevP4_P.TurbineIntegrator_LowerSat) {
      if (localX->TurbineIntegrator_CSTATE !=
          DrivetrainHevP4_P.TurbineIntegrator_LowerSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
        rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
          (DrivetrainHevP4_M->solverInfo, true);
      }

      localX->TurbineIntegrator_CSTATE =
        DrivetrainHevP4_P.TurbineIntegrator_LowerSat;
    }

    if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
      localB->VectorConcatenate_a[0] = DrivetrainHevP4_P.Constant1_Value_h;
      memcpy(&localB->VectorConcatenate_a[1], &DrivetrainHevP4_P.phi[0], 10U *
             sizeof(real_T));
    }

    /* MinMax: '<S154>/MinMax' incorporates:
     *  Constant: '<S154>/Constant1'
     *  Constant: '<S154>/Constant2'
     */
    rtb_Sum_gs = localB->VectorConcatenate_a[0];
    for (i = 0; i < 10; i++) {
      rtb_TurbineSpd = localB->VectorConcatenate_a[i + 1];
      if ((!(rtb_Sum_gs > rtb_TurbineSpd)) && (!rtIsNaN(rtb_TurbineSpd))) {
        rtb_Sum_gs = rtb_TurbineSpd;
      }
    }

    /* Switch: '<S154>/Switch' incorporates:
     *  Abs: '<S154>/Abs'
     *  Constant: '<S154>/Constant'
     *  Constant: '<S158>/Constant'
     *  Integrator: '<S133>/Turbine Integrator'
     *  Product: '<S154>/Divide'
     *  RelationalOperator: '<S158>/Compare'
     */
    if (fabs(rtb_Fx_o) > DrivetrainHevP4_P.CompareToConstant2_const) {
      /* Switch: '<S160>/Switch' incorporates:
       *  Constant: '<S161>/Constant'
       *  Constant: '<S162>/Constant'
       *  Fcn: '<S160>/Fcn'
       *  Logic: '<S160>/Logical Operator'
       *  Product: '<S160>/Product'
       *  RelationalOperator: '<S161>/Compare'
       *  RelationalOperator: '<S162>/Compare'
       */
      if ((rtb_Fx_o >= -DrivetrainHevP4_P.div0protectpoly_thresh) && (rtb_Fx_o <=
           DrivetrainHevP4_P.div0protectpoly_thresh)) {
        /* Switch: '<S160>/Switch1' incorporates:
         *  Constant: '<S160>/Constant'
         *  UnaryMinus: '<S160>/Unary Minus'
         */
        if (rtb_Fx_o >= DrivetrainHevP4_P.Switch1_Threshold) {
          rtb_TurbineSpd = DrivetrainHevP4_P.Constant_Value_c;
        } else {
          rtb_TurbineSpd = -DrivetrainHevP4_P.Constant_Value_c;
        }

        /* End of Switch: '<S160>/Switch1' */
        rtb_TurbineSpd *= 2.0 / (3.0 - rt_powd_snf(rtb_Fx_o, 2.0));
      } else {
        rtb_TurbineSpd = rtb_Fx_o;
      }

      /* End of Switch: '<S160>/Switch' */
      rtb_TurbineSpd = localX->TurbineIntegrator_CSTATE / rtb_TurbineSpd;
    } else {
      rtb_TurbineSpd = DrivetrainHevP4_P.Constant_Value_p;
    }

    /* End of Switch: '<S154>/Switch' */

    /* Switch: '<S159>/Switch2' incorporates:
     *  MinMax: '<S154>/MinMax'
     *  RelationalOperator: '<S159>/LowerRelop1'
     */
    if (!(rtb_TurbineSpd > rtb_Sum_gs)) {
      /* Gain: '<S154>/Gain' */
      rtb_Sum_gs *= DrivetrainHevP4_P.Gain_Gain_p;

      /* Switch: '<S159>/Switch' incorporates:
       *  RelationalOperator: '<S159>/UpperRelop'
       */
      if (!(rtb_TurbineSpd < rtb_Sum_gs)) {
        rtb_Sum_gs = rtb_TurbineSpd;
      }

      /* End of Switch: '<S159>/Switch' */
    }

    /* End of Switch: '<S159>/Switch2' */

    /* PreLookup: '<S152>/speed ratio Prelookup' incorporates:
     *  Constant: '<S152>/phi'
     */
    rtb_speedratioPrelookup_o1 = plook_bincpa(rtb_Sum_gs, DrivetrainHevP4_P.phi,
      9U, &rtb_uniclutch, &localDW->speedratioPrelookup_DWORK1);

    /* Interpolation_n-D: '<S152>/Torque Ratio zeta Interpolation' incorporates:
     *  Constant: '<S152>/zeta'
     */
    rtb_TorqueRatiozetaInterpolation = intrp1d_la_pw(rtb_speedratioPrelookup_o1,
      rtb_uniclutch, DrivetrainHevP4_P.zeta, 9U);

    /* RelationalOperator: '<S155>/Compare' incorporates:
     *  Constant: '<S153>/Constant'
     *  Constant: '<S155>/Constant'
     */
    localB->Compare = (DrivetrainHevP4_P.tauTC >
                       DrivetrainHevP4_P.Constant_Value_k);
    if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
      /* SignalConversion generated from: '<S156>/Enable' */
      localB->HiddenBuf_InsertedFor_LPF_at_inport_2 = localB->Compare;

      /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
       *  EnablePort: '<S156>/Enable'
       */
      if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
        if (localB->HiddenBuf_InsertedFor_LPF_at_inport_2) {
          if (!localDW->LPF_MODE) {
            /* InitializeConditions for Integrator: '<S157>/Integrator' */
            localX->Integrator_CSTATE_e = DrivetrainHevP4_P.Integrator_IC;
            localDW->LPF_MODE = true;
          }
        } else {
          localDW->LPF_MODE = false;
        }
      }

      /* End of Outputs for SubSystem: '<S153>/LPF' */
    }

    /* Outputs for Enabled SubSystem: '<S153>/LPF' incorporates:
     *  EnablePort: '<S156>/Enable'
     */
    if (localDW->LPF_MODE) {
      /* Integrator: '<S157>/Integrator' */
      localB->Integrator_k = localX->Integrator_CSTATE_e;

      /* Gain: '<S156>/Gain' incorporates:
       *  Constant: '<S153>/Constant'
       */
      rtb_TurbineSpd = DrivetrainHevP4_P.Gain_Gain_d * DrivetrainHevP4_P.tauTC;

      /* Saturate: '<S156>/Saturation' */
      if (rtb_TurbineSpd > DrivetrainHevP4_P.Saturation_UpperSat_b) {
        rtb_TurbineSpd = DrivetrainHevP4_P.Saturation_UpperSat_b;
      } else if (rtb_TurbineSpd < DrivetrainHevP4_P.Saturation_LowerSat_o) {
        rtb_TurbineSpd = DrivetrainHevP4_P.Saturation_LowerSat_o;
      }

      /* End of Saturate: '<S156>/Saturation' */

      /* Product: '<S157>/Product' incorporates:
       *  Product: '<S156>/Product'
       *  Sum: '<S157>/Sum'
       */
      localB->Product_f = 1.0 / rtb_TurbineSpd *
        (rtb_TorqueRatiozetaInterpolation - localB->Integrator_k);
    }

    /* End of Outputs for SubSystem: '<S153>/LPF' */

    /* Switch: '<S152>/Switch1' incorporates:
     *  Constant: '<S152>/Constant1'
     *  Constant: '<S152>/psi'
     *  Product: '<S152>/Product3'
     */
    for (i = 0; i < 10; i++) {
      if (DrivetrainHevP4_P.TorqueConverter_KType >
          DrivetrainHevP4_P.Switch1_Threshold_f) {
        rtb_Switch1[i] = DrivetrainHevP4_P.psi[i];
      } else {
        rtb_Switch1[i] = 1.0 / DrivetrainHevP4_P.psi[i] /
          DrivetrainHevP4_P.psi[i];
      }
    }

    /* End of Switch: '<S152>/Switch1' */

    /* Sum: '<S154>/Add' incorporates:
     *  Integrator: '<S133>/Turbine Integrator'
     *  Sum: '<S133>/W_Slip'
     */
    rtb_TurbineSpd = rtb_Fx_o - localX->TurbineIntegrator_CSTATE;

    /* Product: '<S152>/Divide1' incorporates:
     *  Interpolation_n-D: '<S152>/Capacity, K-factor Interpolation'
     *  Sum: '<S154>/Add'
     *  Switch: '<S152>/Switch1'
     *  Trigonometry: '<S152>/Trigonometric Function'
     */
    rtb_uniclutch = tanh(rtb_TurbineSpd) * intrp1d_la_pw
      (rtb_speedratioPrelookup_o1, rtb_uniclutch, rtb_Switch1, 9U) * rtb_Fx_o *
      rtb_Fx_o;

    /* Saturate: '<S152>/uniclutch' */
    if (rtb_uniclutch > DrivetrainHevP4_P.uniclutch_UpperSat) {
      rtb_uniclutch = DrivetrainHevP4_P.uniclutch_UpperSat;
    } else if (rtb_uniclutch < DrivetrainHevP4_P.uniclutch_LowerSat) {
      rtb_uniclutch = DrivetrainHevP4_P.uniclutch_LowerSat;
    }

    /* End of Saturate: '<S152>/uniclutch' */

    /* Product: '<S133>/Max Dynamic Friction Torque' incorporates:
     *  Gain: '<S133>/4'
     *  Trigonometry: '<S133>/Trigonometric Function'
     */
    rtb_SumofElements_d *= tanh(rtb_TurbineSpd * DrivetrainHevP4_P.u_Gain);

    /* Sum: '<S133>/Input Sum' incorporates:
     *  Gain: '<S133>/Impeller Damping'
     */
    rtb_TurbineSpd = ((*rtu_EngTrq - rtb_SumofElements_d) - rtb_uniclutch) -
      DrivetrainHevP4_P.bi * rtb_Fx_o;

    /* Gain: '<S133>/Impeller Inertia' */
    localB->ImpellerInertia = 1.0 / DrivetrainHevP4_P.Ji * rtb_TurbineSpd;

    /* SignalConversion: '<S133>/Signal Conversion' incorporates:
     *  Integrator: '<S133>/Turbine Integrator'
     */
    rtb_TurbineSpd = localX->TurbineIntegrator_CSTATE;

    /* SignalConversion: '<S133>/Signal Conversion1' */
    *rty_EngSpd = rtb_Fx_o;

    /* Merge: '<S126>/Merge2' incorporates:
     *  SignalConversion: '<S133>/Signal Conversion2'
     */
    localB->SpdRatio = rtb_Sum_gs;

    /* Switch: '<S153>/Switch' incorporates:
     *  Constant: '<S153>/Constant'
     */
    if (DrivetrainHevP4_P.tauTC > DrivetrainHevP4_P.Switch_Threshold_l) {
      rtb_TorqueRatiozetaInterpolation = localB->Integrator_k;
    }

    /* End of Switch: '<S153>/Switch' */

    /* Gain: '<S133>/Turbine Inertia' incorporates:
     *  Gain: '<S133>/Turbine Damping'
     *  Integrator: '<S133>/Turbine Integrator'
     *  Product: '<S152>/Divide2'
     *  Sum: '<S133>/Add1'
     *  Sum: '<S133>/Output Sum'
     *  UnaryMinus: '<S86>/Unary Minus'
     */
    localB->TurbineInertia = (((rtb_TorqueRatiozetaInterpolation * rtb_uniclutch
      + rtb_SumofElements_d) - DrivetrainHevP4_P.bt *
      localX->TurbineIntegrator_CSTATE) + -rtb_Subtract1) * (1.0 /
      DrivetrainHevP4_P.Jt);

    /* End of Outputs for SubSystem: '<S126>/Unlocked' */
    break;
  }

  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Gain: '<S149>/Hz2rad' incorporates:
     *  Constant: '<S149>/Constant1'
     *  Product: '<S149>/s2hz'
     */
    localB->Hz2rad = 1.0 / DrivetrainHevP4_P.tauC *
      DrivetrainHevP4_P.Hz2rad_Gain;
  }

  /* Relay: '<S149>/Relay1' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    localDW->Relay1_Mode = ((*rty_EngSpd >= DrivetrainHevP4_P.omegal) ||
      ((!(*rty_EngSpd <= DrivetrainHevP4_P.omegau)) && localDW->Relay1_Mode));
  }

  if (localDW->Relay1_Mode) {
    /* Relay: '<S149>/Relay1' */
    localB->Relay1 = DrivetrainHevP4_P.Relay1_YOn;
  } else {
    /* Relay: '<S149>/Relay1' */
    localB->Relay1 = DrivetrainHevP4_P.Relay1_YOff;
  }

  /* End of Relay: '<S149>/Relay1' */

  /* Switch: '<S150>/Switch' */
  if (!(localB->Memory_b != 0.0)) {
    rtb_Gain1_lh = localB->Constant2;
  }

  /* End of Switch: '<S150>/Switch' */

  /* Product: '<S150>/Product' incorporates:
   *  Constant: '<S149>/Constant'
   *  DataTypeConversion: '<S149>/Data Type Conversion'
   *  Logic: '<S149>/Logic'
   *  RelationalOperator: '<S149>/Relational Operator'
   *  Sum: '<S150>/Sum'
   */
  localB->Product = ((real_T)(localB->Relay1 && (localB->SpdRatio >=
    DrivetrainHevP4_P.philu)) - rtb_Gain1_lh) * localB->Hz2rad;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Gain: '<S94>/2*pi' incorporates:
     *  Constant: '<S94>/Constant'
     *  Product: '<S94>/Product'
     */
    localB->upi = 1.0 / DrivetrainHevP4_P.tau_s * DrivetrainHevP4_P.upi_Gain;

    /* Constant: '<S94>/Constant1' */
    localB->Constant1 = DrivetrainHevP4_P.IdealFixedGearTransmission_G_o;

    /* Memory: '<S96>/Memory' */
    localB->Memory_o = localDW->Memory_PreviousInput_j;
  }

  /* Integrator: '<S96>/Integrator' */
  rtb_Logic = rtsiGetIsOkayToUpdateMode(DrivetrainHevP4_M->solverInfo);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_m,
                       (localB->Memory_o));

    /* evaluate zero-crossings */
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_n != 0)) {
      localX->Integrator_CSTATE_h1 = localB->Constant1;
    }
  }

  *rty_TransGear = localX->Integrator_CSTATE_h1;

  /* End of Integrator: '<S96>/Integrator' */

  /* Switch: '<S96>/Switch' */
  if (localB->Memory_o != 0.0) {
    rtb_Gain1_lh = *rty_TransGear;
  } else {
    rtb_Gain1_lh = localB->Constant1;
  }

  /* End of Switch: '<S96>/Switch' */

  /* Sum: '<S96>/Sum' */
  rtb_Gain1_lh = *rtu_GearCmd - rtb_Gain1_lh;

  /* Product: '<S96>/Product' */
  localB->Product_a = localB->upi * rtb_Gain1_lh;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* InitialCondition: '<S97>/IC' */
    if (localDW->IC_FirstOutputTime_k) {
      localDW->IC_FirstOutputTime_k = false;

      /* InitialCondition: '<S97>/IC' */
      localB->IC_f = DrivetrainHevP4_P.IC_Value_k;
    } else {
      /* InitialCondition: '<S97>/IC' incorporates:
       *  Constant: '<S97>/Constant1'
       */
      localB->IC_f = DrivetrainHevP4_P.Constant1_Value_f;
    }

    /* End of InitialCondition: '<S97>/IC' */

    /* Memory: '<S78>/Memory' */
    localB->Memory_ku = localDW->Memory_PreviousInput_h;

    /* Constant: '<S77>/domega_o' */
    localB->domega_o_j = DrivetrainHevP4_P.domega_o;
  }

  /* Switch: '<S97>/Switch' */
  if (localB->IC_f > DrivetrainHevP4_P.Switch_Threshold_il) {
    /* Switch: '<S97>/Switch' */
    localB->Switch_a = localX->we;
  } else {
    /* Switch: '<S97>/Switch' incorporates:
     *  Constant: '<S97>/Constant'
     */
    localB->Switch_a = DrivetrainHevP4_P.omega_o;
  }

  /* End of Switch: '<S97>/Switch' */

  /* Integrator: '<S78>/Integrator' */
  rtb_Logic = rtsiGetIsOkayToUpdateMode(DrivetrainHevP4_M->solverInfo);
  if (rtb_Logic) {
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Integrator_Reset_ZCE_fz,
                       (localB->Memory_ku));

    /* evaluate zero-crossings */
    if ((zcEvent != NO_ZCEVENT) || (localDW->Integrator_IWORK_l != 0)) {
      localX->Integrator_CSTATE_j = localB->domega_o_j;
    }
  }

  rtb_Fx_o = localX->Integrator_CSTATE_j;

  /* Sum: '<S77>/Subtract1' incorporates:
   *  Gain: '<S77>/Gain1'
   *  Gain: '<S77>/Gain2'
   *  Integrator: '<S77>/Integrator'
   *  Integrator: '<S78>/Integrator'
   */
  rtb_Gain1_lh = DrivetrainHevP4_P.b * localX->Integrator_CSTATE_j +
    DrivetrainHevP4_P.k * localX->Integrator_CSTATE_g4;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* InitialCondition: '<S101>/IC' */
    if (localDW->IC_FirstOutputTime_f) {
      localDW->IC_FirstOutputTime_f = false;

      /* InitialCondition: '<S101>/IC' */
      localB->IC_b = DrivetrainHevP4_P.IC_Value_b;
    } else {
      /* InitialCondition: '<S101>/IC' incorporates:
       *  Constant: '<S101>/Constant1'
       */
      localB->IC_b = DrivetrainHevP4_P.Constant1_Value_g;
    }

    /* End of InitialCondition: '<S101>/IC' */

    /* InitialCondition: '<S99>/IC' */
    if (localDW->IC_FirstOutputTime_j) {
      localDW->IC_FirstOutputTime_j = false;

      /* InitialCondition: '<S99>/IC' */
      localB->IC_a = DrivetrainHevP4_P.IC_Value_bb;
    } else {
      /* InitialCondition: '<S99>/IC' incorporates:
       *  Constant: '<S99>/Constant1'
       */
      localB->IC_a = DrivetrainHevP4_P.Constant1_Value_ou;
    }

    /* End of InitialCondition: '<S99>/IC' */
  }

  /* Switch: '<S101>/Switch' */
  if (localB->IC_b > DrivetrainHevP4_P.Switch_Threshold_gl) {
    /* Switch: '<S101>/Switch' */
    localB->Switch_ht = localX->w;
  } else {
    /* Switch: '<S101>/Switch' incorporates:
     *  Constant: '<S101>/Constant'
     */
    localB->Switch_ht = DrivetrainHevP4_P.omega_o;
  }

  /* End of Switch: '<S101>/Switch' */

  /* Switch: '<S99>/Switch' */
  if (localB->IC_a > DrivetrainHevP4_P.Switch_Threshold_l2) {
    /* Switch: '<S99>/Switch' */
    localB->Switch_p = localX->w;
  } else {
    /* Switch: '<S99>/Switch' incorporates:
     *  Constant: '<S99>/Constant'
     */
    localB->Switch_p = DrivetrainHevP4_P.IdealFixedGearTransmission_omegaN_o;
  }

  /* End of Switch: '<S99>/Switch' */

  /* If: '<S94>/If' */
  rtPrevAction = localDW->If_ActiveSubsystem_b;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    rtAction = (int8_T)!(*rty_TransGear != 0.0);
    localDW->If_ActiveSubsystem_b = rtAction;
  } else {
    rtAction = localDW->If_ActiveSubsystem_b;
  }

  switch (rtAction) {
   case 0:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S94>/Locked' incorporates:
       *  ActionPort: '<S98>/Action'
       */
      /* InitializeConditions for If: '<S94>/If' incorporates:
       *  Integrator: '<S98>/x'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->w = 0.0;
      }

      localDW->x_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S94>/Locked' */
    }

    /* Outputs for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* Lookup_n-D: '<S112>/Gear2Ratios' */
    rtb_Merge = look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.N, 6U);

    /* Abs: '<S98>/Abs' */
    rtb_SumofElements_d = fabs(rtb_Merge);

    /* Integrator: '<S98>/x' */
    if (localDW->x_IWORK != 0) {
      localX->w = localB->Switch_a;
      rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
        (DrivetrainHevP4_M->solverInfo, true);
    }

    /* Lookup_n-D: '<S117>/Eta 4D' incorporates:
     *  Constant: '<S2>/Constant'
     *  Integrator: '<S98>/x'
     *  Sum: '<S86>/Subtract1'
     */
    bpIndices[0U] = plook_binc(rtb_Subtract1, DrivetrainHevP4_P.Trq_bpts, 6U,
      &rtb_Merge1);
    fractions[0U] = rtb_Merge1;
    bpIndices[1U] = plook_binc(localX->w, DrivetrainHevP4_P.omega_bpts, 10U,
      &rtb_Merge1);
    fractions[1U] = rtb_Merge1;
    bpIndices[2U] = plook_binc(*rty_TransGear, DrivetrainHevP4_P.G, 6U,
      &rtb_Merge1);
    fractions[2U] = rtb_Merge1;
    bpIndices[3U] = plook_binc(DrivetrainHevP4_P.Temp_bpts[0],
      DrivetrainHevP4_P.Temp_bpts, 1U, &rtb_Merge1);
    fractions[3U] = rtb_Merge1;
    rtb_Merge1 = intrp4d_l_pw(bpIndices, fractions, DrivetrainHevP4_P.eta_tbl,
      DrivetrainHevP4_P.Eta4D_dimSizes);

    /* Product: '<S98>/Product5' incorporates:
     *  UnaryMinus: '<S77>/Unary Minus'
     */
    rtb_Sum_gs = -rtb_Gain1_lh / rtb_Merge;

    /* Switch: '<S109>/Switch' incorporates:
     *  Constant: '<S109>/Constant'
     *  Integrator: '<S98>/x'
     *  Product: '<S109>/Product1'
     */
    if (rtb_Subtract1 * localX->w > DrivetrainHevP4_P.Switch_Threshold) {
      rtb_uniclutch = rtb_Merge1;
    } else {
      rtb_uniclutch = DrivetrainHevP4_P.Constant_Value;
    }

    /* End of Switch: '<S109>/Switch' */

    /* Switch: '<S110>/Switch' incorporates:
     *  Constant: '<S110>/Constant'
     *  Integrator: '<S98>/x'
     *  Product: '<S110>/Product1'
     */
    if (!(rtb_Sum_gs * localX->w > DrivetrainHevP4_P.Switch_Threshold_a)) {
      rtb_Merge1 = DrivetrainHevP4_P.Constant_Value_f;
    }

    /* End of Switch: '<S110>/Switch' */

    /* Product: '<S98>/Product8' incorporates:
     *  Integrator: '<S98>/x'
     *  Lookup_n-D: '<S112>/Gear2damping'
     *  Lookup_n-D: '<S112>/Gear2inertias'
     *  Product: '<S109>/Product4'
     *  Product: '<S110>/Product4'
     *  Product: '<S98>/Product1'
     *  Product: '<S98>/Product3'
     *  Product: '<S98>/Product6'
     *  Sum: '<S98>/Sum'
     *  Sum: '<S98>/Sum1'
     */
    localB->Product8_e = ((rtb_uniclutch * rtb_Subtract1 + rtb_Merge1 *
      rtb_Sum_gs) - 1.0 / rtb_SumofElements_d / rtb_SumofElements_d *
                          look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.bout, 6U) * localX->w) * (1.0 / (look1_binlxpw
      (*rty_TransGear, DrivetrainHevP4_P.G, DrivetrainHevP4_P.Jout, 6U) /
      rtb_SumofElements_d / rtb_SumofElements_d));

    /* SignalConversion: '<S98>/Signal Conversion2' incorporates:
     *  Integrator: '<S98>/x'
     */
    rtb_Merge1 = localX->w;

    /* SignalConversion: '<S98>/Signal Conversion3' incorporates:
     *  Integrator: '<S98>/x'
     *  Product: '<S98>/Product2'
     */
    rtb_Merge = localX->w / rtb_Merge;

    /* End of Outputs for SubSystem: '<S94>/Locked' */
    break;

   case 1:
    if (rtAction != rtPrevAction) {
      /* InitializeConditions for IfAction SubSystem: '<S94>/Unlocked' incorporates:
       *  ActionPort: '<S100>/Action'
       */
      /* InitializeConditions for If: '<S94>/If' incorporates:
       *  Integrator: '<S100>/xe'
       *  Integrator: '<S100>/xv'
       */
      if (rtmIsFirstInitCond(DrivetrainHevP4_M)) {
        localX->we = 0.0;
        localX->wv = 0.0;
      }

      localDW->xe_IWORK = 1;
      localDW->xv_IWORK = 1;

      /* End of InitializeConditions for SubSystem: '<S94>/Unlocked' */
    }

    /* Outputs for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* Lookup_n-D: '<S120>/Gear2Ratios' */
    rtb_Merge = look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G,
      DrivetrainHevP4_P.N, 6U);

    /* Abs: '<S100>/Abs' */
    rtb_SumofElements_d = fabs(rtb_Merge);

    /* Integrator: '<S100>/xe' */
    if (localDW->xe_IWORK != 0) {
      localX->we = localB->Switch_ht;
      rtsiSetContTimeOutputInconsistentWithStateAtMajorStep
        (DrivetrainHevP4_M->solverInfo, true);
    }

    /* Integrator: '<S100>/xv' */
    if (localDW->xv_IWORK != 0) {
      localX->wv = localB->Switch_p;
    }

    /* Product: '<S100>/Product5' incorporates:
     *  UnaryMinus: '<S77>/Unary Minus'
     */
    rtb_Sum_gs = -rtb_Gain1_lh / rtb_Merge;

    /* Switch: '<S118>/Switch' incorporates:
     *  Constant: '<S118>/Constant'
     *  Integrator: '<S100>/xv'
     *  Lookup_n-D: '<S125>/Eta 4D'
     *  Product: '<S118>/Product1'
     */
    if (rtb_Sum_gs * localX->wv > DrivetrainHevP4_P.Switch_Threshold_i) {
      /* Lookup_n-D: '<S125>/Eta 4D' incorporates:
       *  Constant: '<S100>/No Input Torque'
       *  Constant: '<S2>/Constant'
       */
      bpIndices[0U] = plook_binc(DrivetrainHevP4_P.NoInputTorque_Value,
        DrivetrainHevP4_P.Trq_bpts, 6U, &rtb_Merge1);
      fractions[0U] = rtb_Merge1;
      bpIndices[1U] = plook_binc(localX->wv, DrivetrainHevP4_P.omega_bpts, 10U,
        &rtb_Merge1);
      fractions[1U] = rtb_Merge1;
      bpIndices[2U] = plook_binc(*rty_TransGear, DrivetrainHevP4_P.G, 6U,
        &rtb_Merge1);
      fractions[2U] = rtb_Merge1;
      bpIndices[3U] = plook_binc(DrivetrainHevP4_P.Temp_bpts[0],
        DrivetrainHevP4_P.Temp_bpts, 1U, &rtb_Merge1);
      fractions[3U] = rtb_Merge1;
      rtb_Merge1 = intrp4d_l_pw(bpIndices, fractions, DrivetrainHevP4_P.eta_tbl,
        DrivetrainHevP4_P.Eta4D_dimSizes_m);
    } else {
      rtb_Merge1 = DrivetrainHevP4_P.Constant_Value_i;
    }

    /* End of Switch: '<S118>/Switch' */

    /* Lookup_n-D: '<S100>/Gear2inertias' incorporates:
     *  Constant: '<S100>/Neutral'
     *  Lookup_n-D: '<S100>/Gear2damping'
     */
    rtb_speedratioPrelookup_o1 = plook_u32d_binckan
      (DrivetrainHevP4_P.Neutral_Value, DrivetrainHevP4_P.G, 6U);

    /* Product: '<S100>/Product4' incorporates:
     *  Constant: '<S100>/First'
     *  Integrator: '<S100>/xe'
     *  Lookup_n-D: '<S100>/Gear2damping'
     *  Lookup_n-D: '<S100>/Gear2inertias'
     *  Lookup_n-D: '<S100>/Gear2inertias1'
     *  Product: '<S100>/Product7'
     *  Sum: '<S100>/Subtract'
     *  Sum: '<S100>/Sum1'
     */
    localB->Product4 = 1.0 / (DrivetrainHevP4_P.Jout[plook_u32d_binckan
      (DrivetrainHevP4_P.First_Value, DrivetrainHevP4_P.G, 6U)] -
      DrivetrainHevP4_P.Jout[rtb_speedratioPrelookup_o1]) * (rtb_Subtract1 -
      DrivetrainHevP4_P.bout[rtb_speedratioPrelookup_o1] * localX->we);

    /* Product: '<S100>/Product8' incorporates:
     *  Integrator: '<S100>/xv'
     *  Lookup_n-D: '<S120>/Gear2damping'
     *  Lookup_n-D: '<S120>/Gear2inertias'
     *  Product: '<S100>/Product1'
     *  Product: '<S100>/Product3'
     *  Product: '<S100>/Product6'
     *  Product: '<S118>/Product4'
     *  Sum: '<S100>/Sum'
     */
    localB->Product8 = (rtb_Merge1 * rtb_Sum_gs - 1.0 / rtb_SumofElements_d /
                        rtb_SumofElements_d * look1_binlxpw(*rty_TransGear,
      DrivetrainHevP4_P.G, DrivetrainHevP4_P.bout, 6U) * localX->wv) * (1.0 /
      (look1_binlxpw(*rty_TransGear, DrivetrainHevP4_P.G, DrivetrainHevP4_P.Jout,
                     6U) / rtb_SumofElements_d / rtb_SumofElements_d));

    /* SignalConversion: '<S100>/Signal Conversion' incorporates:
     *  Integrator: '<S100>/xv'
     *  Product: '<S100>/Product2'
     */
    rtb_Merge = localX->wv / rtb_Merge;

    /* SignalConversion: '<S100>/Signal Conversion1' incorporates:
     *  Integrator: '<S100>/xe'
     */
    rtb_Merge1 = localX->we;

    /* End of Outputs for SubSystem: '<S94>/Unlocked' */
    break;
  }

  /* End of If: '<S94>/If' */
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Switch: '<S29>/Switch' incorporates:
     *  Constant: '<S29>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_d >
        DrivetrainHevP4_P.Switch_Threshold_c) {
      /* Switch: '<S29>/Switch' incorporates:
       *  Constant: '<S29>/Constant1'
       */
      localB->diffDir = DrivetrainHevP4_P.Constant1_Value_iv;
    } else {
      /* Switch: '<S29>/Switch' incorporates:
       *  Constant: '<S29>/Constant1'
       *  UnaryMinus: '<S29>/Unary Minus'
       */
      localB->diffDir = -DrivetrainHevP4_P.Constant1_Value_iv;
    }

    /* End of Switch: '<S29>/Switch' */

    /* Constant: '<S25>/Constant' */
    localB->VectorConcatenate_l[0] = DrivetrainHevP4_P.omegaw1o;

    /* Constant: '<S25>/Constant1' */
    localB->VectorConcatenate_l[1] = DrivetrainHevP4_P.omegaw2o;
  }

  /* Integrator: '<S25>/Integrator' */
  /* Limited  Integrator  */
  if (localDW->Integrator_IWORK_j != 0) {
    localX->Integrator_CSTATE_o[0] = localB->VectorConcatenate_l[0];
    localX->Integrator_CSTATE_o[1] = localB->VectorConcatenate_l[1];
  }

  /* Gain: '<S29>/Gain' */
  rtb_Subtract1 = DrivetrainHevP4_P.Ndiff / 2.0;

  /* Integrator: '<S25>/Integrator' */
  if (localX->Integrator_CSTATE_o[0] >= DrivetrainHevP4_P.Integrator_UpperSat) {
    localX->Integrator_CSTATE_o[0] = DrivetrainHevP4_P.Integrator_UpperSat;
  } else if (localX->Integrator_CSTATE_o[0] <=
             DrivetrainHevP4_P.Integrator_LowerSat) {
    localX->Integrator_CSTATE_o[0] = DrivetrainHevP4_P.Integrator_LowerSat;
  }

  /* Integrator: '<S25>/Integrator' */
  rtb_Integrator_g[0] = localX->Integrator_CSTATE_o[0];

  /* Integrator: '<S25>/Integrator' */
  if (localX->Integrator_CSTATE_o[1] >= DrivetrainHevP4_P.Integrator_UpperSat) {
    localX->Integrator_CSTATE_o[1] = DrivetrainHevP4_P.Integrator_UpperSat;
  } else if (localX->Integrator_CSTATE_o[1] <=
             DrivetrainHevP4_P.Integrator_LowerSat) {
    localX->Integrator_CSTATE_o[1] = DrivetrainHevP4_P.Integrator_LowerSat;
  }

  /* Integrator: '<S25>/Integrator' */
  rtb_Integrator_g[1] = localX->Integrator_CSTATE_o[1];

  /* Sum: '<S29>/Sum of Elements' incorporates:
   *  Gain: '<S29>/Gain'
   *  Product: '<S29>/Product'
   */
  rtb_SumofElements_d = localB->diffDir * rtb_Integrator_g[0] * rtb_Subtract1 +
    localB->diffDir * rtb_Integrator_g[1] * rtb_Subtract1;

  /* Sum: '<S77>/Subtract' */
  localB->Subtract = rtb_Merge - rtb_SumofElements_d;

  /* Switch: '<S78>/Switch' */
  if (!(localB->Memory_ku != 0.0)) {
    rtb_Fx_o = localB->domega_o_j;
  }

  /* End of Switch: '<S78>/Switch' */

  /* Product: '<S78>/Product' incorporates:
   *  Constant: '<S77>/omega_c'
   *  Sum: '<S78>/Sum'
   */
  localB->Product_d = (localB->Subtract - rtb_Fx_o) * DrivetrainHevP4_P.omega_c;

  /* Sum: '<S86>/Subtract' */
  localB->Subtract_n = rtb_TurbineSpd - rtb_Merge1;

  /* Switch: '<S87>/Switch' */
  if (!(localB->Memory_k != 0.0)) {
    rtb_Fx = localB->domega_o_h;
  }

  /* End of Switch: '<S87>/Switch' */

  /* Product: '<S87>/Product' incorporates:
   *  Constant: '<S86>/omega_c'
   *  Sum: '<S87>/Sum'
   */
  localB->Product_o = (localB->Subtract_n - rtb_Fx) * DrivetrainHevP4_P.omega_c;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* DataTypeConversion: '<Root>/Data Type Conversion' */
    *rty_Cltch1State = false;

    /* Switch: '<S46>/Switch' incorporates:
     *  Constant: '<S46>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_nn >
        DrivetrainHevP4_P.Switch_Threshold_b) {
      /* Switch: '<S46>/Switch' incorporates:
       *  Constant: '<S46>/Constant1'
       */
      localB->diffDir_n = DrivetrainHevP4_P.Constant1_Value_m0;
    } else {
      /* Switch: '<S46>/Switch' incorporates:
       *  Constant: '<S46>/Constant1'
       *  UnaryMinus: '<S46>/Unary Minus'
       */
      localB->diffDir_n = -DrivetrainHevP4_P.Constant1_Value_m0;
    }

    /* End of Switch: '<S46>/Switch' */

    /* Constant: '<S42>/Constant' */
    localB->VectorConcatenate_b[0] = DrivetrainHevP4_P.omegaw1o;

    /* Constant: '<S42>/Constant1' */
    localB->VectorConcatenate_b[1] = DrivetrainHevP4_P.omegaw2o;
  }

  /* Integrator: '<S42>/Integrator' */
  /* Limited  Integrator  */
  if (localDW->Integrator_IWORK_mn != 0) {
    localX->Integrator_CSTATE_n[0] = localB->VectorConcatenate_b[0];
    localX->Integrator_CSTATE_n[1] = localB->VectorConcatenate_b[1];
  }

  /* Gain: '<S46>/Gain' */
  rtb_Subtract1 = DrivetrainHevP4_P.Ndiff_P4 / 2.0;

  /* Integrator: '<S42>/Integrator' */
  if (localX->Integrator_CSTATE_n[0] >= DrivetrainHevP4_P.Integrator_UpperSat_j)
  {
    localX->Integrator_CSTATE_n[0] = DrivetrainHevP4_P.Integrator_UpperSat_j;
  } else if (localX->Integrator_CSTATE_n[0] <=
             DrivetrainHevP4_P.Integrator_LowerSat_o) {
    localX->Integrator_CSTATE_n[0] = DrivetrainHevP4_P.Integrator_LowerSat_o;
  }

  /* Integrator: '<S42>/Integrator' */
  rtb_Integrator_p[0] = localX->Integrator_CSTATE_n[0];

  /* Integrator: '<S42>/Integrator' */
  if (localX->Integrator_CSTATE_n[1] >= DrivetrainHevP4_P.Integrator_UpperSat_j)
  {
    localX->Integrator_CSTATE_n[1] = DrivetrainHevP4_P.Integrator_UpperSat_j;
  } else if (localX->Integrator_CSTATE_n[1] <=
             DrivetrainHevP4_P.Integrator_LowerSat_o) {
    localX->Integrator_CSTATE_n[1] = DrivetrainHevP4_P.Integrator_LowerSat_o;
  }

  /* Integrator: '<S42>/Integrator' */
  rtb_Integrator_p[1] = localX->Integrator_CSTATE_n[1];

  /* Sum: '<S46>/Sum of Elements' incorporates:
   *  Gain: '<S46>/Gain'
   *  Product: '<S46>/Product'
   */
  *rty_MotSpd = localB->diffDir_n * rtb_Integrator_p[0] * rtb_Subtract1 +
    localB->diffDir_n * rtb_Integrator_p[1] * rtb_Subtract1;

  /* Product: '<S56>/Product1' */
  rtb_Fx = *rtu_MotTrq * *rty_MotSpd;

  /* Switch: '<S56>/Switch' incorporates:
   *  Constant: '<S56>/Constant'
   *  Constant: '<S58>/Constant'
   */
  if (rtb_Fx > DrivetrainHevP4_P.Switch_Threshold_f) {
    rtb_Fx = DrivetrainHevP4_P.eta_diff;
  } else {
    rtb_Fx = DrivetrainHevP4_P.Constant_Value_e;
  }

  /* End of Switch: '<S56>/Switch' */

  /* Product: '<S56>/Product4' */
  rtb_Product4 = rtb_Fx * *rtu_MotTrq;

  /* Switch: '<S54>/Switch' incorporates:
   *  Constant: '<S54>/Constant'
   *  Constant: '<S58>/Constant'
   *  Product: '<S54>/Product1'
   *  UnaryMinus: '<S46>/Unary Minus1'
   *  UnaryMinus: '<S60>/Unary Minus'
   */
  if (-rtb_UnaryMinus1_p * -rtb_Integrator_p[0] >
      DrivetrainHevP4_P.Switch_Threshold_bp) {
    rtb_Fx = DrivetrainHevP4_P.eta_diff;
  } else {
    rtb_Fx = DrivetrainHevP4_P.Constant_Value_j;
  }

  /* End of Switch: '<S54>/Switch' */

  /* Product: '<S54>/Product4' incorporates:
   *  UnaryMinus: '<S60>/Unary Minus'
   */
  rtb_Product4_g = rtb_Fx * -rtb_UnaryMinus1_p;

  /* Switch: '<S55>/Switch' incorporates:
   *  Constant: '<S55>/Constant'
   *  Constant: '<S58>/Constant'
   *  Product: '<S55>/Product1'
   *  UnaryMinus: '<S46>/Unary Minus1'
   *  UnaryMinus: '<S60>/Unary Minus1'
   */
  if (-rtb_UnaryMinus1_p * -rtb_Integrator_p[1] >
      DrivetrainHevP4_P.Switch_Threshold_au) {
    rtb_Fx = DrivetrainHevP4_P.eta_diff;
  } else {
    rtb_Fx = DrivetrainHevP4_P.Constant_Value_jy;
  }

  /* End of Switch: '<S55>/Switch' */

  /* Product: '<S55>/Product4' incorporates:
   *  UnaryMinus: '<S60>/Unary Minus1'
   */
  rtb_Product4_o = rtb_Fx * -rtb_UnaryMinus1_p;

  /* MATLAB Function: '<S42>/Open Differential' incorporates:
   *  Constant: '<S42>/Jd'
   *  Constant: '<S42>/Jw1'
   *  Constant: '<S42>/Jw3'
   *  Constant: '<S42>/Ndiff2'
   *  Constant: '<S42>/bd'
   *  Constant: '<S42>/bw1'
   *  Constant: '<S42>/bw2'
   */
  DrivetrainHevP4_OpenDifferential(rtb_Product4, rtb_Product4_g, rtb_Product4_o,
    DrivetrainHevP4_P.bw1, DrivetrainHevP4_P.bd, DrivetrainHevP4_P.bw2,
    DrivetrainHevP4_P.Ndiff_P4, DrivetrainHevP4_P.Jd, DrivetrainHevP4_P.Jw1,
    DrivetrainHevP4_P.Jw2, rtb_Integrator_p, &localB->sf_OpenDifferential_l,
    &DrivetrainHevP4_P.sf_OpenDifferential_l);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Switch: '<S49>/Switch1' incorporates:
     *  Constant: '<S49>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_o >
        DrivetrainHevP4_P.Switch1_Threshold_b) {
      /* Switch: '<S49>/Switch1' incorporates:
       *  Constant: '<S49>/Constant6'
       */
      localB->diffDir_g = DrivetrainHevP4_P.Constant6_Value_f;
    } else {
      /* Switch: '<S49>/Switch1' incorporates:
       *  Constant: '<S49>/Constant6'
       *  UnaryMinus: '<S49>/Unary Minus'
       */
      localB->diffDir_g = -DrivetrainHevP4_P.Constant6_Value_f;
    }

    /* End of Switch: '<S49>/Switch1' */
  }

  /* Sum: '<S13>/Subtract' incorporates:
   *  UnaryMinus: '<S29>/Unary Minus1'
   */
  localB->Subtract_l = -rtb_Integrator_g[0] -
    rtb_ImpAsg_InsertedFor_Omega_at_inport_0_i;

  /* Switch: '<S14>/Switch' */
  if (!(localB->Memory != 0.0)) {
    rtb_Switch_o = localB->domega_o;
  }

  /* End of Switch: '<S14>/Switch' */

  /* Product: '<S14>/Product' incorporates:
   *  Constant: '<S13>/omega_c'
   *  Sum: '<S14>/Sum'
   */
  localB->Product_m = (localB->Subtract_l - rtb_Switch_o) *
    DrivetrainHevP4_P.omega_c;

  /* Switch: '<S39>/Switch' incorporates:
   *  Constant: '<S39>/Constant'
   *  Constant: '<S41>/Constant'
   *  Product: '<S39>/Product1'
   *  SignalConversion generated from: '<S29>/Vector Concatenate'
   */
  if (rtb_Gain1_lh * rtb_SumofElements_d > DrivetrainHevP4_P.Switch_Threshold_j)
  {
    rtb_Switch_o = DrivetrainHevP4_P.eta_diff;
  } else {
    rtb_Switch_o = DrivetrainHevP4_P.Constant_Value_cg;
  }

  /* End of Switch: '<S39>/Switch' */

  /* Product: '<S39>/Product4' */
  rtb_Product4_e = rtb_Switch_o * rtb_Gain1_lh;

  /* Switch: '<S37>/Switch' incorporates:
   *  Constant: '<S37>/Constant'
   *  Constant: '<S41>/Constant'
   *  Product: '<S37>/Product1'
   *  UnaryMinus: '<S13>/Unary Minus'
   *  UnaryMinus: '<S29>/Unary Minus1'
   */
  if (-rtb_UnaryMinus1_c * -rtb_Integrator_g[0] >
      DrivetrainHevP4_P.Switch_Threshold_kx) {
    rtb_Switch_o = DrivetrainHevP4_P.eta_diff;
  } else {
    rtb_Switch_o = DrivetrainHevP4_P.Constant_Value_h;
  }

  /* End of Switch: '<S37>/Switch' */

  /* Product: '<S37>/Product4' incorporates:
   *  UnaryMinus: '<S13>/Unary Minus'
   */
  rtb_Product4_p = rtb_Switch_o * -rtb_UnaryMinus1_c;

  /* Switch: '<S38>/Switch' incorporates:
   *  Constant: '<S38>/Constant'
   *  Constant: '<S41>/Constant'
   *  Product: '<S38>/Product1'
   *  UnaryMinus: '<S13>/Unary Minus1'
   *  UnaryMinus: '<S29>/Unary Minus1'
   */
  if (-rtb_UnaryMinus1_c * -rtb_Integrator_g[1] >
      DrivetrainHevP4_P.Switch_Threshold_mt) {
    rtb_Switch_o = DrivetrainHevP4_P.eta_diff;
  } else {
    rtb_Switch_o = DrivetrainHevP4_P.Constant_Value_kx;
  }

  /* End of Switch: '<S38>/Switch' */

  /* Product: '<S38>/Product4' incorporates:
   *  UnaryMinus: '<S13>/Unary Minus1'
   */
  rtb_Product4_oe = rtb_Switch_o * -rtb_UnaryMinus1_c;

  /* MATLAB Function: '<S25>/Open Differential' incorporates:
   *  Constant: '<S25>/Jd'
   *  Constant: '<S25>/Jw1'
   *  Constant: '<S25>/Jw3'
   *  Constant: '<S25>/Ndiff2'
   *  Constant: '<S25>/bd'
   *  Constant: '<S25>/bw1'
   *  Constant: '<S25>/bw2'
   */
  DrivetrainHevP4_OpenDifferential(rtb_Product4_e, rtb_Product4_p,
    rtb_Product4_oe, DrivetrainHevP4_P.bw1, DrivetrainHevP4_P.bd,
    DrivetrainHevP4_P.bw2, DrivetrainHevP4_P.Ndiff, DrivetrainHevP4_P.Jd,
    DrivetrainHevP4_P.Jw1, DrivetrainHevP4_P.Jw2, rtb_Integrator_g,
    &localB->sf_OpenDifferential, &DrivetrainHevP4_P.sf_OpenDifferential);
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Switch: '<S32>/Switch1' incorporates:
     *  Constant: '<S32>/Constant'
     */
    if (DrivetrainHevP4_P.Constant_Value_jq >
        DrivetrainHevP4_P.Switch1_Threshold_n) {
      /* Switch: '<S32>/Switch1' incorporates:
       *  Constant: '<S32>/Constant6'
       */
      localB->diffDir_o = DrivetrainHevP4_P.Constant6_Value_fv;
    } else {
      /* Switch: '<S32>/Switch1' incorporates:
       *  Constant: '<S32>/Constant6'
       *  UnaryMinus: '<S32>/Unary Minus'
       */
      localB->diffDir_o = -DrivetrainHevP4_P.Constant6_Value_fv;
    }

    /* End of Switch: '<S32>/Switch1' */
  }

  /* Sum: '<S60>/Subtract' incorporates:
   *  UnaryMinus: '<S46>/Unary Minus1'
   */
  localB->Subtract_e = -rtb_Integrator_p[0] -
    rtb_ImpAsg_InsertedFor_Omega_at_inport_0;

  /* Switch: '<S61>/Switch' */
  if (!(localB->Memory_f != 0.0)) {
    rtb_Switch_a = localB->domega_o_m;
  }

  /* End of Switch: '<S61>/Switch' */

  /* Product: '<S61>/Product' incorporates:
   *  Constant: '<S60>/omega_c'
   *  Sum: '<S61>/Sum'
   */
  localB->Product_b = (localB->Subtract_e - rtb_Switch_a) *
    DrivetrainHevP4_P.omega_c;

  /* Product: '<S230>/Product3' */
  rtb_Switch_o = rtb_ImpAsg_InsertedFor_Omega_at_inport_0_i * localB->Saturation;

  /* Switch: '<S247>/Switch' incorporates:
   *  Abs: '<S247>/Abs'
   *  Constant: '<S248>/Constant'
   *  Constant: '<S249>/Constant'
   *  Fcn: '<S247>/Fcn'
   *  Logic: '<S247>/Logical Operator'
   *  RelationalOperator: '<S248>/Compare'
   *  RelationalOperator: '<S249>/Compare'
   */
  if ((rtb_Switch_o >= -DrivetrainHevP4_P.VXLOW) && (rtb_Switch_o <=
       DrivetrainHevP4_P.VXLOW)) {
    rtb_Fx = 4.0 / (3.0 - rt_powd_snf(rtb_Switch_o / 2.0, 2.0));
  } else {
    rtb_Fx = fabs(rtb_Switch_o);
  }

  /* End of Switch: '<S247>/Switch' */

  /* Product: '<S246>/Product' incorporates:
   *  Constant: '<S230>/Constant2'
   *  Product: '<S230>/Product'
   *  Product: '<S230>/Product2'
   *  Sum: '<S230>/Add'
   *  Sum: '<S246>/Sum'
   */
  localB->Product_o4 = ((localB->sf_SimpleMagicTire.My / localB->Saturation +
    localB->sf_SimpleMagicTire.Fx) - rtb_Integrator_b) * (rtb_Fx /
    DrivetrainHevP4_P.Lrel);

  /* Product: '<S272>/Product3' */
  rtb_Integrator_b = rtb_ImpAsg_InsertedFor_Omega_at_inport_0 *
    localB->Saturation_f;

  /* Switch: '<S289>/Switch' incorporates:
   *  Abs: '<S289>/Abs'
   *  Constant: '<S290>/Constant'
   *  Constant: '<S291>/Constant'
   *  Fcn: '<S289>/Fcn'
   *  Logic: '<S289>/Logical Operator'
   *  RelationalOperator: '<S290>/Compare'
   *  RelationalOperator: '<S291>/Compare'
   */
  if ((rtb_Integrator_b >= -DrivetrainHevP4_P.VXLOW) && (rtb_Integrator_b <=
       DrivetrainHevP4_P.VXLOW)) {
    rtb_Fx = 4.0 / (3.0 - rt_powd_snf(rtb_Integrator_b / 2.0, 2.0));
  } else {
    rtb_Fx = fabs(rtb_Integrator_b);
  }

  /* End of Switch: '<S289>/Switch' */

  /* Product: '<S288>/Product' incorporates:
   *  Constant: '<S272>/Constant2'
   *  Product: '<S272>/Product'
   *  Product: '<S272>/Product2'
   *  Sum: '<S272>/Add'
   *  Sum: '<S288>/Sum'
   */
  localB->Product_de = ((localB->sf_SimpleMagicTire_c.My / localB->Saturation_f
    + localB->sf_SimpleMagicTire_c.Fx) - rtb_Gain) * (rtb_Fx /
    DrivetrainHevP4_P.Lrel);
}

/* Update for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Update(RT_MODEL_DrivetrainHevP4_T * const DrivetrainHevP4_M,
  boolean_T *rty_Cltch2State, DW_DrivetrainHevP4_f_T *localDW)
{
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Update for Memory: '<S14>/Memory' incorporates:
     *  Constant: '<S14>/Reset'
     */
    localDW->Memory_PreviousInput = DrivetrainHevP4_P.Reset_Value_e;

    /* Update for Memory: '<S61>/Memory' incorporates:
     *  Constant: '<S61>/Reset'
     */
    localDW->Memory_PreviousInput_f = DrivetrainHevP4_P.Reset_Value_l;
  }

  /* Update for Integrator: '<S14>/Integrator' */
  localDW->Integrator_IWORK = 0;

  /* Update for Integrator: '<S61>/Integrator' */
  localDW->Integrator_IWORK_m = 0;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Update for Memory: '<S87>/Memory' incorporates:
     *  Constant: '<S87>/Reset'
     */
    localDW->Memory_PreviousInput_e = DrivetrainHevP4_P.Reset_Value_g;

    /* Update for Memory: '<S150>/Memory' incorporates:
     *  Constant: '<S150>/Reset'
     */
    localDW->Memory_PreviousInput_d = DrivetrainHevP4_P.Reset_Value;
  }

  /* Update for Integrator: '<S87>/Integrator' */
  localDW->Integrator_IWORK_d = 0;

  /* Update for Integrator: '<S150>/Integrator' */
  localDW->Integrator_IWORK_h = 0;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Update for Memory: '<S145>/Memory' */
    localDW->Memory_PreviousInput_jb = *rty_Cltch2State;

    /* Update for Memory: '<S96>/Memory' incorporates:
     *  Constant: '<S96>/Reset'
     */
    localDW->Memory_PreviousInput_j = DrivetrainHevP4_P.Reset_Value_m;
  }

  /* Update for If: '<S126>/If' */
  switch (localDW->If_ActiveSubsystem) {
   case 0:
    /* Update for IfAction SubSystem: '<S126>/Locked' incorporates:
     *  ActionPort: '<S132>/Action'
     */
    /* Update for Integrator: '<S132>/Locked Shaft Integrator' */
    localDW->LockedShaftIntegrator_IWORK = 0;

    /* End of Update for SubSystem: '<S126>/Locked' */
    break;

   case 1:
    /* Update for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* Update for Integrator: '<S133>/Pump Integrator' */
    localDW->PumpIntegrator_IWORK = 0;

    /* Update for Integrator: '<S133>/Turbine Integrator' */
    localDW->TurbineIntegrator_IWORK = 0;

    /* End of Update for SubSystem: '<S126>/Unlocked' */
    break;
  }

  /* End of Update for If: '<S126>/If' */

  /* Update for Integrator: '<S96>/Integrator' */
  localDW->Integrator_IWORK_n = 0;
  if (rtmIsMajorTimeStep(DrivetrainHevP4_M)) {
    /* Update for Memory: '<S78>/Memory' incorporates:
     *  Constant: '<S78>/Reset'
     */
    localDW->Memory_PreviousInput_h = DrivetrainHevP4_P.Reset_Value_i;
  }

  /* Update for Integrator: '<S78>/Integrator' */
  localDW->Integrator_IWORK_l = 0;

  /* Update for If: '<S94>/If' */
  switch (localDW->If_ActiveSubsystem_b) {
   case 0:
    /* Update for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* Update for Integrator: '<S98>/x' */
    localDW->x_IWORK = 0;

    /* End of Update for SubSystem: '<S94>/Locked' */
    break;

   case 1:
    /* Update for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* Update for Integrator: '<S100>/xe' */
    localDW->xe_IWORK = 0;

    /* Update for Integrator: '<S100>/xv' */
    localDW->xv_IWORK = 0;

    /* End of Update for SubSystem: '<S94>/Unlocked' */
    break;
  }

  /* End of Update for If: '<S94>/If' */

  /* Update for Integrator: '<S25>/Integrator' */
  localDW->Integrator_IWORK_j = 0;

  /* Update for Integrator: '<S42>/Integrator' */
  localDW->Integrator_IWORK_mn = 0;
}

/* Derivatives for referenced model: 'DrivetrainHevP4' */
void DrivetrainHevP4_Deriv(B_DrivetrainHevP4_c_T *localB, DW_DrivetrainHevP4_f_T
  *localDW, X_DrivetrainHevP4_n_T *localX, XDot_DrivetrainHevP4_n_T *localXdot)
{
  boolean_T lsat;
  boolean_T usat;

  /* Derivatives for Integrator: '<S169>/Integrator' */
  localXdot->Integrator_CSTATE = localB->xddot;

  /* Derivatives for Integrator: '<S164>/Integrator1' */
  localXdot->Integrator1_CSTATE = localB->Divide_l;

  /* Derivatives for Integrator: '<S14>/Integrator' */
  localXdot->Integrator_CSTATE_a = localB->Product_m;

  /* Derivatives for Integrator: '<S13>/Integrator' */
  localXdot->Integrator_CSTATE_c = localB->Subtract_l;

  /* Derivatives for Integrator: '<S246>/Integrator' */
  localXdot->Integrator_CSTATE_h = localB->Product_o4;

  /* Derivatives for Iterator SubSystem: '<S217>/Clutch' */
  DrivetrainHevP4_Clutch_d_Deriv(localB->Signconvention,
    localB->Ratioofstatictokinetic, localB->TorqueConversion, &localB->Clutch,
    &localDW->Clutch, &localXdot->Clutch);

  /* End of Derivatives for SubSystem: '<S217>/Clutch' */

  /* Derivatives for Integrator: '<S163>/Integrator1' */
  localXdot->Integrator1_CSTATE_g = localB->Divide;

  /* Derivatives for Integrator: '<S61>/Integrator' */
  localXdot->Integrator_CSTATE_l = localB->Product_b;

  /* Derivatives for Integrator: '<S60>/Integrator' */
  localXdot->Integrator_CSTATE_i = localB->Subtract_e;

  /* Derivatives for Integrator: '<S288>/Integrator' */
  localXdot->Integrator_CSTATE_hm = localB->Product_de;

  /* Derivatives for Iterator SubSystem: '<S259>/Clutch' */
  DrivetrainHevP4_Clutch_d_Deriv(localB->Signconvention_o,
    localB->Ratioofstatictokinetic_i, localB->TorqueConversion_b,
    &localB->Clutch_e, &localDW->Clutch_e, &localXdot->Clutch_e);

  /* End of Derivatives for SubSystem: '<S259>/Clutch' */

  /* Derivatives for Integrator: '<S3>/Integrator' */
  localXdot->Integrator_CSTATE_d[0] =
    localB->TmpSignalConversionAtIntegratorInport1[0];
  localXdot->Integrator_CSTATE_d[1] =
    localB->TmpSignalConversionAtIntegratorInport1[1];

  /* Derivatives for Integrator: '<S177>/Integrator3' */
  localXdot->Integrator3_CSTATE = localB->VectorConcatenate2[0];

  /* Derivatives for Integrator: '<S166>/Integrator1' */
  localXdot->Integrator1_CSTATE_f = localB->Integrator;

  /* Derivatives for Integrator: '<S87>/Integrator' */
  localXdot->Integrator_CSTATE_de = localB->Product_o;

  /* Derivatives for Integrator: '<S86>/Integrator' */
  localXdot->Integrator_CSTATE_g = localB->Subtract_n;

  /* Derivatives for Integrator: '<S150>/Integrator' */
  localXdot->Integrator_CSTATE_b = localB->Product;

  /* Derivatives for If: '<S126>/If' */
  localXdot->LockedShaftIntegrator_CSTATE = 0.0;

  {
    real_T *dx;
    int_T i;
    dx = &(localXdot->PumpIntegrator_CSTATE);
    for (i=0; i < 3; i++) {
      dx[i] = 0.0;
    }
  }

  switch (localDW->If_ActiveSubsystem) {
   case 0:
    /* Derivatives for IfAction SubSystem: '<S126>/Locked' incorporates:
     *  ActionPort: '<S132>/Action'
     */
    /* Derivatives for Integrator: '<S132>/Locked Shaft Integrator' */
    lsat = (localX->LockedShaftIntegrator_CSTATE <=
            DrivetrainHevP4_P.LockedShaftIntegrator_LowerSat);
    usat = (localX->LockedShaftIntegrator_CSTATE >=
            DrivetrainHevP4_P.LockedShaftIntegrator_UpperSat);
    if (((!lsat) && (!usat)) || (lsat && (localB->Inertia > 0.0)) || (usat &&
         (localB->Inertia < 0.0))) {
      localXdot->LockedShaftIntegrator_CSTATE = localB->Inertia;
    } else {
      /* in saturation */
      localXdot->LockedShaftIntegrator_CSTATE = 0.0;
    }

    /* End of Derivatives for Integrator: '<S132>/Locked Shaft Integrator' */
    /* End of Derivatives for SubSystem: '<S126>/Locked' */
    break;

   case 1:
    /* Derivatives for IfAction SubSystem: '<S126>/Unlocked' incorporates:
     *  ActionPort: '<S133>/Action'
     */
    /* Derivatives for Integrator: '<S133>/Pump Integrator' */
    lsat = (localX->PumpIntegrator_CSTATE <=
            DrivetrainHevP4_P.PumpIntegrator_LowerSat);
    usat = (localX->PumpIntegrator_CSTATE >=
            DrivetrainHevP4_P.PumpIntegrator_UpperSat);
    if (((!lsat) && (!usat)) || (lsat && (localB->ImpellerInertia > 0.0)) ||
        (usat && (localB->ImpellerInertia < 0.0))) {
      localXdot->PumpIntegrator_CSTATE = localB->ImpellerInertia;
    } else {
      /* in saturation */
      localXdot->PumpIntegrator_CSTATE = 0.0;
    }

    /* End of Derivatives for Integrator: '<S133>/Pump Integrator' */

    /* Derivatives for Integrator: '<S133>/Turbine Integrator' */
    lsat = (localX->TurbineIntegrator_CSTATE <=
            DrivetrainHevP4_P.TurbineIntegrator_LowerSat);
    usat = (localX->TurbineIntegrator_CSTATE >=
            DrivetrainHevP4_P.TurbineIntegrator_UpperSat);
    if (((!lsat) && (!usat)) || (lsat && (localB->TurbineInertia > 0.0)) ||
        (usat && (localB->TurbineInertia < 0.0))) {
      localXdot->TurbineIntegrator_CSTATE = localB->TurbineInertia;
    } else {
      /* in saturation */
      localXdot->TurbineIntegrator_CSTATE = 0.0;
    }

    /* End of Derivatives for Integrator: '<S133>/Turbine Integrator' */

    /* Derivatives for Enabled SubSystem: '<S153>/LPF' */
    if (localDW->LPF_MODE) {
      /* Derivatives for Integrator: '<S157>/Integrator' */
      localXdot->Integrator_CSTATE_e = localB->Product_f;
    } else {
      localXdot->Integrator_CSTATE_e = 0.0;
    }

    /* End of Derivatives for SubSystem: '<S153>/LPF' */
    /* End of Derivatives for SubSystem: '<S126>/Unlocked' */
    break;
  }

  /* End of Derivatives for If: '<S126>/If' */

  /* Derivatives for Integrator: '<S96>/Integrator' */
  localXdot->Integrator_CSTATE_h1 = localB->Product_a;

  /* Derivatives for Integrator: '<S78>/Integrator' */
  localXdot->Integrator_CSTATE_j = localB->Product_d;

  /* Derivatives for Integrator: '<S77>/Integrator' */
  localXdot->Integrator_CSTATE_g4 = localB->Subtract;

  /* Derivatives for If: '<S94>/If' */
  localXdot->w = 0.0;

  {
    real_T *dx;
    int_T i;
    dx = &(localXdot->we);
    for (i=0; i < 2; i++) {
      dx[i] = 0.0;
    }
  }

  switch (localDW->If_ActiveSubsystem_b) {
   case 0:
    /* Derivatives for IfAction SubSystem: '<S94>/Locked' incorporates:
     *  ActionPort: '<S98>/Action'
     */
    /* Derivatives for Integrator: '<S98>/x' */
    localXdot->w = localB->Product8_e;

    /* End of Derivatives for SubSystem: '<S94>/Locked' */
    break;

   case 1:
    /* Derivatives for IfAction SubSystem: '<S94>/Unlocked' incorporates:
     *  ActionPort: '<S100>/Action'
     */
    /* Derivatives for Integrator: '<S100>/xe' */
    localXdot->we = localB->Product4;

    /* Derivatives for Integrator: '<S100>/xv' */
    localXdot->wv = localB->Product8;

    /* End of Derivatives for SubSystem: '<S94>/Unlocked' */
    break;
  }

  /* End of Derivatives for If: '<S94>/If' */

  /* Derivatives for Integrator: '<S25>/Integrator' */
  lsat = (localX->Integrator_CSTATE_o[0] <=
          DrivetrainHevP4_P.Integrator_LowerSat);
  usat = (localX->Integrator_CSTATE_o[0] >=
          DrivetrainHevP4_P.Integrator_UpperSat);
  if (((!lsat) && (!usat)) || (lsat && (localB->sf_OpenDifferential.xdot[0] >
        0.0)) || (usat && (localB->sf_OpenDifferential.xdot[0] < 0.0))) {
    localXdot->Integrator_CSTATE_o[0] = localB->sf_OpenDifferential.xdot[0];
  } else {
    /* in saturation */
    localXdot->Integrator_CSTATE_o[0] = 0.0;
  }

  lsat = (localX->Integrator_CSTATE_o[1] <=
          DrivetrainHevP4_P.Integrator_LowerSat);
  usat = (localX->Integrator_CSTATE_o[1] >=
          DrivetrainHevP4_P.Integrator_UpperSat);
  if (((!lsat) && (!usat)) || (lsat && (localB->sf_OpenDifferential.xdot[1] >
        0.0)) || (usat && (localB->sf_OpenDifferential.xdot[1] < 0.0))) {
    localXdot->Integrator_CSTATE_o[1] = localB->sf_OpenDifferential.xdot[1];
  } else {
    /* in saturation */
    localXdot->Integrator_CSTATE_o[1] = 0.0;
  }

  /* End of Derivatives for Integrator: '<S25>/Integrator' */

  /* Derivatives for Integrator: '<S42>/Integrator' */
  lsat = (localX->Integrator_CSTATE_n[0] <=
          DrivetrainHevP4_P.Integrator_LowerSat_o);
  usat = (localX->Integrator_CSTATE_n[0] >=
          DrivetrainHevP4_P.Integrator_UpperSat_j);
  if (((!lsat) && (!usat)) || (lsat && (localB->sf_OpenDifferential_l.xdot[0] >
        0.0)) || (usat && (localB->sf_OpenDifferential_l.xdot[0] < 0.0))) {
    localXdot->Integrator_CSTATE_n[0] = localB->sf_OpenDifferential_l.xdot[0];
  } else {
    /* in saturation */
    localXdot->Integrator_CSTATE_n[0] = 0.0;
  }

  lsat = (localX->Integrator_CSTATE_n[1] <=
          DrivetrainHevP4_P.Integrator_LowerSat_o);
  usat = (localX->Integrator_CSTATE_n[1] >=
          DrivetrainHevP4_P.Integrator_UpperSat_j);
  if (((!lsat) && (!usat)) || (lsat && (localB->sf_OpenDifferential_l.xdot[1] >
        0.0)) || (usat && (localB->sf_OpenDifferential_l.xdot[1] < 0.0))) {
    localXdot->Integrator_CSTATE_n[1] = localB->sf_OpenDifferential_l.xdot[1];
  } else {
    /* in saturation */
    localXdot->Integrator_CSTATE_n[1] = 0.0;
  }

  /* End of Derivatives for Integrator: '<S42>/Integrator' */
}

/* Model initialize function */
void DrivetrainHevP4_initialize(const char_T **rt_errorStatus, boolean_T
  *rt_stopRequested, RTWSolverInfo *rt_solverInfo, const rtTimingBridge
  *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_DrivetrainHevP4_T *const DrivetrainHevP4_M, B_DrivetrainHevP4_c_T
  *localB, DW_DrivetrainHevP4_f_T *localDW, X_DrivetrainHevP4_n_T *localX,
  ZCE_DrivetrainHevP4_T *localZCE, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const
  char_T *rt_ChildPath, int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  DrivetrainHevP4_P.Saturation1_LowerSat = rtMinusInf;
  DrivetrainHevP4_P.Saturation2_UpperSat = rtInf;
  DrivetrainHevP4_P.Saturation1_LowerSat_k = rtMinusInf;
  DrivetrainHevP4_P.Saturation2_UpperSat_b = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_b = rtInf;
  DrivetrainHevP4_P.uniclutch_UpperSat = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_f = rtInf;
  DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_p = rtInf;
  DrivetrainHevP4_P.DisallowNegativeBrakeTorque_UpperSat_o = rtInf;
  DrivetrainHevP4_P.Saturation_UpperSat_h = rtInf;

  /* initialize real-time model */
  (void) memset((void *)DrivetrainHevP4_M, 0,
                sizeof(RT_MODEL_DrivetrainHevP4_T));

  /* setup the global timing engine */
  DrivetrainHevP4_M->Timing.mdlref_GlobalTID[0] = mdlref_TID0;
  DrivetrainHevP4_M->Timing.mdlref_GlobalTID[1] = mdlref_TID1;
  DrivetrainHevP4_M->timingBridge = (timingBridge);

  /* initialize error status */
  rtmSetErrorStatusPointer(DrivetrainHevP4_M, rt_errorStatus);

  /* initialize stop requested flag */
  rtmSetStopRequestedPtr(DrivetrainHevP4_M, rt_stopRequested);

  /* initialize RTWSolverInfo */
  DrivetrainHevP4_M->solverInfo = (rt_solverInfo);

  /* Set the Timing fields to the appropriate data in the RTWSolverInfo */
  rtmSetSimTimeStepPointer(DrivetrainHevP4_M, rtsiGetSimTimeStepPtr
    (DrivetrainHevP4_M->solverInfo));
  DrivetrainHevP4_M->Timing.stepSize0 = (rtsiGetStepSize
    (DrivetrainHevP4_M->solverInfo));

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_DrivetrainHevP4_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_DrivetrainHevP4_f_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  {
    DrivetrainHevP4_InitializeDataMapInfo(DrivetrainHevP4_M, localB, localX);
  }

  /* Initialize Parent model MMI */
  if ((rt_ParentMMI != (NULL)) && (rt_ChildPath != (NULL))) {
    rtwCAPI_SetChildMMI(*rt_ParentMMI, rt_ChildMMIIdx,
                        &(DrivetrainHevP4_M->DataMapInfo.mmi));
    rtwCAPI_SetPath(DrivetrainHevP4_M->DataMapInfo.mmi, rt_ChildPath);
    rtwCAPI_MMISetContStateStartIndex(DrivetrainHevP4_M->DataMapInfo.mmi,
      rt_CSTATEIdx);
  }

  localZCE->Integrator_Reset_ZCE = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_a = UNINITIALIZED_ZCSIG;
  localZCE->VelocitiesMatch_Input_ZCE = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_j = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_f = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_m = UNINITIALIZED_ZCSIG;
  localZCE->Integrator_Reset_ZCE_fz = UNINITIALIZED_ZCSIG;
}
