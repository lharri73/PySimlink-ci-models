/*
 * DrivetrainHevP4_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:03 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DrivetrainHevP4_types_h_
#define RTW_HEADER_DrivetrainHevP4_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Model Code Variants */

/* Parameters for system: '<S25>/Open Differential' */
typedef struct P_OpenDifferential_DrivetrainHevP4_T_
  P_OpenDifferential_DrivetrainHevP4_T;

/* Parameters for system: '<S228>/Clutch' */
typedef struct P_Clutch_DrivetrainHevP4_o_T_ P_Clutch_DrivetrainHevP4_o_T;

/* Parameters for system: '<S217>/Clutch' */
typedef struct P_CoreSubsys_DrivetrainHevP4_T_ P_CoreSubsys_DrivetrainHevP4_T;

/* Parameters for system: '<S217>/Clutch' */
typedef struct P_Clutch_DrivetrainHevP4_T_ P_Clutch_DrivetrainHevP4_T;

/* Parameters (default storage) */
typedef struct P_DrivetrainHevP4_T_ P_DrivetrainHevP4_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_DrivetrainHevP4_T RT_MODEL_DrivetrainHevP4_T;

#endif                                 /* RTW_HEADER_DrivetrainHevP4_types_h_ */
