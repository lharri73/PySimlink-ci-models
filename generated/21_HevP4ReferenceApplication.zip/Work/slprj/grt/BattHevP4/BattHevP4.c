/*
 * Code generation for system model 'BattHevP4'
 *
 * Model                      : BattHevP4
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:20:52 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "BattHevP4_capi.h"
#include "BattHevP4.h"
#include "BattHevP4_private.h"
#include "look1_binlcapw.h"
#include "look2_binlcapw.h"
#include "rt_powd_snf.h"

P_BattHevP4_T BattHevP4_P = {
  /* Variable: BattCapInit
   * Referenced by: '<S18>/Constant1'
   */
  3.1799999999999997,

  /* Variable: BattChargeMax
   * Referenced by:
   *   '<S22>/Constant1'
   *   '<S22>/Integrator Limited'
   *   '<S22>/Switch'
   *   '<S23>/Constant1'
   */
  5.3,

  /* Variable: BattTempBp
   * Referenced by: '<S24>/R'
   */
  { 243.1, 253.1, 263.1, 273.1, 283.1, 298.1, 313.1 },

  /* Variable: CapLUTBp
   * Referenced by: '<S24>/Em'
   */
  { 0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.11, 0.12,
    0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2, 0.21, 0.22, 0.23, 0.24, 0.25,
    0.26, 0.27, 0.28, 0.29, 0.3, 0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38,
    0.39, 0.4, 0.41, 0.42, 0.43, 0.44, 0.45, 0.46, 0.47, 0.48, 0.49, 0.5, 0.51,
    0.52, 0.53, 0.54, 0.55, 0.56, 0.57, 0.58, 0.59, 0.6, 0.61, 0.62, 0.63, 0.64,
    0.65, 0.66, 0.67, 0.68, 0.69, 0.7, 0.71, 0.72, 0.73, 0.74, 0.75, 0.76, 0.77,
    0.78, 0.79, 0.8, 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.87, 0.88, 0.89, 0.9,
    0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1.0 },

  /* Variable: CapSOCBp
   * Referenced by: '<S24>/R'
   */
  { 0.0, 0.2, 0.4, 0.6, 0.8, 1.0 },

  /* Variable: Em
   * Referenced by: '<S24>/Em'
   */
  { 2.8, 3.228, 3.284, 3.361, 3.408, 3.427, 3.472, 3.477, 3.493, 3.504, 3.516,
    3.528, 3.537, 3.545, 3.555, 3.561, 3.566, 3.576, 3.587, 3.589, 3.594, 3.6,
    3.608, 3.61, 3.616, 3.619, 3.626, 3.632, 3.637, 3.64, 3.645, 3.646, 3.652,
    3.655, 3.658, 3.661, 3.664, 3.668, 3.673, 3.678, 3.68, 3.681, 3.686, 3.692,
    3.699, 3.702, 3.705, 3.71, 3.717, 3.723, 3.728, 3.733, 3.735, 3.742, 3.749,
    3.755, 3.761, 3.768, 3.773, 3.78, 3.791, 3.798, 3.798, 3.814, 3.818, 3.825,
    3.841, 3.846, 3.855, 3.863, 3.877, 3.885, 3.894, 3.907, 3.919, 3.926, 3.935,
    3.944, 3.954, 3.964, 3.974, 3.988, 3.998, 4.014, 4.029, 4.034, 4.047, 4.065,
    4.074, 4.086, 4.097, 4.131, 4.126, 4.138, 4.15, 4.18, 4.174, 4.187, 4.207,
    4.231, 4.221 },

  /* Variable: Np
   * Referenced by:
   *   '<S22>/Gain1'
   *   '<S24>/Gain2'
   */
  1.0,

  /* Variable: Ns
   * Referenced by:
   *   '<S20>/Constant2'
   *   '<S24>/Gain1'
   */
  72.0,

  /* Variable: Plimit
   * Referenced by: '<S4>/MaxLdPwr'
   */
  30000.0,

  /* Variable: RInt
   * Referenced by: '<S24>/R'
   */
  { 0.008846, 0.006389, 0.004364, 0.002031, 0.001443, 0.0005603, 0.001028,
    0.009319, 0.006554, 0.004101, 0.002563, 0.001825, 0.0007192, 0.001338,
    0.009027, 0.005553, 0.00406, 0.002532, 0.001795, 0.0006887, 0.001, 0.00847,
    0.005525, 0.003452, 0.00246, 0.001778, 0.0007557, 0.001536, 0.01032,
    0.006043, 0.003846, 0.002716, 0.001924, 0.0007355, 0.001546, 0.01314,
    0.007805, 0.004517, 0.003047, 0.002234, 0.001014, 0.002789 },

  /* Variable: Tc
   * Referenced by:
   *   '<S20>/Constant1'
   *   '<S20>/Gain1'
   *   '<S4>/Gain1'
   *   '<S4>/Gain2'
   */
  0.001,

  /* Variable: Vinit
   * Referenced by:
   *   '<Root>/Constant'
   *   '<S4>/Constant1'
   */
  650.0,

  /* Variable: eff
   * Referenced by: '<S6>/Constant'
   */
  98.0,

  /* Mask Parameter: div0protectabspoly_thresh
   * Referenced by:
   *   '<S9>/Constant'
   *   '<S10>/Constant'
   */
  0.001,

  /* Mask Parameter: div0protectpoly_thresh
   * Referenced by:
   *   '<S12>/Constant'
   *   '<S13>/Constant'
   */
  0.001,

  /* Expression: 0
   * Referenced by: '<S4>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S11>/Switch1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S4>/Switch'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<S6>/Constant1'
   */
  100.0,

  /* Expression: 100
   * Referenced by: '<S6>/Constant2'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S6>/Switch'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S11>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S22>/Integrator Limited'
   */
  0.0,

  /* Expression: 100
   * Referenced by: '<Root>/SOC Ratio to %1'
   */
  100.0,

  /* Computed Parameter: R_maxIndex
   * Referenced by: '<S24>/R'
   */
  { 6U, 5U }
};

/* System initialize for referenced model: 'BattHevP4' */
void BattHevP4_Init(RT_MODEL_BattHevP4_T * const BattHevP4_M, DW_BattHevP4_f_T
                    *localDW, X_BattHevP4_n_T *localX)
{
  /* InitializeConditions for Integrator: '<S4>/Integrator' incorporates:
   *  Integrator: '<S20>/Integrator'
   */
  if (rtmIsFirstInitCond(BattHevP4_M)) {
    localX->Integrator_CSTATE = 0.0;
    localX->Integrator_CSTATE_l = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S4>/Integrator' */

  /* InitializeConditions for Integrator: '<S20>/Integrator' */
  localDW->Integrator_IWORK_c = 1;

  /* InitializeConditions for Integrator: '<S22>/Integrator Limited' */
  if (rtmIsFirstInitCond(BattHevP4_M)) {
    localX->IntegratorLimited_CSTATE = 0.0;
  }

  localDW->IntegratorLimited_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S22>/Integrator Limited' */
}

/* System reset for referenced model: 'BattHevP4' */
void BattHevP4_Reset(RT_MODEL_BattHevP4_T * const BattHevP4_M, DW_BattHevP4_f_T *
                     localDW, X_BattHevP4_n_T *localX)
{
  /* InitializeConditions for Integrator: '<S4>/Integrator' incorporates:
   *  Integrator: '<S20>/Integrator'
   */
  if (rtmIsFirstInitCond(BattHevP4_M)) {
    localX->Integrator_CSTATE = 0.0;
    localX->Integrator_CSTATE_l = 0.0;
  }

  localDW->Integrator_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S4>/Integrator' */

  /* InitializeConditions for Integrator: '<S20>/Integrator' */
  localDW->Integrator_IWORK_c = 1;

  /* InitializeConditions for Integrator: '<S22>/Integrator Limited' */
  if (rtmIsFirstInitCond(BattHevP4_M)) {
    localX->IntegratorLimited_CSTATE = 0.0;
  }

  localDW->IntegratorLimited_IWORK = 1;

  /* End of InitializeConditions for Integrator: '<S22>/Integrator Limited' */
}

/* Outputs for referenced model: 'BattHevP4' */
void BattHevP4(RT_MODEL_BattHevP4_T * const BattHevP4_M, const real_T
               *rtu_LdCurr, const real_T *rtu_BattTemp, real_T *rty_BattSoc,
               real_T *rty_BattV, real_T *rty_BattCurr, real_T *rty_HVDC,
               B_BattHevP4_c_T *localB, DW_BattHevP4_f_T *localDW,
               X_BattHevP4_n_T *localX)
{
  real_T rtb_Em;
  real_T rtb_Product;
  boolean_T rtb_Compare;
  boolean_T rtb_Compare_e;

  /* RelationalOperator: '<S9>/Compare' incorporates:
   *  Constant: '<S9>/Constant'
   */
  rtb_Compare = (*rtu_LdCurr >= -BattHevP4_P.div0protectabspoly_thresh);

  /* RelationalOperator: '<S10>/Compare' incorporates:
   *  Constant: '<S10>/Constant'
   */
  rtb_Compare_e = (*rtu_LdCurr <= BattHevP4_P.div0protectabspoly_thresh);

  /* Switch: '<S8>/Switch' incorporates:
   *  Fcn: '<S8>/Fcn'
   *  Logic: '<S8>/Logical Operator'
   */
  if (rtb_Compare && rtb_Compare_e) {
    /* Fcn: '<S8>/Fcn' */
    rtb_Em = *rtu_LdCurr / 0.001;
    rtb_Em = 0.002 / (3.0 - rt_powd_snf(rtb_Em, 2.0));
  } else {
    /* Abs: '<S8>/Abs' */
    rtb_Em = fabs(*rtu_LdCurr);
  }

  /* End of Switch: '<S8>/Switch' */

  /* Product: '<S4>/Divide' incorporates:
   *  Constant: '<S4>/MaxLdPwr'
   */
  rtb_Em = BattHevP4_P.Plimit / rtb_Em;
  if (rtmIsMajorTimeStep(BattHevP4_M)) {
    /* Gain: '<S4>/Gain2' incorporates:
     *  Constant: '<S4>/Constant1'
     */
    localB->Gain2 = BattHevP4_P.Tc * BattHevP4_P.Vinit;
  }

  /* Integrator: '<S4>/Integrator' */
  if (localDW->Integrator_IWORK != 0) {
    localX->Integrator_CSTATE = localB->Gain2;
  }

  /* Gain: '<S4>/Gain1' incorporates:
   *  Integrator: '<S4>/Integrator'
   */
  *rty_HVDC = 1.0 / BattHevP4_P.Tc * localX->Integrator_CSTATE;
  if (rtmIsMajorTimeStep(BattHevP4_M)) {
    /* Switch: '<S4>/Switch' incorporates:
     *  Constant: '<Root>/Constant'
     */
    if (BattHevP4_P.Vinit >= BattHevP4_P.Switch_Threshold) {
      /* Switch: '<S4>/Switch' */
      localB->Switch = BattHevP4_P.Vinit;
    } else {
      /* Switch: '<S4>/Switch' incorporates:
       *  Constant: '<S4>/Constant'
       */
      localB->Switch = BattHevP4_P.Constant_Value;
    }

    /* End of Switch: '<S4>/Switch' */
  }

  /* MinMax: '<S4>/MinMax' */
  if ((!(rtb_Em < localB->Switch)) && (!rtIsNaN(localB->Switch))) {
    rtb_Em = localB->Switch;
  }

  /* End of MinMax: '<S4>/MinMax' */

  /* Sum: '<S4>/Sum' */
  localB->Sum = rtb_Em - *rty_HVDC;

  /* Product: '<S6>/Product' */
  rtb_Product = *rty_HVDC * *rtu_LdCurr;
  if (rtmIsMajorTimeStep(BattHevP4_M)) {
    /* Sum: '<S6>/Subtract' incorporates:
     *  Constant: '<S6>/Constant'
     *  Constant: '<S6>/Constant1'
     */
    rtb_Em = BattHevP4_P.Constant1_Value - BattHevP4_P.eff;

    /* Product: '<S6>/Divide' incorporates:
     *  Constant: '<S6>/Constant'
     */
    localB->Divide = rtb_Em / BattHevP4_P.eff;

    /* Product: '<S6>/Divide1' incorporates:
     *  Constant: '<S6>/Constant2'
     */
    localB->Divide1 = rtb_Em / BattHevP4_P.Constant2_Value;
  }

  /* Switch: '<S6>/Switch' incorporates:
   *  Abs: '<S6>/Abs'
   *  Product: '<S6>/Product1'
   *  Product: '<S6>/Product2'
   */
  if (rtb_Product >= BattHevP4_P.Switch_Threshold_d) {
    rtb_Em = rtb_Product * localB->Divide;
  } else {
    rtb_Em = fabs(rtb_Product) * localB->Divide1;
  }

  /* End of Switch: '<S6>/Switch' */

  /* Sum: '<S5>/Add' */
  rtb_Product += rtb_Em;
  if (rtmIsMajorTimeStep(BattHevP4_M)) {
    /* Product: '<S20>/Product' incorporates:
     *  Constant: '<S20>/Constant1'
     *  Constant: '<S20>/Constant2'
     */
    localB->Product = BattHevP4_P.Ns * 3.791 * BattHevP4_P.Tc;
  }

  /* Integrator: '<S20>/Integrator' */
  if (localDW->Integrator_IWORK_c != 0) {
    localX->Integrator_CSTATE_l = localB->Product;
  }

  /* Gain: '<S20>/Gain1' incorporates:
   *  Integrator: '<S20>/Integrator'
   */
  *rty_BattV = 1.0 / BattHevP4_P.Tc * localX->Integrator_CSTATE_l;
  if (rtmIsMajorTimeStep(BattHevP4_M)) {
    /* UnaryMinus: '<S11>/Unary Minus' incorporates:
     *  Constant: '<S11>/Constant'
     */
    localB->UnaryMinus = -BattHevP4_P.Constant_Value_j;
  }

  /* Switch: '<S11>/Switch' incorporates:
   *  Constant: '<S12>/Constant'
   *  Constant: '<S13>/Constant'
   *  Fcn: '<S11>/Fcn'
   *  Logic: '<S11>/Logical Operator'
   *  Product: '<S11>/Product'
   *  RelationalOperator: '<S12>/Compare'
   *  RelationalOperator: '<S13>/Compare'
   */
  if ((*rty_BattV >= -BattHevP4_P.div0protectpoly_thresh) && (*rty_BattV <=
       BattHevP4_P.div0protectpoly_thresh)) {
    /* Switch: '<S11>/Switch1' incorporates:
     *  Constant: '<S11>/Constant'
     */
    if (*rty_BattV >= BattHevP4_P.Switch1_Threshold) {
      rtb_Em = BattHevP4_P.Constant_Value_j;
    } else {
      rtb_Em = localB->UnaryMinus;
    }

    /* End of Switch: '<S11>/Switch1' */
    rtb_Em *= 0.002 / (3.0 - rt_powd_snf(*rty_BattV / 0.001, 2.0));
  } else {
    rtb_Em = *rty_BattV;
  }

  /* End of Switch: '<S11>/Switch' */

  /* Product: '<S5>/Divide' */
  *rty_BattCurr = rtb_Product / rtb_Em;

  /* Gain: '<S22>/Gain1' */
  localB->Gain1 = -1.0 / (BattHevP4_P.Np * 3600.0) * *rty_BattCurr;
  if (rtmIsMajorTimeStep(BattHevP4_M)) {
    /* Switch: '<S22>/Switch' incorporates:
     *  Constant: '<S18>/Constant1'
     */
    if (BattHevP4_P.BattCapInit > BattHevP4_P.BattChargeMax) {
      /* Switch: '<S22>/Switch' incorporates:
       *  Constant: '<S22>/Constant1'
       */
      localB->Switch_i = BattHevP4_P.BattChargeMax;
    } else {
      /* Switch: '<S22>/Switch' */
      localB->Switch_i = BattHevP4_P.BattCapInit;
    }

    /* End of Switch: '<S22>/Switch' */
  }

  /* Integrator: '<S22>/Integrator Limited' */
  /* Limited  Integrator  */
  if (localDW->IntegratorLimited_IWORK != 0) {
    localX->IntegratorLimited_CSTATE = localB->Switch_i;
  }

  if (localX->IntegratorLimited_CSTATE >= BattHevP4_P.BattChargeMax) {
    localX->IntegratorLimited_CSTATE = BattHevP4_P.BattChargeMax;
  } else if (localX->IntegratorLimited_CSTATE <=
             BattHevP4_P.IntegratorLimited_LowerSat) {
    localX->IntegratorLimited_CSTATE = BattHevP4_P.IntegratorLimited_LowerSat;
  }

  /* Product: '<S23>/Divide' incorporates:
   *  Constant: '<S23>/Constant1'
   *  Integrator: '<S22>/Integrator Limited'
   */
  rtb_Em = localX->IntegratorLimited_CSTATE / BattHevP4_P.BattChargeMax;

  /* Lookup_n-D: '<S24>/R' incorporates:
   *  Product: '<S23>/Divide'
   */
  rtb_Product = look2_binlcapw(*rtu_BattTemp, rtb_Em, BattHevP4_P.BattTempBp,
    BattHevP4_P.CapSOCBp, BattHevP4_P.RInt, BattHevP4_P.R_maxIndex, 7U);

  /* Sum: '<S20>/Sum' incorporates:
   *  Gain: '<S24>/Gain1'
   *  Gain: '<S24>/Gain2'
   *  Lookup_n-D: '<S24>/Em'
   *  Product: '<S23>/Divide'
   *  Product: '<S24>/Product'
   *  Sum: '<S24>/Subtract'
   */
  localB->Sum_i = (look1_binlcapw(rtb_Em, BattHevP4_P.CapLUTBp, BattHevP4_P.Em,
    100U) - 1.0 / BattHevP4_P.Np * *rty_BattCurr * rtb_Product) * BattHevP4_P.Ns
    - *rty_BattV;

  /* Gain: '<Root>/SOC Ratio to %1' */
  *rty_BattSoc = BattHevP4_P.SOCRatioto1_Gain * rtb_Em;
}

/* Update for referenced model: 'BattHevP4' */
void BattHevP4_Update(DW_BattHevP4_f_T *localDW)
{
  /* Update for Integrator: '<S4>/Integrator' */
  localDW->Integrator_IWORK = 0;

  /* Update for Integrator: '<S20>/Integrator' */
  localDW->Integrator_IWORK_c = 0;

  /* Update for Integrator: '<S22>/Integrator Limited' */
  localDW->IntegratorLimited_IWORK = 0;
}

/* Derivatives for referenced model: 'BattHevP4' */
void BattHevP4_Deriv(B_BattHevP4_c_T *localB, X_BattHevP4_n_T *localX,
                     XDot_BattHevP4_n_T *localXdot)
{
  boolean_T lsat;
  boolean_T usat;

  /* Derivatives for Integrator: '<S4>/Integrator' */
  localXdot->Integrator_CSTATE = localB->Sum;

  /* Derivatives for Integrator: '<S20>/Integrator' */
  localXdot->Integrator_CSTATE_l = localB->Sum_i;

  /* Derivatives for Integrator: '<S22>/Integrator Limited' */
  lsat = (localX->IntegratorLimited_CSTATE <=
          BattHevP4_P.IntegratorLimited_LowerSat);
  usat = (localX->IntegratorLimited_CSTATE >= BattHevP4_P.BattChargeMax);
  if (((!lsat) && (!usat)) || (lsat && (localB->Gain1 > 0.0)) || (usat &&
       (localB->Gain1 < 0.0))) {
    localXdot->IntegratorLimited_CSTATE = localB->Gain1;
  } else {
    /* in saturation */
    localXdot->IntegratorLimited_CSTATE = 0.0;
  }

  /* End of Derivatives for Integrator: '<S22>/Integrator Limited' */
}

/* Model initialize function */
void BattHevP4_initialize(const char_T **rt_errorStatus, boolean_T
  *rt_stopRequested, RTWSolverInfo *rt_solverInfo, const rtTimingBridge
  *timingBridge, RT_MODEL_BattHevP4_T *const BattHevP4_M, B_BattHevP4_c_T
  *localB, DW_BattHevP4_f_T *localDW, X_BattHevP4_n_T *localX,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)BattHevP4_M, 0,
                sizeof(RT_MODEL_BattHevP4_T));
  BattHevP4_M->timingBridge = (timingBridge);

  /* initialize error status */
  rtmSetErrorStatusPointer(BattHevP4_M, rt_errorStatus);

  /* initialize stop requested flag */
  rtmSetStopRequestedPtr(BattHevP4_M, rt_stopRequested);

  /* initialize RTWSolverInfo */
  BattHevP4_M->solverInfo = (rt_solverInfo);

  /* Set the Timing fields to the appropriate data in the RTWSolverInfo */
  rtmSetSimTimeStepPointer(BattHevP4_M, rtsiGetSimTimeStepPtr
    (BattHevP4_M->solverInfo));
  BattHevP4_M->Timing.stepSize0 = (rtsiGetStepSize(BattHevP4_M->solverInfo));

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_BattHevP4_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_BattHevP4_f_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  {
    BattHevP4_InitializeDataMapInfo(BattHevP4_M, localB, localX);
  }

  /* Initialize Parent model MMI */
  if ((rt_ParentMMI != (NULL)) && (rt_ChildPath != (NULL))) {
    rtwCAPI_SetChildMMI(*rt_ParentMMI, rt_ChildMMIIdx,
                        &(BattHevP4_M->DataMapInfo.mmi));
    rtwCAPI_SetPath(BattHevP4_M->DataMapInfo.mmi, rt_ChildPath);
    rtwCAPI_MMISetContStateStartIndex(BattHevP4_M->DataMapInfo.mmi, rt_CSTATEIdx);
  }
}
