/*
 * BattHevP4_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "BattHevP4".
 *
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:20:52 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "BattHevP4_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "BattHevP4.h"
#include "BattHevP4_capi.h"
#include "BattHevP4_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 8, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Output Filter/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 8, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Output Filter/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 2, 8, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 3, 8, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 4, 8, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 5, 8, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 6, 8, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Divide1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 7, 8, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Unary Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 8, 8, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 9, 8, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 10, TARGET_STRING("BattHevP4/SOC Ratio to %1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 11, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 12, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 13, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 14, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly"),
    TARGET_STRING("thresh"), 0, 0, 0 },

  { 15, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 16, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 17, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 18, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 19, TARGET_STRING("BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 20, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Integrator Limited"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 21, TARGET_STRING("BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Voltage and Power Calculation/R"),
    TARGET_STRING("maxIndex"), 1, 1, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 22, 1, TARGET_STRING(
    "BattHevP4/Lithium Ion Battery Pack/Output Filter/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 1, 1, -1, 0 },

  { 23, 0, TARGET_STRING(
    "BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 1, 1, -1, 0 },

  { 24, 2, TARGET_STRING(
    "BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model/Integrator\nLimited"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 1, 1, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 25, TARGET_STRING("BattCapInit"), 0, 0, 0 },

  { 26, TARGET_STRING("BattChargeMax"), 0, 0, 0 },

  { 27, TARGET_STRING("BattTempBp"), 0, 2, 0 },

  { 28, TARGET_STRING("CapLUTBp"), 0, 3, 0 },

  { 29, TARGET_STRING("CapSOCBp"), 0, 4, 0 },

  { 30, TARGET_STRING("Em"), 0, 3, 0 },

  { 31, TARGET_STRING("Np"), 0, 0, 0 },

  { 32, TARGET_STRING("Ns"), 0, 0, 0 },

  { 33, TARGET_STRING("Plimit"), 0, 0, 0 },

  { 34, TARGET_STRING("RInt"), 0, 5, 0 },

  { 35, TARGET_STRING("Tc"), 0, 0, 0 },

  { 36, TARGET_STRING("Vinit"), 0, 0, 0 },

  { 37, TARGET_STRING("eff"), 0, 0, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void BattHevP4_InitializeDataAddr(void* dataAddr[], B_BattHevP4_c_T
  *localB, X_BattHevP4_n_T *localX)
{
  dataAddr[0] = (void*) (&localB->Product);
  dataAddr[1] = (void*) (&localB->Sum_i);
  dataAddr[2] = (void*) (&localB->Gain2);
  dataAddr[3] = (void*) (&localB->Sum);
  dataAddr[4] = (void*) (&localB->Switch);
  dataAddr[5] = (void*) (&localB->Divide);
  dataAddr[6] = (void*) (&localB->Divide1);
  dataAddr[7] = (void*) (&localB->UnaryMinus);
  dataAddr[8] = (void*) (&localB->Gain1);
  dataAddr[9] = (void*) (&localB->Switch_i);
  dataAddr[10] = (void*) (&BattHevP4_P.SOCRatioto1_Gain);
  dataAddr[11] = (void*) (&BattHevP4_P.div0protectabspoly_thresh);
  dataAddr[12] = (void*) (&BattHevP4_P.Constant_Value);
  dataAddr[13] = (void*) (&BattHevP4_P.Switch_Threshold);
  dataAddr[14] = (void*) (&BattHevP4_P.div0protectpoly_thresh);
  dataAddr[15] = (void*) (&BattHevP4_P.Constant1_Value);
  dataAddr[16] = (void*) (&BattHevP4_P.Constant2_Value);
  dataAddr[17] = (void*) (&BattHevP4_P.Switch_Threshold_d);
  dataAddr[18] = (void*) (&BattHevP4_P.Constant_Value_j);
  dataAddr[19] = (void*) (&BattHevP4_P.Switch1_Threshold);
  dataAddr[20] = (void*) (&BattHevP4_P.IntegratorLimited_LowerSat);
  dataAddr[21] = (void*) (&BattHevP4_P.R_maxIndex[0]);
  dataAddr[22] = (void*) (&localX->Integrator_CSTATE_l);
  dataAddr[23] = (void*) (&localX->Integrator_CSTATE);
  dataAddr[24] = (void*) (&localX->IntegratorLimited_CSTATE);
  dataAddr[25] = (void*) (&BattHevP4_P.BattCapInit);
  dataAddr[26] = (void*) (&BattHevP4_P.BattChargeMax);
  dataAddr[27] = (void*) (&BattHevP4_P.BattTempBp[0]);
  dataAddr[28] = (void*) (&BattHevP4_P.CapLUTBp[0]);
  dataAddr[29] = (void*) (&BattHevP4_P.CapSOCBp[0]);
  dataAddr[30] = (void*) (&BattHevP4_P.Em[0]);
  dataAddr[31] = (void*) (&BattHevP4_P.Np);
  dataAddr[32] = (void*) (&BattHevP4_P.Ns);
  dataAddr[33] = (void*) (&BattHevP4_P.Plimit);
  dataAddr[34] = (void*) (&BattHevP4_P.RInt[0]);
  dataAddr[35] = (void*) (&BattHevP4_P.Tc);
  dataAddr[36] = (void*) (&BattHevP4_P.Vinit);
  dataAddr[37] = (void*) (&BattHevP4_P.eff);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void BattHevP4_InitializeVarDimsAddr(int32_T* vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void BattHevP4_InitializeLoggingFunctions(RTWLoggingFcnPtr loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
  loggingPtrs[14] = (NULL);
  loggingPtrs[15] = (NULL);
  loggingPtrs[16] = (NULL);
  loggingPtrs[17] = (NULL);
  loggingPtrs[18] = (NULL);
  loggingPtrs[19] = (NULL);
  loggingPtrs[20] = (NULL);
  loggingPtrs[21] = (NULL);
  loggingPtrs[22] = (NULL);
  loggingPtrs[23] = (NULL);
  loggingPtrs[24] = (NULL);
  loggingPtrs[25] = (NULL);
  loggingPtrs[26] = (NULL);
  loggingPtrs[27] = (NULL);
  loggingPtrs[28] = (NULL);
  loggingPtrs[29] = (NULL);
  loggingPtrs[30] = (NULL);
  loggingPtrs[31] = (NULL);
  loggingPtrs[32] = (NULL);
  loggingPtrs[33] = (NULL);
  loggingPtrs[34] = (NULL);
  loggingPtrs[35] = (NULL);
  loggingPtrs[36] = (NULL);
  loggingPtrs[37] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  2,                                   /* 2 */
  1,                                   /* 3 */
  1,                                   /* 4 */
  7,                                   /* 5 */
  1,                                   /* 6 */
  101,                                 /* 7 */
  1,                                   /* 8 */
  6,                                   /* 9 */
  7,                                   /* 10 */
  6                                    /* 11 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0001, 0.0
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[1],
    0, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 10,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 12,
    rtModelParameters, 13 },

  { rtBlockStates, 3 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 177714638U,
    3763876140U,
    2976813885U,
    1314313601U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  BattHevP4_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void BattHevP4_InitializeDataMapInfo(RT_MODEL_BattHevP4_T *const BattHevP4_M,
  B_BattHevP4_c_T *localB, X_BattHevP4_n_T *localX)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(BattHevP4_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(BattHevP4_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(BattHevP4_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  BattHevP4_InitializeDataAddr(BattHevP4_M->DataMapInfo.dataAddress, localB,
    localX);
  rtwCAPI_SetDataAddressMap(BattHevP4_M->DataMapInfo.mmi,
    BattHevP4_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  BattHevP4_InitializeVarDimsAddr(BattHevP4_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(BattHevP4_M->DataMapInfo.mmi,
    BattHevP4_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(BattHevP4_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(BattHevP4_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  BattHevP4_InitializeLoggingFunctions(BattHevP4_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(BattHevP4_M->DataMapInfo.mmi,
    BattHevP4_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(BattHevP4_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(BattHevP4_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(BattHevP4_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void BattHevP4_host_InitializeDataMapInfo(BattHevP4_host_DataMapInfo_T
    *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: BattHevP4_capi.c */
