/*
 * Code generation for system model 'BattHevP4'
 * For more details, see corresponding source file BattHevP4.c
 *
 */

#ifndef RTW_HEADER_BattHevP4_h_
#define RTW_HEADER_BattHevP4_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef BattHevP4_COMMON_INCLUDES_
#define BattHevP4_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* BattHevP4_COMMON_INCLUDES_ */

#include "BattHevP4_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rt_nonfinite.h"

/* Block signals for model 'BattHevP4' */
typedef struct {
  real_T Gain2;                        /* '<S4>/Gain2' */
  real_T Switch;                       /* '<S4>/Switch' */
  real_T Sum;                          /* '<S4>/Sum' */
  real_T Divide;                       /* '<S6>/Divide' */
  real_T Divide1;                      /* '<S6>/Divide1' */
  real_T Product;                      /* '<S20>/Product' */
  real_T UnaryMinus;                   /* '<S11>/Unary Minus' */
  real_T Gain1;                        /* '<S22>/Gain1' */
  real_T Switch_i;                     /* '<S22>/Switch' */
  real_T Sum_i;                        /* '<S20>/Sum' */
} B_BattHevP4_c_T;

/* Block states (default storage) for model 'BattHevP4' */
typedef struct {
  int_T Integrator_IWORK;              /* '<S4>/Integrator' */
  int_T Integrator_IWORK_c;            /* '<S20>/Integrator' */
  int_T IntegratorLimited_IWORK;       /* '<S22>/Integrator Limited' */
} DW_BattHevP4_f_T;

/* Continuous states for model 'BattHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S4>/Integrator' */
  real_T Integrator_CSTATE_l;          /* '<S20>/Integrator' */
  real_T IntegratorLimited_CSTATE;     /* '<S22>/Integrator Limited' */
} X_BattHevP4_n_T;

/* State derivatives for model 'BattHevP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S4>/Integrator' */
  real_T Integrator_CSTATE_l;          /* '<S20>/Integrator' */
  real_T IntegratorLimited_CSTATE;     /* '<S22>/Integrator Limited' */
} XDot_BattHevP4_n_T;

/* State Disabled for model 'BattHevP4' */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<S4>/Integrator' */
  boolean_T Integrator_CSTATE_l;       /* '<S20>/Integrator' */
  boolean_T IntegratorLimited_CSTATE;  /* '<S22>/Integrator Limited' */
} XDis_BattHevP4_n_T;

/* Parameters (default storage) */
struct P_BattHevP4_T_ {
  real_T BattCapInit;                  /* Variable: BattCapInit
                                        * Referenced by: '<S18>/Constant1'
                                        */
  real_T BattChargeMax;                /* Variable: BattChargeMax
                                        * Referenced by:
                                        *   '<S22>/Constant1'
                                        *   '<S22>/Integrator Limited'
                                        *   '<S22>/Switch'
                                        *   '<S23>/Constant1'
                                        */
  real_T BattTempBp[7];                /* Variable: BattTempBp
                                        * Referenced by: '<S24>/R'
                                        */
  real_T CapLUTBp[101];                /* Variable: CapLUTBp
                                        * Referenced by: '<S24>/Em'
                                        */
  real_T CapSOCBp[6];                  /* Variable: CapSOCBp
                                        * Referenced by: '<S24>/R'
                                        */
  real_T Em[101];                      /* Variable: Em
                                        * Referenced by: '<S24>/Em'
                                        */
  real_T Np;                           /* Variable: Np
                                        * Referenced by:
                                        *   '<S22>/Gain1'
                                        *   '<S24>/Gain2'
                                        */
  real_T Ns;                           /* Variable: Ns
                                        * Referenced by:
                                        *   '<S20>/Constant2'
                                        *   '<S24>/Gain1'
                                        */
  real_T Plimit;                       /* Variable: Plimit
                                        * Referenced by: '<S4>/MaxLdPwr'
                                        */
  real_T RInt[42];                     /* Variable: RInt
                                        * Referenced by: '<S24>/R'
                                        */
  real_T Tc;                           /* Variable: Tc
                                        * Referenced by:
                                        *   '<S20>/Constant1'
                                        *   '<S20>/Gain1'
                                        *   '<S4>/Gain1'
                                        *   '<S4>/Gain2'
                                        */
  real_T Vinit;                        /* Variable: Vinit
                                        * Referenced by:
                                        *   '<Root>/Constant'
                                        *   '<S4>/Constant1'
                                        */
  real_T eff;                          /* Variable: eff
                                        * Referenced by: '<S6>/Constant'
                                        */
  real_T div0protectabspoly_thresh; /* Mask Parameter: div0protectabspoly_thresh
                                     * Referenced by:
                                     *   '<S9>/Constant'
                                     *   '<S10>/Constant'
                                     */
  real_T div0protectpoly_thresh;       /* Mask Parameter: div0protectpoly_thresh
                                        * Referenced by:
                                        *   '<S12>/Constant'
                                        *   '<S13>/Constant'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S4>/Constant'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S11>/Switch1'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S4>/Switch'
                                        */
  real_T Constant1_Value;              /* Expression: 100
                                        * Referenced by: '<S6>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 100
                                        * Referenced by: '<S6>/Constant2'
                                        */
  real_T Switch_Threshold_d;           /* Expression: 0
                                        * Referenced by: '<S6>/Switch'
                                        */
  real_T Constant_Value_j;             /* Expression: 1
                                        * Referenced by: '<S11>/Constant'
                                        */
  real_T IntegratorLimited_LowerSat;   /* Expression: 0
                                        * Referenced by: '<S22>/Integrator Limited'
                                        */
  real_T SOCRatioto1_Gain;             /* Expression: 100
                                        * Referenced by: '<Root>/SOC Ratio to %1'
                                        */
  uint32_T R_maxIndex[2];              /* Computed Parameter: R_maxIndex
                                        * Referenced by: '<S24>/R'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_BattHevP4_T {
  const char_T **errorStatus;
  RTWSolverInfo *solverInfo;
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[38];
    int32_T* vardimsAddress[38];
    RTWLoggingFcnPtr loggingPtrs[38];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize0;
    SimTimeStep *simTimeStep;
    boolean_T *stopRequestedFlag;
  } Timing;
};

typedef struct {
  B_BattHevP4_c_T rtb;
  DW_BattHevP4_f_T rtdw;
  RT_MODEL_BattHevP4_T rtm;
} MdlrefDW_BattHevP4_T;

/* Model reference registration function */
extern void BattHevP4_initialize(const char_T **rt_errorStatus, boolean_T
  *rt_stopRequested, RTWSolverInfo *rt_solverInfo, const rtTimingBridge
  *timingBridge, RT_MODEL_BattHevP4_T *const BattHevP4_M, B_BattHevP4_c_T
  *localB, DW_BattHevP4_f_T *localDW, X_BattHevP4_n_T *localX,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  BattHevP4_GetCAPIStaticMap(void);
extern void BattHevP4_Init(RT_MODEL_BattHevP4_T * const BattHevP4_M,
  DW_BattHevP4_f_T *localDW, X_BattHevP4_n_T *localX);
extern void BattHevP4_Reset(RT_MODEL_BattHevP4_T * const BattHevP4_M,
  DW_BattHevP4_f_T *localDW, X_BattHevP4_n_T *localX);
extern void BattHevP4_Deriv(B_BattHevP4_c_T *localB, X_BattHevP4_n_T *localX,
  XDot_BattHevP4_n_T *localXdot);
extern void BattHevP4_Update(DW_BattHevP4_f_T *localDW);
extern void BattHevP4(RT_MODEL_BattHevP4_T * const BattHevP4_M, const real_T
                      *rtu_LdCurr, const real_T *rtu_BattTemp, real_T
                      *rty_BattSoc, real_T *rty_BattV, real_T *rty_BattCurr,
                      real_T *rty_HVDC, B_BattHevP4_c_T *localB,
                      DW_BattHevP4_f_T *localDW, X_BattHevP4_n_T *localX);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'BattHevP4'
 * '<S1>'   : 'BattHevP4/DC-DC Converter'
 * '<S2>'   : 'BattHevP4/Lithium Ion Battery Pack'
 * '<S3>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss'
 * '<S4>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response'
 * '<S5>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current'
 * '<S6>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Single Effeciency Measurement'
 * '<S7>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Subsystem'
 * '<S8>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly'
 * '<S9>'   : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly/Compare To Constant'
 * '<S10>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/DC to DC Voltage Response/div0protect - abs poly/Compare To Constant1'
 * '<S11>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly'
 * '<S12>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Compare To Constant'
 * '<S13>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Electrical Current/div0protect - poly/Compare To Constant1'
 * '<S14>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Subsystem/Power Accounting Bus Creator'
 * '<S15>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Subsystem/Power Accounting Bus Creator/No PwrStored Input'
 * '<S16>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Subsystem/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S17>'  : 'BattHevP4/DC-DC Converter/DC to DC Converter Core Single Efficiency Loss/Subsystem/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S18>'  : 'BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal'
 * '<S19>'  : 'BattHevP4/Lithium Ion Battery Pack/Info Bus'
 * '<S20>'  : 'BattHevP4/Lithium Ion Battery Pack/Output Filter'
 * '<S21>'  : 'BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery'
 * '<S22>'  : 'BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Charge Model'
 * '<S23>'  : 'BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/State of Charge Capacity'
 * '<S24>'  : 'BattHevP4/Lithium Ion Battery Pack/Datasheet Battery Internal/Datasheet Battery/Voltage and Power Calculation'
 * '<S25>'  : 'BattHevP4/Lithium Ion Battery Pack/Info Bus/Power Accounting Bus Creator'
 * '<S26>'  : 'BattHevP4/Lithium Ion Battery Pack/Info Bus/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S27>'  : 'BattHevP4/Lithium Ion Battery Pack/Info Bus/Power Accounting Bus Creator/PwrStored Input'
 * '<S28>'  : 'BattHevP4/Lithium Ion Battery Pack/Info Bus/Power Accounting Bus Creator/PwrTrnsfrd Input'
 */
#endif                                 /* RTW_HEADER_BattHevP4_h_ */
