/*
 * BattHevP4_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "BattHevP4".
 *
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:20:52 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BattHevP4_types_h_
#define RTW_HEADER_BattHevP4_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_BattHevP4_T_ P_BattHevP4_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_BattHevP4_T RT_MODEL_BattHevP4_T;

#endif                                 /* RTW_HEADER_BattHevP4_types_h_ */
