/*
 * Code generation for system model 'MotMappedP4'
 * For more details, see corresponding source file MotMappedP4.c
 *
 */

#ifndef RTW_HEADER_MotMappedP4_h_
#define RTW_HEADER_MotMappedP4_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef MotMappedP4_COMMON_INCLUDES_
#define MotMappedP4_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* MotMappedP4_COMMON_INCLUDES_ */

#include "MotMappedP4_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"

/* Block signals for model 'MotMappedP4' */
typedef struct {
  real_T Sum;                          /* '<S6>/Sum' */
} B_MotMappedP4_c_T;

/* Continuous states for model 'MotMappedP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S6>/Integrator' */
} X_MotMappedP4_n_T;

/* State derivatives for model 'MotMappedP4' */
typedef struct {
  real_T Integrator_CSTATE;            /* '<S6>/Integrator' */
} XDot_MotMappedP4_n_T;

/* State Disabled for model 'MotMappedP4' */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<S6>/Integrator' */
} XDis_MotMappedP4_n_T;

/* Parameters (default storage) */
struct P_MotMappedP4_T_ {
  real_T Tc;                           /* Variable: Tc
                                        * Referenced by: '<S6>/Gain1'
                                        */
  real_T MaxTorqueLimit_tableData[27]; /* Expression: T_t_extended
                                        * Referenced by: '<S6>/Max Torque Limit'
                                        */
  real_T MaxTorqueLimit_bp01Data[27];  /* Expression: w_t_extended
                                        * Referenced by: '<S6>/Max Torque Limit'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S6>/Integrator'
                                        */
  real_T Interpolatedzerocrossing_tableData[2];/* Expression: [-1 1]
                                                * Referenced by: '<S6>/Interpolated zero-crossing'
                                                */
  real_T Interpolatedzerocrossing_bp01Data[2];/* Expression: [-1 1]
                                               * Referenced by: '<S6>/Interpolated zero-crossing'
                                               */
  real_T uDLookupTable_tableData[567]; /* Expression: x_losses_mat
                                        * Referenced by: '<S5>/2-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[27];   /* Expression: x_w_eff_vec
                                        * Referenced by: '<S5>/2-D Lookup Table'
                                        */
  real_T uDLookupTable_bp02Data[21];   /* Expression: x_T_eff_vec
                                        * Referenced by: '<S5>/2-D Lookup Table'
                                        */
  real_T Saturation_UpperSat;          /* Expression: Inf
                                        * Referenced by: '<S3>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0.0001
                                        * Referenced by: '<S3>/Saturation'
                                        */
  uint32_T uDLookupTable_maxIndex[2];
                                   /* Computed Parameter: uDLookupTable_maxIndex
                                    * Referenced by: '<S5>/2-D Lookup Table'
                                    */
};

/* Real-time Model Data Structure */
struct tag_RTM_MotMappedP4_T {
  const char_T **errorStatus;
  RTWSolverInfo *solverInfo;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[14];
    int32_T* vardimsAddress[14];
    RTWLoggingFcnPtr loggingPtrs[14];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize0;
    SimTimeStep *simTimeStep;
    boolean_T *stopRequestedFlag;
  } Timing;
};

typedef struct {
  B_MotMappedP4_c_T rtb;
  RT_MODEL_MotMappedP4_T rtm;
} MdlrefDW_MotMappedP4_T;

/* Model reference registration function */
extern void MotMappedP4_initialize(const char_T **rt_errorStatus, boolean_T
  *rt_stopRequested, RTWSolverInfo *rt_solverInfo, RT_MODEL_MotMappedP4_T *const
  MotMappedP4_M, B_MotMappedP4_c_T *localB, X_MotMappedP4_n_T *localX,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  MotMappedP4_GetCAPIStaticMap(void);
extern void MotMappedP4_Init(X_MotMappedP4_n_T *localX);
extern void MotMappedP4_Reset(X_MotMappedP4_n_T *localX);
extern void MotMappedP4_Deriv(B_MotMappedP4_c_T *localB, XDot_MotMappedP4_n_T
  *localXdot);
extern void MotMappedP4_Update(void);
extern void MotMappedP4(const real_T *rtu_MotTrqCmd, const real_T *rtu_MotSpd,
  const real_T *rtu_BusVolt, real_T *rty_MotTrq, real_T *rty_MotCurr,
  B_MotMappedP4_c_T *localB, X_MotMappedP4_n_T *localX);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'MotMappedP4'
 * '<S1>'   : 'MotMappedP4/Mapped Motor'
 * '<S2>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4'
 * '<S3>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Electrical Current'
 * '<S4>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Motor Units'
 * '<S5>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Tabular Power Loss Data'
 * '<S6>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Tabulated Torque-speed Envelope'
 * '<S7>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Motor Units/Power Accounting Bus Creator'
 * '<S8>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Motor Units/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S9>'   : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Motor Units/Power Accounting Bus Creator/PwrStored Input'
 * '<S10>'  : 'MotMappedP4/Mapped Motor/Mapped Motor Core Speed 4/Motor Units/Power Accounting Bus Creator/PwrTrnsfrd Input'
 */
#endif                                 /* RTW_HEADER_MotMappedP4_h_ */
