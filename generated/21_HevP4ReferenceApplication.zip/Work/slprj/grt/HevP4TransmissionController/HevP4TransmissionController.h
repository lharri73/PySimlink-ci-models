/*
 * Code generation for system model 'HevP4TransmissionController'
 * For more details, see corresponding source file HevP4TransmissionController.c
 *
 */

#ifndef RTW_HEADER_HevP4TransmissionController_h_
#define RTW_HEADER_HevP4TransmissionController_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef HevP4TransmissionController_COMMON_INCLUDES_
#define HevP4TransmissionController_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                        /* HevP4TransmissionController_COMMON_INCLUDES_ */

#include "HevP4TransmissionController_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"

/* Block signals for system '<S2>/calc' */
typedef struct {
  real_T Add4;                         /* '<S3>/Add4' */
} B_calc_HevP4TransmissionController_T;

/* Block signals for model 'HevP4TransmissionController' */
typedef struct {
  real_T gear_o;                       /* '<S1>/Chart' */
  real_T pedal_b;                      /* '<S1>/Chart' */
  real_T speed;                        /* '<S1>/Chart' */
  B_calc_HevP4TransmissionController_T calc;/* '<S2>/calc' */
} B_HevP4TransmissionController_c_T;

/* Block states (default storage) for model 'HevP4TransmissionController' */
typedef struct {
  int32_T sfEvent;                     /* '<S1>/Chart' */
  uint8_T is_active_c1_HevP4TransmissionController;/* '<S1>/Chart' */
  uint8_T is_GearState;                /* '<S1>/Chart' */
  uint8_T is_active_GearState;         /* '<S1>/Chart' */
  uint8_T is_SelectionState;           /* '<S1>/Chart' */
  uint8_T is_active_SelectionState;    /* '<S1>/Chart' */
  uint8_T temporalCounter_i1;          /* '<S1>/Chart' */
  boolean_T isStable;                  /* '<S1>/Chart' */
} DW_HevP4TransmissionController_f_T;

/* Parameters for system: '<S2>/calc' */
struct P_calc_HevP4TransmissionController_T_ {
  real_T SpdThr_Y0;                    /* Computed Parameter: SpdThr_Y0
                                        * Referenced by: '<S3>/SpdThr'
                                        */
  uint32_T CalculateUpshiftThreshold_maxIndex[2];
                       /* Computed Parameter: CalculateUpshiftThreshold_maxIndex
                        * Referenced by: '<S3>/Calculate Upshift Threshold'
                        */
  uint32_T CalculateDownshiftThreshold_maxIndex[2];
                     /* Computed Parameter: CalculateDownshiftThreshold_maxIndex
                      * Referenced by: '<S3>/Calculate  Downshift Threshold'
                      */
};

/* Parameters (default storage) */
struct P_HevP4TransmissionController_T_ {
  real_T Dn_Shft_Spd[20];              /* Variable: Dn_Shft_Spd
                                        * Referenced by:
                                        *   '<S3>/Calculate  Downshift Threshold'
                                        *   '<S4>/Calculate  Downshift Threshold'
                                        */
  real_T Gear_Dn_bpt[5];               /* Variable: Gear_Dn_bpt
                                        * Referenced by:
                                        *   '<S3>/Calculate  Downshift Threshold'
                                        *   '<S4>/Calculate  Downshift Threshold'
                                        */
  real_T Gear_Up_bpt[5];               /* Variable: Gear_Up_bpt
                                        * Referenced by:
                                        *   '<S3>/Calculate Upshift Threshold'
                                        *   '<S5>/Calculate Upshift Threshold'
                                        */
  real_T Pdl_Pos_Dn_bpt[4];            /* Variable: Pdl_Pos_Dn_bpt
                                        * Referenced by:
                                        *   '<S3>/Calculate  Downshift Threshold'
                                        *   '<S4>/Calculate  Downshift Threshold'
                                        */
  real_T Pdl_Pos_Up_bpt[4];            /* Variable: Pdl_Pos_Up_bpt
                                        * Referenced by:
                                        *   '<S3>/Calculate Upshift Threshold'
                                        *   '<S5>/Calculate Upshift Threshold'
                                        */
  real_T Up_Shft_Spd[20];              /* Variable: Up_Shft_Spd
                                        * Referenced by:
                                        *   '<S3>/Calculate Upshift Threshold'
                                        *   '<S5>/Calculate Upshift Threshold'
                                        */
  real_T up_th_Y0;                     /* Computed Parameter: up_th_Y0
                                        * Referenced by: '<S5>/up_th'
                                        */
  real_T down_th_Y0;                   /* Computed Parameter: down_th_Y0
                                        * Referenced by: '<S4>/down_th'
                                        */
  uint32_T CalculateUpshiftThreshold_maxIndex[2];
                       /* Computed Parameter: CalculateUpshiftThreshold_maxIndex
                        * Referenced by: '<S5>/Calculate Upshift Threshold'
                        */
  uint32_T CalculateDownshiftThreshold_maxIndex[2];
                     /* Computed Parameter: CalculateDownshiftThreshold_maxIndex
                      * Referenced by: '<S4>/Calculate  Downshift Threshold'
                      */
  P_calc_HevP4TransmissionController_T calc;/* '<S2>/calc' */
};

/* Real-time Model Data Structure */
struct tag_RTM_HevP4TransmissionController_T {
  const char_T **errorStatus;
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[15];
    int32_T* vardimsAddress[15];
    RTWLoggingFcnPtr loggingPtrs[15];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    int_T mdlref_GlobalTID[2];
  } Timing;
};

typedef struct {
  B_HevP4TransmissionController_c_T rtb;
  DW_HevP4TransmissionController_f_T rtdw;
  RT_MODEL_HevP4TransmissionController_T rtm;
} MdlrefDW_HevP4TransmissionController_T;

/* Model reference registration function */
extern void HevP4TransmissionController_initialize(const char_T **rt_errorStatus,
  const rtTimingBridge *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_HevP4TransmissionController_T *const HevP4TransmissionController_M,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath,
  int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  HevP4TransmissionController_GetCAPIStaticMap(void);
extern void HevP4TransmissionController_calc_Init
  (B_calc_HevP4TransmissionController_T *localB,
   P_calc_HevP4TransmissionController_T *localP);
extern void HevP4TransmissionController_calc(real_T rtu_gear, real_T rtu_pedal,
  real_T rtu_speed, B_calc_HevP4TransmissionController_T *localB,
  P_calc_HevP4TransmissionController_T *localP);
extern void HevP4TransmissionController_Init(real_T *rty_GearState,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW);
extern void HevP4TransmissionController_Reset(real_T *rty_GearState,
  DW_HevP4TransmissionController_f_T *localDW);
extern void HevP4TransmissionController(RT_MODEL_HevP4TransmissionController_T *
  const HevP4TransmissionController_M, const real_T *rtu_VehSpd, const real_T
  *rtu_AccelPdl, const real_T *rtu_Neutral, real_T *rty_GearState,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HevP4TransmissionController'
 * '<S1>'   : 'HevP4TransmissionController/Shift state'
 * '<S2>'   : 'HevP4TransmissionController/Shift state/Chart'
 * '<S3>'   : 'HevP4TransmissionController/Shift state/Chart/calc'
 * '<S4>'   : 'HevP4TransmissionController/Shift state/Chart/calc_down'
 * '<S5>'   : 'HevP4TransmissionController/Shift state/Chart/calc_up'
 */
#endif                           /* RTW_HEADER_HevP4TransmissionController_h_ */
