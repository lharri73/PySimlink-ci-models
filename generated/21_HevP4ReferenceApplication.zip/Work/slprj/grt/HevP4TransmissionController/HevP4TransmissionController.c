/*
 * Code generation for system model 'HevP4TransmissionController'
 *
 * Model                      : HevP4TransmissionController
 * Model version              : 4.1
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:18 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "HevP4TransmissionController_capi.h"
#include "HevP4TransmissionController.h"
#include "HevP4TransmissionController_private.h"
#include "look2_binlcapw.h"

/* Named constants for Chart: '<S1>/Chart' */
#define HevP4TransmissionController_CALL_EVENT (-1)
#define HevP4TransmissionController_IN_DownShifting ((uint8_T)1U)
#define HevP4TransmissionController_IN_G1 ((uint8_T)1U)
#define HevP4TransmissionController_IN_G2 ((uint8_T)2U)
#define HevP4TransmissionController_IN_G3 ((uint8_T)3U)
#define HevP4TransmissionController_IN_G4 ((uint8_T)4U)
#define HevP4TransmissionController_IN_G5 ((uint8_T)5U)
#define HevP4TransmissionController_IN_G6 ((uint8_T)6U)
#define HevP4TransmissionController_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define HevP4TransmissionController_IN_Neutral ((uint8_T)7U)
#define HevP4TransmissionController_IN_SteadyState ((uint8_T)2U)
#define HevP4TransmissionController_IN_UpShifting ((uint8_T)3U)
#define HevP4TransmissionController_IN_preDownShifting ((uint8_T)4U)
#define HevP4TransmissionController_IN_preUpShifting ((uint8_T)5U)
#define HevP4TransmissionController_event_Down (0)
#define HevP4TransmissionController_event_Up (1)

P_HevP4TransmissionController_T HevP4TransmissionController_P = {
  /* Variable: Dn_Shft_Spd
   * Referenced by:
   *   '<S3>/Calculate  Downshift Threshold'
   *   '<S4>/Calculate  Downshift Threshold'
   */
  { 3.0, 3.0, 10.0, 10.0, 7.0, 7.0, 17.0, 17.0, 11.0, 11.0, 26.0, 26.0, 15.0,
    15.0, 35.0, 35.0, 19.0, 19.0, 49.0, 49.0 },

  /* Variable: Gear_Dn_bpt
   * Referenced by:
   *   '<S3>/Calculate  Downshift Threshold'
   *   '<S4>/Calculate  Downshift Threshold'
   */
  { 2.0, 3.0, 4.0, 5.0, 6.0 },

  /* Variable: Gear_Up_bpt
   * Referenced by:
   *   '<S3>/Calculate Upshift Threshold'
   *   '<S5>/Calculate Upshift Threshold'
   */
  { 1.0, 2.0, 3.0, 4.0, 5.0 },

  /* Variable: Pdl_Pos_Dn_bpt
   * Referenced by:
   *   '<S3>/Calculate  Downshift Threshold'
   *   '<S4>/Calculate  Downshift Threshold'
   */
  { 0.0, 0.6, 0.9, 1.0 },

  /* Variable: Pdl_Pos_Up_bpt
   * Referenced by:
   *   '<S3>/Calculate Upshift Threshold'
   *   '<S5>/Calculate Upshift Threshold'
   */
  { 0.0, 0.25, 0.9, 1.0 },

  /* Variable: Up_Shft_Spd
   * Referenced by:
   *   '<S3>/Calculate Upshift Threshold'
   *   '<S5>/Calculate Upshift Threshold'
   */
  { 5.0, 5.0, 12.0, 12.0, 9.0, 9.0, 19.0, 19.0, 13.0, 13.0, 28.0, 28.0, 17.0,
    17.0, 37.0, 37.0, 21.0, 21.0, 51.0, 51.0 },

  /* Computed Parameter: up_th_Y0
   * Referenced by: '<S5>/up_th'
   */
  0.0,

  /* Computed Parameter: down_th_Y0
   * Referenced by: '<S4>/down_th'
   */
  0.0,

  /* Computed Parameter: CalculateUpshiftThreshold_maxIndex
   * Referenced by: '<S5>/Calculate Upshift Threshold'
   */
  { 3U, 4U },

  /* Computed Parameter: CalculateDownshiftThreshold_maxIndex
   * Referenced by: '<S4>/Calculate  Downshift Threshold'
   */
  { 3U, 4U },

  /* Start of '<S2>/calc' */
  {
    /* Computed Parameter: SpdThr_Y0
     * Referenced by: '<S3>/SpdThr'
     */
    0.0,

    /* Computed Parameter: CalculateUpshiftThreshold_maxIndex
     * Referenced by: '<S3>/Calculate Upshift Threshold'
     */
    { 3U, 4U },

    /* Computed Parameter: CalculateDownshiftThreshold_maxIndex
     * Referenced by: '<S3>/Calculate  Downshift Threshold'
     */
    { 3U, 4U }
  }
  /* End of '<S2>/calc' */
};

/* Forward declaration for local functions */
static void HevP4TransmissionController_GearState(const real_T *rtu_VehSpd,
  const real_T *rtu_AccelPdl, const real_T *rtu_Neutral, real_T *rty_GearState,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW);

/* System initialize for function-call system: '<S2>/calc' */
void HevP4TransmissionController_calc_Init(B_calc_HevP4TransmissionController_T *
  localB, P_calc_HevP4TransmissionController_T *localP)
{
  /* SystemInitialize for Sum: '<S3>/Add4' incorporates:
   *  Outport: '<S3>/SpdThr'
   */
  localB->Add4 = localP->SpdThr_Y0;
}

/* Output and update for function-call system: '<S2>/calc' */
void HevP4TransmissionController_calc(real_T rtu_gear, real_T rtu_pedal, real_T
  rtu_speed, B_calc_HevP4TransmissionController_T *localB,
  P_calc_HevP4TransmissionController_T *localP)
{
  /* Sum: '<S3>/Add4' incorporates:
   *  Lookup_n-D: '<S3>/Calculate  Downshift Threshold'
   *  Lookup_n-D: '<S3>/Calculate Upshift Threshold'
   *  Sum: '<S3>/Add1'
   *  Sum: '<S3>/Add3'
   */
  localB->Add4 = (look2_binlcapw(rtu_pedal, rtu_gear,
    HevP4TransmissionController_P.Pdl_Pos_Up_bpt,
    HevP4TransmissionController_P.Gear_Up_bpt,
    HevP4TransmissionController_P.Up_Shft_Spd,
    localP->CalculateUpshiftThreshold_maxIndex, 4U) - rtu_speed) - (rtu_speed -
    look2_binlcapw(rtu_pedal, rtu_gear,
                   HevP4TransmissionController_P.Pdl_Pos_Dn_bpt,
                   HevP4TransmissionController_P.Gear_Dn_bpt,
                   HevP4TransmissionController_P.Dn_Shft_Spd,
                   localP->CalculateDownshiftThreshold_maxIndex, 4U));
}

/* Function for Chart: '<S1>/Chart' */
static void HevP4TransmissionController_GearState(const real_T *rtu_VehSpd,
  const real_T *rtu_AccelPdl, const real_T *rtu_Neutral, real_T *rty_GearState,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW)
{
  switch (localDW->is_GearState) {
   case HevP4TransmissionController_IN_G1:
    if (localDW->sfEvent == HevP4TransmissionController_event_Up) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G2;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 2.0;
    } else if (*rtu_Neutral != 0.0) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_Neutral;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 0.0;
    }
    break;

   case HevP4TransmissionController_IN_G2:
    if (localDW->sfEvent == HevP4TransmissionController_event_Up) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G3;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 3.0;
    } else if (localDW->sfEvent == HevP4TransmissionController_event_Down) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G1;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 1.0;
    } else {
      localB->gear_o = 2.0;

      /* Chart: '<S1>/Chart' */
      localB->pedal_b = *rtu_AccelPdl;
      localB->speed = *rtu_VehSpd;

      /* Outputs for Function Call SubSystem: '<S2>/calc' */
      HevP4TransmissionController_calc(localB->gear_o, localB->pedal_b,
        localB->speed, &localB->calc, &HevP4TransmissionController_P.calc);

      /* End of Outputs for SubSystem: '<S2>/calc' */
    }
    break;

   case HevP4TransmissionController_IN_G3:
    if (localDW->sfEvent == HevP4TransmissionController_event_Up) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G4;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 4.0;
    } else if (localDW->sfEvent == HevP4TransmissionController_event_Down) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G2;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 2.0;
    } else {
      localB->gear_o = 3.0;

      /* Chart: '<S1>/Chart' */
      localB->pedal_b = *rtu_AccelPdl;
      localB->speed = *rtu_VehSpd;

      /* Outputs for Function Call SubSystem: '<S2>/calc' */
      HevP4TransmissionController_calc(localB->gear_o, localB->pedal_b,
        localB->speed, &localB->calc, &HevP4TransmissionController_P.calc);

      /* End of Outputs for SubSystem: '<S2>/calc' */
    }
    break;

   case HevP4TransmissionController_IN_G4:
    if (localDW->sfEvent == HevP4TransmissionController_event_Up) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G5;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 5.0;
    } else if (localDW->sfEvent == HevP4TransmissionController_event_Down) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G3;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 3.0;
    } else {
      localB->gear_o = 4.0;

      /* Chart: '<S1>/Chart' */
      localB->pedal_b = *rtu_AccelPdl;
      localB->speed = *rtu_VehSpd;

      /* Outputs for Function Call SubSystem: '<S2>/calc' */
      HevP4TransmissionController_calc(localB->gear_o, localB->pedal_b,
        localB->speed, &localB->calc, &HevP4TransmissionController_P.calc);

      /* End of Outputs for SubSystem: '<S2>/calc' */
    }
    break;

   case HevP4TransmissionController_IN_G5:
    if (localDW->sfEvent == HevP4TransmissionController_event_Up) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G6;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 6.0;
    } else if (localDW->sfEvent == HevP4TransmissionController_event_Down) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G4;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 4.0;
    } else {
      localB->gear_o = 5.0;

      /* Chart: '<S1>/Chart' */
      localB->pedal_b = *rtu_AccelPdl;
      localB->speed = *rtu_VehSpd;

      /* Outputs for Function Call SubSystem: '<S2>/calc' */
      HevP4TransmissionController_calc(localB->gear_o, localB->pedal_b,
        localB->speed, &localB->calc, &HevP4TransmissionController_P.calc);

      /* End of Outputs for SubSystem: '<S2>/calc' */
    }
    break;

   case HevP4TransmissionController_IN_G6:
    if (localDW->sfEvent == HevP4TransmissionController_event_Down) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G5;

      /* Chart: '<S1>/Chart' */
      *rty_GearState = 5.0;
    }
    break;

   case HevP4TransmissionController_IN_Neutral:
    /* Chart: '<S1>/Chart' */
    if (!(*rtu_Neutral != 0.0)) {
      localDW->isStable = false;
      localDW->is_GearState = HevP4TransmissionController_IN_G1;
      *rty_GearState = 1.0;
    }
    break;

   default:
    /* Unreachable state, for coverage only */
    localDW->is_GearState = HevP4TransmissionController_IN_NO_ACTIVE_CHILD;
    break;
  }
}

/* System initialize for referenced model: 'HevP4TransmissionController' */
void HevP4TransmissionController_Init(real_T *rty_GearState,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW)
{
  localDW->sfEvent = HevP4TransmissionController_CALL_EVENT;
  localDW->is_active_GearState = 0U;
  localDW->is_GearState = HevP4TransmissionController_IN_NO_ACTIVE_CHILD;
  localDW->is_active_SelectionState = 0U;
  localDW->is_SelectionState = HevP4TransmissionController_IN_NO_ACTIVE_CHILD;
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c1_HevP4TransmissionController = 0U;
  *rty_GearState = 1.0;

  /* SystemInitialize for Chart: '<S1>/Chart' incorporates:
   *  SubSystem: '<S2>/calc'
   */
  HevP4TransmissionController_calc_Init(&localB->calc,
    &HevP4TransmissionController_P.calc);
}

/* System reset for referenced model: 'HevP4TransmissionController' */
void HevP4TransmissionController_Reset(real_T *rty_GearState,
  DW_HevP4TransmissionController_f_T *localDW)
{
  /* SystemReset for Chart: '<S1>/Chart' */
  localDW->sfEvent = HevP4TransmissionController_CALL_EVENT;
  localDW->is_active_GearState = 0U;
  localDW->is_GearState = HevP4TransmissionController_IN_NO_ACTIVE_CHILD;
  localDW->is_active_SelectionState = 0U;
  localDW->is_SelectionState = HevP4TransmissionController_IN_NO_ACTIVE_CHILD;
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c1_HevP4TransmissionController = 0U;
  *rty_GearState = 1.0;
}

/* Output and update for referenced model: 'HevP4TransmissionController' */
void HevP4TransmissionController(RT_MODEL_HevP4TransmissionController_T * const
  HevP4TransmissionController_M, const real_T *rtu_VehSpd, const real_T
  *rtu_AccelPdl, const real_T *rtu_Neutral, real_T *rty_GearState,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW)
{
  real_T pedal;
  real_T pedal_e;
  int32_T b_previousEvent;
  int32_T superStepCount;
  if (rtmIsSampleHit(HevP4TransmissionController_M, 1, 0)) {
    /* Chart: '<S1>/Chart' */
    if (localDW->temporalCounter_i1 < 63U) {
      localDW->temporalCounter_i1++;
    }

    localDW->sfEvent = HevP4TransmissionController_CALL_EVENT;
    superStepCount = 0;
    do {
      localDW->isStable = true;
      if (localDW->is_active_c1_HevP4TransmissionController == 0U) {
        localDW->is_active_c1_HevP4TransmissionController = 1U;
        localDW->is_active_GearState = 1U;
        localDW->is_GearState = HevP4TransmissionController_IN_G1;
        *rty_GearState = 1.0;
        localDW->is_active_SelectionState = 1U;
        localDW->isStable = false;
        localDW->is_SelectionState = HevP4TransmissionController_IN_SteadyState;
      } else {
        if (localDW->is_active_GearState != 0U) {
          HevP4TransmissionController_GearState(rtu_VehSpd, rtu_AccelPdl,
            rtu_Neutral, rty_GearState, localB, localDW);
        }

        if (localDW->is_active_SelectionState != 0U) {
          pedal = *rtu_AccelPdl;
          pedal = look2_binlcapw(pedal, *rty_GearState,
            HevP4TransmissionController_P.Pdl_Pos_Up_bpt,
            HevP4TransmissionController_P.Gear_Up_bpt,
            HevP4TransmissionController_P.Up_Shft_Spd,
            HevP4TransmissionController_P.CalculateUpshiftThreshold_maxIndex, 4U);
          pedal_e = *rtu_AccelPdl;
          pedal_e = look2_binlcapw(pedal_e, *rty_GearState,
            HevP4TransmissionController_P.Pdl_Pos_Dn_bpt,
            HevP4TransmissionController_P.Gear_Dn_bpt,
            HevP4TransmissionController_P.Dn_Shft_Spd,
            HevP4TransmissionController_P.CalculateDownshiftThreshold_maxIndex,
            4U);
          switch (localDW->is_SelectionState) {
           case HevP4TransmissionController_IN_DownShifting:
            b_previousEvent = localDW->sfEvent;
            localDW->sfEvent = HevP4TransmissionController_event_Down;
            if (localDW->is_active_GearState != 0U) {
              HevP4TransmissionController_GearState(rtu_VehSpd, rtu_AccelPdl,
                rtu_Neutral, rty_GearState, localB, localDW);
            }

            localDW->sfEvent = b_previousEvent;
            localDW->isStable = false;
            localDW->is_SelectionState =
              HevP4TransmissionController_IN_SteadyState;
            break;

           case HevP4TransmissionController_IN_SteadyState:
            if ((*rtu_VehSpd < pedal_e) && (*rty_GearState > 1.0)) {
              localDW->isStable = false;
              localDW->is_SelectionState =
                HevP4TransmissionController_IN_preDownShifting;
              localDW->temporalCounter_i1 = 0U;
            } else if ((*rtu_VehSpd > pedal) && (*rty_GearState <= 5.0) &&
                       (floor(*rty_GearState) == *rty_GearState)) {
              localDW->isStable = false;
              localDW->is_SelectionState =
                HevP4TransmissionController_IN_preUpShifting;
              localDW->temporalCounter_i1 = 0U;
            }
            break;

           case HevP4TransmissionController_IN_UpShifting:
            b_previousEvent = localDW->sfEvent;
            localDW->sfEvent = HevP4TransmissionController_event_Up;
            if (localDW->is_active_GearState != 0U) {
              HevP4TransmissionController_GearState(rtu_VehSpd, rtu_AccelPdl,
                rtu_Neutral, rty_GearState, localB, localDW);
            }

            localDW->sfEvent = b_previousEvent;
            localDW->isStable = false;
            localDW->is_SelectionState =
              HevP4TransmissionController_IN_SteadyState;
            break;

           case HevP4TransmissionController_IN_preDownShifting:
            if ((localDW->temporalCounter_i1 >= 50U) && (*rtu_VehSpd < pedal_e -
                 2.0)) {
              localDW->isStable = false;
              localDW->is_SelectionState =
                HevP4TransmissionController_IN_DownShifting;
            } else if (*rtu_VehSpd >= pedal_e) {
              localDW->isStable = false;
              localDW->is_SelectionState =
                HevP4TransmissionController_IN_SteadyState;
            }
            break;

           case HevP4TransmissionController_IN_preUpShifting:
            if ((localDW->temporalCounter_i1 >= 50U) && (*rtu_VehSpd > pedal)) {
              localDW->isStable = false;
              localDW->is_SelectionState =
                HevP4TransmissionController_IN_UpShifting;
            } else if (*rtu_VehSpd <= pedal) {
              localDW->isStable = false;
              localDW->is_SelectionState =
                HevP4TransmissionController_IN_SteadyState;
            }
            break;

           default:
            /* Unreachable state, for coverage only */
            localDW->is_SelectionState =
              HevP4TransmissionController_IN_NO_ACTIVE_CHILD;
            break;
          }
        }
      }

      superStepCount++;
    } while ((!localDW->isStable) && ((uint32_T)superStepCount <= 1000U));

    /* End of Chart: '<S1>/Chart' */
  }
}

/* Model initialize function */
void HevP4TransmissionController_initialize(const char_T **rt_errorStatus, const
  rtTimingBridge *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_HevP4TransmissionController_T *const HevP4TransmissionController_M,
  B_HevP4TransmissionController_c_T *localB, DW_HevP4TransmissionController_f_T *
  localDW, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath,
  int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)HevP4TransmissionController_M, 0,
                sizeof(RT_MODEL_HevP4TransmissionController_T));

  /* setup the global timing engine */
  HevP4TransmissionController_M->Timing.mdlref_GlobalTID[0] = mdlref_TID0;
  HevP4TransmissionController_M->Timing.mdlref_GlobalTID[1] = mdlref_TID1;
  HevP4TransmissionController_M->timingBridge = (timingBridge);

  /* initialize error status */
  rtmSetErrorStatusPointer(HevP4TransmissionController_M, rt_errorStatus);

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_HevP4TransmissionController_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_HevP4TransmissionController_f_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  {
    HevP4TransmissionController_InitializeDataMapInfo
      (HevP4TransmissionController_M, localB);
  }

  /* Initialize Parent model MMI */
  if ((rt_ParentMMI != (NULL)) && (rt_ChildPath != (NULL))) {
    rtwCAPI_SetChildMMI(*rt_ParentMMI, rt_ChildMMIIdx,
                        &(HevP4TransmissionController_M->DataMapInfo.mmi));
    rtwCAPI_SetPath(HevP4TransmissionController_M->DataMapInfo.mmi, rt_ChildPath);
    rtwCAPI_MMISetContStateStartIndex
      (HevP4TransmissionController_M->DataMapInfo.mmi, rt_CSTATEIdx);
  }
}
