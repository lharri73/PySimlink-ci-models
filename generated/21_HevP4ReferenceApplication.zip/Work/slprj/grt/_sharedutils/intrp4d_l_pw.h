/*
 * intrp4d_l_pw.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:03 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef RTW_HEADER_intrp4d_l_pw_h_
#define RTW_HEADER_intrp4d_l_pw_h_
#include "rtwtypes.h"

extern real_T intrp4d_l_pw(const uint32_T bpIndex[], const real_T frac[], const
  real_T table[], const uint32_T stride[]);

#endif                                 /* RTW_HEADER_intrp4d_l_pw_h_ */
