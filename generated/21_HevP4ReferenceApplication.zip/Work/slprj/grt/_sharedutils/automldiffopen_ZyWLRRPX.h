/*
 * automldiffopen_ZyWLRRPX.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:03 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef RTW_HEADER_automldiffopen_ZyWLRRPX_h_
#define RTW_HEADER_automldiffopen_ZyWLRRPX_h_
#include "rtwtypes.h"

extern void automldiffopen_ZyWLRRPX(const real_T u[3], real_T bw1, real_T bd,
  real_T bw2, real_T Ndiff, real_T shaftSwitch, real_T Jd, real_T Jw1, real_T
  Jw2, const real_T x[2], real_T y[3], real_T xdot[2]);

#endif                               /* RTW_HEADER_automldiffopen_ZyWLRRPX_h_ */
