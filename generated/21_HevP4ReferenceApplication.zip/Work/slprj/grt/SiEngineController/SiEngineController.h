/*
 * Code generation for system model 'SiEngineController'
 * For more details, see corresponding source file SiEngineController.c
 *
 */

#ifndef RTW_HEADER_SiEngineController_h_
#define RTW_HEADER_SiEngineController_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef SiEngineController_COMMON_INCLUDES_
#define SiEngineController_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* SiEngineController_COMMON_INCLUDES_ */

#include "SiEngineController_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Block signals for model 'SiEngineController' */
typedef struct {
  real_T Saturation1;                  /* '<S38>/Saturation1' */
} B_SiEngineController_c_T;

/* Block states (default storage) for model 'SiEngineController' */
typedef struct {
  real_T UnitDelay1_DSTATE;            /* '<S46>/Unit Delay1' */
  real_T UnitDelay_DSTATE;             /* '<S2>/Unit Delay' */
  real_T UnitDelay1_DSTATE_k;          /* '<S2>/Unit Delay1' */
  real_T UnitDelay_DSTATE_k;           /* '<S38>/Unit Delay' */
  real_T UnitDelay_DSTATE_f;           /* '<S28>/Unit Delay' */
  real_T UnitDelay_DSTATE_c;           /* '<S27>/Unit Delay' */
  real_T RichCount;           /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T LeanCount;           /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T DitherCount;         /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2VoltLearnTimeSen;  /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2OfsVoltSen;        /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2StoichVoltSen;     /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2MinVoltSen;        /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2MaxVoltSen;        /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2ReadySen;          /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T O2VoltLastSen;       /* '<S17>/Calculate Front AFR Control Feedback' */
  real_T ClsdLpFuelIntgLast;  /* '<S17>/Calculate Front AFR Control Feedback' */
  boolean_T RichCount_not_empty;
                              /* '<S17>/Calculate Front AFR Control Feedback' */
  boolean_T IdleSpeedControl_MODE;     /* '<S7>/Idle Speed Control' */
} DW_SiEngineController_f_T;

/* Parameters (default storage) */
struct P_SiEngineController_T_ {
  real_T CatLightOffTime;              /* Variable: CatLightOffTime
                                        * Referenced by:
                                        *   '<S2>/Unit Delay1'
                                        *   '<S59>/Constant'
                                        */
  real_T Cps;                          /* Variable: Cps
                                        * Referenced by:
                                        *   '<S18>/rev per cycle'
                                        *   '<S47>/rev per cycle'
                                        */
  real_T CrankSpeed;                   /* Variable: CrankSpeed
                                        * Referenced by:
                                        *   '<S17>/Constant18'
                                        *   '<S35>/Constant'
                                        *   '<S31>/Constant'
                                        *   '<S32>/Constant'
                                        */
  real_T EngRevLim;                    /* Variable: EngRevLim
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T EngStopTime;                  /* Variable: EngStopTime
                                        * Referenced by:
                                        *   '<S2>/Unit Delay'
                                        *   '<S57>/Constant'
                                        */
  real_T NCyl;                         /* Variable: NCyl
                                        * Referenced by:
                                        *   '<S18>/inj per cycle'
                                        *   '<S47>/cyls per cycle'
                                        *   '<S47>/cyls per cycle '
                                        */
  real_T N_idle;                       /* Variable: N_idle
                                        * Referenced by:
                                        *   '<S17>/Constant17'
                                        *   '<S38>/Base Idle Speed'
                                        *   '<S27>/Constant2'
                                        */
  real_T Pstd;                         /* Variable: Pstd
                                        * Referenced by:
                                        *   '<S11>/Standard Pressure'
                                        *   '<S43>/Standard Pressure'
                                        *   '<S44>/Standard Pressure'
                                        *   '<S47>/Standard Pressure Sea Level'
                                        *   '<S48>/Standard Pressure Sea Level'
                                        */
  real_T Rair;                         /* Variable: Rair
                                        * Referenced by:
                                        *   '<S47>/Ideal Gas Constant'
                                        *   '<S47>/Ideal Gas Constant IVC Trapped Gas'
                                        */
  real_T Sinj;                         /* Variable: Sinj
                                        * Referenced by: '<S18>/Injector Slope mg//ms'
                                        */
  real_T Ts;                           /* Variable: Ts
                                        * Referenced by:
                                        *   '<S2>/Constant'
                                        *   '<S2>/Constant3'
                                        */
  real_T Tstd;                         /* Variable: Tstd
                                        * Referenced by:
                                        *   '<S11>/Standard Temperature'
                                        *   '<S43>/Standard Temperature'
                                        *   '<S44>/Standard Temperature'
                                        *   '<S47>/Standard Air Temperature'
                                        *   '<S47>/Standard Air Temperature K'
                                        *   '<S48>/Standard Air Temperature'
                                        */
  real_T Vd;                           /* Variable: Vd
                                        * Referenced by: '<S47>/Engine Displacement'
                                        */
  real_T afr_stoich;                   /* Variable: afr_stoich
                                        * Referenced by: '<S25>/Stoichiometric AFR'
                                        */
  real_T f_cp_ld_bpt[16];              /* Variable: f_cp_ld_bpt
                                        * Referenced by:
                                        *   '<S10>/Optimal Exhaust Cam Phaser Retard'
                                        *   '<S10>/Optimal Intake Cam Phaser Advance'
                                        */
  real_T f_cp_n_bpt[15];               /* Variable: f_cp_n_bpt
                                        * Referenced by:
                                        *   '<S10>/Optimal Exhaust Cam Phaser Retard'
                                        *   '<S10>/Optimal Intake Cam Phaser Advance'
                                        */
  real_T f_ecp[240];                   /* Variable: f_ecp
                                        * Referenced by: '<S10>/Optimal Exhaust Cam Phaser Retard'
                                        */
  real_T f_egr_areapct_cmd[600];       /* Variable: f_egr_areapct_cmd
                                        * Referenced by: '<S11>/EGR Valve Area Percent'
                                        */
  real_T f_egr_areapct_nrmlzdflow_bpt[30];/* Variable: f_egr_areapct_nrmlzdflow_bpt
                                           * Referenced by: '<S11>/EGR Valve Area Percent'
                                           */
  real_T f_egr_areapct_pr_bpt[20];     /* Variable: f_egr_areapct_pr_bpt
                                        * Referenced by:
                                        *   '<S11>/EGR Valve Area Percent'
                                        *   '<S11>/Open EGR Valve Mass Flow Rate'
                                        */
  real_T f_egr_max_stdflow[20];        /* Variable: f_egr_max_stdflow
                                        * Referenced by: '<S11>/Open EGR Valve Mass Flow Rate'
                                        */
  real_T f_egr_stdflow[420];           /* Variable: f_egr_stdflow
                                        * Referenced by: '<S43>/EGR Corrected Mass Flow Rate'
                                        */
  real_T f_egr_stdflow_egrap_bpt[21];  /* Variable: f_egr_stdflow_egrap_bpt
                                        * Referenced by: '<S43>/EGR Corrected Mass Flow Rate'
                                        */
  real_T f_egr_stdflow_pr_bpt[20];     /* Variable: f_egr_stdflow_pr_bpt
                                        * Referenced by: '<S43>/EGR Corrected Mass Flow Rate'
                                        */
  real_T f_egrpct_cmd[240];            /* Variable: f_egrpct_cmd
                                        * Referenced by: '<S11>/EGR Percent Command'
                                        */
  real_T f_egrpct_ld_bpt[16];          /* Variable: f_egrpct_ld_bpt
                                        * Referenced by: '<S11>/EGR Percent Command'
                                        */
  real_T f_egrpct_n_bpt[15];           /* Variable: f_egrpct_n_bpt
                                        * Referenced by: '<S11>/EGR Percent Command'
                                        */
  real_T f_icp[240];                   /* Variable: f_icp
                                        * Referenced by: '<S10>/Optimal Intake Cam Phaser Advance'
                                        */
  real_T f_intksys_stdflow_bpt[20];    /* Variable: f_intksys_stdflow_bpt
                                        * Referenced by: '<S44>/Intake Pressure Ratio'
                                        */
  real_T f_intksys_stdflow_pr[20];     /* Variable: f_intksys_stdflow_pr
                                        * Referenced by: '<S44>/Intake Pressure Ratio'
                                        */
  real_T f_lamcmd[240];                /* Variable: f_lamcmd
                                        * Referenced by: '<S25>/ Optimal Lambda'
                                        */
  real_T f_lamcmd_ld_bpt[16];          /* Variable: f_lamcmd_ld_bpt
                                        * Referenced by: '<S25>/ Optimal Lambda'
                                        */
  real_T f_lamcmd_n_bpt[15];           /* Variable: f_lamcmd_n_bpt
                                        * Referenced by: '<S25>/ Optimal Lambda'
                                        */
  real_T f_lcmd[315];                  /* Variable: f_lcmd
                                        * Referenced by: '<S12>/Load Command From Torque Command At Current Engine Speed'
                                        */
  real_T f_lcmd_n_bpt[15];             /* Variable: f_lcmd_n_bpt
                                        * Referenced by: '<S12>/Load Command From Torque Command At Current Engine Speed'
                                        */
  real_T f_lcmd_tq_bpt[21];            /* Variable: f_lcmd_tq_bpt
                                        * Referenced by: '<S12>/Load Command From Torque Command At Current Engine Speed'
                                        */
  real_T f_mdot_air_corr[400];         /* Variable: f_mdot_air_corr
                                        * Referenced by: '<S47>/Air Mass Flow Correction'
                                        */
  real_T f_mdot_air_corr_ld_bpt[20];   /* Variable: f_mdot_air_corr_ld_bpt
                                        * Referenced by: '<S47>/Air Mass Flow Correction'
                                        */
  real_T f_mdot_air_n_bpt[20];         /* Variable: f_mdot_air_n_bpt
                                        * Referenced by: '<S47>/Air Mass Flow Correction'
                                        */
  real_T f_mdot_intk[400];             /* Variable: f_mdot_intk
                                        * Referenced by: '<S47>/Ideal Mass Flow'
                                        */
  real_T f_mdot_intk_ecp_bpt[20];      /* Variable: f_mdot_intk_ecp_bpt
                                        * Referenced by: '<S47>/Ideal Mass Flow'
                                        */
  real_T f_mdot_trpd_bpt[20];          /* Variable: f_mdot_trpd_bpt
                                        * Referenced by: '<S47>/Ideal Mass Flow'
                                        */
  real_T f_sa[240];                    /* Variable: f_sa
                                        * Referenced by: '<S9>/Optimal Spark Advance'
                                        */
  real_T f_sa_ld_bpt[16];              /* Variable: f_sa_ld_bpt
                                        * Referenced by: '<S9>/Optimal Spark Advance'
                                        */
  real_T f_sa_n_bpt[15];               /* Variable: f_sa_n_bpt
                                        * Referenced by: '<S9>/Optimal Spark Advance'
                                        */
  real_T f_startup_ect_bpt[4];         /* Variable: f_startup_ect_bpt
                                        * Referenced by:
                                        *   '<S28>/Startup Delta Lambda'
                                        *   '<S28>/Startup Lambda Decay Time Constant'
                                        */
  real_T f_startup_lambda_delta[4];    /* Variable: f_startup_lambda_delta
                                        * Referenced by: '<S28>/Startup Delta Lambda'
                                        */
  real_T f_startup_lambda_delta_timecnst[4];
                                    /* Variable: f_startup_lambda_delta_timecnst
                                     * Referenced by: '<S28>/Startup Lambda Decay Time Constant'
                                     */
  real_T f_tap[315];                   /* Variable: f_tap
                                        * Referenced by: '<S13>/Throttle Area Percent Feedforward'
                                        */
  real_T f_tap_ld_bpt[21];             /* Variable: f_tap_ld_bpt
                                        * Referenced by: '<S13>/Throttle Area Percent Feedforward'
                                        */
  real_T f_tap_n_bpt[15];              /* Variable: f_tap_n_bpt
                                        * Referenced by: '<S13>/Throttle Area Percent Feedforward'
                                        */
  real_T f_tm_corr[400];               /* Variable: f_tm_corr
                                        * Referenced by: '<S47>/Trapped Mass Correction'
                                        */
  real_T f_tm_corr_n_bpt[20];          /* Variable: f_tm_corr_n_bpt
                                        * Referenced by: '<S47>/Trapped Mass Correction'
                                        */
  real_T f_tm_corr_nd_bpt[20];         /* Variable: f_tm_corr_nd_bpt
                                        * Referenced by: '<S47>/Trapped Mass Correction'
                                        */
  real_T f_tpp[2];                     /* Variable: f_tpp
                                        * Referenced by: '<S13>/Throttle Position Percent'
                                        */
  real_T f_tpp_tap_bpt[2];             /* Variable: f_tpp_tap_bpt
                                        * Referenced by: '<S13>/Throttle Position Percent'
                                        */
  real_T f_vivc[20];                   /* Variable: f_vivc
                                        * Referenced by: '<S47>/IVC Volume vs ICP Calibration'
                                        */
  real_T f_vivc_icp_bpt[20];           /* Variable: f_vivc_icp_bpt
                                        * Referenced by: '<S47>/IVC Volume vs ICP Calibration'
                                        */
  real_T f_wap[315];                   /* Variable: f_wap
                                        * Referenced by: '<S14>/Wastegate Area Percent Feedforward'
                                        */
  real_T f_wap_ld_bpt[21];             /* Variable: f_wap_ld_bpt
                                        * Referenced by: '<S14>/Wastegate Area Percent Feedforward'
                                        */
  real_T f_wap_n_bpt[15];              /* Variable: f_wap_n_bpt
                                        * Referenced by: '<S14>/Wastegate Area Percent Feedforward'
                                        */
  real_T tau_egr;                      /* Variable: tau_egr
                                        * Referenced by: '<S46>/Time constant'
                                        */
  boolean_T EngStopStartEnable;        /* Variable: EngStopStartEnable
                                        * Referenced by: '<S2>/Constant5'
                                        */
  real_T SIController_ClsdLpFuelEn; /* Mask Parameter: SIController_ClsdLpFuelEn
                                     * Referenced by: '<S17>/Constant'
                                     */
  real_T SIController_Ki_idle;         /* Mask Parameter: SIController_Ki_idle
                                        * Referenced by: '<S38>/I Gain'
                                        */
  real_T SIController_Kp_idle;         /* Mask Parameter: SIController_Kp_idle
                                        * Referenced by: '<S38>/P Gain'
                                        */
  real_T SIController_OpenLpDitherEn;
                                  /* Mask Parameter: SIController_OpenLpDitherEn
                                   * Referenced by: '<S17>/Constant11'
                                   */
  real_T SIController_Trq_idlecmd_enable;
                              /* Mask Parameter: SIController_Trq_idlecmd_enable
                               * Referenced by: '<S37>/Constant'
                               */
  real_T SIController_Trq_idlecmd_max;
                                 /* Mask Parameter: SIController_Trq_idlecmd_max
                                  * Referenced by:
                                  *   '<S38>/Saturation'
                                  *   '<S38>/Saturation1'
                                  */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S58>/Constant'
                                      */
  real_T div0protectpoly1_thresh;     /* Mask Parameter: div0protectpoly1_thresh
                                       * Referenced by:
                                       *   '<S33>/Constant'
                                       *   '<S34>/Constant'
                                       */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S29>/Switch1'
                                        */
  real_T Switch1_Threshold_g;          /* Expression: 0
                                        * Referenced by: '<S30>/Switch1'
                                        */
  real_T WeightedSampleTimeMath_WtEt;
                              /* Computed Parameter: WeightedSampleTimeMath_WtEt
                               * Referenced by: '<S27>/Weighted Sample Time Math'
                               */
  real_T Gain_Gain;                    /* Expression: -1
                                        * Referenced by: '<S27>/Gain'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S29>/Constant'
                                        */
  real_T Constant_Value_h;             /* Expression: 1
                                        * Referenced by: '<S30>/Constant'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S27>/Unit Delay'
                                        */
  real_T Constant2_Value;              /* Expression: 273.15
                                        * Referenced by: '<S28>/Constant2'
                                        */
  real_T UnitDelay_InitialCondition_o; /* Expression: 0
                                        * Referenced by: '<S28>/Unit Delay'
                                        */
  real_T Gain1_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<S17>/Gain1'
                                        */
  real_T Constant14_Value;             /* Expression: 0
                                        * Referenced by: '<S17>/Constant14'
                                        */
  real_T Constant15_Value;             /* Expression: 0
                                        * Referenced by: '<S17>/Constant15'
                                        */
  real_T Constant16_Value;             /* Expression: 0
                                        * Referenced by: '<S17>/Constant16'
                                        */
  real_T Constant4_Value;              /* Expression: ClsdLpFuelPGain
                                        * Referenced by: '<S17>/Constant4'
                                        */
  real_T Constant12_Value;             /* Expression: ClsdLpFuelIGain
                                        * Referenced by: '<S17>/Constant12'
                                        */
  real_T Constant19_Value;             /* Expression: ClsdLpFuelIntgLmt
                                        * Referenced by: '<S17>/Constant19'
                                        */
  real_T WeightedSampleTime_WtEt; /* Computed Parameter: WeightedSampleTime_WtEt
                                   * Referenced by: '<S17>/Weighted Sample Time'
                                   */
  real_T Constant5_Value;              /* Expression: LambdaDitherAmp
                                        * Referenced by: '<S17>/Constant5'
                                        */
  real_T Constant3_Value;              /* Expression: LambdaDitherFrq
                                        * Referenced by: '<S17>/Constant3'
                                        */
  real_T Constant6_Value;              /* Expression: O2ResetStoichVoltSen
                                        * Referenced by: '<S17>/Constant6'
                                        */
  real_T Constant1_Value;              /* Expression: O2ResetMinVoltSen
                                        * Referenced by: '<S17>/Constant1'
                                        */
  real_T Constant7_Value;              /* Expression: O2ResetMaxVoltSen
                                        * Referenced by: '<S17>/Constant7'
                                        */
  real_T Constant13_Value;             /* Expression: O2LearnUpdatePerSen
                                        * Referenced by: '<S17>/Constant13'
                                        */
  real_T Constant8_Value;              /* Expression: O2AmpMinVoltSen
                                        * Referenced by: '<S17>/Constant8'
                                        */
  real_T Constant9_Value;              /* Expression: O2ReadyVoltSen
                                        * Referenced by: '<S17>/Constant9'
                                        */
  real_T Constant10_Value;             /* Expression: O2NotReadyVoltSen
                                        * Referenced by: '<S17>/Constant10'
                                        */
  real_T Constant2_Value_e;            /* Expression: 0
                                        * Referenced by: '<S17>/Constant2'
                                        */
  real_T TrqCmd_Y0;                    /* Expression: 1
                                        * Referenced by: '<S38>/TrqCmd'
                                        */
  real_T WeightedSampleTimeMath_WtEt_m;
                            /* Computed Parameter: WeightedSampleTimeMath_WtEt_m
                             * Referenced by: '<S38>/Weighted Sample Time Math'
                             */
  real_T UnitDelay_InitialCondition_a; /* Expression: 0
                                        * Referenced by: '<S38>/Unit Delay'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0
                                        * Referenced by: '<S38>/Saturation'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S38>/Constant'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S38>/Saturation1'
                                        */
  real_T Saturation_UpperSat;          /* Expression: inf
                                        * Referenced by: '<S18>/Saturation'
                                        */
  real_T Saturation_LowerSat_n;        /* Expression: Nmin
                                        * Referenced by: '<S18>/Saturation'
                                        */
  real_T secpermin_Value;              /* Expression: 60
                                        * Referenced by: '<S18>/sec per min'
                                        */
  real_T mgperg_Value;                 /* Expression: 1000
                                        * Referenced by: '<S18>/mg per g'
                                        */
  real_T kgstogs_Gain;                 /* Expression: 1000
                                        * Referenced by: '<S18>/kg//s to g//s'
                                        */
  real_T Constant_Value_hu;            /* Expression: 0
                                        * Referenced by: '<S18>/Constant'
                                        */
  real_T FuelCut_Threshold;            /* Expression: 0
                                        * Referenced by: '<S18>/Fuel Cut'
                                        */
  real_T Constant4_Value_n;            /* Expression: 0
                                        * Referenced by: '<S2>/Constant4'
                                        */
  real_T Constant1_Value_l;            /* Expression: 0
                                        * Referenced by: '<S2>/Constant1'
                                        */
  real_T Constant2_Value_m;            /* Expression: 0
                                        * Referenced by: '<S2>/Constant2'
                                        */
  real_T Constant_Value_o;             /* Expression: 1
                                        * Referenced by: '<S46>/Constant'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S46>/Unit Delay1'
                                        */
  real_T Saturation3_UpperSat;         /* Expression: 1
                                        * Referenced by: '<S46>/Saturation3'
                                        */
  real_T Saturation3_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S46>/Saturation3'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 1e6
                                        * Referenced by: '<S47>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_a;       /* Expression: 1
                                        * Referenced by: '<S47>/Saturation1'
                                        */
  real_T Saturation2_UpperSat;         /* Expression: 1e6
                                        * Referenced by: '<S47>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: 1
                                        * Referenced by: '<S47>/Saturation2'
                                        */
  real_T Saturation_UpperSat_c;        /* Expression: 20000
                                        * Referenced by: '<S47>/Saturation'
                                        */
  real_T Saturation_LowerSat_g;        /* Expression: 0
                                        * Referenced by: '<S47>/Saturation'
                                        */
  real_T secpermin_Value_a;            /* Expression: 60
                                        * Referenced by: '<S47>/sec per min'
                                        */
  real_T kgtog_Value;                  /* Expression: 1000
                                        * Referenced by: '<S47>/kg to g'
                                        */
  real_T Saturation3_UpperSat_n;       /* Expression: 1e6
                                        * Referenced by: '<S47>/Saturation3'
                                        */
  real_T Saturation3_LowerSat_g;       /* Expression: 0.01
                                        * Referenced by: '<S47>/Saturation3'
                                        */
  real_T SpeedBlend_tableData[2];      /* Expression: [0 1]
                                        * Referenced by: '<S48>/Speed Blend'
                                        */
  real_T SpeedBlend_bp01Data[2];       /* Expression: [0 300]
                                        * Referenced by: '<S48>/Speed Blend'
                                        */
  real_T Constant_Value_oj;            /* Expression: 1
                                        * Referenced by: '<S48>/Constant'
                                        */
  real_T Saturation1_UpperSat_b;       /* Expression: inf
                                        * Referenced by: '<S11>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_i;       /* Expression: 1
                                        * Referenced by: '<S11>/Saturation1'
                                        */
  real_T Saturation1_UpperSat_h;       /* Expression: inf
                                        * Referenced by: '<S44>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_h;       /* Expression: 1
                                        * Referenced by: '<S44>/Saturation1'
                                        */
  real_T Saturation_UpperSat_k;        /* Expression: inf
                                        * Referenced by: '<S44>/Saturation'
                                        */
  real_T Saturation_LowerSat_b;        /* Expression: 1
                                        * Referenced by: '<S44>/Saturation'
                                        */
  real_T gstokgs_Gain;                 /* Expression: 0.001
                                        * Referenced by: '<S47>/g//s to kg//s'
                                        */
  real_T kgstogs_Gain_d;               /* Expression: 1000
                                        * Referenced by: '<S44>/kg//s to g//s'
                                        */
  real_T Gain_Gain_p;                  /* Expression: 1/100
                                        * Referenced by: '<S11>/Gain'
                                        */
  real_T Saturation4_UpperSat;         /* Expression: 1
                                        * Referenced by: '<S47>/Saturation4'
                                        */
  real_T Saturation4_LowerSat;         /* Expression: 0.0001
                                        * Referenced by: '<S47>/Saturation4'
                                        */
  real_T Saturation_UpperSat_i;        /* Expression: inf
                                        * Referenced by: '<S11>/Saturation'
                                        */
  real_T Saturation_LowerSat_g0;       /* Expression: .00001
                                        * Referenced by: '<S11>/Saturation'
                                        */
  real_T gstokgs_Gain_j;               /* Expression: 0.001
                                        * Referenced by: '<S11>/g//s to kg//s'
                                        */
  real_T uDLookupTable_tableData[2];   /* Expression: [1 0]
                                        * Referenced by: '<S8>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[2];    /* Expression: [1 1.01]
                                        * Referenced by: '<S8>/1-D Lookup Table'
                                        */
  real_T Constant_Value_i;             /* Expression: 1
                                        * Referenced by: '<S25>/Constant'
                                        */
  real_T SensorAFRtomv_XData[3];    /* Expression: [14.4540   14.6000   14.7460]
                                     * Referenced by: '<Root>/Sensor AFR to mv'
                                     */
  real_T SensorAFRtomv_YData[3];       /* Expression: [950   450    50]
                                        * Referenced by: '<Root>/Sensor AFR to mv'
                                        */
  real_T Saturation_UpperSat_n;        /* Expression: inf
                                        * Referenced by: '<S43>/Saturation'
                                        */
  real_T Saturation_LowerSat_bn;       /* Expression: 1
                                        * Referenced by: '<S43>/Saturation'
                                        */
  real_T gstokgs_Gain_d;               /* Expression: 0.001
                                        * Referenced by: '<S43>/g//s to kg//s'
                                        */
  real_T Saturation1_UpperSat_k;       /* Expression: 1e6
                                        * Referenced by: '<S46>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_hg;      /* Expression: 0.0001
                                        * Referenced by: '<S46>/Saturation1'
                                        */
  real_T Saturation2_UpperSat_i;       /* Expression: 1
                                        * Referenced by: '<S46>/Saturation2'
                                        */
  real_T Saturation2_LowerSat_n;       /* Expression: 0
                                        * Referenced by: '<S46>/Saturation2'
                                        */
  real_T WeightedSampleTime_WtEt_p;
                                /* Computed Parameter: WeightedSampleTime_WtEt_p
                                 * Referenced by: '<S46>/Weighted Sample Time'
                                 */
  real_T Constant_Value_n;             /* Expression: 0
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Constant1_Value_g;            /* Expression: 0
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T Constant2_Value_d;            /* Expression: 0
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Constant3_Value_n;            /* Expression: 0
                                        * Referenced by: '<Root>/Constant3'
                                        */
  real_T Constant4_Value_p;            /* Expression: 0
                                        * Referenced by: '<Root>/Constant4'
                                        */
  real_T Constant5_Value_o;            /* Expression: 0
                                        * Referenced by: '<Root>/Constant5'
                                        */
  uint32_T TrappedMassCorrection_maxIndex[2];
                           /* Computed Parameter: TrappedMassCorrection_maxIndex
                            * Referenced by: '<S47>/Trapped Mass Correction'
                            */
  uint32_T IdealMassFlow_maxIndex[2];
                                   /* Computed Parameter: IdealMassFlow_maxIndex
                                    * Referenced by: '<S47>/Ideal Mass Flow'
                                    */
  uint32_T AirMassFlowCorrection_maxIndex[2];
                           /* Computed Parameter: AirMassFlowCorrection_maxIndex
                            * Referenced by: '<S47>/Air Mass Flow Correction'
                            */
  uint32_T OptimalExhaustCamPhaserRetard_maxIndex[2];
                   /* Computed Parameter: OptimalExhaustCamPhaserRetard_maxIndex
                    * Referenced by: '<S10>/Optimal Exhaust Cam Phaser Retard'
                    */
  uint32_T OptimalIntakeCamPhaserAdvance_maxIndex[2];
                   /* Computed Parameter: OptimalIntakeCamPhaserAdvance_maxIndex
                    * Referenced by: '<S10>/Optimal Intake Cam Phaser Advance'
                    */
  uint32_T EGRPercentCommand_maxIndex[2];
                               /* Computed Parameter: EGRPercentCommand_maxIndex
                                * Referenced by: '<S11>/EGR Percent Command'
                                */
  uint32_T EGRValveAreaPercent_maxIndex[2];
                             /* Computed Parameter: EGRValveAreaPercent_maxIndex
                              * Referenced by: '<S11>/EGR Valve Area Percent'
                              */
  uint32_T LoadCommandFromTorqueCommandAtCurrentEngineSpeed_maxIndex[2];
  /* Computed Parameter: LoadCommandFromTorqueCommandAtCurrentEngineSpeed_maxIndex
   * Referenced by: '<S12>/Load Command From Torque Command At Current Engine Speed'
   */
  uint32_T ThrottleAreaPercentFeedforward_maxIndex[2];
                  /* Computed Parameter: ThrottleAreaPercentFeedforward_maxIndex
                   * Referenced by: '<S13>/Throttle Area Percent Feedforward'
                   */
  uint32_T WastegateAreaPercentFeedforward_maxIndex[2];
                 /* Computed Parameter: WastegateAreaPercentFeedforward_maxIndex
                  * Referenced by: '<S14>/Wastegate Area Percent Feedforward'
                  */
  uint32_T OptimalLambda_maxIndex[2];
                                   /* Computed Parameter: OptimalLambda_maxIndex
                                    * Referenced by: '<S25>/ Optimal Lambda'
                                    */
  uint32_T OptimalSparkAdvance_maxIndex[2];
                             /* Computed Parameter: OptimalSparkAdvance_maxIndex
                              * Referenced by: '<S9>/Optimal Spark Advance'
                              */
  uint32_T EGRCorrectedMassFlowRate_maxIndex[2];
                        /* Computed Parameter: EGRCorrectedMassFlowRate_maxIndex
                         * Referenced by: '<S43>/EGR Corrected Mass Flow Rate'
                         */
};

/* Real-time Model Data Structure */
struct tag_RTM_SiEngineController_T {
  const char_T **errorStatus;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[185];
    int32_T* vardimsAddress[185];
    RTWLoggingFcnPtr loggingPtrs[185];
  } DataMapInfo;
};

typedef struct {
  B_SiEngineController_c_T rtb;
  DW_SiEngineController_f_T rtdw;
  RT_MODEL_SiEngineController_T rtm;
} MdlrefDW_SiEngineController_T;

/* Model reference registration function */
extern void SiEngineController_initialize(const char_T **rt_errorStatus,
  RT_MODEL_SiEngineController_T *const SiEngineController_M,
  B_SiEngineController_c_T *localB, DW_SiEngineController_f_T *localDW,
  rtwCAPI_ModelMappingInfo *rt_ParentMMI, const char_T *rt_ChildPath, int_T
  rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  SiEngineController_GetCAPIStaticMap(void);
extern void SiEngineController_Init(real_T *rty_FuelMainSoi, real_T
  *rty_TurboRackPosCmd, real_T *rty_VarCompRatioPosCmd, real_T
  *rty_IntkVlvLiftCmd, real_T *rty_VarIntkRunLenCmd, real_T
  *rty_IntkSwirlVlvPosCmd, B_SiEngineController_c_T *localB,
  DW_SiEngineController_f_T *localDW);
extern void SiEngineController_Reset(DW_SiEngineController_f_T *localDW);
extern void SiEngineController_Disable(B_SiEngineController_c_T *localB,
  DW_SiEngineController_f_T *localDW);
extern void SiEngineController(const real_T *rtu_TrqCmd, const real_T
  *rtu_EngSpd, const real_T *rtu_Map, const real_T *rtu_Mat, const real_T
  *rtu_IntkCamPhase, const real_T *rtu_ExhCamPhase, const real_T
  *rtu_EgrVlvAreaPct, const real_T *rtu_Afr, const real_T *rtu_AmbPrs, const
  boolean_T *rtu_IgSw, const real_T *rtu_Iat, const real_T *rtu_Ect, const
  real_T *rtu_EgrVlvDeltaPrs, const real_T *rtu_EgrVlvInTemp, real_T
  *rty_ThrPosPctCmd, real_T *rty_WgAreaPctCmd, real_T *rty_InjPw, real_T
  *rty_FuelMainSoi, real_T *rty_SpkAdv, real_T *rty_IntkCamPhaseCmd, real_T
  *rty_ExhCamPhaseCmd, real_T *rty_TurboRackPosCmd, real_T *rty_EgrVlvAreaPctCmd,
  real_T *rty_VarCompRatioPosCmd, real_T *rty_IntkVlvLiftCmd, real_T
  *rty_VarIntkRunLenCmd, real_T *rty_ClsdLpFuelMult, real_T
  *rty_IntkSwirlVlvPosCmd, real_T *rty_TrqCmdISC, real_T *rty_LoadCmd, real_T
  *rty_EstIntkPortFlw, B_SiEngineController_c_T *localB,
  DW_SiEngineController_f_T *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SiEngineController'
 * '<S1>'   : 'SiEngineController/SI Controller'
 * '<S2>'   : 'SiEngineController/Start Stop Logic'
 * '<S3>'   : 'SiEngineController/SI Controller/Controllers'
 * '<S4>'   : 'SiEngineController/SI Controller/Estimators'
 * '<S5>'   : 'SiEngineController/SI Controller/Controllers/Air'
 * '<S6>'   : 'SiEngineController/SI Controller/Controllers/Fuel'
 * '<S7>'   : 'SiEngineController/SI Controller/Controllers/Idle Speed Control'
 * '<S8>'   : 'SiEngineController/SI Controller/Controllers/Rev Limiter Control'
 * '<S9>'   : 'SiEngineController/SI Controller/Controllers/Spark'
 * '<S10>'  : 'SiEngineController/SI Controller/Controllers/Air/Cam Phaser Control'
 * '<S11>'  : 'SiEngineController/SI Controller/Controllers/Air/EGR Control'
 * '<S12>'  : 'SiEngineController/SI Controller/Controllers/Air/Load Command'
 * '<S13>'  : 'SiEngineController/SI Controller/Controllers/Air/Throttle Position Control'
 * '<S14>'  : 'SiEngineController/SI Controller/Controllers/Air/Wastegate Control'
 * '<S15>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR'
 * '<S16>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command'
 * '<S17>'  : 'SiEngineController/SI Controller/Controllers/Fuel/Front AFR Control Feedback'
 * '<S18>'  : 'SiEngineController/SI Controller/Controllers/Fuel/Open-Loop AFR Control'
 * '<S19>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR/Engine AFR and Fuel Calculation'
 * '<S20>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR/Engine AFR and Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation'
 * '<S21>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR/Engine AFR and Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation Without Vol'
 * '<S22>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR/Engine AFR and Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation Without Vol/div0protect - poly'
 * '<S23>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR/Engine AFR and Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation Without Vol/div0protect - poly/Compare To Constant'
 * '<S24>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR/Engine AFR and Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation/Fuel Mass Engine AFR and  Fuel Calculation Without Vol/div0protect - poly/Compare To Constant1'
 * '<S25>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command'
 * '<S26>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset'
 * '<S27>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay'
 * '<S28>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Initialization'
 * '<S29>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay/div0protect - poly'
 * '<S30>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay/div0protect - poly1'
 * '<S31>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay/div0protect - poly/Compare To Constant'
 * '<S32>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay/div0protect - poly/Compare To Constant1'
 * '<S33>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay/div0protect - poly1/Compare To Constant'
 * '<S34>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Decay/div0protect - poly1/Compare To Constant1'
 * '<S35>'  : 'SiEngineController/SI Controller/Controllers/Fuel/AFR Command/AFR Command/Startup Lambda Offset/Lambda Start Delta Initialization/Compare To Constant'
 * '<S36>'  : 'SiEngineController/SI Controller/Controllers/Fuel/Front AFR Control Feedback/Calculate Front AFR Control Feedback'
 * '<S37>'  : 'SiEngineController/SI Controller/Controllers/Idle Speed Control/Compare To Constant'
 * '<S38>'  : 'SiEngineController/SI Controller/Controllers/Idle Speed Control/Idle Speed Control'
 * '<S39>'  : 'SiEngineController/SI Controller/Estimators/EGR Flow Estimator'
 * '<S40>'  : 'SiEngineController/SI Controller/Estimators/Exhaust'
 * '<S41>'  : 'SiEngineController/SI Controller/Estimators/Intake Air Flow'
 * '<S42>'  : 'SiEngineController/SI Controller/Estimators/Torque'
 * '<S43>'  : 'SiEngineController/SI Controller/Estimators/EGR Flow Estimator/EGR Mass Flow Rate'
 * '<S44>'  : 'SiEngineController/SI Controller/Estimators/EGR Flow Estimator/EGR Outlet Pressure'
 * '<S45>'  : 'SiEngineController/SI Controller/Estimators/Exhaust/Spark Ignition Exhaust'
 * '<S46>'  : 'SiEngineController/SI Controller/Estimators/Intake Air Flow/Air Mass Fraction'
 * '<S47>'  : 'SiEngineController/SI Controller/Estimators/Intake Air Flow/SI Engine Breathing with Cam Phasing'
 * '<S48>'  : 'SiEngineController/SI Controller/Estimators/Intake Air Flow/SI Engine Breathing with Cam Phasing/Shut down load'
 * '<S49>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure'
 * '<S50>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Compare To Zero'
 * '<S51>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Crank angle based cylinder pressure and torque'
 * '<S52>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Subsystem'
 * '<S53>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Crank angle based cylinder pressure and torque/Cylinder Pressure Inactive'
 * '<S54>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Subsystem/div0protect - poly1'
 * '<S55>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Subsystem/div0protect - poly1/Compare To Constant'
 * '<S56>'  : 'SiEngineController/SI Controller/Estimators/Torque/Spark Ignition Torque Structure/Subsystem/div0protect - poly1/Compare To Constant1'
 * '<S57>'  : 'SiEngineController/Start Stop Logic/Compare To Constant'
 * '<S58>'  : 'SiEngineController/Start Stop Logic/Compare To Constant1'
 * '<S59>'  : 'SiEngineController/Start Stop Logic/Compare To Constant2'
 */
#endif                                 /* RTW_HEADER_SiEngineController_h_ */
