/*
 * HevP4OptimalController_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HevP4OptimalController".
 *
 * Model version              : 2.3
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 14:21:13 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "HevP4OptimalController_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "HevP4OptimalController.h"
#include "HevP4OptimalController_capi.h"
#include "HevP4OptimalController_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 0, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 2, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 3, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/rads2rpm"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 4, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/rads2rpm1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 5, TARGET_STRING("HevP4OptimalController/Brake Pedal to Total Braking Pressure Request/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 6, TARGET_STRING("HevP4OptimalController/Brake Pedal to Total Braking Pressure Request/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 7, TARGET_STRING("HevP4OptimalController/ECMS/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 8, TARGET_STRING("HevP4OptimalController/ECMS/Merge"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 9, TARGET_STRING("HevP4OptimalController/ECMS/Merge1"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 10, TARGET_STRING("HevP4OptimalController/ECMS/Merge2"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 11, TARGET_STRING("HevP4OptimalController/ECMS/Merge3"),
    TARGET_STRING("InitialOutput"), 0, 0, 0 },

  { 12, TARGET_STRING("HevP4OptimalController/Series Regen Braking/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 13, TARGET_STRING("HevP4OptimalController/Series Regen Braking/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 14, TARGET_STRING("HevP4OptimalController/Series Regen Braking/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 15, TARGET_STRING("HevP4OptimalController/Series Regen Braking/Gain5"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 16, TARGET_STRING("HevP4OptimalController/Series Regen Braking/rads2rpm1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 17, TARGET_STRING("HevP4OptimalController/Series Regen Braking/rads_to_rpm"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 18, TARGET_STRING("HevP4OptimalController/Series Regen Braking/RegenBrakingCutoff"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 1, 0 },

  { 19, TARGET_STRING("HevP4OptimalController/Series Regen Braking/Negative 5"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 20, TARGET_STRING("HevP4OptimalController/Series Regen Braking/Negative 5"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 21, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque/MaxEngineTorque"),
    TARGET_STRING("Table"), 0, 2, 0 },

  { 22, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/neutral"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 23, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 24, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/GEMinSpeed"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 25, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 26, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 27, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 28, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 29, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/rads2rpm"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 30, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model"),
    TARGET_STRING("AccPwrTbl"), 0, 1, 0 },

  { 31, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model"),
    TARGET_STRING("AccSpdBpts"), 0, 1, 0 },

  { 32, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 33, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 34, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 35, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 36, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque/Accessory Load Model/Kw to w"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 37, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque/Accessory Load Model/rpm to rad//s"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 38, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque/Accessory Load Model/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 39, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque/Accessory Load Model/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 40, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MotTrq2WhlMotTrq/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 41, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MotTrq2WhlMotTrq/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 42, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MotTrq2WhlMotTrq/Diff Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 43, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MotTrq2WhlMotTrq/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 44, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 45, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 46, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Diff Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 47, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 48, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 49, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 50, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 51, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta/Eta 4D"),
    TARGET_STRING("maxIndex"), 1, 3, 0 },

  { 52, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta/Eta 4D"),
    TARGET_STRING("dimSizes"), 1, 3, 0 },

  { 53, TARGET_STRING("HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 54, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq Control Vector"),
    TARGET_STRING("Value"), 0, 4, 0 },

  { 55, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/neutral"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 56, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/no electric"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 57, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/rads2rpm"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 58, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 59, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/TracPwrErr Penalty"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 60, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/W2kW "),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 61, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/W2kW 1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 62, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 63, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 64, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/Discrete Transfer Fcn"),
    TARGET_STRING("Numerator"), 0, 1, 0 },

  { 65, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/Discrete Transfer Fcn"),
    TARGET_STRING("Denominator"), 0, 1, 0 },

  { 66, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/Discrete Transfer Fcn"),
    TARGET_STRING("InitialStates"), 0, 0, 0 },

  { 67, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/Unit Delay2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 68, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 69, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 70, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model/Kw to w"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 71, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model/rpm to rad//s"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 72, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 73, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 74, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Lower Limit/Gain5"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 75, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Lower Limit/Max Torque vs Speed"),
    TARGET_STRING("Table"), 0, 5, 0 },

  { 76, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Lower Limit/Max Torque vs Speed"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 5, 0 },

  { 77, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Lower Limit/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 78, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Lower Limit/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 79, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/neutral"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 80, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 81, TARGET_STRING("HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq/Diff Eta/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 82, TARGET_STRING("HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 83, TARGET_STRING("HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 84, TARGET_STRING("HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq/Diff Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 85, TARGET_STRING("HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 86, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/EngPwr Rate Limit/W2kW"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 87, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 88, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 89, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/2-D Lookup Table"),
    TARGET_STRING("Table"), 0, 6, 0 },

  { 90, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/2-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 1, 0 },

  { 91, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/2-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 1, 0 },

  { 92, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/2-D Lookup Table"),
    TARGET_STRING("maxIndex"), 1, 7, 0 },

  { 93, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Battery Constraint/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 94, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/rads2rpm"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 95, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/rads2rpm1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 96, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 97, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Diff Eta/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 98, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 99, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 100, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Diff Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 101, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 102, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 103, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 104, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 105, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta/Eta 4D"),
    TARGET_STRING("maxIndex"), 1, 3, 0 },

  { 106, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta/Eta 4D"),
    TARGET_STRING("dimSizes"), 1, 3, 0 },

  { 107, TARGET_STRING("HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 108, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Battery Constraint/Electrical Current/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 109, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Battery Constraint/Electrical Current/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 110, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/2-D Lookup Table"),
    TARGET_STRING("maxIndex"), 1, 7, 0 },

  { 111, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/EngSpd Calculation/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 112, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/EngSpd Calculation/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 113, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/neutral"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 114, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 115, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque/EngIdle"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 116, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 117, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Tabular Power Loss Data/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 118, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Tabular Power Loss Data/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 119, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Tabular Power Loss Data/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 120, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Tabular Power Loss Data/Eff Map"),
    TARGET_STRING("maxIndex"), 1, 7, 0 },

  { 121, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Tabular Power Loss Data/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 122, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 123, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 124, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 125, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 126, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 127, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 128, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/EngTrqLmtLow/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 129, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/EngTrqLmtUp/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 130, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Lower Limit/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 131, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Upper Limit/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 132, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Upper Limit/Max Torque vs Speed"),
    TARGET_STRING("Table"), 0, 2, 0 },

  { 133, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Unit Delay1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 134, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Unit Delay2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 135, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 136, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 137, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 138, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 139, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 140, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 141, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 142, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 143, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 144, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 145, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 146, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 147, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 148, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 149, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/rpm2rads"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 150, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 151, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 152, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 153, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 154, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 155, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 156, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 157, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("maxIndex"), 1, 3, 0 },

  { 158, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("dimSizes"), 1, 3, 0 },

  { 159, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("maxIndex"), 1, 3, 0 },

  { 160, TARGET_STRING("HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Eta Lookup/Eta 4D/Eta 4D"),
    TARGET_STRING("dimSizes"), 1, 3, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 161, -1, TARGET_STRING(
    "HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation\nand minimization/Discrete\nTransfer Fcn"),
    TARGET_STRING("states"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 162, -1, TARGET_STRING(
    "HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation\nand minimization/Unit Delay2"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 163, -1, TARGET_STRING(
    "HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Unit Delay"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 164, -1, TARGET_STRING(
    "HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Unit Delay1"),
    TARGET_STRING("DSTATE"), "", 0, 0, 8, 0, 0, 0, -1, 0 },

  { 165, -1, TARGET_STRING(
    "HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Unit Delay2"),
    TARGET_STRING("DSTATE"), "", 0, 0, 8, 0, 0, 0, -1, 0 },

  { 166, -1, TARGET_STRING(
    "HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Unit Delay"),
    TARGET_STRING("DSTATE"), "", 0, 0, 8, 0, 0, 0, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 167, TARGET_STRING("AccPwrbp"), 0, 1, 0 },

  { 168, TARGET_STRING("AccSpdbp"), 0, 1, 0 },

  { 169, TARGET_STRING("BattChrgPwrMax"), 0, 0, 0 },

  { 170, TARGET_STRING("BattCurrMax"), 0, 0, 0 },

  { 171, TARGET_STRING("BattDischrgPwrMax"), 0, 0, 0 },

  { 172, TARGET_STRING("BrkPrsMax"), 0, 0, 0 },

  { 173, TARGET_STRING("ChrgLmt_bpt"), 0, 9, 0 },

  { 174, TARGET_STRING("DischrgLmt_bpt"), 0, 9, 0 },

  { 175, TARGET_STRING("ECMS_s"), 0, 0, 0 },

  { 176, TARGET_STRING("G"), 0, 10, 0 },

  { 177, TARGET_STRING("Lhv"), 0, 0, 0 },

  { 178, TARGET_STRING("N"), 0, 10, 0 },

  { 179, TARGET_STRING("N_idle"), 0, 0, 0 },

  { 180, TARGET_STRING("Ndiff"), 0, 0, 0 },

  { 181, TARGET_STRING("Ndiff_P4"), 0, 0, 0 },

  { 182, TARGET_STRING("Re"), 0, 0, 0 },

  { 183, TARGET_STRING("RegenBrkCutOff"), 0, 1, 0 },

  { 184, TARGET_STRING("Rm"), 0, 0, 0 },

  { 185, TARGET_STRING("SOCTrgt"), 0, 0, 0 },

  { 186, TARGET_STRING("SOC_bpt"), 0, 9, 0 },

  { 187, TARGET_STRING("SOCmax"), 0, 0, 0 },

  { 188, TARGET_STRING("SOCmin"), 0, 0, 0 },

  { 189, TARGET_STRING("T_eff_bp"), 0, 9, 0 },

  { 190, TARGET_STRING("T_t"), 0, 11, 0 },

  { 191, TARGET_STRING("Temp_bpts"), 0, 1, 0 },

  { 192, TARGET_STRING("Trq_bpts"), 0, 10, 0 },

  { 193, TARGET_STRING("a"), 0, 0, 0 },

  { 194, TARGET_STRING("efficiency_table"), 0, 12, 0 },

  { 195, TARGET_STRING("eta_dcdc"), 0, 0, 0 },

  { 196, TARGET_STRING("eta_diff"), 0, 0, 0 },

  { 197, TARGET_STRING("eta_tbl"), 0, 13, 0 },

  { 198, TARGET_STRING("f_fuel"), 0, 14, 0 },

  { 199, TARGET_STRING("f_tbrake_min"), 0, 2, 0 },

  { 200, TARGET_STRING("f_tbrake_n_bpt"), 0, 2, 0 },

  { 201, TARGET_STRING("f_tbrake_t_bpt"), 0, 2, 0 },

  { 202, TARGET_STRING("mu_kinetic"), 0, 0, 0 },

  { 203, TARGET_STRING("num_pads"), 0, 0, 0 },

  { 204, TARGET_STRING("omega_bpts"), 0, 9, 0 },

  { 205, TARGET_STRING("w_eff_bp"), 0, 11, 0 },

  { 206, TARGET_STRING("PenaltyFctr"), 1, 0, 1 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void HevP4OptimalController_InitializeDataAddr(void* dataAddr[],
  DW_HevP4OptimalController_f_T *localDW)
{
  dataAddr[0] = (void*) (&HevP4OptimalController_P.CompareToConstant_const);
  dataAddr[1] = (void*) (&HevP4OptimalController_P.CompareToConstant1_const);
  dataAddr[2] = (void*) (&HevP4OptimalController_P.Constant_Value);
  dataAddr[3] = (void*) (&HevP4OptimalController_P.rads2rpm_Gain);
  dataAddr[4] = (void*) (&HevP4OptimalController_P.rads2rpm1_Gain);
  dataAddr[5] = (void*) (&HevP4OptimalController_P.Constant1_Value_aw);
  dataAddr[6] = (void*) (&HevP4OptimalController_P.Switch_Threshold_o);
  dataAddr[7] = (void*) (&HevP4OptimalController_P.Gain1_Gain_e);
  dataAddr[8] = (void*) (&HevP4OptimalController_P.Merge_InitialOutput);
  dataAddr[9] = (void*) (&HevP4OptimalController_P.Merge1_InitialOutput);
  dataAddr[10] = (void*) (&HevP4OptimalController_P.Merge2_InitialOutput);
  dataAddr[11] = (void*) (&HevP4OptimalController_P.Merge3_InitialOutput);
  dataAddr[12] = (void*) (&HevP4OptimalController_P.Gain_Gain);
  dataAddr[13] = (void*) (&HevP4OptimalController_P.Gain3_Gain);
  dataAddr[14] = (void*) (&HevP4OptimalController_P.Gain4_Gain);
  dataAddr[15] = (void*) (&HevP4OptimalController_P.Gain5_Gain_m);
  dataAddr[16] = (void*) (&HevP4OptimalController_P.rads2rpm1_Gain_o);
  dataAddr[17] = (void*) (&HevP4OptimalController_P.rads_to_rpm_Gain);
  dataAddr[18] = (void*) (&HevP4OptimalController_P.RegenBrakingCutoff_bp01Data
    [0]);
  dataAddr[19] = (void*) (&HevP4OptimalController_P.Negative5_UpperSat);
  dataAddr[20] = (void*) (&HevP4OptimalController_P.Negative5_LowerSat);
  dataAddr[21] = (void*) (&HevP4OptimalController_P.MaxEngineTorque_tableData[0]);
  dataAddr[22] = (void*) (&HevP4OptimalController_P.neutral_Value);
  dataAddr[23] = (void*) (&HevP4OptimalController_P.Switch1_Threshold);
  dataAddr[24] = (void*) (&HevP4OptimalController_P.GEMinSpeed_const);
  dataAddr[25] = (void*) (&HevP4OptimalController_P.Constant_Value_p);
  dataAddr[26] = (void*) (&HevP4OptimalController_P.Constant1_Value_a5);
  dataAddr[27] = (void*) (&HevP4OptimalController_P.Constant2_Value_ir);
  dataAddr[28] = (void*) (&HevP4OptimalController_P.Gain_Gain_i);
  dataAddr[29] = (void*) (&HevP4OptimalController_P.rads2rpm_Gain_h);
  dataAddr[30] = (void*)
    (&HevP4OptimalController_P.AccessoryLoadModel_AccPwrTbl[0]);
  dataAddr[31] = (void*)
    (&HevP4OptimalController_P.AccessoryLoadModel_AccSpdBpts[0]);
  dataAddr[32] = (void*) (&HevP4OptimalController_P.Constant2_Value_ny);
  dataAddr[33] = (void*) (&HevP4OptimalController_P.Saturation_UpperSat_b);
  dataAddr[34] = (void*) (&HevP4OptimalController_P.Saturation_LowerSat_n);
  dataAddr[35] = (void*) (&HevP4OptimalController_P.Switch_Threshold);
  dataAddr[36] = (void*) (&HevP4OptimalController_P.Kwtow_Gain);
  dataAddr[37] = (void*) (&HevP4OptimalController_P.rpmtorads_Gain);
  dataAddr[38] = (void*) (&HevP4OptimalController_P.Saturation_UpperSat);
  dataAddr[39] = (void*) (&HevP4OptimalController_P.Saturation_LowerSat);
  dataAddr[40] = (void*) (&HevP4OptimalController_P.Constant1_Value_a);
  dataAddr[41] = (void*) (&HevP4OptimalController_P.Constant2_Value_i);
  dataAddr[42] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_h);
  dataAddr[43] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_a);
  dataAddr[44] = (void*) (&HevP4OptimalController_P.Constant1_Value_aj);
  dataAddr[45] = (void*) (&HevP4OptimalController_P.Constant2_Value_d);
  dataAddr[46] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_l);
  dataAddr[47] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_c);
  dataAddr[48] = (void*) (&HevP4OptimalController_P.Constant1_Value);
  dataAddr[49] = (void*) (&HevP4OptimalController_P.Constant2_Value);
  dataAddr[50] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain);
  dataAddr[51] = (void*) (&HevP4OptimalController_P.Eta4D_maxIndex[0]);
  dataAddr[52] = (void*) (&HevP4OptimalController_P.Eta4D_dimSizes[0]);
  dataAddr[53] = (void*) (&HevP4OptimalController_P.Switch2_Threshold);
  dataAddr[54] = (void*) (&HevP4OptimalController_P.MotTrqControlVector_Value[0]);
  dataAddr[55] = (void*) (&HevP4OptimalController_P.neutral_Value_b);
  dataAddr[56] = (void*) (&HevP4OptimalController_P.noelectric_Value);
  dataAddr[57] = (void*) (&HevP4OptimalController_P.rads2rpm_Gain_o);
  dataAddr[58] = (void*) (&HevP4OptimalController_P.Switch1_Threshold_h);
  dataAddr[59] = (void*) (&HevP4OptimalController_P.TracPwrErrPenalty_Gain);
  dataAddr[60] = (void*) (&HevP4OptimalController_P.W2kW_Gain);
  dataAddr[61] = (void*) (&HevP4OptimalController_P.W2kW1_Gain);
  dataAddr[62] = (void*) (&HevP4OptimalController_P.Saturation_UpperSat_a);
  dataAddr[63] = (void*) (&HevP4OptimalController_P.Saturation_LowerSat_a);
  dataAddr[64] = (void*) (&HevP4OptimalController_P.DiscreteTransferFcn_NumCoef
    [0]);
  dataAddr[65] = (void*) (&HevP4OptimalController_P.DiscreteTransferFcn_DenCoef
    [0]);
  dataAddr[66] = (void*)
    (&HevP4OptimalController_P.DiscreteTransferFcn_InitialStates);
  dataAddr[67] = (void*)
    (&HevP4OptimalController_P.UnitDelay2_InitialCondition_c);
  dataAddr[68] = (void*) (&HevP4OptimalController_P.Saturation1_UpperSat);
  dataAddr[69] = (void*) (&HevP4OptimalController_P.Saturation1_LowerSat);
  dataAddr[70] = (void*) (&HevP4OptimalController_P.Kwtow_Gain_m);
  dataAddr[71] = (void*) (&HevP4OptimalController_P.rpmtorads_Gain_j);
  dataAddr[72] = (void*) (&HevP4OptimalController_P.Saturation_UpperSat_f);
  dataAddr[73] = (void*) (&HevP4OptimalController_P.Saturation_LowerSat_ch);
  dataAddr[74] = (void*) (&HevP4OptimalController_P.Gain5_Gain);
  dataAddr[75] = (void*)
    (&HevP4OptimalController_P.MaxTorquevsSpeed_tableData_i[0]);
  dataAddr[76] = (void*) (&HevP4OptimalController_P.MaxTorquevsSpeed_bp01Data[0]);
  dataAddr[77] = (void*) (&HevP4OptimalController_P.Saturation1_UpperSat_k);
  dataAddr[78] = (void*) (&HevP4OptimalController_P.Saturation1_LowerSat_n);
  dataAddr[79] = (void*) (&HevP4OptimalController_P.neutral_Value_a);
  dataAddr[80] = (void*) (&HevP4OptimalController_P.Switch1_Threshold_d);
  dataAddr[81] = (void*) (&HevP4OptimalController_P.Constant_Value_eu);
  dataAddr[82] = (void*) (&HevP4OptimalController_P.Constant1_Value_m3);
  dataAddr[83] = (void*) (&HevP4OptimalController_P.Constant2_Value_e);
  dataAddr[84] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_b);
  dataAddr[85] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_l);
  dataAddr[86] = (void*) (&HevP4OptimalController_P.W2kW_Gain_g);
  dataAddr[87] = (void*) (&HevP4OptimalController_P.Constant_Value_i);
  dataAddr[88] = (void*) (&HevP4OptimalController_P.Constant2_Value_p);
  dataAddr[89] = (void*) (&HevP4OptimalController_P.uDLookupTable_tableData[0]);
  dataAddr[90] = (void*) (&HevP4OptimalController_P.uDLookupTable_bp01Data[0]);
  dataAddr[91] = (void*) (&HevP4OptimalController_P.uDLookupTable_bp02Data[0]);
  dataAddr[92] = (void*) (&HevP4OptimalController_P.uDLookupTable_maxIndex_o[0]);
  dataAddr[93] = (void*) (&HevP4OptimalController_P.Gain1_Gain);
  dataAddr[94] = (void*) (&HevP4OptimalController_P.rads2rpm_Gain_g);
  dataAddr[95] = (void*) (&HevP4OptimalController_P.rads2rpm1_Gain_e);
  dataAddr[96] = (void*) (&HevP4OptimalController_P.UnitDelay_InitialCondition);
  dataAddr[97] = (void*) (&HevP4OptimalController_P.Constant_Value_c);
  dataAddr[98] = (void*) (&HevP4OptimalController_P.Constant1_Value_ji);
  dataAddr[99] = (void*) (&HevP4OptimalController_P.Constant2_Value_nl);
  dataAddr[100] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_e);
  dataAddr[101] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_p);
  dataAddr[102] = (void*) (&HevP4OptimalController_P.Constant1_Value_h);
  dataAddr[103] = (void*) (&HevP4OptimalController_P.Constant2_Value_k);
  dataAddr[104] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_f);
  dataAddr[105] = (void*) (&HevP4OptimalController_P.Eta4D_maxIndex_e[0]);
  dataAddr[106] = (void*) (&HevP4OptimalController_P.Eta4D_dimSizes_f[0]);
  dataAddr[107] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_n);
  dataAddr[108] = (void*) (&HevP4OptimalController_P.Saturation_UpperSat_i);
  dataAddr[109] = (void*) (&HevP4OptimalController_P.Saturation_LowerSat_c);
  dataAddr[110] = (void*) (&HevP4OptimalController_P.uDLookupTable_maxIndex[0]);
  dataAddr[111] = (void*) (&HevP4OptimalController_P.Saturation_UpperSat_l);
  dataAddr[112] = (void*) (&HevP4OptimalController_P.Saturation_LowerSat_h);
  dataAddr[113] = (void*) (&HevP4OptimalController_P.neutral_Value_o);
  dataAddr[114] = (void*) (&HevP4OptimalController_P.Switch1_Threshold_f);
  dataAddr[115] = (void*) (&HevP4OptimalController_P.EngIdle_const);
  dataAddr[116] = (void*) (&HevP4OptimalController_P.Gain_Gain_m);
  dataAddr[117] = (void*) (&HevP4OptimalController_P.Constant1_Value_l);
  dataAddr[118] = (void*) (&HevP4OptimalController_P.Constant2_Value_n2);
  dataAddr[119] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_is);
  dataAddr[120] = (void*) (&HevP4OptimalController_P.EffMap_maxIndex[0]);
  dataAddr[121] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_kx);
  dataAddr[122] = (void*) (&HevP4OptimalController_P.Constant1_Value_m);
  dataAddr[123] = (void*) (&HevP4OptimalController_P.Constant2_Value_f);
  dataAddr[124] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_o);
  dataAddr[125] = (void*) (&HevP4OptimalController_P.Constant1_Value_f);
  dataAddr[126] = (void*) (&HevP4OptimalController_P.Constant2_Value_g);
  dataAddr[127] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_i);
  dataAddr[128] = (void*) (&HevP4OptimalController_P.Gain_Gain_o);
  dataAddr[129] = (void*) (&HevP4OptimalController_P.Gain_Gain_op);
  dataAddr[130] = (void*) (&HevP4OptimalController_P.Constant_Value_e);
  dataAddr[131] = (void*) (&HevP4OptimalController_P.Constant_Value_f);
  dataAddr[132] = (void*) (&HevP4OptimalController_P.MaxTorquevsSpeed_tableData
    [0]);
  dataAddr[133] = (void*) (&HevP4OptimalController_P.UnitDelay1_InitialCondition);
  dataAddr[134] = (void*) (&HevP4OptimalController_P.UnitDelay2_InitialCondition);
  dataAddr[135] = (void*) (&HevP4OptimalController_P.Constant1_Value_jb);
  dataAddr[136] = (void*) (&HevP4OptimalController_P.Constant2_Value_di);
  dataAddr[137] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_bg);
  dataAddr[138] = (void*) (&HevP4OptimalController_P.Constant1_Value_j);
  dataAddr[139] = (void*) (&HevP4OptimalController_P.Constant2_Value_n);
  dataAddr[140] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_c);
  dataAddr[141] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_b);
  dataAddr[142] = (void*) (&HevP4OptimalController_P.Constant_Value_d);
  dataAddr[143] = (void*)
    (&HevP4OptimalController_P.UnitDelay_InitialCondition_l);
  dataAddr[144] = (void*) (&HevP4OptimalController_P.Constant1_Value_i);
  dataAddr[145] = (void*) (&HevP4OptimalController_P.Constant2_Value_m);
  dataAddr[146] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_f);
  dataAddr[147] = (void*) (&HevP4OptimalController_P.Constant1_Value_o);
  dataAddr[148] = (void*) (&HevP4OptimalController_P.Constant2_Value_h);
  dataAddr[149] = (void*) (&HevP4OptimalController_P.rpm2rads_Gain_i);
  dataAddr[150] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_m);
  dataAddr[151] = (void*) (&HevP4OptimalController_P.Constant1_Value_c);
  dataAddr[152] = (void*) (&HevP4OptimalController_P.Constant2_Value_o);
  dataAddr[153] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_b4);
  dataAddr[154] = (void*) (&HevP4OptimalController_P.Constant1_Value_f0);
  dataAddr[155] = (void*) (&HevP4OptimalController_P.Constant2_Value_a);
  dataAddr[156] = (void*) (&HevP4OptimalController_P.Switch2_Threshold_k);
  dataAddr[157] = (void*) (&HevP4OptimalController_P.Eta4D_maxIndex_j[0]);
  dataAddr[158] = (void*) (&HevP4OptimalController_P.Eta4D_dimSizes_k[0]);
  dataAddr[159] = (void*) (&HevP4OptimalController_P.Eta4D_maxIndex_g[0]);
  dataAddr[160] = (void*) (&HevP4OptimalController_P.Eta4D_dimSizes_a[0]);
  dataAddr[161] = (void*) (&localDW->DiscreteTransferFcn_states);
  dataAddr[162] = (void*) (&localDW->UnitDelay2_DSTATE_d);
  dataAddr[163] = (void*) (&localDW->UnitDelay_DSTATE_c);
  dataAddr[164] = (void*) (&localDW->UnitDelay1_DSTATE[0]);
  dataAddr[165] = (void*) (&localDW->UnitDelay2_DSTATE[0]);
  dataAddr[166] = (void*) (&localDW->UnitDelay_DSTATE[0]);
  dataAddr[167] = (void*) (&HevP4OptimalController_P.AccPwrbp[0]);
  dataAddr[168] = (void*) (&HevP4OptimalController_P.AccSpdbp[0]);
  dataAddr[169] = (void*) (&HevP4OptimalController_P.BattChrgPwrMax);
  dataAddr[170] = (void*) (&HevP4OptimalController_P.BattCurrMax);
  dataAddr[171] = (void*) (&HevP4OptimalController_P.BattDischrgPwrMax);
  dataAddr[172] = (void*) (&HevP4OptimalController_P.BrkPrsMax);
  dataAddr[173] = (void*) (&HevP4OptimalController_P.ChrgLmt_bpt[0]);
  dataAddr[174] = (void*) (&HevP4OptimalController_P.DischrgLmt_bpt[0]);
  dataAddr[175] = (void*) (&HevP4OptimalController_P.ECMS_s);
  dataAddr[176] = (void*) (&HevP4OptimalController_P.G[0]);
  dataAddr[177] = (void*) (&HevP4OptimalController_P.Lhv);
  dataAddr[178] = (void*) (&HevP4OptimalController_P.N[0]);
  dataAddr[179] = (void*) (&HevP4OptimalController_P.N_idle);
  dataAddr[180] = (void*) (&HevP4OptimalController_P.Ndiff);
  dataAddr[181] = (void*) (&HevP4OptimalController_P.Ndiff_P4);
  dataAddr[182] = (void*) (&HevP4OptimalController_P.Re);
  dataAddr[183] = (void*) (&HevP4OptimalController_P.RegenBrkCutOff[0]);
  dataAddr[184] = (void*) (&HevP4OptimalController_P.Rm);
  dataAddr[185] = (void*) (&HevP4OptimalController_P.SOCTrgt);
  dataAddr[186] = (void*) (&HevP4OptimalController_P.SOC_bpt[0]);
  dataAddr[187] = (void*) (&HevP4OptimalController_P.SOCmax);
  dataAddr[188] = (void*) (&HevP4OptimalController_P.SOCmin);
  dataAddr[189] = (void*) (&HevP4OptimalController_P.T_eff_bp[0]);
  dataAddr[190] = (void*) (&HevP4OptimalController_P.T_t[0]);
  dataAddr[191] = (void*) (&HevP4OptimalController_P.Temp_bpts[0]);
  dataAddr[192] = (void*) (&HevP4OptimalController_P.Trq_bpts[0]);
  dataAddr[193] = (void*) (&HevP4OptimalController_P.a);
  dataAddr[194] = (void*) (&HevP4OptimalController_P.efficiency_table[0]);
  dataAddr[195] = (void*) (&HevP4OptimalController_P.eta_dcdc);
  dataAddr[196] = (void*) (&HevP4OptimalController_P.eta_diff);
  dataAddr[197] = (void*) (&HevP4OptimalController_P.eta_tbl[0]);
  dataAddr[198] = (void*) (&HevP4OptimalController_P.f_fuel[0]);
  dataAddr[199] = (void*) (&HevP4OptimalController_P.f_tbrake_min[0]);
  dataAddr[200] = (void*) (&HevP4OptimalController_P.f_tbrake_n_bpt[0]);
  dataAddr[201] = (void*) (&HevP4OptimalController_P.f_tbrake_t_bpt[0]);
  dataAddr[202] = (void*) (&HevP4OptimalController_P.mu_kinetic);
  dataAddr[203] = (void*) (&HevP4OptimalController_P.num_pads);
  dataAddr[204] = (void*) (&HevP4OptimalController_P.omega_bpts[0]);
  dataAddr[205] = (void*) (&HevP4OptimalController_P.w_eff_bp[0]);
  dataAddr[206] = (void*) (&HevP4OptimalController_P.PenaltyFctr);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void HevP4OptimalController_InitializeVarDimsAddr(int32_T* vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void HevP4OptimalController_InitializeLoggingFunctions(RTWLoggingFcnPtr
  loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
  loggingPtrs[14] = (NULL);
  loggingPtrs[15] = (NULL);
  loggingPtrs[16] = (NULL);
  loggingPtrs[17] = (NULL);
  loggingPtrs[18] = (NULL);
  loggingPtrs[19] = (NULL);
  loggingPtrs[20] = (NULL);
  loggingPtrs[21] = (NULL);
  loggingPtrs[22] = (NULL);
  loggingPtrs[23] = (NULL);
  loggingPtrs[24] = (NULL);
  loggingPtrs[25] = (NULL);
  loggingPtrs[26] = (NULL);
  loggingPtrs[27] = (NULL);
  loggingPtrs[28] = (NULL);
  loggingPtrs[29] = (NULL);
  loggingPtrs[30] = (NULL);
  loggingPtrs[31] = (NULL);
  loggingPtrs[32] = (NULL);
  loggingPtrs[33] = (NULL);
  loggingPtrs[34] = (NULL);
  loggingPtrs[35] = (NULL);
  loggingPtrs[36] = (NULL);
  loggingPtrs[37] = (NULL);
  loggingPtrs[38] = (NULL);
  loggingPtrs[39] = (NULL);
  loggingPtrs[40] = (NULL);
  loggingPtrs[41] = (NULL);
  loggingPtrs[42] = (NULL);
  loggingPtrs[43] = (NULL);
  loggingPtrs[44] = (NULL);
  loggingPtrs[45] = (NULL);
  loggingPtrs[46] = (NULL);
  loggingPtrs[47] = (NULL);
  loggingPtrs[48] = (NULL);
  loggingPtrs[49] = (NULL);
  loggingPtrs[50] = (NULL);
  loggingPtrs[51] = (NULL);
  loggingPtrs[52] = (NULL);
  loggingPtrs[53] = (NULL);
  loggingPtrs[54] = (NULL);
  loggingPtrs[55] = (NULL);
  loggingPtrs[56] = (NULL);
  loggingPtrs[57] = (NULL);
  loggingPtrs[58] = (NULL);
  loggingPtrs[59] = (NULL);
  loggingPtrs[60] = (NULL);
  loggingPtrs[61] = (NULL);
  loggingPtrs[62] = (NULL);
  loggingPtrs[63] = (NULL);
  loggingPtrs[64] = (NULL);
  loggingPtrs[65] = (NULL);
  loggingPtrs[66] = (NULL);
  loggingPtrs[67] = (NULL);
  loggingPtrs[68] = (NULL);
  loggingPtrs[69] = (NULL);
  loggingPtrs[70] = (NULL);
  loggingPtrs[71] = (NULL);
  loggingPtrs[72] = (NULL);
  loggingPtrs[73] = (NULL);
  loggingPtrs[74] = (NULL);
  loggingPtrs[75] = (NULL);
  loggingPtrs[76] = (NULL);
  loggingPtrs[77] = (NULL);
  loggingPtrs[78] = (NULL);
  loggingPtrs[79] = (NULL);
  loggingPtrs[80] = (NULL);
  loggingPtrs[81] = (NULL);
  loggingPtrs[82] = (NULL);
  loggingPtrs[83] = (NULL);
  loggingPtrs[84] = (NULL);
  loggingPtrs[85] = (NULL);
  loggingPtrs[86] = (NULL);
  loggingPtrs[87] = (NULL);
  loggingPtrs[88] = (NULL);
  loggingPtrs[89] = (NULL);
  loggingPtrs[90] = (NULL);
  loggingPtrs[91] = (NULL);
  loggingPtrs[92] = (NULL);
  loggingPtrs[93] = (NULL);
  loggingPtrs[94] = (NULL);
  loggingPtrs[95] = (NULL);
  loggingPtrs[96] = (NULL);
  loggingPtrs[97] = (NULL);
  loggingPtrs[98] = (NULL);
  loggingPtrs[99] = (NULL);
  loggingPtrs[100] = (NULL);
  loggingPtrs[101] = (NULL);
  loggingPtrs[102] = (NULL);
  loggingPtrs[103] = (NULL);
  loggingPtrs[104] = (NULL);
  loggingPtrs[105] = (NULL);
  loggingPtrs[106] = (NULL);
  loggingPtrs[107] = (NULL);
  loggingPtrs[108] = (NULL);
  loggingPtrs[109] = (NULL);
  loggingPtrs[110] = (NULL);
  loggingPtrs[111] = (NULL);
  loggingPtrs[112] = (NULL);
  loggingPtrs[113] = (NULL);
  loggingPtrs[114] = (NULL);
  loggingPtrs[115] = (NULL);
  loggingPtrs[116] = (NULL);
  loggingPtrs[117] = (NULL);
  loggingPtrs[118] = (NULL);
  loggingPtrs[119] = (NULL);
  loggingPtrs[120] = (NULL);
  loggingPtrs[121] = (NULL);
  loggingPtrs[122] = (NULL);
  loggingPtrs[123] = (NULL);
  loggingPtrs[124] = (NULL);
  loggingPtrs[125] = (NULL);
  loggingPtrs[126] = (NULL);
  loggingPtrs[127] = (NULL);
  loggingPtrs[128] = (NULL);
  loggingPtrs[129] = (NULL);
  loggingPtrs[130] = (NULL);
  loggingPtrs[131] = (NULL);
  loggingPtrs[132] = (NULL);
  loggingPtrs[133] = (NULL);
  loggingPtrs[134] = (NULL);
  loggingPtrs[135] = (NULL);
  loggingPtrs[136] = (NULL);
  loggingPtrs[137] = (NULL);
  loggingPtrs[138] = (NULL);
  loggingPtrs[139] = (NULL);
  loggingPtrs[140] = (NULL);
  loggingPtrs[141] = (NULL);
  loggingPtrs[142] = (NULL);
  loggingPtrs[143] = (NULL);
  loggingPtrs[144] = (NULL);
  loggingPtrs[145] = (NULL);
  loggingPtrs[146] = (NULL);
  loggingPtrs[147] = (NULL);
  loggingPtrs[148] = (NULL);
  loggingPtrs[149] = (NULL);
  loggingPtrs[150] = (NULL);
  loggingPtrs[151] = (NULL);
  loggingPtrs[152] = (NULL);
  loggingPtrs[153] = (NULL);
  loggingPtrs[154] = (NULL);
  loggingPtrs[155] = (NULL);
  loggingPtrs[156] = (NULL);
  loggingPtrs[157] = (NULL);
  loggingPtrs[158] = (NULL);
  loggingPtrs[159] = (NULL);
  loggingPtrs[160] = (NULL);
  loggingPtrs[161] = (NULL);
  loggingPtrs[162] = (NULL);
  loggingPtrs[163] = (NULL);
  loggingPtrs[164] = (NULL);
  loggingPtrs[165] = (NULL);
  loggingPtrs[166] = (NULL);
  loggingPtrs[167] = (NULL);
  loggingPtrs[168] = (NULL);
  loggingPtrs[169] = (NULL);
  loggingPtrs[170] = (NULL);
  loggingPtrs[171] = (NULL);
  loggingPtrs[172] = (NULL);
  loggingPtrs[173] = (NULL);
  loggingPtrs[174] = (NULL);
  loggingPtrs[175] = (NULL);
  loggingPtrs[176] = (NULL);
  loggingPtrs[177] = (NULL);
  loggingPtrs[178] = (NULL);
  loggingPtrs[179] = (NULL);
  loggingPtrs[180] = (NULL);
  loggingPtrs[181] = (NULL);
  loggingPtrs[182] = (NULL);
  loggingPtrs[183] = (NULL);
  loggingPtrs[184] = (NULL);
  loggingPtrs[185] = (NULL);
  loggingPtrs[186] = (NULL);
  loggingPtrs[187] = (NULL);
  loggingPtrs[188] = (NULL);
  loggingPtrs[189] = (NULL);
  loggingPtrs[190] = (NULL);
  loggingPtrs[191] = (NULL);
  loggingPtrs[192] = (NULL);
  loggingPtrs[193] = (NULL);
  loggingPtrs[194] = (NULL);
  loggingPtrs[195] = (NULL);
  loggingPtrs[196] = (NULL);
  loggingPtrs[197] = (NULL);
  loggingPtrs[198] = (NULL);
  loggingPtrs[199] = (NULL);
  loggingPtrs[200] = (NULL);
  loggingPtrs[201] = (NULL);
  loggingPtrs[202] = (NULL);
  loggingPtrs[203] = (NULL);
  loggingPtrs[204] = (NULL);
  loggingPtrs[205] = (NULL);
  loggingPtrs[206] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_VECTOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_VECTOR, 10, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_VECTOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_VECTOR, 20, 2, 0 },

  { rtwCAPI_VECTOR, 22, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 24, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR_ND, 26, 4, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 30, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  1,                                   /* 2 */
  2,                                   /* 3 */
  1,                                   /* 4 */
  16,                                  /* 5 */
  4,                                   /* 6 */
  1,                                   /* 7 */
  1,                                   /* 8 */
  200,                                 /* 9 */
  1,                                   /* 10 */
  17,                                  /* 11 */
  2,                                   /* 12 */
  2,                                   /* 13 */
  2,                                   /* 14 */
  1,                                   /* 15 */
  202,                                 /* 16 */
  1,                                   /* 17 */
  1,                                   /* 18 */
  11,                                  /* 19 */
  1,                                   /* 20 */
  7,                                   /* 21 */
  1,                                   /* 22 */
  14,                                  /* 23 */
  14,                                  /* 24 */
  11,                                  /* 25 */
  7,                                   /* 26 */
  11,                                  /* 27 */
  7,                                   /* 28 */
  2,                                   /* 29 */
  16,                                  /* 30 */
  16                                   /* 31 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.01, 0.0, 1.0
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[1],
    rtwCAPI_FIX_UNIFORM_SCALING, 32, -8, 0 }
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 0,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 161,
    rtModelParameters, 40 },

  { rtBlockStates, 6 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 2800375710U,
    2140849828U,
    3378403270U,
    1053925316U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  HevP4OptimalController_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void HevP4OptimalController_InitializeDataMapInfo
  (RT_MODEL_HevP4OptimalController_T *const HevP4OptimalController_M,
   DW_HevP4OptimalController_f_T *localDW)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(HevP4OptimalController_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(HevP4OptimalController_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(HevP4OptimalController_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  HevP4OptimalController_InitializeDataAddr
    (HevP4OptimalController_M->DataMapInfo.dataAddress, localDW);
  rtwCAPI_SetDataAddressMap(HevP4OptimalController_M->DataMapInfo.mmi,
    HevP4OptimalController_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  HevP4OptimalController_InitializeVarDimsAddr
    (HevP4OptimalController_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(HevP4OptimalController_M->DataMapInfo.mmi,
    HevP4OptimalController_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(HevP4OptimalController_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(HevP4OptimalController_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  HevP4OptimalController_InitializeLoggingFunctions
    (HevP4OptimalController_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(HevP4OptimalController_M->DataMapInfo.mmi,
    HevP4OptimalController_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(HevP4OptimalController_M->DataMapInfo.mmi,
    (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(HevP4OptimalController_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(HevP4OptimalController_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void HevP4OptimalController_host_InitializeDataMapInfo
    (HevP4OptimalController_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: HevP4OptimalController_capi.c */
