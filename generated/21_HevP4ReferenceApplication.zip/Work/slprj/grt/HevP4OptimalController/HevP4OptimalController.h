/*
 * Code generation for system model 'HevP4OptimalController'
 * For more details, see corresponding source file HevP4OptimalController.c
 *
 */

#ifndef RTW_HEADER_HevP4OptimalController_h_
#define RTW_HEADER_HevP4OptimalController_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef HevP4OptimalController_COMMON_INCLUDES_
#define HevP4OptimalController_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                             /* HevP4OptimalController_COMMON_INCLUDES_ */

#include "HevP4OptimalController_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rt_nonfinite.h"

/* Block states (default storage) for model 'HevP4OptimalController' */
typedef struct {
  real_T UnitDelay1_DSTATE[202];       /* '<S42>/Unit Delay1' */
  real_T UnitDelay2_DSTATE[202];       /* '<S42>/Unit Delay2' */
  real_T UnitDelay_DSTATE[202];        /* '<S60>/Unit Delay' */
  real_T UnitDelay2_DSTATE_d;          /* '<S18>/Unit Delay2' */
  real_T DiscreteTransferFcn_states;   /* '<S18>/Discrete Transfer Fcn' */
  real_T UnitDelay_DSTATE_c;           /* '<S64>/Unit Delay' */
  real_T DiscreteTransferFcn_tmp;      /* '<S18>/Discrete Transfer Fcn' */
  int8_T If_ActiveSubsystem;           /* '<S3>/If' */
} DW_HevP4OptimalController_f_T;

/* Parameters (default storage) */
struct P_HevP4OptimalController_T_ {
  real_T AccPwrbp[2];                  /* Variable: AccPwrbp
                                        * Referenced by: '<S10>/Accessory Load Power'
                                        */
  real_T AccSpdbp[2];                  /* Variable: AccSpdbp
                                        * Referenced by: '<S10>/Accessory Load Power'
                                        */
  real_T BattChrgPwrMax;               /* Variable: BattChrgPwrMax
                                        * Referenced by: '<S29>/MaxChrg'
                                        */
  real_T BattCurrMax;                  /* Variable: BattCurrMax
                                        * Referenced by: '<S29>/Imax3'
                                        */
  real_T BattDischrgPwrMax;            /* Variable: BattDischrgPwrMax
                                        * Referenced by: '<S29>/MaxDischrg'
                                        */
  real_T BrkPrsMax;                    /* Variable: BrkPrsMax
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T ChrgLmt_bpt[11];              /* Variable: ChrgLmt_bpt
                                        * Referenced by:
                                        *   '<S4>/ChrgLmt'
                                        *   '<S29>/ChrgLmt'
                                        */
  real_T DischrgLmt_bpt[11];           /* Variable: DischrgLmt_bpt
                                        * Referenced by: '<S29>/DischrgLmt'
                                        */
  real_T ECMS_s;                       /* Variable: ECMS_s
                                        * Referenced by: '<S27>/Constant1'
                                        */
  real_T G[7];                         /* Variable: G
                                        * Referenced by:
                                        *   '<S13>/Eta 4D'
                                        *   '<S72>/Eta 4D'
                                        *   '<S50>/Eta 4D'
                                        *   '<S46>/Eta 4D'
                                        */
  real_T Lhv;                          /* Variable: Lhv
                                        * Referenced by: '<S18>/LHV'
                                        */
  real_T N[7];                         /* Variable: N
                                        * Referenced by:
                                        *   '<S1>/Direct Lookup Table (n-D)'
                                        *   '<S4>/Direct Lookup Table (n-D)'
                                        *   '<S9>/Gear ratio look up'
                                        *   '<S70>/Gear ratio look up'
                                        *   '<S35>/Gear ratio look up'
                                        *   '<S36>/Gear ratio look up'
                                        *   '<S42>/Gear ratio look up'
                                        */
  real_T N_idle;                       /* Variable: N_idle
                                        * Referenced by:
                                        *   '<S40>/Switch'
                                        *   '<S41>/Switch'
                                        */
  real_T Ndiff;                        /* Variable: Ndiff
                                        * Referenced by:
                                        *   '<S1>/Gain'
                                        *   '<S4>/Gain1'
                                        *   '<S9>/Diff ratio'
                                        *   '<S70>/Diff ratio'
                                        *   '<S35>/Gain'
                                        *   '<S36>/Diff ratio'
                                        *   '<S42>/Gain1'
                                        */
  real_T Ndiff_P4;                     /* Variable: Ndiff_P4
                                        * Referenced by:
                                        *   '<S8>/Gain3'
                                        *   '<S67>/Gain3'
                                        *   '<S64>/Gain3'
                                        *   '<S21>/Gain3'
                                        *   '<S58>/Gain3'
                                        *   '<S60>/Gain3'
                                        */
  real_T Re;                           /* Variable: Re
                                        * Referenced by:
                                        *   '<S1>/Gain2'
                                        *   '<S4>/Gain2'
                                        *   '<S35>/Veh2WhlSpd'
                                        */
  real_T RegenBrkCutOff[2];            /* Variable: RegenBrkCutOff
                                        * Referenced by: '<S4>/RegenBrakingCutoff'
                                        */
  real_T Rm;                           /* Variable: Rm
                                        * Referenced by:
                                        *   '<S4>/Constant'
                                        *   '<S4>/Constant1'
                                        */
  real_T SOCTrgt;                      /* Variable: SOCTrgt
                                        * Referenced by: '<S26>/ '
                                        */
  real_T SOC_bpt[11];                  /* Variable: SOC_bpt
                                        * Referenced by:
                                        *   '<S4>/ChrgLmt'
                                        *   '<S29>/ChrgLmt'
                                        *   '<S29>/DischrgLmt'
                                        */
  real_T SOCmax;                       /* Variable: SOCmax
                                        * Referenced by: '<S26>/ 1'
                                        */
  real_T SOCmin;                       /* Variable: SOCmin
                                        * Referenced by: '<S26>/ 1'
                                        */
  real_T T_eff_bp[11];                 /* Variable: T_eff_bp
                                        * Referenced by: '<S53>/Eff Map'
                                        */
  real_T T_t[14];                      /* Variable: T_t
                                        * Referenced by:
                                        *   '<S1>/MaxMotTrqVsSpd'
                                        *   '<S4>/MaxMotTrqVsSpd'
                                        *   '<S51>/Maximum Torque Lookup'
                                        */
  real_T Temp_bpts[2];                 /* Variable: Temp_bpts
                                        * Referenced by:
                                        *   '<Root>/Constant'
                                        *   '<S13>/Constant'
                                        *   '<S13>/Eta 4D'
                                        *   '<S72>/Constant'
                                        *   '<S72>/Eta 4D'
                                        *   '<S50>/Eta 4D'
                                        *   '<S46>/Eta 4D'
                                        */
  real_T Trq_bpts[7];                  /* Variable: Trq_bpts
                                        * Referenced by:
                                        *   '<S13>/Eta 4D'
                                        *   '<S72>/Eta 4D'
                                        *   '<S50>/Eta 4D'
                                        *   '<S46>/Eta 4D'
                                        */
  real_T a;                            /* Variable: a
                                        * Referenced by: '<S26>/Constant1'
                                        */
  real_T efficiency_table[154];        /* Variable: efficiency_table
                                        * Referenced by: '<S53>/Eff Map'
                                        */
  real_T eta_dcdc;                     /* Variable: eta_dcdc
                                        * Referenced by: '<S32>/DCDC Constant Eff'
                                        */
  real_T eta_diff;                     /* Variable: eta_diff
                                        * Referenced by:
                                        *   '<S11>/Constant'
                                        *   '<S12>/Constant'
                                        *   '<S65>/Constant'
                                        *   '<S22>/Constant'
                                        *   '<S47>/Constant'
                                        *   '<S43>/Constant'
                                        *   '<S59>/Constant'
                                        *   '<S61>/Constant'
                                        */
  real_T eta_tbl[1078];                /* Variable: eta_tbl
                                        * Referenced by:
                                        *   '<S13>/Eta 4D'
                                        *   '<S72>/Eta 4D'
                                        *   '<S50>/Eta 4D'
                                        *   '<S46>/Eta 4D'
                                        */
  real_T f_fuel[256];                  /* Variable: f_fuel
                                        * Referenced by: '<S34>/2-D Lookup Table'
                                        */
  real_T f_tbrake_min[16];             /* Variable: f_tbrake_min
                                        * Referenced by: '<S40>/Min Torque vs Speed'
                                        */
  real_T f_tbrake_n_bpt[16];           /* Variable: f_tbrake_n_bpt
                                        * Referenced by:
                                        *   '<S7>/MaxEngineTorque'
                                        *   '<S34>/2-D Lookup Table'
                                        *   '<S40>/Min Torque vs Speed'
                                        *   '<S41>/Max Torque vs Speed'
                                        */
  real_T f_tbrake_t_bpt[16];           /* Variable: f_tbrake_t_bpt
                                        * Referenced by: '<S34>/2-D Lookup Table'
                                        */
  real_T mu_kinetic;                   /* Variable: mu_kinetic
                                        * Referenced by:
                                        *   '<S4>/Constant'
                                        *   '<S4>/Constant1'
                                        */
  real_T num_pads;                     /* Variable: num_pads
                                        * Referenced by:
                                        *   '<S4>/Constant'
                                        *   '<S4>/Constant1'
                                        */
  real_T omega_bpts[11];               /* Variable: omega_bpts
                                        * Referenced by:
                                        *   '<S13>/Eta 4D'
                                        *   '<S72>/Eta 4D'
                                        *   '<S50>/Eta 4D'
                                        *   '<S46>/Eta 4D'
                                        */
  real_T w_eff_bp[14];                 /* Variable: w_eff_bp
                                        * Referenced by:
                                        *   '<S1>/MaxMotTrqVsSpd'
                                        *   '<S4>/MaxMotTrqVsSpd'
                                        *   '<S51>/Maximum Torque Lookup'
                                        *   '<S53>/Eff Map'
                                        */
  uint32_T PenaltyFctr;                /* Variable: PenaltyFctr
                                        * Referenced by: '<S18>/Constraint Penalty Factor'
                                        */
  real_T AccessoryLoadModel_AccPwrTbl[2];
                                 /* Mask Parameter: AccessoryLoadModel_AccPwrTbl
                                  * Referenced by: '<S68>/Accessory Load Power'
                                  */
  real_T AccessoryLoadModel_AccSpdBpts[2];
                                /* Mask Parameter: AccessoryLoadModel_AccSpdBpts
                                 * Referenced by: '<S68>/Accessory Load Power'
                                 */
  real_T GEMinSpeed_const;             /* Mask Parameter: GEMinSpeed_const
                                        * Referenced by: '<S62>/Constant'
                                        */
  real_T EngIdle_const;                /* Mask Parameter: EngIdle_const
                                        * Referenced by: '<S56>/Constant'
                                        */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S6>/Constant'
                                      */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S5>/Constant'
                                       */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S1>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S13>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: -1
                                        * Referenced by: '<S13>/Constant2'
                                        */
  real_T Saturation_UpperSat;          /* Expression: Inf
                                        * Referenced by: '<S10>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 300
                                        * Referenced by: '<S10>/Saturation'
                                        */
  real_T rpmtorads_Gain;               /* Expression: pi/30
                                        * Referenced by: '<S10>/rpm to rad//s'
                                        */
  real_T Kwtow_Gain;                   /* Expression: 1000
                                        * Referenced by: '<S10>/Kw to w'
                                        */
  real_T MaxEngineTorque_tableData[16];/* Expression: [0 max(f_tbrake(:,2:end))]
                                        * Referenced by: '<S7>/MaxEngineTorque'
                                        */
  real_T rpm2rads_Gain;                /* Expression: pi/30
                                        * Referenced by: '<S13>/rpm2rads'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0
                                        * Referenced by: '<S13>/Switch2'
                                        */
  real_T neutral_Value;                /* Expression: 0
                                        * Referenced by: '<S9>/neutral'
                                        */
  real_T Constant1_Value_a;            /* Expression: 1
                                        * Referenced by: '<S11>/Constant1'
                                        */
  real_T Constant1_Value_aj;           /* Expression: 1
                                        * Referenced by: '<S12>/Constant1'
                                        */
  real_T Constant2_Value_i;            /* Expression: -1
                                        * Referenced by: '<S11>/Constant2'
                                        */
  real_T Constant2_Value_d;            /* Expression: -1
                                        * Referenced by: '<S12>/Constant2'
                                        */
  real_T rads2rpm1_Gain;               /* Expression: 30/pi
                                        * Referenced by: '<S1>/rads2rpm1'
                                        */
  real_T rads2rpm_Gain;                /* Expression: 30/pi
                                        * Referenced by: '<S1>/rads2rpm'
                                        */
  real_T rpm2rads_Gain_h;              /* Expression: pi/30
                                        * Referenced by: '<S11>/rpm2rads'
                                        */
  real_T Switch2_Threshold_a;          /* Expression: 0
                                        * Referenced by: '<S11>/Switch2'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S9>/Switch1'
                                        */
  real_T rpm2rads_Gain_l;              /* Expression: pi/30
                                        * Referenced by: '<S12>/rpm2rads'
                                        */
  real_T Switch2_Threshold_c;          /* Expression: 0
                                        * Referenced by: '<S12>/Switch2'
                                        */
  real_T Gain_Gain;                    /* Expression: -1
                                        * Referenced by: '<S4>/Gain'
                                        */
  real_T Constant1_Value_aw;           /* Expression: 1
                                        * Referenced by: '<S2>/Constant1'
                                        */
  real_T Constant1_Value_m;            /* Expression: 1
                                        * Referenced by: '<S65>/Constant1'
                                        */
  real_T Constant2_Value_f;            /* Expression: -1
                                        * Referenced by: '<S65>/Constant2'
                                        */
  real_T Constant_Value_p;             /* Expression: 0
                                        * Referenced by: '<S16>/Constant'
                                        */
  real_T Gain_Gain_i;                  /* Expression: 1/N_P0
                                        * Referenced by: '<S16>/Gain'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S64>/Unit Delay'
                                        */
  real_T rads2rpm_Gain_h;              /* Expression: 30/pi
                                        * Referenced by: '<S16>/rads2rpm'
                                        */
  real_T Switch2_Threshold_o;          /* Expression: 0
                                        * Referenced by: '<S65>/Switch2'
                                        */
  real_T Constant2_Value_ir;           /* Expression: 0
                                        * Referenced by: '<S16>/Constant2'
                                        */
  real_T Constant1_Value_a5;           /* Expression: 0
                                        * Referenced by: '<S16>/Constant1'
                                        */
  real_T neutral_Value_b;              /* Expression: 0
                                        * Referenced by: '<S17>/neutral'
                                        */
  real_T Constant_Value_i;             /* Expression: 0
                                        * Referenced by: '<S26>/Constant'
                                        */
  real_T Gain_Gain_o;                  /* Expression: 0
                                        * Referenced by: '<S37>/Gain'
                                        */
  real_T Gain_Gain_op;                 /* Expression: 0
                                        * Referenced by: '<S38>/Gain'
                                        */
  real_T Constant_Value_e;             /* Expression: 0
                                        * Referenced by: '<S40>/Constant'
                                        */
  real_T MaxTorquevsSpeed_tableData[16];/* Expression: max(f_tbrake)
                                         * Referenced by: '<S41>/Max Torque vs Speed'
                                         */
  real_T Constant_Value_f;             /* Expression: 0
                                        * Referenced by: '<S41>/Constant'
                                        */
  real_T Constant2_Value_n;            /* Expression: -1
                                        * Referenced by: '<S48>/Constant2'
                                        */
  real_T rpm2rads_Gain_c;              /* Expression: pi/30
                                        * Referenced by: '<S48>/rpm2rads'
                                        */
  real_T Constant1_Value_j;            /* Expression: 1
                                        * Referenced by: '<S48>/Constant1'
                                        */
  real_T Switch2_Threshold_b;          /* Expression: 0
                                        * Referenced by: '<S48>/Switch2'
                                        */
  real_T neutral_Value_o;              /* Expression: 0
                                        * Referenced by: '<S36>/neutral'
                                        */
  real_T Constant_Value_d;             /* Expression: 0
                                        * Referenced by: '<S55>/Constant'
                                        */
  real_T MotTrqControlVector_Value[200];
            /* Expression: linspace( -max(f_mtr_t_bpt), max(f_mtr_t_bpt), Ngrid)
             * Referenced by: '<S17>/MotTrq Control Vector'
             */
  real_T Constant1_Value_f;            /* Expression: 1
                                        * Referenced by: '<S22>/Constant1'
                                        */
  real_T Constant2_Value_g;            /* Expression: -1
                                        * Referenced by: '<S22>/Constant2'
                                        */
  real_T rads2rpm_Gain_o;              /* Expression: 30/pi
                                        * Referenced by: '<S17>/rads2rpm'
                                        */
  real_T Switch2_Threshold_i;          /* Expression: 0
                                        * Referenced by: '<S22>/Switch2'
                                        */
  real_T Switch1_Threshold_h;          /* Expression: 0
                                        * Referenced by: '<S17>/Switch1'
                                        */
  real_T noelectric_Value;             /* Expression: 0
                                        * Referenced by: '<S17>/no electric'
                                        */
  real_T Saturation_UpperSat_l;        /* Expression: inf
                                        * Referenced by: '<S35>/Saturation'
                                        */
  real_T Saturation_LowerSat_h;        /* Expression: 0
                                        * Referenced by: '<S35>/Saturation'
                                        */
  real_T rads2rpm_Gain_g;              /* Expression: 30/pi
                                        * Referenced by: '<S30>/rads2rpm'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S42>/Unit Delay1'
                                        */
  real_T Constant1_Value_o;            /* Expression: 1
                                        * Referenced by: '<S44>/Constant1'
                                        */
  real_T rpm2rads_Gain_i;              /* Expression: pi/30
                                        * Referenced by: '<S44>/rpm2rads'
                                        */
  real_T Constant2_Value_h;            /* Expression: -1
                                        * Referenced by: '<S44>/Constant2'
                                        */
  real_T Switch2_Threshold_m;          /* Expression: 0
                                        * Referenced by: '<S44>/Switch2'
                                        */
  real_T Constant1_Value_i;            /* Expression: 1
                                        * Referenced by: '<S43>/Constant1'
                                        */
  real_T UnitDelay2_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S42>/Unit Delay2'
                                        */
  real_T Constant2_Value_m;            /* Expression: -1
                                        * Referenced by: '<S43>/Constant2'
                                        */
  real_T Switch2_Threshold_f;          /* Expression: 0
                                        * Referenced by: '<S43>/Switch2'
                                        */
  real_T Constant1_Value_c;            /* Expression: 1
                                        * Referenced by: '<S59>/Constant1'
                                        */
  real_T rads2rpm1_Gain_e;             /* Expression: 30/pi
                                        * Referenced by: '<S31>/rads2rpm1'
                                        */
  real_T Constant1_Value_f0;           /* Expression: 1
                                        * Referenced by: '<S61>/Constant1'
                                        */
  real_T UnitDelay_InitialCondition_l; /* Expression: 0
                                        * Referenced by: '<S60>/Unit Delay'
                                        */
  real_T Constant2_Value_a;            /* Expression: -1
                                        * Referenced by: '<S61>/Constant2'
                                        */
  real_T Switch2_Threshold_k;          /* Expression: 0
                                        * Referenced by: '<S61>/Switch2'
                                        */
  real_T Gain_Gain_m;                  /* Expression: -1
                                        * Referenced by: '<S51>/Gain'
                                        */
  real_T Constant2_Value_o;            /* Expression: -1
                                        * Referenced by: '<S59>/Constant2'
                                        */
  real_T Switch2_Threshold_b4;         /* Expression: 0
                                        * Referenced by: '<S59>/Switch2'
                                        */
  real_T rpm2rads_Gain_is;             /* Expression: pi/30
                                        * Referenced by: '<S53>/rpm2rads'
                                        */
  real_T Constant1_Value_l;            /* Expression: -1
                                        * Referenced by: '<S53>/Constant1'
                                        */
  real_T Constant2_Value_n2;           /* Expression: 1
                                        * Referenced by: '<S53>/Constant2'
                                        */
  real_T Switch2_Threshold_kx;         /* Expression: 0
                                        * Referenced by: '<S53>/Switch2'
                                        */
  real_T Saturation_UpperSat_i;        /* Expression: Inf
                                        * Referenced by: '<S32>/Saturation'
                                        */
  real_T Saturation_LowerSat_c;        /* Expression: 0.0001
                                        * Referenced by: '<S32>/Saturation'
                                        */
  real_T Gain1_Gain;                   /* Expression: -1
                                        * Referenced by: '<S29>/Gain1'
                                        */
  real_T W2kW_Gain;                    /* Expression: 1/1000
                                        * Referenced by: '<S18>/W2kW '
                                        */
  real_T uDLookupTable_tableData[4];   /* Expression: [0 2; 1.9 2]
                                        * Referenced by: '<S26>/2-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[2];    /* Expression: [0 15]
                                        * Referenced by: '<S26>/2-D Lookup Table'
                                        */
  real_T uDLookupTable_bp02Data[2];    /* Expression: [20 SOCmin]
                                        * Referenced by: '<S26>/2-D Lookup Table'
                                        */
  real_T Constant2_Value_p;            /* Expression: 1
                                        * Referenced by: '<S26>/Constant2'
                                        */
  real_T Constant1_Value_jb;           /* Expression: 1
                                        * Referenced by: '<S47>/Constant1'
                                        */
  real_T Switch1_Threshold_f;          /* Expression: 0
                                        * Referenced by: '<S36>/Switch1'
                                        */
  real_T Constant2_Value_di;           /* Expression: -1
                                        * Referenced by: '<S47>/Constant2'
                                        */
  real_T Switch2_Threshold_bg;         /* Expression: 0
                                        * Referenced by: '<S47>/Switch2'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: inf
                                        * Referenced by: '<S19>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: 0.001
                                        * Referenced by: '<S19>/Saturation1'
                                        */
  real_T W2kW1_Gain;                   /* Expression: 1/1000
                                        * Referenced by: '<S18>/W2kW 1'
                                        */
  real_T TracPwrErrPenalty_Gain;       /* Expression: 6
                                        * Referenced by: '<S18>/TracPwrErr Penalty'
                                        */
  real_T UnitDelay2_InitialCondition_c;/* Expression: 0
                                        * Referenced by: '<S18>/Unit Delay2'
                                        */
  real_T W2kW_Gain_g;                  /* Expression: 1/1000
                                        * Referenced by: '<S24>/W2kW'
                                        */
  real_T DiscreteTransferFcn_NumCoef[2];/* Expression: [0.1 -0.05123]
                                         * Referenced by: '<S18>/Discrete Transfer Fcn'
                                         */
  real_T DiscreteTransferFcn_DenCoef[2];/* Expression: [1 -0.9512]
                                         * Referenced by: '<S18>/Discrete Transfer Fcn'
                                         */
  real_T DiscreteTransferFcn_InitialStates;/* Expression: 0
                                            * Referenced by: '<S18>/Discrete Transfer Fcn'
                                            */
  real_T Saturation_UpperSat_a;        /* Expression: inf
                                        * Referenced by: '<S18>/Saturation'
                                        */
  real_T Saturation_LowerSat_a;        /* Expression: 0
                                        * Referenced by: '<S18>/Saturation'
                                        */
  real_T Constant1_Value_ji;           /* Expression: 1
                                        * Referenced by: '<S71>/Constant1'
                                        */
  real_T Constant2_Value_nl;           /* Expression: -1
                                        * Referenced by: '<S71>/Constant2'
                                        */
  real_T Constant1_Value_h;            /* Expression: 1
                                        * Referenced by: '<S72>/Constant1'
                                        */
  real_T Constant2_Value_k;            /* Expression: -1
                                        * Referenced by: '<S72>/Constant2'
                                        */
  real_T MaxTorquevsSpeed_tableData_i[17];
                                     /* Expression: [0 0 min(f_tbrake(:,2:end))]
                                      * Referenced by: '<S69>/Max Torque vs Speed'
                                      */
  real_T MaxTorquevsSpeed_bp01Data[17];
                                  /* Expression: [0 749 f_tbrake_n_bpt(:,2:end)]
                                   * Referenced by: '<S69>/Max Torque vs Speed'
                                   */
  real_T Gain5_Gain;                   /* Expression: -1
                                        * Referenced by: '<S69>/Gain5'
                                        */
  real_T Saturation1_UpperSat_k;       /* Expression: inf
                                        * Referenced by: '<S69>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_n;       /* Expression: 0
                                        * Referenced by: '<S69>/Saturation1'
                                        */
  real_T Constant2_Value_ny;           /* Expression: 0
                                        * Referenced by: '<S66>/Constant2'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S66>/Switch'
                                        */
  real_T Saturation_UpperSat_f;        /* Expression: Inf
                                        * Referenced by: '<S68>/Saturation'
                                        */
  real_T Saturation_LowerSat_ch;       /* Expression: 300
                                        * Referenced by: '<S68>/Saturation'
                                        */
  real_T rpmtorads_Gain_j;             /* Expression: pi/30
                                        * Referenced by: '<S68>/rpm to rad//s'
                                        */
  real_T Kwtow_Gain_m;                 /* Expression: 1000
                                        * Referenced by: '<S68>/Kw to w'
                                        */
  real_T rpm2rads_Gain_f;              /* Expression: pi/30
                                        * Referenced by: '<S72>/rpm2rads'
                                        */
  real_T Switch2_Threshold_n;          /* Expression: 0
                                        * Referenced by: '<S72>/Switch2'
                                        */
  real_T neutral_Value_a;              /* Expression: 0
                                        * Referenced by: '<S70>/neutral'
                                        */
  real_T Constant1_Value_m3;           /* Expression: 1
                                        * Referenced by: '<S73>/Constant1'
                                        */
  real_T Constant2_Value_e;            /* Expression: -1
                                        * Referenced by: '<S73>/Constant2'
                                        */
  real_T Switch_Threshold_o;           /* Expression: 0
                                        * Referenced by: '<S2>/Switch'
                                        */
  real_T Constant_Value_c;             /* Expression: 1
                                        * Referenced by: '<S71>/Constant'
                                        */
  real_T rads2rpm1_Gain_o;             /* Expression: 30/pi
                                        * Referenced by: '<S4>/rads2rpm1'
                                        */
  real_T Switch1_Threshold_d;          /* Expression: 0
                                        * Referenced by: '<S70>/Switch1'
                                        */
  real_T rpm2rads_Gain_e;              /* Expression: pi/30
                                        * Referenced by: '<S71>/rpm2rads'
                                        */
  real_T Switch2_Threshold_p;          /* Expression: 0
                                        * Referenced by: '<S71>/Switch2'
                                        */
  real_T Saturation_UpperSat_b;        /* Expression: inf
                                        * Referenced by: '<S66>/Saturation'
                                        */
  real_T Saturation_LowerSat_n;        /* Expression: 0
                                        * Referenced by: '<S66>/Saturation'
                                        */
  real_T Constant_Value_eu;            /* Expression: 1
                                        * Referenced by: '<S73>/Constant'
                                        */
  real_T rads_to_rpm_Gain;             /* Expression: 30/pi
                                        * Referenced by: '<S4>/rads_to_rpm'
                                        */
  real_T Gain3_Gain;                   /* Expression: -1
                                        * Referenced by: '<S4>/Gain3'
                                        */
  real_T rpm2rads_Gain_b;              /* Expression: pi/30
                                        * Referenced by: '<S73>/rpm2rads'
                                        */
  real_T Switch2_Threshold_l;          /* Expression: 0
                                        * Referenced by: '<S73>/Switch2'
                                        */
  real_T Gain4_Gain;                   /* Expression: -1
                                        * Referenced by: '<S4>/Gain4'
                                        */
  real_T RegenBrakingCutoff_bp01Data[2];
                            /* Expression: [f_tbrake_n_bpt(2) f_tbrake_n_bpt(3)]
                             * Referenced by: '<S4>/RegenBrakingCutoff'
                             */
  real_T Gain5_Gain_m;                 /* Expression: 1/100
                                        * Referenced by: '<S4>/Gain5'
                                        */
  real_T Gain1_Gain_e;                 /* Expression: 1/100
                                        * Referenced by: '<S3>/Gain1'
                                        */
  real_T Merge_InitialOutput;          /* Expression: 0
                                        * Referenced by: '<S3>/Merge'
                                        */
  real_T Merge1_InitialOutput;         /* Expression: 0
                                        * Referenced by: '<S3>/Merge1'
                                        */
  real_T Merge2_InitialOutput;         /* Expression: 0
                                        * Referenced by: '<S3>/Merge2'
                                        */
  real_T Merge3_InitialOutput;         /* Expression: 0
                                        * Referenced by: '<S3>/Merge3'
                                        */
  real_T Negative5_UpperSat;           /* Expression: inf
                                        * Referenced by: '<S4>/Negative 5'
                                        */
  real_T Negative5_LowerSat;           /* Expression: 0
                                        * Referenced by: '<S4>/Negative 5'
                                        */
  uint32_T Eta4D_maxIndex[4];          /* Computed Parameter: Eta4D_maxIndex
                                        * Referenced by: '<S13>/Eta 4D'
                                        */
  uint32_T Eta4D_dimSizes[4];          /* Computed Parameter: Eta4D_dimSizes
                                        * Referenced by: '<S13>/Eta 4D'
                                        */
  uint32_T Eta4D_maxIndex_g[4];        /* Computed Parameter: Eta4D_maxIndex_g
                                        * Referenced by: '<S46>/Eta 4D'
                                        */
  uint32_T Eta4D_dimSizes_a[4];        /* Computed Parameter: Eta4D_dimSizes_a
                                        * Referenced by: '<S46>/Eta 4D'
                                        */
  uint32_T uDLookupTable_maxIndex[2];
                                   /* Computed Parameter: uDLookupTable_maxIndex
                                    * Referenced by: '<S34>/2-D Lookup Table'
                                    */
  uint32_T EffMap_maxIndex[2];         /* Computed Parameter: EffMap_maxIndex
                                        * Referenced by: '<S53>/Eff Map'
                                        */
  uint32_T uDLookupTable_maxIndex_o[2];
                                 /* Computed Parameter: uDLookupTable_maxIndex_o
                                  * Referenced by: '<S26>/2-D Lookup Table'
                                  */
  uint32_T Eta4D_maxIndex_j[4];        /* Computed Parameter: Eta4D_maxIndex_j
                                        * Referenced by: '<S50>/Eta 4D'
                                        */
  uint32_T Eta4D_dimSizes_k[4];        /* Computed Parameter: Eta4D_dimSizes_k
                                        * Referenced by: '<S50>/Eta 4D'
                                        */
  uint32_T Eta4D_maxIndex_e[4];        /* Computed Parameter: Eta4D_maxIndex_e
                                        * Referenced by: '<S72>/Eta 4D'
                                        */
  uint32_T Eta4D_dimSizes_f[4];        /* Computed Parameter: Eta4D_dimSizes_f
                                        * Referenced by: '<S72>/Eta 4D'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_HevP4OptimalController_T {
  const char_T **errorStatus;
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[207];
    int32_T* vardimsAddress[207];
    RTWLoggingFcnPtr loggingPtrs[207];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    int_T mdlref_GlobalTID[2];
  } Timing;
};

typedef struct {
  DW_HevP4OptimalController_f_T rtdw;
  RT_MODEL_HevP4OptimalController_T rtm;
} MdlrefDW_HevP4OptimalController_T;

/* Model reference registration function */
extern void HevP4OptimalController_initialize(const char_T **rt_errorStatus,
  const rtTimingBridge *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_HevP4OptimalController_T *const HevP4OptimalController_M,
  DW_HevP4OptimalController_f_T *localDW, rtwCAPI_ModelMappingInfo *rt_ParentMMI,
  const char_T *rt_ChildPath, int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  HevP4OptimalController_GetCAPIStaticMap(void);
extern void HevP4OptimalController_Init(real_T *rty_EngTrqCmd, real_T
  *rty_MtrTrqCmd, real_T *rty_Cltch1Cmd, real_T *rty_StartCmd, real_T
  *rty_Neutral, DW_HevP4OptimalController_f_T *localDW);
extern void HevP4OptimalController_Disable(DW_HevP4OptimalController_f_T
  *localDW);
extern void HevP4OptimalController(RT_MODEL_HevP4OptimalController_T * const
  HevP4OptimalController_M, const real_T *rtu_AccelPdl, const real_T
  *rtu_DecelPdl, const real_T *rtu_VehSpdFdbk, const real_T *rtu_BattSoc, const
  real_T *rtu_MtrSpd, const real_T *rtu_TransGear, const real_T *rtu_BattVolt,
  real_T *rty_EngTrqCmd, real_T *rty_MtrTrqCmd, real_T *rty_BrkCmd, real_T
  *rty_Cltch1Cmd, real_T *rty_StartCmd, real_T *rty_Neutral, real_T
  *rty_WhlTrqCmd, DW_HevP4OptimalController_f_T *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HevP4OptimalController'
 * '<S1>'   : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request'
 * '<S2>'   : 'HevP4OptimalController/Brake Pedal to Total Braking Pressure Request'
 * '<S3>'   : 'HevP4OptimalController/ECMS'
 * '<S4>'   : 'HevP4OptimalController/Series Regen Braking'
 * '<S5>'   : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Compare To Constant'
 * '<S6>'   : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Compare To Constant1'
 * '<S7>'   : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque'
 * '<S8>'   : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MotTrq2WhlMotTrq'
 * '<S9>'   : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission'
 * '<S10>'  : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MaxEngineTorque/Accessory Load Model'
 * '<S11>'  : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/MotTrq2WhlMotTrq/Diff Eta'
 * '<S12>'  : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Diff Eta'
 * '<S13>'  : 'HevP4OptimalController/Accel Pedal to Traction Wheel Torque Request/Transmission/Trans Eta'
 * '<S14>'  : 'HevP4OptimalController/ECMS/ECMS Info'
 * '<S15>'  : 'HevP4OptimalController/ECMS/Energy Management'
 * '<S16>'  : 'HevP4OptimalController/ECMS/Energy Management Off'
 * '<S17>'  : 'HevP4OptimalController/ECMS/Energy Management/Control Domain'
 * '<S18>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization'
 * '<S19>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints'
 * '<S20>'  : 'HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq2WhlMotTrq'
 * '<S21>'  : 'HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4'
 * '<S22>'  : 'HevP4OptimalController/ECMS/Energy Management/Control Domain/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta'
 * '<S23>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/ECMS Method'
 * '<S24>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/EngPwr Rate Limit'
 * '<S25>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/MATLAB Function'
 * '<S26>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)'
 * '<S27>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/ECMS Method/Nonadaptive ECMS'
 * '<S28>'  : 'HevP4OptimalController/ECMS/Energy Management/Hamiltonian computation and minimization/p(SOC)/Saturation Dynamic'
 * '<S29>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Battery Constraint'
 * '<S30>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint'
 * '<S31>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint'
 * '<S32>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Battery Constraint/Electrical Current'
 * '<S33>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Battery Constraint/Saturation Dynamic'
 * '<S34>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On'
 * '<S35>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/EngSpd Calculation'
 * '<S36>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission'
 * '<S37>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/EngTrqLmtLow'
 * '<S38>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/EngTrqLmtUp'
 * '<S39>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Engine Torque Saturation'
 * '<S40>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Lower Limit'
 * '<S41>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Upper Limit'
 * '<S42>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq'
 * '<S43>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Diff Eta'
 * '<S44>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta'
 * '<S45>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Eta Lookup'
 * '<S46>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Eng On/Whl2EngTrq/Trans Eta/Eta Lookup/Eta 4D'
 * '<S47>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Diff Eta'
 * '<S48>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta'
 * '<S49>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Eta Lookup'
 * '<S50>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Engine Constraint/Transmission/Trans Eta/Eta Lookup/Eta 4D'
 * '<S51>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque'
 * '<S52>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/MotTrq2WhlMotTrq'
 * '<S53>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Tabular Power Loss Data'
 * '<S54>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq'
 * '<S55>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque/Compare To Zero'
 * '<S56>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque/EngIdle'
 * '<S57>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/Maximum Torque/Saturation Dynamic'
 * '<S58>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4'
 * '<S59>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/MotTrq2WhlMotTrq/MotTrq2WhlMotTrq P4/Diff Eta'
 * '<S60>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4'
 * '<S61>'  : 'HevP4OptimalController/ECMS/Energy Management/Powertrain Constraints/Motor Constraint/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta'
 * '<S62>'  : 'HevP4OptimalController/ECMS/Energy Management Off/GEMinSpeed'
 * '<S63>'  : 'HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq'
 * '<S64>'  : 'HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4'
 * '<S65>'  : 'HevP4OptimalController/ECMS/Energy Management Off/WhlTrqCmd2MotTrq/WhlTrq2MotTrq P4/Diff Eta'
 * '<S66>'  : 'HevP4OptimalController/Series Regen Braking/EngBrakingEstimate'
 * '<S67>'  : 'HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq'
 * '<S68>'  : 'HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Accessory Load Model'
 * '<S69>'  : 'HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Lower Limit'
 * '<S70>'  : 'HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission'
 * '<S71>'  : 'HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Diff Eta'
 * '<S72>'  : 'HevP4OptimalController/Series Regen Braking/EngBrakingEstimate/Transmission/Trans Eta'
 * '<S73>'  : 'HevP4OptimalController/Series Regen Braking/MotTrq2WhlMotTrq/Diff Eta'
 */
#endif                                /* RTW_HEADER_HevP4OptimalController_h_ */
