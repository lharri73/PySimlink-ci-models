/*
 * AutomatedParkingValet.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:14:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rt_logging_mmi.h"
#include "AutomatedParkingValet_capi.h"
#include "AutomatedParkingValet.h"
#include "AutomatedParkingValet_private.h"
#include "NeighborhoodProcessor__exhgTOQa.h"
#include "all_NdIgJbYL.h"
#include "angleUtilities_wrapTo2_bbViJ3IV.h"
#include "cos_yxWixxmO.h"
#include "div_s32.h"
#include "div_s32_floor.h"
#include "eml_rand_mt19937ar_Ja00L5sI.h"
#include "look1_binlcpw.h"
#include "look1_binlxpw.h"
#include "norm_Sv0LdesD.h"
#include "rt_atan2d_snf.h"
#include "rt_hypotd_snf.h"
#include "rt_powd_snf.h"
#include "rt_remd_snf.h"
#include "rt_roundd_snf.h"
#include "sin_aZRL3w35.h"

rtTimingBridge AutomatedParkingVale_TimingBrdg;

/* Block signals (default storage) */
B_AutomatedParkingValet_T AutomatedParkingValet_B;

/* Continuous states */
X_AutomatedParkingValet_T AutomatedParkingValet_X;

/* Block states (default storage) */
DW_AutomatedParkingValet_T AutomatedParkingValet_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_AutomatedParkingValet_T AutomatedParkingValet_PrevZCX;

/* Real-time model */
RT_MODEL_AutomatedParkingVale_T AutomatedParkingValet_M_;
RT_MODEL_AutomatedParkingVale_T *const AutomatedParkingValet_M =
  &AutomatedParkingValet_M_;

/* Forward declaration for local functions */
static void AutomatedParking_emxInit_real_T(emxArray_real_T_AutomatedPark_T
  **pEmxArray, int32_T numDimensions);
static void emxInitStruct_driving_internal_(driving_internal_planning_Pat_T
  *pStruct);
static void Automa_emxEnsureCapacity_real_T(emxArray_real_T_AutomatedPark_T
  *emxArray, int32_T oldNumel);
static void AutomatedPa_SystemCore_setup_pm(driving_internal_planning_Pat_T *obj,
  const int32_T varargin_1_size[2], const int32_T *varargin_2_size);
static void emxInitStruct_driving_interna_p(driving_internal_planning_Vel_T
  *pStruct);
static void AutomatedPar_SystemCore_setup_p(driving_internal_planning_Vel_T *obj,
  const int32_T *varargin_1_size, const int32_T *varargin_2_size, const int32_T *
  varargin_3_size);
static void emxInitStruct_HelperPathAnalyze(HelperPathAnalyzer_AutomatedP_T
  *pStruct);
static void AutomatedParki_SystemCore_setup(HelperPathAnalyzer_AutomatedP_T *obj,
  const int32_T varargin_3_size[2], const int32_T *varargin_4_size, const
  int32_T *varargin_5_size, const int32_T *varargin_6_size);
static void emxInit_c_driving_internal_plan(emxArray_c_driving_internal_p_T
  **pEmxArray, int32_T numDimensions);
static void emxInitStruct_d_driving_interna(d_driving_internal_planning_D_T
  *pStruct);
static void Auto_emxInitStruct_driving_Path(driving_Path_AutomatedParking_T
  *pStruct);
static void Au_emxInitStruct_pathPlannerRRT(pathPlannerRRT_AutomatedParki_T
  *pStruct);
static void HelperBehavioralPlanner_request(HelperBehavioralPlanner_Autom_T
  *this, const real_T currentPose[3], real_T currentSpeed, real_T nextGoal[3],
  real_T *plannerConfig_ConnectionDistanc, real_T *plannerConfig_MinIterations,
  real_T plannerConfig_GoalTolerance[3], real_T *plannerConfig_MinTurningRadius,
  boolean_T *plannerConfig_IsParkManeuver, real_T *speedProfile_StartSpeed,
  real_T *speedProfile_EndSpeed, real_T *speedProfile_MaxSpeed);
static void AutomatedParkingValet_imdilate(const boolean_T A[15000], boolean_T
  B[15000]);
static void VehicleCostmapCodegen_configure(c_driving_internal_costmap_Ve_T
  *this);
static void VehicleCostmapCodegen_configu_o(c_driving_internal_costmap_Ve_T
  *this, const boolean_T freeMap[15000], const boolean_T occMap[15000]);
static c_driving_internal_costmap_Ve_T *Auto_VehicleCostmapCodegen_copy(const
  c_driving_internal_costmap_Ve_T *this, c_driving_internal_costmap_Ve_T *iobj_0);
static void AutomatedParkingValet_rand(real_T r[15000]);
static void VehicleCostmapImpl_vehiclePoseT(const
  c_driving_internal_costmap_Ve_T *this, const real_T vehiclePoses[15000],
  real_T xyPoints[40000]);
static void VehicleCostmapImpl_withinMapLim(const
  c_driving_internal_costmap_Ve_T *this, const real_T xyPoints[40000], boolean_T
  insideMap[20000]);
static void AutomatedParking_emxFree_real_T(emxArray_real_T_AutomatedPark_T
  **pEmxArray);
static void VehicleCostmapImpl_xyPointsToGr(const
  c_driving_internal_costmap_Ve_T *this, const emxArray_real_T_AutomatedPark_T
  *xyPoints, emxArray_real_T_AutomatedPark_T *gridIndices);
static void VehicleCostmapImpl_checkFreeWor(const
  c_driving_internal_costmap_Ve_T *this, const real_T xyPoints[40000], boolean_T
  b_free[20000]);
static void UniformPoseSampler_checkForColl(e_matlabshared_planning_inter_T
  *this);
static void UniformPoseSampler_fillPoseBuff(e_matlabshared_planning_inter_T
  *this);
static void AutomatedParkingValet_rand_n(real_T r[5000]);
static void AutomatedP_emxInit_cell_wrap_38(emxArray_cell_wrap_38_Automat_T
  **pEmxArray, int32_T numDimensions);
static void emxInitStruct_e_driving_interna(e_driving_internal_planning_D_T
  *pStruct);
static e_driving_internal_planning_D_T *Automat_DubinsConnection_create
  (e_driving_internal_planning_D_T *iobj_0);
static void emxEnsureCapacity_c_driving_int(emxArray_c_driving_internal_p_T
  *emxArray, int32_T oldNumel);
static void AutomatedP_emxFree_cell_wrap_38(emxArray_cell_wrap_38_Automat_T
  **pEmxArray);
static void emxFreeStruct_e_driving_interna(e_driving_internal_planning_D_T
  *pStruct);
static void DubinsPathSegmentCodegen_makeem(emxArray_c_driving_internal_p_T
  *e_Data);
static void emxCopy_c_driving_internal_plan(emxArray_c_driving_internal_p_T
  **dst, emxArray_c_driving_internal_p_T * const *src);
static void emxCopyStruct_d_driving_interna(d_driving_internal_planning_D_T *dst,
  const d_driving_internal_planning_D_T *src);
static void Auto_emxCopyStruct_driving_Path(driving_Path_AutomatedParking_T *dst,
  const driving_Path_AutomatedParking_T *src);
static void UniformPoseSampler_attemptResam(e_matlabshared_planning_inter_T
  *this);
static void AutomatedPark_emxInit_boolean_T(emxArray_boolean_T_AutomatedP_T
  **pEmxArray, int32_T numDimensions);
static void SqrtApproxNeighborSearcher_comp(d_matlabshared_planning_inter_T
  *this, const real_T *numNodes, real_T *offset, real_T *step);
static void AutomatedParkin_RRTTree_nearest(f_matlabshared_planning_inter_T
  *this, const real_T node_data[], const int32_T node_size[2], real_T
  nearestNode[3], real_T *nearestId);
static void Aut_emxEnsureCapacity_boolean_T(emxArray_boolean_T_AutomatedP_T
  *emxArray, int32_T oldNumel);
static void AutomatedParkin_emxInit_int32_T(emxArray_int32_T_AutomatedPar_T
  **pEmxArray, int32_T numDimensions);
static void Autom_emxEnsureCapacity_int32_T(emxArray_int32_T_AutomatedPar_T
  *emxArray, int32_T oldNumel);
static void AutomatedParkin_emxFree_int32_T(emxArray_int32_T_AutomatedPar_T
  **pEmxArray);
static void AutomatedPark_emxFree_boolean_T(emxArray_boolean_T_AutomatedP_T
  **pEmxArray);
static void VehicleCostmapImpl_checkFreePos(const
  c_driving_internal_costmap_Ve_T *this, const emxArray_real_T_AutomatedPark_T
  *vehiclePoses, emxArray_boolean_T_AutomatedP_T *b_free);
static void Autom_NeighborSearcher_distance(d_matlabshared_planning_inter_T
  *this, const emxArray_real_T_AutomatedPark_T *from, const real_T to[3],
  emxArray_real_T_AutomatedPark_T *d);
static void AutomatedParkin_sortedInsertion(real_T x, int32_T ix,
  emxArray_real_T_AutomatedPark_T *b, int32_T *nb, int32_T blen, int32_T
  idx_data[]);
static boolean_T AutomatedParkingValet_sortLE(const
  emxArray_real_T_AutomatedPark_T *v, int32_T idx1, int32_T idx2);
static void AutomatedParkingValet_mergesort(int32_T idx_data[], const
  emxArray_real_T_AutomatedPark_T *x, int32_T n);
static void AutomatedParkingValet_sortIdx(const emxArray_real_T_AutomatedPark_T *
  x, int32_T idx_data[], int32_T *idx_size);
static void AutomatedParkingValet_exkib(const emxArray_real_T_AutomatedPark_T *a,
  int32_T k, int32_T idx_data[], int32_T *idx_size,
  emxArray_real_T_AutomatedPark_T *b);
static void SqrtApproxNeighborSearcher_near(d_matlabshared_planning_inter_T
  *this, const real_T nodeBuffer[30003], real_T numNodes, const real_T node[3],
  real_T K, emxArray_real_T_AutomatedPark_T *nearNodes,
  emxArray_real_T_AutomatedPark_T *nearIds);
static real_T AutomatedParking_RRTTree_costTo(const
  f_matlabshared_planning_inter_T *this, real_T id);
static void DubinsConnectionMechanism_dista(const
  c_matlabshared_planning_inter_T *this, const emxArray_real_T_AutomatedPark_T
  *from, const real_T to[3], emxArray_real_T_AutomatedPark_T *d);
static void AutomatedParkin_RRTTree_addEdge(f_matlabshared_planning_inter_T
  *this, real_T fromId, real_T toId);
static void AutomatedParki_emxInit_uint32_T(emxArray_uint32_T_AutomatedPa_T
  **pEmxArray, int32_T numDimensions);
static void AutomatedParki_emxFree_uint32_T(emxArray_uint32_T_AutomatedPa_T
  **pEmxArray);
static void Automate_RRTPlanner_interpolate(g_matlabshared_planning_inter_T
  *this, const real_T from[3], const real_T towards[3], real_T pose[3],
  boolean_T *inCollision);
static void Auto_emxEnsureCapacity_uint32_T(emxArray_uint32_T_AutomatedPa_T
  *emxArray, int32_T oldNumel);
static void Automated_RRTPlanner_rewireTree(g_matlabshared_planning_inter_T
  *this, const emxArray_real_T_AutomatedPark_T *nearPoses, const
  emxArray_real_T_AutomatedPark_T *nearIds, const real_T newPose[3], real_T
  newId);
static boolean_T AutomatedParkingVal_ifWhileCond(const boolean_T x_data[], const
  int32_T *x_size);
static void AutomatedParkingVal_mergesort_c(int32_T idx_data[], const uint32_T
  x_data[], int32_T n);
static int32_T AutomatedParkin_nonSingletonDim(const int32_T *x_size);
static void AutomatedParkingValet_merge(int32_T idx_data[], int32_T x_data[],
  int32_T offset, int32_T np, int32_T nq, int32_T iwork_data[], int32_T
  xwork_data[]);
static void AutomatedParkingVal_merge_block(int32_T idx_data[], int32_T x_data[],
  int32_T offset, int32_T n, int32_T preSortLevel, int32_T iwork_data[], int32_T
  xwork_data[]);
static void AutomatedParki_merge_pow2_block(int32_T idx_data[], int32_T x_data[],
  int32_T offset);
static void AutomatedParkingValet_sortIdx_j(int32_T x_data[], int32_T *x_size,
  int32_T idx_data[], int32_T *idx_size);
static void AutomatedParkingValet_sort(int32_T x_data[], const int32_T *x_size,
  int32_T idx_data[], int32_T *idx_size);
static void AutomatedParkingVale_do_vectors(const uint32_T a_data[], const
  int32_T a_size[2], const emxArray_real_T_AutomatedPark_T *b, uint32_T c_data[],
  int32_T c_size[2], int32_T ia_data[], int32_T *ia_size, int32_T ib_data[],
  int32_T *ib_size);
static void AutomatedParki_RRTTree_costTo_g(const
  f_matlabshared_planning_inter_T *this, const real_T id_data[], const int32_T
  id_size[2], real_T cost_data[], int32_T cost_size[2]);
static void AutomatedPa_RRTPlanner_planPath(g_matlabshared_planning_inter_T
  *this, const real_T startPose[3], const real_T goalPose[3],
  emxArray_real_T_AutomatedPark_T *varargout_1);
static void emxFree_c_driving_internal_plan(emxArray_c_driving_internal_p_T
  **pEmxArray);
static void emxEnsureCapacity_cell_wrap_38(emxArray_cell_wrap_38_Automat_T
  *emxArray, int32_T oldNumel);
static boolean_T Autom_OneDimArrayBehavior_isrow(const
  emxArray_c_driving_internal_p_T *this_Data);
static boolean_T AutomatedParkingValet_vectorAny(const boolean_T x_data[], const
  int32_T x_size[2]);
static void Autom_pathPlannerRRT_createPath(const
  pathPlannerRRT_AutomatedParki_T *this, const emxArray_real_T_AutomatedPark_T
  *pathPoses, emxArray_c_driving_internal_p_T *refPath_PathSegments_Data);
static void OneDimArrayBehavior_parenRefere(d_driving_internal_planning_D_T
  *this);
static real_T AutomatedParkin_Path_get_Length(const
  emxArray_c_driving_internal_p_T *this_PathSegments_Data);
static void emxFreeStruct_d_driving_interna(d_driving_internal_planning_D_T
  *pStruct);
static void OneDimArrayBehavior_parenRefe_j(d_driving_internal_planning_D_T
  *this, real_T idx);
static void DubinsPathSegmentCodegen_get_Le(const
  emxArray_c_driving_internal_p_T *this_Data, real_T len_data[], int32_T
  *len_size);
static void interpolateInternalInputValidat(const
  emxArray_real_T_AutomatedPark_T *varargin_1, boolean_T varargin_2,
  emxArray_real_T_AutomatedPark_T *samples);
static void AutomatedPar_Path_interpolateCG(const
  d_driving_internal_planning_D_T this_PathSegments,
  emxArray_real_T_AutomatedPark_T *poses, emxArray_real_T_AutomatedPark_T
  *directions);
static void Auto_emxFreeStruct_driving_Path(driving_Path_AutomatedParking_T
  *pStruct);
static void SystemCore_systemblock_prestep(driving_internal_planning_Pat_T *obj,
  const int32_T varargin_1_size[2], const int32_T *varargin_2_size);
static boolean_T SystemCore_detectInputSizeChang(driving_internal_planning_Pat_T
  *obj, const int32_T varargin_1_size[2], const int32_T *varargin_2_size);
static boolean_T AutomatedParkingValet_isequaln(const real_T varargin_1_data[],
  const int32_T varargin_1_size[2], const emxArray_real_T_AutomatedPark_T
  *varargin_2);
static boolean_T AutomatedParkingVale_isequaln_p(const real_T varargin_1_data[],
  const int32_T *varargin_1_size, const emxArray_real_T_AutomatedPark_T
  *varargin_2);
static void AutomatedParkingValet_power_p(const real_T a_data[], const int32_T
  *a_size, real_T y_data[], int32_T *y_size);
static void AutomatedParkingVal_filterPoses(const real_T refPoses_data[], const
  int32_T refPoses_size[2], const real_T refDirections_data[], const int32_T
  *refDirections_size, real_T poses_data[], int32_T poses_size[2], real_T
  directions_data[], int32_T *directions_size);
static void getSegmentBoundaryPointIndex_p(const real_T directions_data[], const
  int32_T *directions_size, real_T segStartIdx_data[], int32_T *segStartIdx_size,
  real_T segEndIdx_data[], int32_T *segEndIdx_size);
static void AutomatedParkingVale_sqrt_pmhul(real_T x_data[], const int32_T
  *x_size);
static void Au_computeCumulativeChordLength(const real_T poses_data[], const
  int32_T poses_size[2], real_T cumChordLength_data[], int32_T
  *cumChordLength_size);
static void Automa_setSegmentNumSmoothPoses(const real_T
  chordLengthOfSegments_data[], const int32_T *chordLengthOfSegments_size,
  real_T numPosesSeg_data[], int32_T *numPosesSeg_size);
static void AutomatedParkingValet_pwchcore(const real_T x_data[], const int32_T *
  x_size, const real_T y_data[], int32_T yoffset, const real_T s_data[], const
  int32_T s_size[2], const real_T dx_data[], const real_T divdif_data[], real_T
  pp_breaks_data[], int32_T pp_breaks_size[2], real_T pp_coefs_data[], int32_T
  pp_coefs_size[2]);
static void AutomatedParki_degenerateSpline(const real_T x_data[], const int32_T
  *x_size, const real_T y_data[], const int32_T y_size[2], real_T
  pp_breaks_data[], int32_T pp_breaks_size[2], real_T pp_coefs_data[], int32_T
  pp_coefs_size[2]);
static void AutomatedParkingValet_spline(const real_T x_data[], const int32_T
  *x_size, const real_T y_data[], const int32_T *y_size, real_T
  output_breaks_data[], int32_T output_breaks_size[2], real_T output_coefs_data[],
  int32_T output_coefs_size[2]);
static void AutomatedParkingValet_bsxfun(const real_T a_data[], const int32_T
  a_size[2], real_T c_data[], int32_T c_size[2]);
static void Aut_fitSplineAndFirstDerivative(const real_T refPoses_data[], const
  int32_T refPoses_size[2], const real_T t_data[], const int32_T *t_size, real_T
  direction, real_T splineX_breaks_data[], int32_T splineX_breaks_size[2],
  real_T splineX_coefs_data[], int32_T splineX_coefs_size[2], real_T
  splineY_breaks_data[], int32_T splineY_breaks_size[2], real_T
  splineY_coefs_data[], int32_T splineY_coefs_size[2], real_T
  splineDx_breaks_data[], int32_T splineDx_breaks_size[2], real_T
  splineDx_coefs_data[], int32_T splineDx_coefs_size[3], real_T
  splineDy_breaks_data[], int32_T splineDy_breaks_size[2], real_T
  splineDy_coefs_data[], int32_T splineDy_coefs_size[3]);
static void AutomatedParkingValet_linspace(real_T d2, real_T n1,
  emxArray_real_T_AutomatedPark_T *y);
static int32_T AutomatedParkingValet_bsearch(const real_T x_data[], const
  int32_T x_size[2], real_T xi);
static void AutomatedParkingValet_ppval(const real_T pp_breaks_data[], const
  int32_T pp_breaks_size[2], const real_T pp_coefs_data[], const int32_T
  pp_coefs_size[2], const real_T x_data[], const int32_T x_size[2], real_T
  v_data[], int32_T v_size[2]);
static void AutomatedParkingValet_ppval_p(const real_T pp_breaks_data[], const
  int32_T pp_breaks_size[2], const real_T pp_coefs_data[], const int32_T
  pp_coefs_size[3], const emxArray_real_T_AutomatedPark_T *x,
  emxArray_real_T_AutomatedPark_T *v);
static void AutomatedParkingValet_atan2(const real_T y_data[], const int32_T
  y_size[2], const real_T x_data[], const int32_T x_size[2], real_T r_data[],
  int32_T r_size[2]);
static void AutomatedParkingValet_mod(const real_T x_data[], const int32_T
  x_size[2], real_T r_data[], int32_T r_size[2]);
static void Automa_angleUtilities_wrapTo2Pi(const real_T theta_data[], const
  int32_T theta_size[2], real_T b_theta_data[], int32_T b_theta_size[2]);
static void AutomatedParki_interpolatePoses(const real_T splineX_breaks_data[],
  const int32_T splineX_breaks_size[2], const real_T splineX_coefs_data[], const
  int32_T splineX_coefs_size[2], const real_T splineY_breaks_data[], const
  int32_T splineY_breaks_size[2], const real_T splineY_coefs_data[], const
  int32_T splineY_coefs_size[2], const real_T splineDx_breaks_data[], const
  int32_T splineDx_breaks_size[2], const real_T splineDx_coefs_data[], const
  int32_T splineDx_coefs_size[3], const real_T splineDy_breaks_data[], const
  int32_T splineDy_breaks_size[2], const real_T splineDy_coefs_data[], const
  int32_T splineDy_coefs_size[3], const real_T tQuery_data[], const int32_T
  tQuery_size[2], real_T direction, real_T poses_data[], int32_T poses_size[2]);
static real_T AutomatedParkingValet_sum_p(const real_T x_data[], const int32_T
  *x_size);
static void AutomatedParkingValet_power_pm(const emxArray_real_T_AutomatedPark_T
  *a, emxArray_real_T_AutomatedPark_T *y);
static void AutomatedParkingValet_sqrt_pmh(const emxArray_real_T_AutomatedPark_T
  *x, emxArray_real_T_AutomatedPark_T *b_x);
static void AutomatedParkingValet_cumtrapz(const emxArray_real_T_AutomatedPark_T
  *x, emxArray_real_T_AutomatedPark_T *z);
static void Aut_computeCumulativePathLength(const real_T splineDx_breaks_data[],
  const int32_T splineDx_breaks_size[2], const real_T splineDx_coefs_data[],
  const int32_T splineDx_coefs_size[3], const real_T splineDy_breaks_data[],
  const int32_T splineDy_breaks_size[2], const real_T splineDy_coefs_data[],
  const int32_T splineDy_coefs_size[3], const real_T tQuery_data[], const
  int32_T tQuery_size[2], real_T cumLengths_data[], int32_T cumLengths_size[2]);
static void AutomatedParkingValet_bsxfun_p(const real_T a_data[], const int32_T
  a_size[2], real_T c_data[], int32_T c_size[2]);
static void AutomatedParkingValet_power_pmh(const real_T a_data[], const int32_T
  a_size[2], real_T y_data[], int32_T y_size[2]);
static void Automated_computePathCurvatures(const real_T splineDx_breaks_data[],
  const int32_T splineDx_breaks_size[2], const real_T splineDx_coefs_data[],
  const int32_T splineDx_coefs_size[3], const real_T splineDy_breaks_data[],
  const int32_T splineDy_breaks_size[2], const real_T splineDy_coefs_data[],
  const int32_T splineDy_coefs_size[3], const real_T tQuery_data[], const
  int32_T tQuery_size[2], real_T curvatures_data[], int32_T curvatures_size[2]);
static void AutomatedParki_smoothPathSpline(real_T refPoses_data[], int32_T
  refPoses_size[2], const real_T refDirections_data[], const int32_T
  *refDirections_size, real_T poses[1500], real_T directions[500], real_T
  varargout_1[500], real_T varargout_2[500]);
static void Aut_PathSmootherSpline_stepImpl(driving_internal_planning_Pat_T *obj,
  const real_T refPoses_data[], const int32_T refPoses_size[2], const real_T
  refDirections_data[], const int32_T *refDirections_size, real_T poses[1500],
  real_T directions[500], real_T varargout_1[500], real_T varargout_2[500]);
static void AutomatedParkin_SystemCore_step(driving_internal_planning_Pat_T *obj,
  const real_T varargin_1_data[], const int32_T varargin_1_size[2], const real_T
  varargin_2_data[], const int32_T *varargin_2_size, real_T varargout_1[1500],
  real_T varargout_2[500], real_T varargout_3[500], real_T varargout_4[500]);
static boolean_T AutomatedParkingValet_isequal_p(const real_T varargin_1_data[],
  const int32_T *varargin_1_size, const emxArray_real_T_AutomatedPark_T
  *varargin_2);
static boolean_T Auto_VelocityProfiler_isPathNew(const
  driving_internal_planning_Vel_T *obj, const real_T directions_data[], const
  int32_T *directions_size, const real_T cumLengths_data[], const int32_T
  *cumLengths_size, const real_T curvatures_data[], const int32_T
  *curvatures_size, real_T startVelocity, real_T endVelocity);
static void AutomatedParkingVal_parseInputs(real_T varargin_2, real_T *maxSpeed,
  real_T *maxLatAccel, real_T *maxLonAccel, real_T *maxLonDecel, real_T
  *maxLonJerk);
static void Au_getSegmentBoundaryPointIndex(const real_T directions_data[],
  const int32_T *directions_size, real_T segStartIdx_data[], int32_T
  *segStartIdx_size, real_T segEndIdx_data[], int32_T *segEndIdx_size);
static void AutomatedParkingValet_abs(const real_T x_data[], const int32_T
  *x_size, real_T y_data[], int32_T *y_size);
static void AutomatedParkingValet_sqrt_pmhu(real_T x_data[], const int32_T
  *x_size);
static void getNonConstSpeedIntervalDistanc(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3]);
static void getNonConstSpeedIntervalDista_p(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3]);
static real_T AutomatedParkingValet_sum(const real_T x[3]);
static real_T Automa_calculateNewMaximumSpeed(real_T vStart, real_T vEnd, real_T
  accelMax, real_T decelMax, real_T distance);
static void getNonConstSpeedIntervalDist_pm(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3], real_T T[3], real_T V[3]);
static void getNonConstSpeedIntervalDis_pmh(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3], real_T T[3], real_T V[3]);
static boolean_T AutomatedParkingVa_anyNonFinite(const creal_T x_data[], const
  int32_T x_size[2]);
static real_T AutomatedParkingValet_xzlanhs(const creal_T A_data[], const
  int32_T A_size[2], int32_T ilo, int32_T ihi);
static creal_T AutomatedParkingValet_sqrt_p(const creal_T x);
static void AutomatedParkingValet_xzlartg(const creal_T f, const creal_T g,
  real_T *cs, creal_T *sn, creal_T *r);
static void AutomatedParkingValet_xzhgeqz(const creal_T A_data[], const int32_T
  A_size[2], int32_T ilo, int32_T ihi, int32_T *info, creal_T alpha1_data[],
  int32_T *alpha1_size, creal_T beta1_data[], int32_T *beta1_size);
static void AutomatedParkingValet_xzgeev(const creal_T A_data[], const int32_T
  A_size[2], int32_T *info, creal_T alpha1_data[], int32_T *alpha1_size, creal_T
  beta1_data[], int32_T *beta1_size);
static real_T AutomatedParkingValet_xdlapy3(real_T x1, real_T x2, real_T x3);
static creal_T AutomatedParkingValet_recip(const creal_T y);
static void AutomatedParkingValet_xgehrd(const creal_T a_data[], const int32_T
  a_size[2], creal_T b_a_data[], int32_T b_a_size[2]);
static void AutomatedParkingValet_xhseqr(const creal_T h_data[], const int32_T
  h_size[2], creal_T b_h_data[], int32_T b_h_size[2], int32_T *info);
static void AutomatedParkingValet_roots(const real_T c[4], creal_T r_data[],
  int32_T *r_size);
static real_T Automat_computeTimeFromDistance(const real_T p[4], real_T tUpper);
static void AutomatedParkingValet_arrayfun(const real_T
  fun_tunableEnvironment_f1[8], real_T fun_tunableEnvironment_f2, real_T
  fun_tunableEnvironment_f3, real_T fun_tunableEnvironment_f4, const real_T
  fun_tunableEnvironment_f5[8], const real_T fun_tunableEnvironment_f6[8], const
  real_T varargin_1_data[], const int32_T *varargin_1_size, real_T
  varargout_1_data[], int32_T *varargout_1_size, real_T varargout_2_data[],
  int32_T *varargout_2_size);
static void generateSegmentVelocityProfile(real_T vStart, real_T vEnd, const
  real_T segCumLengths_data[], const int32_T *segCumLengths_size, const real_T
  segCurvatures_data[], const int32_T *segCurvatures_size, real_T direction,
  real_T maxSpeed, real_T velocities_data[], int32_T *velocities_size, real_T
  times_data[], int32_T *times_size);
static void Automat_generateVelocityProfile(const real_T directions_data[],
  const int32_T *directions_size, const real_T cumLengths_data[], const int32_T *
  cumLengths_size, const real_T curvatures_data[], real_T startVelocity, real_T
  endVelocity, real_T varargin_2, real_T velocities_data[], int32_T
  *velocities_size, real_T times_data[], int32_T *times_size);
static void Autom_VelocityProfiler_stepImpl(driving_internal_planning_Vel_T *obj,
  const real_T directions_data[], const int32_T *directions_size, const real_T
  cumLengths_data[], const int32_T *cumLengths_size, const real_T
  curvatures_data[], const int32_T *curvatures_size, real_T startVelocity,
  real_T endVelocity, emxArray_real_T_AutomatedPark_T *varargout_1);
static boolean_T AutomatedParkingValet_isequal(const
  emxArray_real_T_AutomatedPark_T *varargin_1, const real_T varargin_2_data[],
  const int32_T varargin_2_size[2]);
static void AutomatedParkingValet_power(const emxArray_real_T_AutomatedPark_T *a,
  emxArray_real_T_AutomatedPark_T *y);
static real_T HelperPathAnalyzer_findClosestP(const
  HelperPathAnalyzer_AutomatedP_T *obj, real_T pose[3],
  emxArray_real_T_AutomatedPark_T *refPoses);
static void Aut_HelperPathAnalyzer_stepImpl(HelperPathAnalyzer_AutomatedP_T *obj,
  const real_T currPose[3], real_T currVel, const real_T varargin_1_data[],
  const int32_T varargin_1_size[2], const real_T varargin_2_data[], const
  int32_T *varargin_2_size, const real_T varargin_3_data[], const int32_T
  *varargin_3_size, const real_T varargin_4_data[], const int32_T
  *varargin_4_size, real_T refPose[3], real_T *refVel, real_T *direction, real_T
  *curvature, real_T *varargout_1);
static void AutomatedP_automlvehdynftiresat(real_T Ftire_y, real_T b_Fxtire_sat,
  real_T b_Fytire_sat, real_T *Ftire_xs, real_T *Ftire_ys);
static void Au_emxFreeStruct_pathPlannerRRT(pathPlannerRRT_AutomatedParki_T
  *pStruct);
static void emxFreeStruct_driving_internal_(driving_internal_planning_Pat_T
  *pStruct);
static void emxFreeStruct_driving_interna_p(driving_internal_planning_Vel_T
  *pStruct);
static void emxFreeStruct_HelperPathAnalyze(HelperPathAnalyzer_AutomatedP_T
  *pStruct);
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (AutomatedParkingValet_M->Timing.TaskCounters.TID[2])++;
  if ((AutomatedParkingValet_M->Timing.TaskCounters.TID[2]) > 49) {/* Sample time: [0.05s, 0.0s] */
    AutomatedParkingValet_M->Timing.TaskCounters.TID[2] = 0;
  }

  (AutomatedParkingValet_M->Timing.TaskCounters.TID[3])++;
  if ((AutomatedParkingValet_M->Timing.TaskCounters.TID[3]) > 99) {/* Sample time: [0.1s, 0.0s] */
    AutomatedParkingValet_M->Timing.TaskCounters.TID[3] = 0;
  }
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 8;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  AutomatedParkingValet_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  AutomatedParkingValet_step();
  AutomatedParkingValet_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  AutomatedParkingValet_step();
  AutomatedParkingValet_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

static void AutomatedParking_emxInit_real_T(emxArray_real_T_AutomatedPark_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_real_T_AutomatedPark_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_real_T_AutomatedPark_T *)malloc(sizeof
    (emxArray_real_T_AutomatedPark_T));
  emxArray = *pEmxArray;
  emxArray->data = (real_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static void emxInitStruct_driving_internal_(driving_internal_planning_Pat_T
  *pStruct)
{
  AutomatedParking_emxInit_real_T(&pStruct->RefPosesInternal, 2);
  AutomatedParking_emxInit_real_T(&pStruct->RefDirectionsInternal, 1);
}

static void Automa_emxEnsureCapacity_real_T(emxArray_real_T_AutomatedPark_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(real_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(real_T) * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (real_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

static void AutomatedPa_SystemCore_setup_pm(driving_internal_planning_Pat_T *obj,
  const int32_T varargin_1_size[2], const int32_T *varargin_2_size)
{
  int32_T i;
  int32_T loop_ub;
  obj->isInitialized = 1;
  i = varargin_1_size[0];
  if (varargin_1_size[0] < 0) {
    i = 0;
  }

  obj->inputVarSize[0].f1[0] = (uint32_T)i;
  i = varargin_1_size[1];
  if (varargin_1_size[1] < 0) {
    i = 0;
  }

  obj->inputVarSize[0].f1[1] = (uint32_T)i;
  i = *varargin_2_size;
  if (*varargin_2_size < 0) {
    i = 0;
  }

  obj->inputVarSize[1].f1[0] = (uint32_T)i;
  obj->inputVarSize[1].f1[1] = 1U;
  for (i = 0; i < 6; i++) {
    obj->inputVarSize[0].f1[i + 2] = 1U;
    obj->inputVarSize[1].f1[i + 2] = 1U;
  }

  i = obj->RefPosesInternal->size[0] * obj->RefPosesInternal->size[1];
  obj->RefPosesInternal->size[0] = varargin_1_size[0];
  obj->RefPosesInternal->size[1] = varargin_1_size[1];
  Automa_emxEnsureCapacity_real_T(obj->RefPosesInternal, i);
  loop_ub = varargin_1_size[0] * varargin_1_size[1] - 1;
  for (i = 0; i <= loop_ub; i++) {
    obj->RefPosesInternal->data[i] = (rtNaN);
  }

  loop_ub = *varargin_2_size;
  i = obj->RefDirectionsInternal->size[0];
  obj->RefDirectionsInternal->size[0] = *varargin_2_size;
  Automa_emxEnsureCapacity_real_T(obj->RefDirectionsInternal, i);
  for (i = 0; i < loop_ub; i++) {
    obj->RefDirectionsInternal->data[i] = (rtNaN);
  }

  for (i = 0; i < 1500; i++) {
    obj->LastPosesOutput[i] = (rtNaN);
  }

  for (i = 0; i < 500; i++) {
    obj->LastDirectionsOutput[i] = (rtNaN);
    obj->LastCumLengthsOutput[i] = (rtNaN);
    obj->LastCurvaturesOutput[i] = (rtNaN);
  }
}

static void emxInitStruct_driving_interna_p(driving_internal_planning_Vel_T
  *pStruct)
{
  AutomatedParking_emxInit_real_T(&pStruct->LastVelocities, 1);
  AutomatedParking_emxInit_real_T(&pStruct->LastCumLengths, 1);
  AutomatedParking_emxInit_real_T(&pStruct->LastCurvatures, 1);
  AutomatedParking_emxInit_real_T(&pStruct->LastDirections, 1);
}

static void AutomatedPar_SystemCore_setup_p(driving_internal_planning_Vel_T *obj,
  const int32_T *varargin_1_size, const int32_T *varargin_2_size, const int32_T *
  varargin_3_size)
{
  int32_T b_idx_0;
  int32_T i;
  obj->isInitialized = 1;
  i = *varargin_1_size;
  if (*varargin_1_size < 0) {
    i = 0;
  }

  obj->inputVarSize[0].f1[0] = (uint32_T)i;
  obj->inputVarSize[0].f1[1] = 1U;
  i = *varargin_2_size;
  if (*varargin_2_size < 0) {
    i = 0;
  }

  obj->inputVarSize[1].f1[0] = (uint32_T)i;
  obj->inputVarSize[1].f1[1] = 1U;
  i = *varargin_3_size;
  if (*varargin_3_size < 0) {
    i = 0;
  }

  obj->inputVarSize[2].f1[0] = (uint32_T)i;
  obj->inputVarSize[2].f1[1] = 1U;
  obj->inputVarSize[3].f1[0] = 1U;
  obj->inputVarSize[3].f1[1] = 1U;
  obj->inputVarSize[4].f1[0] = 1U;
  obj->inputVarSize[4].f1[1] = 1U;
  for (i = 0; i < 6; i++) {
    obj->inputVarSize[0].f1[i + 2] = 1U;
    obj->inputVarSize[1].f1[i + 2] = 1U;
    obj->inputVarSize[2].f1[i + 2] = 1U;
    obj->inputVarSize[3].f1[i + 2] = 1U;
    obj->inputVarSize[4].f1[i + 2] = 1U;
  }

  b_idx_0 = *varargin_1_size;
  i = obj->LastVelocities->size[0];
  obj->LastVelocities->size[0] = *varargin_1_size;
  Automa_emxEnsureCapacity_real_T(obj->LastVelocities, i);
  for (i = 0; i < b_idx_0; i++) {
    obj->LastVelocities->data[i] = 0.0;
  }

  i = obj->LastCumLengths->size[0];
  obj->LastCumLengths->size[0] = *varargin_1_size;
  Automa_emxEnsureCapacity_real_T(obj->LastCumLengths, i);
  for (i = 0; i < b_idx_0; i++) {
    obj->LastCumLengths->data[i] = 0.0;
  }

  i = obj->LastDirections->size[0];
  obj->LastDirections->size[0] = *varargin_1_size;
  Automa_emxEnsureCapacity_real_T(obj->LastDirections, i);
  for (i = 0; i < b_idx_0; i++) {
    obj->LastDirections->data[i] = 1.0;
  }

  i = obj->LastCurvatures->size[0];
  obj->LastCurvatures->size[0] = *varargin_1_size;
  Automa_emxEnsureCapacity_real_T(obj->LastCurvatures, i);
  for (i = 0; i < b_idx_0; i++) {
    obj->LastCurvatures->data[i] = 0.0;
  }

  obj->LastStartVelocity = 0.0;
  obj->LastEndVelocity = 0.0;
}

static void emxInitStruct_HelperPathAnalyze(HelperPathAnalyzer_AutomatedP_T
  *pStruct)
{
  AutomatedParking_emxInit_real_T(&pStruct->SegmentStartIndex, 1);
  AutomatedParking_emxInit_real_T(&pStruct->SegmentEndIndex, 1);
  AutomatedParking_emxInit_real_T(&pStruct->RefPosesInternal, 2);
  AutomatedParking_emxInit_real_T(&pStruct->DirectionsInternal, 1);
  AutomatedParking_emxInit_real_T(&pStruct->CurvaturesInternal, 1);
  AutomatedParking_emxInit_real_T(&pStruct->VelocityProfileInternal, 1);
}

static void AutomatedParki_SystemCore_setup(HelperPathAnalyzer_AutomatedP_T *obj,
  const int32_T varargin_3_size[2], const int32_T *varargin_4_size, const
  int32_T *varargin_5_size, const int32_T *varargin_6_size)
{
  int32_T loop_ub;
  int32_T i;
  obj->isInitialized = 1;

  /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
  /*    HelperPathAnalyzer computes the reference pose and the reference */
  /*    velocity based on the current pose of the vehicle. */
  /*  */
  /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
  /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
  /*  */
  /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
  /*    pathAnalyzer, with additional options specified by one or more */
  /*    Name,Value pair arguments: */
  /*  */
  /*    'Wheelbase'             Wheelbase of the vehicle */
  /*  */
  /*                            Default: 2.8 (meters) */
  /*  */
  /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
  /*                            reference path */
  /*  */
  /*    'Directions'            A N-by-1 vector representing the driving */
  /*                            directions at each point on the reference path. */
  /*                            The vector is composed by possible values: 1 */
  /*                            for forward motion and -1 for reverse motion. */
  /*  */
  /*    'Curvatures'            A N-by-1 vector representing the curvature */
  /*                            of the reference path */
  /*  */
  /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
  /*                            the reference path (in meters/second) */
  /*  */
  /*  */
  /*    Step method syntax: */
  /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
  /*    returns the reference pose, refPose, reference velocity, refVel, and */
  /*    the driving direction based on the current pose, currPose and the */
  /*    current velocity, currVel of the vehicle. */
  /*  */
  /*    System objects may be called directly like a function instead of using */
  /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
  /*  */
  /*    HelperPathAnalyzer properties: */
  /*    Wheelbase              - Wheelbase of the vehicle */
  /*    RefPoses               - Poses of the reference path */
  /*    VelocityProfile        - Velocities along the reference path */
  /*    Directions             - Driving directions at each point on the path */
  /*    Curvatures             - Path curvaturesa at each point on the path */
  /*  */
  /*    HelperPathAnalyzer methods: */
  /*    step                   - Compute reference poses, velocity and direction */
  /*    release                - Allow property value changes */
  /*    clone                  - Create a copy of the object */
  /*    isLocked               - Locked status (logical) */
  /*  */
  /*    See also lateralControllerStanley, HelperLongitudinalController, */
  /*      smoothPathSpline, helperGenerateVelocityProfile */
  /*    Copyright 2018 The MathWorks, Inc. */
  /*  Public, non-tunable properties */
  /* Wheelbase Vehicle wheelbase (m) */
  /*    A scalar specifying the distance between the front and the rear */
  /*    axles. */
  /*  */
  /*    Default: 2.8 (m) */
  /*  Public properties (Only used in MATLAB) */
  /* RefPoses Vehicle poses along the reference path */
  /*     */
  /* VelocityProfile Speed profile along the reference path */
  /*  */
  /* Directions Driving directions corresponding to RefPoses */
  /*  */
  /* Curvatures Path curvatures  */
  /*  */
  /*  Public properties (Only used in Simulink) */
  /* HasResetOutput Show Reset output port */
  /*    Flag indicating if the Reset output port is enabled.  */
  /*  */
  /*    Default:      false */
  /* ClosestPointIndex Store the previous projection point index */
  /*    to handle encircled path */
  /*  */
  /*    Default: 1 */
  /* NumPathSegments Number of segments in a path. When  */
  /*  */
  /*    Default: 1 */
  /* CurrentSegmentIndex Index of the current segment */
  /*  */
  /* SegmentStartIndex A vector storing the indices of the starting  */
  /*    points of all the path segments */
  /*  */
  /* SegmentStartIndex  A vector storing the indices of the ending  */
  /*    points of all the path segments */
  /*  The following four properties are used to transfer reference  */
  /*  data within the system object. Depending on the environment the  */
  /*  object is executing in, they are assigned either by public */
  /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
  /*  in MATLAB, or by the input ports in Simulink. The selection is  */
  /*  determined by the HasReferenceInports property. */
  /* RefPosesInternal */
  /* DirectionsInternal */
  /* CurvaturesInternal */
  /* VelocityProfileInternal */
  /*  The following four properties are used to store the last output. */
  /* LastRefPoseOutput */
  /* LastRefVelocityOutput */
  /* LastCurvatureOutput */
  /* LastDirectionOutput */
  /* HasReferenceInports Flag indicating if there are refPose, directions */
  /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
  /*     values are set via properties while in Simulink they are  */
  /*     passed as inputs via input ports. */
  /*  */
  /*    Default:          false */
  /* ---------------------------------------------------------------------- */
  /*  Setter and constructor */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* HelperPathAnalyzer Constructor  */
  /* ---------------------------------------------------------------------- */
  /*  Main algorithm */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* setupImpl Perform one-time calculations */
  /*  In Simulink */
  /*  In MATLAB */
  /* ------------------------------------------------------------------ */
  /*  processTunedPropertiesImpl Perform actions when tunable  */
  /*  properties change between calls to the System object */
  /* ------------------------------------------------------------------ */
  /* stepImpl Implement the main algorithm and return the reference */
  /*    pose, velocity and driving direction. varargout is an */
  /*    optional output in Simulink that signifies reaching */
  /*    intermediate goals within a reference path, i.e., reaching */
  /*    the direction-switching positions.  */
  /*  Check if the reference path is new */
  /*  In MATLAB, values are from properties */
  /*  Divide the path to segments based on driving direction */
  /*  Check if reaching the final goal. If yes, use the previous */
  /*  outputs */
  /*  Get the desired pose, desired velocity and driving direction */
  /*  Check if the vehicle reaches the intermediate goal. If yes, */
  /*  increment the path segment index and reset reference velocity */
  /*  to zero as the vehicle needs to switch direction at the */
  /*  intermediate goal positions */
  /*  Store the output */
  /* ------------------------------------------------------------------ */
  /* findDesiredPoseAndVelocity Determine the desired pose and */
  /*    velocity based on the current pose. The desired pose is */
  /*    determined by searching the closest point on the reference */
  /*    path. The desired velocity is the velocity corresponding to */
  /*    the closest point. */
  /*  Get the current segment indexes */
  /*  Only search within the current segment of the path */
  /*  Current driving direction */
  /*  Compute the index of the closest point on the path segment */
  /*  Convert the segment index to the whole path index */
  /*  Get the desired velocity. Set a lower threshold to avoid zero  */
  /*  reference velocity at the very beginning. */
  /*  Get the desired pose. In forward motion, the refPose is */
  /*  specified for the front wheel. */
  /*  forward */
  /*  Workaround to support lateralControllerStanley in MATLAB */
  /*  that does not require curvature input */
  /* ------------------------------------------------------------------ */
  /* findClosestPathPoint Find the index of the closest point */
  /*  forward driving uses front wheel as reference */
  /*  Find the closest point on the reference path */
  /*  Enforce to be a scalar in Simulink */
  /*  If the reference pose is lagging behind the current pose, */
  /*  move to the next reference path. */
  /* ------------------------------------------------------------------ */
  /* moveToNext Check if the refPose is lagging behind the current */
  /*    pose. If yes, move to the next refPose. */
  /*    The is necessary when the vehicle is at accelerating stage. */
  /*    When the reference speed is small it takes relatively */
  /*    longer time to reach the desired maximum speed. When the */
  /*    vehicle reaches somewhere between two reference points, */
  /*    use the next one as the reference to set a larger */
  /*    reference speed. */
  /* ---------------------------------------------------------------------- */
  /*  Common methods */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /*  Validate inputs to the step method at initialization */
  /*  RefPoses */
  /*  Directions */
  /*  Curvatures */
  /*  VelocityProfile */
  /* ------------------------------------------------------------------ */
  /*  Define total number of inputs for system with optional inputs */
  /* ------------------------------------------------------------------ */
  /*  Define total number of outputs for system with optional */
  /*  outputs */
  /* ------------------------------------------------------------------ */
  /*  Set properties in structure s to values in object obj */
  /*  Set public properties and states */
  /*  Set private and protected properties */
  /* ------------------------------------------------------------------ */
  /*  Set properties in object obj to values in structure s */
  /*  Set private and protected properties */
  /*  Set public properties and states */
  /* ---------------------------------------------------------------------- */
  /*  Simulink-only methods */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /*  Define icon for System block */
  /*  Use class name */
  /* ------------------------------------------------------------------ */
  /*  Return input port names for System block */
  /* ------------------------------------------------------------------ */
  /*  Return output port names for System block */
  /* ------------------------------------------------------------------ */
  /*  Return size for each output port */
  /*  RefPose */
  /*  RefVelocity */
  /*  Direction */
  /*  Curvature */
  /*  Reset */
  /* ------------------------------------------------------------------ */
  /*  Return data type for each output port */
  /* ------------------------------------------------------------------ */
  /*  Return true for each output port with complex data */
  /* ------------------------------------------------------------------ */
  /*  Return true for each output port with fixed size */
  /* ------------------------------------------------------------------ */
  /*  Return false if input size cannot change */
  /*  between calls to the System object */
  /*  refPoses, directions, curvatures, and speeProfile are variable-size */
  /* ------------------------------------------------------------------ */
  /*  Return false if property is visible based on object */
  /*  configuration, for the command line and System block dialog */
  /* ---------------------------------------------------------------------- */
  /*  Simulink dialog */
  /* ---------------------------------------------------------------------- */
  /*  Define property section(s) for System block dialog */
  /* ---------------------------------------------------------------------- */
  /*  Utility functions */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* isSimulinkBlock Check if the system object in used in Simulink */
  /*  0 for MATLAB, 1 for Simulink */
  for (i = 0; i < 8; i++) {
    obj->inputVarSize[0].f1[i] = 1U;
    obj->inputVarSize[1].f1[i] = 1U;
  }

  i = varargin_3_size[0];
  if (varargin_3_size[0] < 0) {
    i = 0;
  }

  obj->inputVarSize[2].f1[0] = (uint32_T)i;
  i = varargin_3_size[1];
  if (varargin_3_size[1] < 0) {
    i = 0;
  }

  obj->inputVarSize[2].f1[1] = (uint32_T)i;
  i = *varargin_4_size;
  if (*varargin_4_size < 0) {
    i = 0;
  }

  obj->inputVarSize[3].f1[0] = (uint32_T)i;
  obj->inputVarSize[3].f1[1] = 1U;
  i = *varargin_5_size;
  if (*varargin_5_size < 0) {
    i = 0;
  }

  obj->inputVarSize[4].f1[0] = (uint32_T)i;
  obj->inputVarSize[4].f1[1] = 1U;
  i = *varargin_6_size;
  if (*varargin_6_size < 0) {
    i = 0;
  }

  obj->inputVarSize[5].f1[0] = (uint32_T)i;
  obj->inputVarSize[5].f1[1] = 1U;
  for (i = 0; i < 6; i++) {
    obj->inputVarSize[2].f1[i + 2] = 1U;
    obj->inputVarSize[3].f1[i + 2] = 1U;
    obj->inputVarSize[4].f1[i + 2] = 1U;
    obj->inputVarSize[5].f1[i + 2] = 1U;
  }

  /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
  /*    HelperPathAnalyzer computes the reference pose and the reference */
  /*    velocity based on the current pose of the vehicle. */
  /*  */
  /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
  /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
  /*  */
  /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
  /*    pathAnalyzer, with additional options specified by one or more */
  /*    Name,Value pair arguments: */
  /*  */
  /*    'Wheelbase'             Wheelbase of the vehicle */
  /*  */
  /*                            Default: 2.8 (meters) */
  /*  */
  /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
  /*                            reference path */
  /*  */
  /*    'Directions'            A N-by-1 vector representing the driving */
  /*                            directions at each point on the reference path. */
  /*                            The vector is composed by possible values: 1 */
  /*                            for forward motion and -1 for reverse motion. */
  /*  */
  /*    'Curvatures'            A N-by-1 vector representing the curvature */
  /*                            of the reference path */
  /*  */
  /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
  /*                            the reference path (in meters/second) */
  /*  */
  /*  */
  /*    Step method syntax: */
  /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
  /*    returns the reference pose, refPose, reference velocity, refVel, and */
  /*    the driving direction based on the current pose, currPose and the */
  /*    current velocity, currVel of the vehicle. */
  /*  */
  /*    System objects may be called directly like a function instead of using */
  /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
  /*  */
  /*    HelperPathAnalyzer properties: */
  /*    Wheelbase              - Wheelbase of the vehicle */
  /*    RefPoses               - Poses of the reference path */
  /*    VelocityProfile        - Velocities along the reference path */
  /*    Directions             - Driving directions at each point on the path */
  /*    Curvatures             - Path curvaturesa at each point on the path */
  /*  */
  /*    HelperPathAnalyzer methods: */
  /*    step                   - Compute reference poses, velocity and direction */
  /*    release                - Allow property value changes */
  /*    clone                  - Create a copy of the object */
  /*    isLocked               - Locked status (logical) */
  /*  */
  /*    See also lateralControllerStanley, HelperLongitudinalController, */
  /*      smoothPathSpline, helperGenerateVelocityProfile */
  /*    Copyright 2018 The MathWorks, Inc. */
  /*  Public, non-tunable properties */
  /* Wheelbase Vehicle wheelbase (m) */
  /*    A scalar specifying the distance between the front and the rear */
  /*    axles. */
  /*  */
  /*    Default: 2.8 (m) */
  /*  Public properties (Only used in MATLAB) */
  /* RefPoses Vehicle poses along the reference path */
  /*     */
  /* VelocityProfile Speed profile along the reference path */
  /*  */
  /* Directions Driving directions corresponding to RefPoses */
  /*  */
  /* Curvatures Path curvatures  */
  /*  */
  /*  Public properties (Only used in Simulink) */
  /* HasResetOutput Show Reset output port */
  /*    Flag indicating if the Reset output port is enabled.  */
  /*  */
  /*    Default:      false */
  /* ClosestPointIndex Store the previous projection point index */
  /*    to handle encircled path */
  /*  */
  /*    Default: 1 */
  /* NumPathSegments Number of segments in a path. When  */
  /*  */
  /*    Default: 1 */
  /* CurrentSegmentIndex Index of the current segment */
  /*  */
  /* SegmentStartIndex A vector storing the indices of the starting  */
  /*    points of all the path segments */
  /*  */
  /* SegmentStartIndex  A vector storing the indices of the ending  */
  /*    points of all the path segments */
  /*  The following four properties are used to transfer reference  */
  /*  data within the system object. Depending on the environment the  */
  /*  object is executing in, they are assigned either by public */
  /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
  /*  in MATLAB, or by the input ports in Simulink. The selection is  */
  /*  determined by the HasReferenceInports property. */
  /* RefPosesInternal */
  /* DirectionsInternal */
  /* CurvaturesInternal */
  /* VelocityProfileInternal */
  /*  The following four properties are used to store the last output. */
  /* LastRefPoseOutput */
  /* LastRefVelocityOutput */
  /* LastCurvatureOutput */
  /* LastDirectionOutput */
  /* HasReferenceInports Flag indicating if there are refPose, directions */
  /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
  /*     values are set via properties while in Simulink they are  */
  /*     passed as inputs via input ports. */
  /*  */
  /*    Default:          false */
  /* ---------------------------------------------------------------------- */
  /*  Setter and constructor */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* HelperPathAnalyzer Constructor  */
  /* ---------------------------------------------------------------------- */
  /*  Main algorithm */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* setupImpl Perform one-time calculations */
  /*  In Simulink */
  /*  In MATLAB */
  /* ------------------------------------------------------------------ */
  /*  processTunedPropertiesImpl Perform actions when tunable  */
  /*  properties change between calls to the System object */
  /* ------------------------------------------------------------------ */
  /* stepImpl Implement the main algorithm and return the reference */
  /*    pose, velocity and driving direction. varargout is an */
  /*    optional output in Simulink that signifies reaching */
  /*    intermediate goals within a reference path, i.e., reaching */
  /*    the direction-switching positions.  */
  /*  Check if the reference path is new */
  /*  In MATLAB, values are from properties */
  /*  Divide the path to segments based on driving direction */
  /*  Check if reaching the final goal. If yes, use the previous */
  /*  outputs */
  /*  Get the desired pose, desired velocity and driving direction */
  /*  Check if the vehicle reaches the intermediate goal. If yes, */
  /*  increment the path segment index and reset reference velocity */
  /*  to zero as the vehicle needs to switch direction at the */
  /*  intermediate goal positions */
  /*  Store the output */
  /* ------------------------------------------------------------------ */
  /* findDesiredPoseAndVelocity Determine the desired pose and */
  /*    velocity based on the current pose. The desired pose is */
  /*    determined by searching the closest point on the reference */
  /*    path. The desired velocity is the velocity corresponding to */
  /*    the closest point. */
  /*  Get the current segment indexes */
  /*  Only search within the current segment of the path */
  /*  Current driving direction */
  /*  Compute the index of the closest point on the path segment */
  /*  Convert the segment index to the whole path index */
  /*  Get the desired velocity. Set a lower threshold to avoid zero  */
  /*  reference velocity at the very beginning. */
  /*  Get the desired pose. In forward motion, the refPose is */
  /*  specified for the front wheel. */
  /*  forward */
  /*  Workaround to support lateralControllerStanley in MATLAB */
  /*  that does not require curvature input */
  /* ------------------------------------------------------------------ */
  /* findClosestPathPoint Find the index of the closest point */
  /*  forward driving uses front wheel as reference */
  /*  Find the closest point on the reference path */
  /*  Enforce to be a scalar in Simulink */
  /*  If the reference pose is lagging behind the current pose, */
  /*  move to the next reference path. */
  /* ------------------------------------------------------------------ */
  /* moveToNext Check if the refPose is lagging behind the current */
  /*    pose. If yes, move to the next refPose. */
  /*    The is necessary when the vehicle is at accelerating stage. */
  /*    When the reference speed is small it takes relatively */
  /*    longer time to reach the desired maximum speed. When the */
  /*    vehicle reaches somewhere between two reference points, */
  /*    use the next one as the reference to set a larger */
  /*    reference speed. */
  /* ---------------------------------------------------------------------- */
  /*  Common methods */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /*  Validate inputs to the step method at initialization */
  /*  RefPoses */
  /*  Directions */
  /*  Curvatures */
  /*  VelocityProfile */
  /* ------------------------------------------------------------------ */
  /*  Define total number of inputs for system with optional inputs */
  /* ------------------------------------------------------------------ */
  /*  Define total number of outputs for system with optional */
  /*  outputs */
  /* ------------------------------------------------------------------ */
  /*  Set properties in structure s to values in object obj */
  /*  Set public properties and states */
  /*  Set private and protected properties */
  /* ------------------------------------------------------------------ */
  /*  Set properties in object obj to values in structure s */
  /*  Set private and protected properties */
  /*  Set public properties and states */
  /* ---------------------------------------------------------------------- */
  /*  Simulink-only methods */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /*  Define icon for System block */
  /*  Use class name */
  /* ------------------------------------------------------------------ */
  /*  Return input port names for System block */
  /* ------------------------------------------------------------------ */
  /*  Return output port names for System block */
  /* ------------------------------------------------------------------ */
  /*  Return size for each output port */
  /*  RefPose */
  /*  RefVelocity */
  /*  Direction */
  /*  Curvature */
  /*  Reset */
  /* ------------------------------------------------------------------ */
  /*  Return data type for each output port */
  /* ------------------------------------------------------------------ */
  /*  Return true for each output port with complex data */
  /* ------------------------------------------------------------------ */
  /*  Return true for each output port with fixed size */
  /* ------------------------------------------------------------------ */
  /*  Return false if input size cannot change */
  /*  between calls to the System object */
  /*  refPoses, directions, curvatures, and speeProfile are variable-size */
  /* ------------------------------------------------------------------ */
  /*  Return false if property is visible based on object */
  /*  configuration, for the command line and System block dialog */
  /* ---------------------------------------------------------------------- */
  /*  Simulink dialog */
  /* ---------------------------------------------------------------------- */
  /*  Define property section(s) for System block dialog */
  /* ---------------------------------------------------------------------- */
  /*  Utility functions */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* isSimulinkBlock Check if the system object in used in Simulink */
  /*  0 for MATLAB, 1 for Simulink */
  obj->ClosestPointIndex = 1.0;
  obj->NumPathSegments = 1.0;
  obj->CurrentSegmentIndex = 1.0;

  /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
  /*    HelperPathAnalyzer computes the reference pose and the reference */
  /*    velocity based on the current pose of the vehicle. */
  /*  */
  /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
  /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
  /*  */
  /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
  /*    pathAnalyzer, with additional options specified by one or more */
  /*    Name,Value pair arguments: */
  /*  */
  /*    'Wheelbase'             Wheelbase of the vehicle */
  /*  */
  /*                            Default: 2.8 (meters) */
  /*  */
  /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
  /*                            reference path */
  /*  */
  /*    'Directions'            A N-by-1 vector representing the driving */
  /*                            directions at each point on the reference path. */
  /*                            The vector is composed by possible values: 1 */
  /*                            for forward motion and -1 for reverse motion. */
  /*  */
  /*    'Curvatures'            A N-by-1 vector representing the curvature */
  /*                            of the reference path */
  /*  */
  /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
  /*                            the reference path (in meters/second) */
  /*  */
  /*  */
  /*    Step method syntax: */
  /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
  /*    returns the reference pose, refPose, reference velocity, refVel, and */
  /*    the driving direction based on the current pose, currPose and the */
  /*    current velocity, currVel of the vehicle. */
  /*  */
  /*    System objects may be called directly like a function instead of using */
  /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
  /*  */
  /*    HelperPathAnalyzer properties: */
  /*    Wheelbase              - Wheelbase of the vehicle */
  /*    RefPoses               - Poses of the reference path */
  /*    VelocityProfile        - Velocities along the reference path */
  /*    Directions             - Driving directions at each point on the path */
  /*    Curvatures             - Path curvaturesa at each point on the path */
  /*  */
  /*    HelperPathAnalyzer methods: */
  /*    step                   - Compute reference poses, velocity and direction */
  /*    release                - Allow property value changes */
  /*    clone                  - Create a copy of the object */
  /*    isLocked               - Locked status (logical) */
  /*  */
  /*    See also lateralControllerStanley, HelperLongitudinalController, */
  /*      smoothPathSpline, helperGenerateVelocityProfile */
  /*    Copyright 2018 The MathWorks, Inc. */
  /*  Public, non-tunable properties */
  /* Wheelbase Vehicle wheelbase (m) */
  /*    A scalar specifying the distance between the front and the rear */
  /*    axles. */
  /*  */
  /*    Default: 2.8 (m) */
  /*  Public properties (Only used in MATLAB) */
  /* RefPoses Vehicle poses along the reference path */
  /*     */
  /* VelocityProfile Speed profile along the reference path */
  /*  */
  /* Directions Driving directions corresponding to RefPoses */
  /*  */
  /* Curvatures Path curvatures  */
  /*  */
  /*  Public properties (Only used in Simulink) */
  /* HasResetOutput Show Reset output port */
  /*    Flag indicating if the Reset output port is enabled.  */
  /*  */
  /*    Default:      false */
  /* ClosestPointIndex Store the previous projection point index */
  /*    to handle encircled path */
  /*  */
  /*    Default: 1 */
  /* NumPathSegments Number of segments in a path. When  */
  /*  */
  /*    Default: 1 */
  /* CurrentSegmentIndex Index of the current segment */
  /*  */
  /* SegmentStartIndex A vector storing the indices of the starting  */
  /*    points of all the path segments */
  /*  */
  /* SegmentStartIndex  A vector storing the indices of the ending  */
  /*    points of all the path segments */
  /*  The following four properties are used to transfer reference  */
  /*  data within the system object. Depending on the environment the  */
  /*  object is executing in, they are assigned either by public */
  /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
  /*  in MATLAB, or by the input ports in Simulink. The selection is  */
  /*  determined by the HasReferenceInports property. */
  /* RefPosesInternal */
  /* DirectionsInternal */
  /* CurvaturesInternal */
  /* VelocityProfileInternal */
  /*  The following four properties are used to store the last output. */
  /* LastRefPoseOutput */
  /* LastRefVelocityOutput */
  /* LastCurvatureOutput */
  /* LastDirectionOutput */
  /* HasReferenceInports Flag indicating if there are refPose, directions */
  /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
  /*     values are set via properties while in Simulink they are  */
  /*     passed as inputs via input ports. */
  /*  */
  /*    Default:          false */
  /* ---------------------------------------------------------------------- */
  /*  Setter and constructor */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ */
  /* HelperPathAnalyzer Constructor  */
  /* ---------------------------------------------------------------------- */
  /*  Main algorithm */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* setupImpl Perform one-time calculations */
  /*  In Simulink */
  /*  In MATLAB */
  /* ------------------------------------------------------------------ */
  /*  processTunedPropertiesImpl Perform actions when tunable  */
  /*  properties change between calls to the System object */
  /* ------------------------------------------------------------------ */
  /* stepImpl Implement the main algorithm and return the reference */
  /*    pose, velocity and driving direction. varargout is an */
  /*    optional output in Simulink that signifies reaching */
  /*    intermediate goals within a reference path, i.e., reaching */
  /*    the direction-switching positions.  */
  /*  Check if the reference path is new */
  /*  In MATLAB, values are from properties */
  /*  Divide the path to segments based on driving direction */
  /*  Check if reaching the final goal. If yes, use the previous */
  /*  outputs */
  /*  Get the desired pose, desired velocity and driving direction */
  /*  Check if the vehicle reaches the intermediate goal. If yes, */
  /*  increment the path segment index and reset reference velocity */
  /*  to zero as the vehicle needs to switch direction at the */
  /*  intermediate goal positions */
  /*  Store the output */
  /* ------------------------------------------------------------------ */
  /* findDesiredPoseAndVelocity Determine the desired pose and */
  /*    velocity based on the current pose. The desired pose is */
  /*    determined by searching the closest point on the reference */
  /*    path. The desired velocity is the velocity corresponding to */
  /*    the closest point. */
  /*  Get the current segment indexes */
  /*  Only search within the current segment of the path */
  /*  Current driving direction */
  /*  Compute the index of the closest point on the path segment */
  /*  Convert the segment index to the whole path index */
  /*  Get the desired velocity. Set a lower threshold to avoid zero  */
  /*  reference velocity at the very beginning. */
  /*  Get the desired pose. In forward motion, the refPose is */
  /*  specified for the front wheel. */
  /*  forward */
  /*  Workaround to support lateralControllerStanley in MATLAB */
  /*  that does not require curvature input */
  /* ------------------------------------------------------------------ */
  /* findClosestPathPoint Find the index of the closest point */
  /*  forward driving uses front wheel as reference */
  /*  Find the closest point on the reference path */
  /*  Enforce to be a scalar in Simulink */
  /*  If the reference pose is lagging behind the current pose, */
  /*  move to the next reference path. */
  /* ------------------------------------------------------------------ */
  /* moveToNext Check if the refPose is lagging behind the current */
  /*    pose. If yes, move to the next refPose. */
  /*    The is necessary when the vehicle is at accelerating stage. */
  /*    When the reference speed is small it takes relatively */
  /*    longer time to reach the desired maximum speed. When the */
  /*    vehicle reaches somewhere between two reference points, */
  /*    use the next one as the reference to set a larger */
  /*    reference speed. */
  /* ---------------------------------------------------------------------- */
  /*  Common methods */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /*  Validate inputs to the step method at initialization */
  /*  RefPoses */
  /*  Directions */
  /*  Curvatures */
  /*  VelocityProfile */
  /* ------------------------------------------------------------------ */
  /*  Define total number of inputs for system with optional inputs */
  /* ------------------------------------------------------------------ */
  /*  Define total number of outputs for system with optional */
  /*  outputs */
  /* ------------------------------------------------------------------ */
  /*  Set properties in structure s to values in object obj */
  /*  Set public properties and states */
  /*  Set private and protected properties */
  /* ------------------------------------------------------------------ */
  /*  Set properties in object obj to values in structure s */
  /*  Set private and protected properties */
  /*  Set public properties and states */
  /* ---------------------------------------------------------------------- */
  /*  Simulink-only methods */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /*  Define icon for System block */
  /*  Use class name */
  /* ------------------------------------------------------------------ */
  /*  Return input port names for System block */
  /* ------------------------------------------------------------------ */
  /*  Return output port names for System block */
  /* ------------------------------------------------------------------ */
  /*  Return size for each output port */
  /*  RefPose */
  /*  RefVelocity */
  /*  Direction */
  /*  Curvature */
  /*  Reset */
  /* ------------------------------------------------------------------ */
  /*  Return data type for each output port */
  /* ------------------------------------------------------------------ */
  /*  Return true for each output port with complex data */
  /* ------------------------------------------------------------------ */
  /*  Return true for each output port with fixed size */
  /* ------------------------------------------------------------------ */
  /*  Return false if input size cannot change */
  /*  between calls to the System object */
  /*  refPoses, directions, curvatures, and speeProfile are variable-size */
  /* ------------------------------------------------------------------ */
  /*  Return false if property is visible based on object */
  /*  configuration, for the command line and System block dialog */
  /* ---------------------------------------------------------------------- */
  /*  Simulink dialog */
  /* ---------------------------------------------------------------------- */
  /*  Define property section(s) for System block dialog */
  /* ---------------------------------------------------------------------- */
  /*  Utility functions */
  /* ---------------------------------------------------------------------- */
  /* ------------------------------------------------------------------ */
  /* isSimulinkBlock Check if the system object in used in Simulink */
  /*  0 for MATLAB, 1 for Simulink */
  i = obj->RefPosesInternal->size[0] * obj->RefPosesInternal->size[1];
  obj->RefPosesInternal->size[0] = varargin_3_size[0];
  obj->RefPosesInternal->size[1] = varargin_3_size[1];
  Automa_emxEnsureCapacity_real_T(obj->RefPosesInternal, i);
  loop_ub = varargin_3_size[0] * varargin_3_size[1] - 1;
  for (i = 0; i <= loop_ub; i++) {
    obj->RefPosesInternal->data[i] = (rtNaN);
  }

  loop_ub = *varargin_4_size;
  i = obj->DirectionsInternal->size[0];
  obj->DirectionsInternal->size[0] = *varargin_4_size;
  Automa_emxEnsureCapacity_real_T(obj->DirectionsInternal, i);
  for (i = 0; i < loop_ub; i++) {
    obj->DirectionsInternal->data[i] = (rtNaN);
  }

  loop_ub = *varargin_5_size;
  i = obj->CurvaturesInternal->size[0];
  obj->CurvaturesInternal->size[0] = *varargin_5_size;
  Automa_emxEnsureCapacity_real_T(obj->CurvaturesInternal, i);
  for (i = 0; i < loop_ub; i++) {
    obj->CurvaturesInternal->data[i] = (rtNaN);
  }

  loop_ub = *varargin_6_size;
  i = obj->VelocityProfileInternal->size[0];
  obj->VelocityProfileInternal->size[0] = *varargin_6_size;
  Automa_emxEnsureCapacity_real_T(obj->VelocityProfileInternal, i);
  for (i = 0; i < loop_ub; i++) {
    obj->VelocityProfileInternal->data[i] = (rtNaN);
  }

  obj->TunablePropsChanged = false;
}

static void emxInit_c_driving_internal_plan(emxArray_c_driving_internal_p_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_c_driving_internal_p_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_c_driving_internal_p_T *)malloc(sizeof
    (emxArray_c_driving_internal_p_T));
  emxArray = *pEmxArray;
  emxArray->data = (c_driving_internal_planning_D_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static void emxInitStruct_d_driving_interna(d_driving_internal_planning_D_T
  *pStruct)
{
  emxInit_c_driving_internal_plan(&pStruct->Data, 2);
}

static void Auto_emxInitStruct_driving_Path(driving_Path_AutomatedParking_T
  *pStruct)
{
  emxInitStruct_d_driving_interna(&pStruct->PathSegments);
}

static void Au_emxInitStruct_pathPlannerRRT(pathPlannerRRT_AutomatedParki_T
  *pStruct)
{
  Auto_emxInitStruct_driving_Path(&pStruct->Path);
}

/* Function for MATLAB Function: '<Root>/BehaviorPlanner' */
static void HelperBehavioralPlanner_request(HelperBehavioralPlanner_Autom_T
  *this, const real_T currentPose[3], real_T currentSpeed, real_T nextGoal[3],
  real_T *plannerConfig_ConnectionDistanc, real_T *plannerConfig_MinIterations,
  real_T plannerConfig_GoalTolerance[3], real_T *plannerConfig_MinTurningRadius,
  boolean_T *plannerConfig_IsParkManeuver, real_T *speedProfile_StartSpeed,
  real_T *speedProfile_EndSpeed, real_T *speedProfile_MaxSpeed)
{
  real_T a;
  real_T z1_idx_0;
  int32_T nextGoal_tmp;
  *plannerConfig_ConnectionDistanc = 10.0;
  *plannerConfig_MinIterations = 1000.0;
  nextGoal_tmp = (int32_T)this->GoalIndex - 1;
  nextGoal[0] = this->RoutePlan[nextGoal_tmp].EndPose[0];
  plannerConfig_GoalTolerance[0] = 0.5;
  nextGoal[1] = this->RoutePlan[nextGoal_tmp].EndPose[1];
  plannerConfig_GoalTolerance[1] = 0.5;
  nextGoal[2] = this->RoutePlan[nextGoal_tmp].EndPose[2];
  plannerConfig_GoalTolerance[2] = 5.0;
  *plannerConfig_IsParkManeuver = (this->GoalIndex == 5.0);
  if (*plannerConfig_IsParkManeuver) {
    plannerConfig_GoalTolerance[0] = 0.5;
    plannerConfig_GoalTolerance[1] = 0.5;
    plannerConfig_GoalTolerance[2] = 10.0;
    *plannerConfig_ConnectionDistanc = 6.0;
  }

  a = currentPose[0] - this->RoutePlan[nextGoal_tmp].EndPose[0];
  z1_idx_0 = a * a;
  a = currentPose[1] - this->RoutePlan[nextGoal_tmp].EndPose[1];
  if (sqrt(a * a + z1_idx_0) < 10.0) {
    *plannerConfig_ConnectionDistanc = 6.0;
  }

  if (!this->RoutePlan[nextGoal_tmp].Attributes.TurnManeuver) {
    *plannerConfig_MinTurningRadius = 20.0;
  } else if (*plannerConfig_IsParkManeuver) {
    *plannerConfig_MinTurningRadius = 4.0;
  } else {
    *plannerConfig_MinTurningRadius = 5.0;
  }

  *speedProfile_StartSpeed = currentSpeed;
  *speedProfile_EndSpeed = this->RoutePlan[nextGoal_tmp].Attributes.EndSpeed;
  *speedProfile_MaxSpeed = this->RoutePlan[nextGoal_tmp].Attributes.MaxSpeed;
  this->GoalIndex++;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_imdilate(const boolean_T A[15000], boolean_T
  B[15000])
{
  int32_T b[45];
  int32_T c[90];
  real_T d[2];
  int32_T e[2];
  int32_T secondIndRange[2];
  boolean_T out_[100];
  int32_T pind;
  int32_T imnhInds_data[45];
  int32_T b_imnhInds_data[45];
  int32_T c_imnhInds_data[45];
  int32_T e_pind;
  int32_T d_imnhInds_data[45];
  boolean_T isInside[45];
  int32_T minval;
  int16_T b_pixelSub[2];
  int32_T c_pixelSub[2];
  int32_T imnhInds_[45];
  int16_T d_pixelSub[2];
  int32_T imnhSubs[90];
  int8_T b_varargin_1_data[46];
  int32_T e_c;
  int32_T g_y;
  int32_T i;
  int32_T d_imnhInds_size_idx_0;
  int32_T firstIndRange_idx_0;
  int32_T firstDimExtents_idx_0;
  static const boolean_T nhConn[49] = { false, true, true, true, true, true,
    false, true, true, true, true, true, true, true, true, true, true, true,
    true, true, true, true, true, true, true, true, true, true, true, true, true,
    true, true, true, true, true, true, true, true, true, true, true, false,
    true, true, true, true, true, false };

  boolean_T exitg1;
  memset(&b[0], 0, 45U * sizeof(int32_T));
  memset(&imnhInds_[0], 0, 45U * sizeof(int32_T));
  memset(&c[0], 0, 90U * sizeof(int32_T));
  e[0] = 100;
  e[1] = 150;
  NeighborhoodProcessor__exhgTOQa(e, nhConn, b, imnhInds_, c, d);
  firstIndRange_idx_0 = (int32_T)d[0];
  for (firstDimExtents_idx_0 = (int32_T)d[1]; firstDimExtents_idx_0 <= e[1];
       firstDimExtents_idx_0++) {
    for (minval = firstIndRange_idx_0 - 1; minval < e[0]; minval++) {
      pind = (firstDimExtents_idx_0 - 1) * 100 + minval;
      for (e_pind = 0; e_pind < 45; e_pind++) {
        b_varargin_1_data[e_pind] = (int8_T)A[b[e_pind] + pind];
      }

      b_varargin_1_data[45] = 0;
      pind = b_varargin_1_data[0];
      for (e_pind = 1; e_pind < 46; e_pind++) {
        if (pind < b_varargin_1_data[e_pind]) {
          pind = b_varargin_1_data[e_pind];
        }
      }

      out_[minval] = (pind != 0);
    }

    memcpy(&B[firstDimExtents_idx_0 * 100 + -100], &out_[0], 100U * sizeof
           (boolean_T));
  }

  if (rtIsNaN(d[1] - 1.0) || (d[1] - 1.0 > 150.0)) {
    g_y = 150;
  } else {
    g_y = (int32_T)(d[1] - 1.0);
  }

  minval = g_y - 1;
  for (pind = 0; pind <= minval; pind++) {
    for (e_pind = 0; e_pind < 100; e_pind++) {
      firstIndRange_idx_0 = pind * 100 + e_pind;
      for (i = 0; i < 45; i++) {
        imnhInds_[i] = (b[i] + firstIndRange_idx_0) + 1;
      }

      e_c = firstIndRange_idx_0 - 100 * div_s32(firstIndRange_idx_0, 100);
      firstDimExtents_idx_0 = firstIndRange_idx_0 - e_c;
      if (firstDimExtents_idx_0 >= 0) {
        i = firstDimExtents_idx_0;
      } else if (firstDimExtents_idx_0 == MIN_int32_T) {
        i = MAX_int32_T;
      } else {
        i = -firstDimExtents_idx_0;
      }

      g_y = i / 100;
      i -= g_y * 100;
      if ((i > 0) && (i >= 50)) {
        g_y++;
      }

      if (firstDimExtents_idx_0 < 0) {
        g_y = -g_y;
      }

      secondIndRange[1] = g_y + 1;
      secondIndRange[0] = e_c + 1;
      for (e_c = 0; e_c < 2; e_c++) {
        for (firstDimExtents_idx_0 = 0; firstDimExtents_idx_0 < 45;
             firstDimExtents_idx_0++) {
          g_y = 45 * e_c + firstDimExtents_idx_0;
          imnhSubs[g_y] = c[g_y] + secondIndRange[e_c];
        }
      }

      e_c = 0;
      for (i = 0; i < 45; i++) {
        isInside[i] = true;
        firstDimExtents_idx_0 = 0;
        exitg1 = false;
        while ((!exitg1) && (firstDimExtents_idx_0 < 2)) {
          g_y = 45 * firstDimExtents_idx_0 + i;
          if ((imnhSubs[g_y] < 1) || (imnhSubs[g_y] > 50 * firstDimExtents_idx_0
               + 100)) {
            isInside[i] = false;
            exitg1 = true;
          } else {
            firstDimExtents_idx_0++;
          }
        }

        if (isInside[i]) {
          e_c++;
        }
      }

      d_imnhInds_size_idx_0 = e_c;
      e_c = 0;
      for (firstDimExtents_idx_0 = 0; firstDimExtents_idx_0 < 45;
           firstDimExtents_idx_0++) {
        if (isInside[firstDimExtents_idx_0]) {
          imnhInds_data[e_c] = imnhInds_[firstDimExtents_idx_0];
          e_c++;
        }
      }

      for (g_y = 0; g_y < d_imnhInds_size_idx_0; g_y++) {
        isInside[g_y] = A[imnhInds_data[g_y] - 1];
      }

      i = d_imnhInds_size_idx_0 + 1;
      for (g_y = 0; g_y < d_imnhInds_size_idx_0; g_y++) {
        b_varargin_1_data[g_y] = (int8_T)isInside[g_y];
      }

      b_varargin_1_data[d_imnhInds_size_idx_0] = 0;
      if (i <= 2) {
        if (i == 1) {
          e_c = b_varargin_1_data[0];
        } else if (b_varargin_1_data[0] < b_varargin_1_data[1]) {
          e_c = b_varargin_1_data[1];
        } else {
          e_c = b_varargin_1_data[0];
        }
      } else {
        e_c = b_varargin_1_data[0];
        for (firstDimExtents_idx_0 = 1; firstDimExtents_idx_0 < i;
             firstDimExtents_idx_0++) {
          if (e_c < b_varargin_1_data[firstDimExtents_idx_0]) {
            e_c = b_varargin_1_data[firstDimExtents_idx_0];
          }
        }
      }

      B[firstIndRange_idx_0] = (e_c != 0);
    }
  }

  secondIndRange[0] = e[1] + 1;
  if (secondIndRange[0] < 1) {
    minval = 1;
  } else {
    minval = secondIndRange[0];
  }

  while (minval <= 150) {
    for (pind = 0; pind < 100; pind++) {
      e_pind = (minval - 1) * 100 + pind;
      for (i = 0; i < 45; i++) {
        imnhInds_[i] = (b[i] + e_pind) + 1;
      }

      firstIndRange_idx_0 = e_pind - 100 * div_s32(e_pind, 100);
      e_c = e_pind - firstIndRange_idx_0;
      if (e_c >= 0) {
        g_y = e_c;
      } else {
        g_y = -e_c;
      }

      i = g_y / 100;
      g_y -= i * 100;
      if ((g_y > 0) && (g_y >= 50)) {
        i++;
      }

      if (e_c < 0) {
        i = -i;
      }

      b_pixelSub[1] = (int16_T)(i + 1);
      b_pixelSub[0] = (int16_T)(firstIndRange_idx_0 + 1);
      for (firstIndRange_idx_0 = 0; firstIndRange_idx_0 < 2; firstIndRange_idx_0
           ++) {
        secondIndRange[firstIndRange_idx_0] = b_pixelSub[firstIndRange_idx_0];
        for (e_c = 0; e_c < 45; e_c++) {
          g_y = 45 * firstIndRange_idx_0 + e_c;
          imnhSubs[g_y] = c[g_y] + secondIndRange[firstIndRange_idx_0];
        }
      }

      firstIndRange_idx_0 = 0;
      for (i = 0; i < 45; i++) {
        isInside[i] = true;
        e_c = 0;
        exitg1 = false;
        while ((!exitg1) && (e_c < 2)) {
          g_y = 45 * e_c + i;
          if ((imnhSubs[g_y] < 1) || (imnhSubs[g_y] > 50 * e_c + 100)) {
            isInside[i] = false;
            exitg1 = true;
          } else {
            e_c++;
          }
        }

        if (isInside[i]) {
          firstIndRange_idx_0++;
        }
      }

      firstDimExtents_idx_0 = firstIndRange_idx_0;
      firstIndRange_idx_0 = 0;
      for (e_c = 0; e_c < 45; e_c++) {
        if (isInside[e_c]) {
          b_imnhInds_data[firstIndRange_idx_0] = imnhInds_[e_c];
          firstIndRange_idx_0++;
        }
      }

      for (g_y = 0; g_y < firstDimExtents_idx_0; g_y++) {
        isInside[g_y] = A[b_imnhInds_data[g_y] - 1];
      }

      i = firstDimExtents_idx_0 + 1;
      for (g_y = 0; g_y < firstDimExtents_idx_0; g_y++) {
        b_varargin_1_data[g_y] = (int8_T)isInside[g_y];
      }

      b_varargin_1_data[firstDimExtents_idx_0] = 0;
      if (i <= 2) {
        if (i == 1) {
          firstIndRange_idx_0 = b_varargin_1_data[0];
        } else if (b_varargin_1_data[0] < b_varargin_1_data[1]) {
          firstIndRange_idx_0 = b_varargin_1_data[1];
        } else {
          firstIndRange_idx_0 = b_varargin_1_data[0];
        }
      } else {
        firstIndRange_idx_0 = b_varargin_1_data[0];
        for (e_c = 1; e_c < i; e_c++) {
          if (firstIndRange_idx_0 < b_varargin_1_data[e_c]) {
            firstIndRange_idx_0 = b_varargin_1_data[e_c];
          }
        }
      }

      B[e_pind] = (firstIndRange_idx_0 != 0);
    }

    minval++;
  }

  if (rtIsNaN(d[0] - 1.0) || (d[0] - 1.0 > 100.0)) {
    g_y = 100;
  } else {
    g_y = (int32_T)(d[0] - 1.0);
  }

  firstDimExtents_idx_0 = g_y - 1;
  for (minval = 1; minval < 151; minval++) {
    for (pind = 0; pind <= firstDimExtents_idx_0; pind++) {
      e_pind = (minval - 1) * 100 + pind;
      for (i = 0; i < 45; i++) {
        imnhInds_[i] = (b[i] + e_pind) + 1;
      }

      firstIndRange_idx_0 = e_pind - 100 * div_s32(e_pind, 100);
      e_c = e_pind - firstIndRange_idx_0;
      if (e_c >= 0) {
        g_y = e_c;
      } else if (e_c == MIN_int32_T) {
        g_y = MAX_int32_T;
      } else {
        g_y = -e_c;
      }

      i = g_y / 100;
      g_y -= i * 100;
      if ((g_y > 0) && (g_y >= 50)) {
        i++;
      }

      if (e_c < 0) {
        i = -i;
      }

      c_pixelSub[1] = i + 1;
      c_pixelSub[0] = firstIndRange_idx_0 + 1;
      for (firstIndRange_idx_0 = 0; firstIndRange_idx_0 < 2; firstIndRange_idx_0
           ++) {
        for (e_c = 0; e_c < 45; e_c++) {
          g_y = 45 * firstIndRange_idx_0 + e_c;
          imnhSubs[g_y] = c[g_y] + c_pixelSub[firstIndRange_idx_0];
        }
      }

      firstIndRange_idx_0 = 0;
      for (i = 0; i < 45; i++) {
        isInside[i] = true;
        e_c = 0;
        exitg1 = false;
        while ((!exitg1) && (e_c < 2)) {
          g_y = 45 * e_c + i;
          if ((imnhSubs[g_y] < 1) || (imnhSubs[g_y] > 50 * e_c + 100)) {
            isInside[i] = false;
            exitg1 = true;
          } else {
            e_c++;
          }
        }

        if (isInside[i]) {
          firstIndRange_idx_0++;
        }
      }

      d_imnhInds_size_idx_0 = firstIndRange_idx_0;
      firstIndRange_idx_0 = 0;
      for (e_c = 0; e_c < 45; e_c++) {
        if (isInside[e_c]) {
          c_imnhInds_data[firstIndRange_idx_0] = imnhInds_[e_c];
          firstIndRange_idx_0++;
        }
      }

      for (g_y = 0; g_y < d_imnhInds_size_idx_0; g_y++) {
        isInside[g_y] = A[c_imnhInds_data[g_y] - 1];
      }

      i = d_imnhInds_size_idx_0 + 1;
      for (g_y = 0; g_y < d_imnhInds_size_idx_0; g_y++) {
        b_varargin_1_data[g_y] = (int8_T)isInside[g_y];
      }

      b_varargin_1_data[d_imnhInds_size_idx_0] = 0;
      if (i <= 2) {
        if (i == 1) {
          firstIndRange_idx_0 = b_varargin_1_data[0];
        } else if (b_varargin_1_data[0] < b_varargin_1_data[1]) {
          firstIndRange_idx_0 = b_varargin_1_data[1];
        } else {
          firstIndRange_idx_0 = b_varargin_1_data[0];
        }
      } else {
        firstIndRange_idx_0 = b_varargin_1_data[0];
        for (e_c = 1; e_c < i; e_c++) {
          if (firstIndRange_idx_0 < b_varargin_1_data[e_c]) {
            firstIndRange_idx_0 = b_varargin_1_data[e_c];
          }
        }
      }

      B[e_pind] = (firstIndRange_idx_0 != 0);
    }
  }

  firstDimExtents_idx_0 = e[0] + 1;
  if (firstDimExtents_idx_0 < 1) {
    firstDimExtents_idx_0 = 1;
  }

  for (minval = 1; minval < 151; minval++) {
    for (pind = firstDimExtents_idx_0; pind < 101; pind++) {
      e_pind = ((minval - 1) * 100 + pind) - 1;
      for (i = 0; i < 45; i++) {
        imnhInds_[i] = (b[i] + e_pind) + 1;
      }

      firstIndRange_idx_0 = e_pind - 100 * div_s32(e_pind, 100);
      e_c = e_pind - firstIndRange_idx_0;
      if (e_c >= 0) {
        g_y = e_c;
      } else {
        g_y = -e_c;
      }

      i = g_y / 100;
      g_y -= i * 100;
      if ((g_y > 0) && (g_y >= 50)) {
        i++;
      }

      if (e_c < 0) {
        i = -i;
      }

      d_pixelSub[1] = (int16_T)(i + 1);
      d_pixelSub[0] = (int16_T)(firstIndRange_idx_0 + 1);
      for (firstIndRange_idx_0 = 0; firstIndRange_idx_0 < 2; firstIndRange_idx_0
           ++) {
        secondIndRange[firstIndRange_idx_0] = d_pixelSub[firstIndRange_idx_0];
        for (e_c = 0; e_c < 45; e_c++) {
          g_y = 45 * firstIndRange_idx_0 + e_c;
          imnhSubs[g_y] = c[g_y] + secondIndRange[firstIndRange_idx_0];
        }
      }

      firstIndRange_idx_0 = 0;
      for (i = 0; i < 45; i++) {
        isInside[i] = true;
        e_c = 0;
        exitg1 = false;
        while ((!exitg1) && (e_c < 2)) {
          g_y = 45 * e_c + i;
          if ((imnhSubs[g_y] < 1) || (imnhSubs[g_y] > 50 * e_c + 100)) {
            isInside[i] = false;
            exitg1 = true;
          } else {
            e_c++;
          }
        }

        if (isInside[i]) {
          firstIndRange_idx_0++;
        }
      }

      d_imnhInds_size_idx_0 = firstIndRange_idx_0;
      firstIndRange_idx_0 = 0;
      for (e_c = 0; e_c < 45; e_c++) {
        if (isInside[e_c]) {
          d_imnhInds_data[firstIndRange_idx_0] = imnhInds_[e_c];
          firstIndRange_idx_0++;
        }
      }

      for (g_y = 0; g_y < d_imnhInds_size_idx_0; g_y++) {
        isInside[g_y] = A[d_imnhInds_data[g_y] - 1];
      }

      i = d_imnhInds_size_idx_0 + 1;
      for (g_y = 0; g_y < d_imnhInds_size_idx_0; g_y++) {
        b_varargin_1_data[g_y] = (int8_T)isInside[g_y];
      }

      b_varargin_1_data[d_imnhInds_size_idx_0] = 0;
      if (i <= 2) {
        if (i == 1) {
          firstIndRange_idx_0 = b_varargin_1_data[0];
        } else if (b_varargin_1_data[0] < b_varargin_1_data[1]) {
          firstIndRange_idx_0 = b_varargin_1_data[1];
        } else {
          firstIndRange_idx_0 = b_varargin_1_data[0];
        }
      } else {
        firstIndRange_idx_0 = b_varargin_1_data[0];
        for (e_c = 1; e_c < i; e_c++) {
          if (firstIndRange_idx_0 < b_varargin_1_data[e_c]) {
            firstIndRange_idx_0 = b_varargin_1_data[e_c];
          }
        }
      }

      B[e_pind] = (firstIndRange_idx_0 != 0);
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapCodegen_configure(c_driving_internal_costmap_Ve_T
  *this)
{
  int32_T i;
  this->CollisionCheckOffsets[0] = -0.4125;
  this->CollisionCheckOffsets[1] = 0.76250000000000018;
  this->CollisionCheckOffsets[2] = 1.9375;
  this->CollisionCheckOffsets[3] = 3.1125;
  for (i = 0; i < 15000; i++) {
    AutomatedParkingValet_B.this_c[i] = (this->Costmap[i] >
      this->pOccupiedThreshold);
  }

  AutomatedParkingValet_imdilate(AutomatedParkingValet_B.this_c,
    this->OccupiedMap);
  for (i = 0; i < 15000; i++) {
    this->FreeMap[i] = ((this->Costmap[i] < this->pFreeThreshold) &&
                        (!this->OccupiedMap[i]));
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapCodegen_configu_o(c_driving_internal_costmap_Ve_T
  *this, const boolean_T freeMap[15000], const boolean_T occMap[15000])
{
  this->CollisionCheckOffsets[0] = -0.4125;
  this->CollisionCheckOffsets[1] = 0.76250000000000018;
  this->CollisionCheckOffsets[2] = 1.9375;
  this->CollisionCheckOffsets[3] = 3.1125;
  memcpy(&this->FreeMap[0], &freeMap[0], 15000U * sizeof(boolean_T));
  memcpy(&this->OccupiedMap[0], &occMap[0], 15000U * sizeof(boolean_T));
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static c_driving_internal_costmap_Ve_T *Auto_VehicleCostmapCodegen_copy(const
  c_driving_internal_costmap_Ve_T *this, c_driving_internal_costmap_Ve_T *iobj_0)
{
  c_driving_internal_costmap_Ve_T *that;
  int32_T i;
  that = iobj_0;
  iobj_0->MapLocation[0] = this->MapLocation[0];
  iobj_0->MapLocation[1] = this->MapLocation[1];
  for (i = 0; i < 15000; i++) {
    iobj_0->Costmap[i] = this->Costmap[i];
  }

  iobj_0->pFreeThreshold = this->pFreeThreshold;
  iobj_0->pOccupiedThreshold = this->pOccupiedThreshold;
  VehicleCostmapCodegen_configu_o(iobj_0, this->FreeMap, this->OccupiedMap);
  return that;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_rand(real_T r[15000])
{
  int32_T k;
  for (k = 0; k < 15000; k++) {
    r[k] = eml_rand_mt19937ar_Ja00L5sI(AutomatedParkingValet_DW.state);
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapImpl_vehiclePoseT(const
  c_driving_internal_costmap_Ve_T *this, const real_T vehiclePoses[15000],
  real_T xyPoints[40000])
{
  int32_T n;
  int32_T i;
  int32_T xyPoints_tmp;
  memset(&xyPoints[0], 0, 40000U * sizeof(real_T));
  for (i = 0; i < 5000; i++) {
    AutomatedParkingValet_B.idx[i] = (real_T)i + 1.0;
  }

  for (n = 0; n < 4; n++) {
    memcpy(&AutomatedParkingValet_B.b[0], &vehiclePoses[10000], 5000U * sizeof
           (real_T));
    cos_yxWixxmO(AutomatedParkingValet_B.b);
    memcpy(&AutomatedParkingValet_B.c[0], &vehiclePoses[10000], 5000U * sizeof
           (real_T));
    sin_aZRL3w35(AutomatedParkingValet_B.c);
    for (i = 0; i < 5000; i++) {
      xyPoints_tmp = (int32_T)AutomatedParkingValet_B.idx[i];
      xyPoints[xyPoints_tmp - 1] = this->CollisionCheckOffsets[n] *
        AutomatedParkingValet_B.b[i] + vehiclePoses[i];
      xyPoints[xyPoints_tmp + 19999] = vehiclePoses[i + 5000] +
        this->CollisionCheckOffsets[n] * AutomatedParkingValet_B.c[i];
    }

    for (i = 0; i < 5000; i++) {
      AutomatedParkingValet_B.idx[i] += 5000.0;
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapImpl_withinMapLim(const
  c_driving_internal_costmap_Ve_T *this, const real_T xyPoints[40000], boolean_T
  insideMap[20000])
{
  int32_T i;
  real_T insideMap_tmp;
  for (i = 0; i < 20000; i++) {
    insideMap_tmp = xyPoints[i + 20000];
    insideMap[i] = ((xyPoints[i] >= this->MapLocation[0]) && (xyPoints[i] <=
      this->MapLocation[0] + 75.0) && (insideMap_tmp >= this->MapLocation[1]) &&
                    (insideMap_tmp <= this->MapLocation[1] + 50.0));
  }
}

static void AutomatedParking_emxFree_real_T(emxArray_real_T_AutomatedPark_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_real_T_AutomatedPark_T *)NULL) {
    if (((*pEmxArray)->data != (real_T *)NULL) && (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_real_T_AutomatedPark_T *)NULL;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapImpl_xyPointsToGr(const
  c_driving_internal_costmap_Ve_T *this, const emxArray_real_T_AutomatedPark_T
  *xyPoints, emxArray_real_T_AutomatedPark_T *gridIndices)
{
  emxArray_real_T_AutomatedPark_T *gridLocations;
  emxArray_real_T_AutomatedPark_T *c;
  real_T tmp;
  int32_T acoef;
  int32_T d_k;
  int32_T csz_idx_0;
  AutomatedParking_emxInit_real_T(&c, 2);
  csz_idx_0 = xyPoints->size[0];
  d_k = c->size[0] * c->size[1];
  c->size[0] = csz_idx_0;
  c->size[1] = 2;
  Automa_emxEnsureCapacity_real_T(c, d_k);
  if (c->size[0] != 0) {
    csz_idx_0 = c->size[0];
    acoef = (xyPoints->size[0] != 1);
    for (d_k = 0; d_k < csz_idx_0; d_k++) {
      c->data[d_k] = xyPoints->data[acoef * d_k] - this->MapLocation[0];
    }

    csz_idx_0 = c->size[0];
    acoef = (xyPoints->size[0] != 1);
    for (d_k = 0; d_k < csz_idx_0; d_k++) {
      c->data[d_k + c->size[0]] = xyPoints->data[acoef * d_k + xyPoints->size[0]]
        - this->MapLocation[1];
    }
  }

  if (c->size[0] != 0) {
    csz_idx_0 = c->size[0];
    for (acoef = 0; acoef < csz_idx_0; acoef++) {
      tmp = c->data[acoef];
      d_k = acoef + csz_idx_0;
      c->data[acoef] = c->data[d_k];
      c->data[d_k] = tmp;
    }
  }

  csz_idx_0 = c->size[0] * c->size[1];
  d_k = c->size[0] * c->size[1];
  c->size[1] = 2;
  Automa_emxEnsureCapacity_real_T(c, d_k);
  csz_idx_0--;
  for (d_k = 0; d_k <= csz_idx_0; d_k++) {
    c->data[d_k] /= 0.5;
  }

  csz_idx_0 = c->size[0] << 1;
  for (acoef = 0; acoef < csz_idx_0; acoef++) {
    c->data[acoef] = ceil(c->data[acoef]);
  }

  AutomatedParking_emxInit_real_T(&gridLocations, 2);
  d_k = gridLocations->size[0] * gridLocations->size[1];
  gridLocations->size[0] = c->size[0];
  gridLocations->size[1] = 2;
  Automa_emxEnsureCapacity_real_T(gridLocations, d_k);
  csz_idx_0 = c->size[0] << 1;
  for (acoef = 0; acoef < csz_idx_0; acoef++) {
    gridLocations->data[acoef] = fmax(c->data[acoef], 1.0);
  }

  AutomatedParking_emxFree_real_T(&c);
  csz_idx_0 = gridLocations->size[0];
  d_k = gridIndices->size[0];
  gridIndices->size[0] = csz_idx_0;
  Automa_emxEnsureCapacity_real_T(gridIndices, d_k);
  for (d_k = 0; d_k < csz_idx_0; d_k++) {
    gridIndices->data[d_k] = (gridLocations->data[d_k + gridLocations->size[0]]
      - 1.0) * 100.0 + (101.0 - gridLocations->data[d_k]);
  }

  AutomatedParking_emxFree_real_T(&gridLocations);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapImpl_checkFreeWor(const
  c_driving_internal_costmap_Ve_T *this, const real_T xyPoints[40000], boolean_T
  b_free[20000])
{
  int32_T trueCount;
  emxArray_real_T_AutomatedPark_T *d;
  int32_T i;
  emxArray_real_T_AutomatedPark_T *xyPoints_0;
  int32_T c_size_idx_0;
  VehicleCostmapImpl_withinMapLim(this, xyPoints,
    AutomatedParkingValet_B.insideMap);
  trueCount = 0;
  for (i = 0; i < 20000; i++) {
    b_free[i] = false;
    if (AutomatedParkingValet_B.insideMap[i]) {
      trueCount++;
    }
  }

  c_size_idx_0 = trueCount;
  trueCount = 0;
  for (i = 0; i < 20000; i++) {
    if (AutomatedParkingValet_B.insideMap[i]) {
      AutomatedParkingValet_B.c_data[trueCount] = (int16_T)(i + 1);
      trueCount++;
    }
  }

  AutomatedParking_emxInit_real_T(&xyPoints_0, 2);
  i = xyPoints_0->size[0] * xyPoints_0->size[1];
  xyPoints_0->size[0] = c_size_idx_0;
  xyPoints_0->size[1] = 2;
  Automa_emxEnsureCapacity_real_T(xyPoints_0, i);
  for (i = 0; i < c_size_idx_0; i++) {
    xyPoints_0->data[i] = xyPoints[AutomatedParkingValet_B.c_data[i] - 1];
  }

  for (i = 0; i < c_size_idx_0; i++) {
    xyPoints_0->data[i + xyPoints_0->size[0]] =
      xyPoints[AutomatedParkingValet_B.c_data[i] + 19999];
  }

  AutomatedParking_emxInit_real_T(&d, 1);
  VehicleCostmapImpl_xyPointsToGr(this, xyPoints_0, d);
  trueCount = 0;
  AutomatedParking_emxFree_real_T(&xyPoints_0);
  for (i = 0; i < 20000; i++) {
    if (AutomatedParkingValet_B.insideMap[i]) {
      b_free[i] = this->FreeMap[(int32_T)d->data[trueCount] - 1];
      trueCount++;
    }
  }

  AutomatedParking_emxFree_real_T(&d);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void UniformPoseSampler_checkForColl(e_matlabshared_planning_inter_T
  *this)
{
  c_driving_internal_costmap_Ve_T *b_this;
  int32_T i;
  int32_T i_0;
  for (i_0 = 0; i_0 < 3; i_0++) {
    for (i = 0; i < 5000; i++) {
      AutomatedParkingValet_B.vehiclePoses[i + 5000 * i_0] = this->PoseBuffer[3 *
        i + i_0];
    }
  }

  b_this = this->Costmap;
  VehicleCostmapImpl_vehiclePoseT(b_this, AutomatedParkingValet_B.vehiclePoses,
    AutomatedParkingValet_B.xyPoints);
  VehicleCostmapImpl_checkFreeWor(b_this, AutomatedParkingValet_B.xyPoints,
    AutomatedParkingValet_B.freeMat);
  all_NdIgJbYL(AutomatedParkingValet_B.freeMat, this->CollisionFree);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void UniformPoseSampler_fillPoseBuff(e_matlabshared_planning_inter_T
  *this)
{
  int32_T k;
  real_T a_idx_0;
  real_T a_idx_1;
  real_T a_idx_2;
  int32_T r_tmp;
  AutomatedParkingValet_rand(AutomatedParkingValet_B.r);
  a_idx_0 = this->UpperLimits[0] - this->LowerLimits[0];
  a_idx_1 = this->UpperLimits[1] - this->LowerLimits[1];
  a_idx_2 = this->UpperLimits[2] - this->LowerLimits[2];
  for (k = 0; k < 5000; k++) {
    AutomatedParkingValet_B.r[3 * k] = AutomatedParkingValet_B.r[3 * k] *
      a_idx_0 + this->LowerLimits[0];
    r_tmp = 3 * k + 1;
    AutomatedParkingValet_B.r[r_tmp] = AutomatedParkingValet_B.r[r_tmp] *
      a_idx_1 + this->LowerLimits[1];
    r_tmp = 3 * k + 2;
    AutomatedParkingValet_B.r[r_tmp] = AutomatedParkingValet_B.r[r_tmp] *
      a_idx_2 + this->LowerLimits[2];
  }

  memcpy(&this->PoseBuffer[0], &AutomatedParkingValet_B.r[0], 15000U * sizeof
         (real_T));
  UniformPoseSampler_checkForColl(this);
  this->PoseIndex = 1.0;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_rand_n(real_T r[5000])
{
  int32_T k;
  for (k = 0; k < 5000; k++) {
    r[k] = eml_rand_mt19937ar_Ja00L5sI(AutomatedParkingValet_DW.state);
  }
}

static void AutomatedP_emxInit_cell_wrap_38(emxArray_cell_wrap_38_Automat_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_cell_wrap_38_Automat_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_cell_wrap_38_Automat_T *)malloc(sizeof
    (emxArray_cell_wrap_38_Automat_T));
  emxArray = *pEmxArray;
  emxArray->data = (cell_wrap_38_AutomatedParking_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static void emxInitStruct_e_driving_interna(e_driving_internal_planning_D_T
  *pStruct)
{
  AutomatedP_emxInit_cell_wrap_38(&pStruct->DisabledPathTypesInternal, 2);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static e_driving_internal_planning_D_T *Automat_DubinsConnection_create
  (e_driving_internal_planning_D_T *iobj_0)
{
  e_driving_internal_planning_D_T *this;
  this = iobj_0;
  iobj_0->MinTurningRadius = 1.0;
  iobj_0->DisabledPathTypesInternal->size[0] = 0;
  iobj_0->DisabledPathTypesInternal->size[1] = 0;
  iobj_0->MinTurningRadius = 4.0;
  return this;
}

static void emxEnsureCapacity_c_driving_int(emxArray_c_driving_internal_p_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(c_driving_internal_planning_D_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(c_driving_internal_planning_D_T)
             * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (c_driving_internal_planning_D_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

static void AutomatedP_emxFree_cell_wrap_38(emxArray_cell_wrap_38_Automat_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_cell_wrap_38_Automat_T *)NULL) {
    if (((*pEmxArray)->data != (cell_wrap_38_AutomatedParking_T *)NULL) &&
        (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_cell_wrap_38_Automat_T *)NULL;
  }
}

static void emxFreeStruct_e_driving_interna(e_driving_internal_planning_D_T
  *pStruct)
{
  AutomatedP_emxFree_cell_wrap_38(&pStruct->DisabledPathTypesInternal);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void DubinsPathSegmentCodegen_makeem(emxArray_c_driving_internal_p_T
  *e_Data)
{
  e_driving_internal_planning_D_T lobj_0;
  e_driving_internal_planning_D_T *varargin_1;
  c_driving_internal_planning_D_T this;
  real_T startPose[3];
  real_T goalPose[3];
  int32_T tmp;
  emxInitStruct_e_driving_interna(&lobj_0);
  varargin_1 = Automat_DubinsConnection_create(&lobj_0);
  startPose[0] = 0.0;
  startPose[1] = 0.0;
  startPose[2] = 0.0;
  angleUtilities_wrapTo2_bbViJ3IV(&startPose[2]);
  goalPose[0] = 0.0;
  goalPose[1] = 0.0;
  goalPose[2] = 0.0;
  angleUtilities_wrapTo2_bbViJ3IV(&goalPose[2]);
  this.MinTurningRadius = varargin_1->MinTurningRadius;
  this.StartPoseInternal[0] = startPose[0];
  this.StartPoseInternal[1] = startPose[1];
  this.StartPoseInternal[2] = startPose[2];
  angleUtilities_wrapTo2_bbViJ3IV(&this.StartPoseInternal[2]);
  this.GoalPoseInternal[0] = goalPose[0];
  this.GoalPoseInternal[1] = goalPose[1];
  this.GoalPoseInternal[2] = goalPose[2];
  angleUtilities_wrapTo2_bbViJ3IV(&this.GoalPoseInternal[2]);
  this.MotionLengths[0] = 0.0;
  this.MotionTypes[0] = 'L';
  this.MotionLengths[1] = 0.0;
  this.MotionTypes[1] = 'S';
  this.MotionLengths[2] = 0.0;
  this.MotionTypes[2] = 'L';
  tmp = e_Data->size[0] * e_Data->size[1];
  e_Data->size[0] = 1;
  e_Data->size[1] = 1;
  emxEnsureCapacity_c_driving_int(e_Data, tmp);
  e_Data->data[0] = this;
  e_Data->size[0] = 0;
  e_Data->size[1] = 0;
  emxFreeStruct_e_driving_interna(&lobj_0);
}

static void emxCopy_c_driving_internal_plan(emxArray_c_driving_internal_p_T
  **dst, emxArray_c_driving_internal_p_T * const *src)
{
  int32_T i;
  int32_T numElDst;
  int32_T numElSrc;
  numElDst = 1;
  numElSrc = 1;
  for (i = 0; i < (*dst)->numDimensions; i++) {
    numElDst *= (*dst)->size[i];
    numElSrc *= (*src)->size[i];
  }

  for (i = 0; i < (*dst)->numDimensions; i++) {
    (*dst)->size[i] = (*src)->size[i];
  }

  emxEnsureCapacity_c_driving_int(*dst, numElDst);
  for (i = 0; i < numElSrc; i++) {
    (*dst)->data[i] = (*src)->data[i];
  }
}

static void emxCopyStruct_d_driving_interna(d_driving_internal_planning_D_T *dst,
  const d_driving_internal_planning_D_T *src)
{
  emxCopy_c_driving_internal_plan(&dst->Data, &src->Data);
}

static void Auto_emxCopyStruct_driving_Path(driving_Path_AutomatedParking_T *dst,
  const driving_Path_AutomatedParking_T *src)
{
  emxCopyStruct_d_driving_interna(&dst->PathSegments, &src->PathSegments);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void UniformPoseSampler_attemptResam(e_matlabshared_planning_inter_T
  *this)
{
  int32_T numAttempts;
  boolean_T noFreePoses;
  int32_T k;
  boolean_T exitg1;
  numAttempts = 1;
  noFreePoses = true;
  while (noFreePoses && (numAttempts < 4)) {
    UniformPoseSampler_fillPoseBuff(this);
    noFreePoses = false;
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 5000)) {
      if (!this->CollisionFree[k]) {
        k++;
      } else {
        noFreePoses = true;
        exitg1 = true;
      }
    }

    noFreePoses = !noFreePoses;
    numAttempts++;
  }
}

static void AutomatedPark_emxInit_boolean_T(emxArray_boolean_T_AutomatedP_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_boolean_T_AutomatedP_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_boolean_T_AutomatedP_T *)malloc(sizeof
    (emxArray_boolean_T_AutomatedP_T));
  emxArray = *pEmxArray;
  emxArray->data = (boolean_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void SqrtApproxNeighborSearcher_comp(d_matlabshared_planning_inter_T
  *this, const real_T *numNodes, real_T *offset, real_T *step)
{
  real_T r;
  *step = floor(sqrt(*numNodes));
  r = this->Offset;
  if (*step == 0.0) {
    if (this->Offset == 0.0) {
      r = *step;
    }
  } else if (rtIsNaN(this->Offset) || rtIsNaN(*step) || rtIsInf(this->Offset)) {
    r = (rtNaN);
  } else if (this->Offset == 0.0) {
    r = 0.0 / *step;
  } else if (rtIsInf(*step)) {
    if ((*step < 0.0) != (this->Offset < 0.0)) {
      r = *step;
    }
  } else {
    r = fmod(this->Offset, *step);
    if (r == 0.0) {
      r = *step * 0.0;
    } else {
      if ((this->Offset < 0.0) != (*step < 0.0)) {
        r += *step;
      }
    }
  }

  *offset = r + 1.0;
  this->Offset++;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkin_RRTTree_nearest(f_matlabshared_planning_inter_T
  *this, const real_T node_data[], const int32_T node_size[2], real_T
  nearestNode[3], real_T *nearestId)
{
  d_matlabshared_planning_inter_T *b_this;
  real_T offset;
  real_T step;
  real_T b_numNodes;
  int32_T b;
  int32_T c;
  int32_T d;
  emxArray_real_T_AutomatedPark_T *b_d;
  emxArray_real_T_AutomatedPark_T *from;
  c_matlabshared_planning_inter_T *c_this;
  int32_T nearestId_0;
  int32_T i;
  int32_T loop_ub;
  int32_T tmp;
  boolean_T exitg1;
  b_this = this->NeighborSearcher;
  for (nearestId_0 = 0; nearestId_0 < 30003; nearestId_0++) {
    AutomatedParkingValet_B.nodeBuffer[nearestId_0] = this->
      NodeBuffer[nearestId_0];
  }

  b_numNodes = this->NodeIndex - 1.0;
  SqrtApproxNeighborSearcher_comp(b_this, &b_numNodes, &offset, &step);
  if ((step == 0.0) || (((step > 0.0) && (offset > b_numNodes)) || ((0.0 > step)
        && (b_numNodes > offset)))) {
    d = 0;
    c = 1;
    b = -1;
  } else {
    d = (int32_T)offset - 1;
    c = (int32_T)step;
    b = (int32_T)b_numNodes - 1;
  }

  AutomatedParking_emxInit_real_T(&from, 2);
  nearestId_0 = from->size[0] * from->size[1];
  loop_ub = div_s32_floor(b - d, c);
  tmp = loop_ub + 1;
  from->size[0] = tmp;
  from->size[1] = 3;
  Automa_emxEnsureCapacity_real_T(from, nearestId_0);
  for (nearestId_0 = 0; nearestId_0 < 3; nearestId_0++) {
    for (i = 0; i <= loop_ub; i++) {
      from->data[i + from->size[0] * nearestId_0] =
        AutomatedParkingValet_B.nodeBuffer[(c * i + d) + 10001 * nearestId_0];
    }
  }

  AutomatedParking_emxInit_real_T(&b_d, 1);
  c_this = b_this->ConnectionMechanism;
  b_numNodes = c_this->TurningRadius;
  nearestId_0 = b_d->size[0];
  b_d->size[0] = (int32_T)fmax(tmp, node_size[0]);
  Automa_emxEnsureCapacity_real_T(b_d, nearestId_0);
  autonomousDubinsDistanceCodegen_real64(&from->data[0], (uint32_T)
    (div_s32_floor(b - d, c) + 1), &node_data[0], (uint32_T)node_size[0],
    b_numNodes, &b_d->data[0]);
  AutomatedParking_emxFree_real_T(&from);
  if (b_d->size[0] <= 2) {
    if (b_d->size[0] == 1) {
      d = 1;
    } else if ((b_d->data[0] > b_d->data[1]) || (rtIsNaN(b_d->data[0]) &&
                (!rtIsNaN(b_d->data[1])))) {
      d = 2;
    } else {
      d = 1;
    }
  } else {
    if (!rtIsNaN(b_d->data[0])) {
      d = 1;
    } else {
      d = 0;
      c = 2;
      exitg1 = false;
      while ((!exitg1) && (c <= b_d->size[0])) {
        if (!rtIsNaN(b_d->data[c - 1])) {
          d = c;
          exitg1 = true;
        } else {
          c++;
        }
      }
    }

    if (d == 0) {
      d = 1;
    } else {
      b_numNodes = b_d->data[d - 1];
      for (c = d; c < b_d->size[0]; c++) {
        if (b_numNodes > b_d->data[c]) {
          b_numNodes = b_d->data[c];
          d = c + 1;
        }
      }
    }
  }

  AutomatedParking_emxFree_real_T(&b_d);
  *nearestId = ((real_T)d - 1.0) * step + offset;
  nearestId_0 = (int32_T)*nearestId;
  nearestNode[0] = AutomatedParkingValet_B.nodeBuffer[nearestId_0 - 1];
  nearestNode[1] = AutomatedParkingValet_B.nodeBuffer[nearestId_0 + 10000];
  nearestNode[2] = AutomatedParkingValet_B.nodeBuffer[nearestId_0 + 20001];
}

static void Aut_emxEnsureCapacity_boolean_T(emxArray_boolean_T_AutomatedP_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(boolean_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(boolean_T) * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (boolean_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

static void AutomatedParkin_emxInit_int32_T(emxArray_int32_T_AutomatedPar_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_int32_T_AutomatedPar_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_int32_T_AutomatedPar_T *)malloc(sizeof
    (emxArray_int32_T_AutomatedPar_T));
  emxArray = *pEmxArray;
  emxArray->data = (int32_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static void Autom_emxEnsureCapacity_int32_T(emxArray_int32_T_AutomatedPar_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(int32_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(int32_T) * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (int32_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

static void AutomatedParkin_emxFree_int32_T(emxArray_int32_T_AutomatedPar_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_int32_T_AutomatedPar_T *)NULL) {
    if (((*pEmxArray)->data != (int32_T *)NULL) && (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_int32_T_AutomatedPar_T *)NULL;
  }
}

static void AutomatedPark_emxFree_boolean_T(emxArray_boolean_T_AutomatedP_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_boolean_T_AutomatedP_T *)NULL) {
    if (((*pEmxArray)->data != (boolean_T *)NULL) && (*pEmxArray)->canFreeData)
    {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_boolean_T_AutomatedP_T *)NULL;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void VehicleCostmapImpl_checkFreePos(const
  c_driving_internal_costmap_Ve_T *this, const emxArray_real_T_AutomatedPark_T
  *vehiclePoses, emxArray_boolean_T_AutomatedP_T *b_free)
{
  emxArray_real_T_AutomatedPark_T *xyPoints;
  emxArray_boolean_T_AutomatedP_T *freeMat;
  emxArray_real_T_AutomatedPark_T *idx;
  emxArray_boolean_T_AutomatedP_T *insideMap;
  emxArray_real_T_AutomatedPark_T *gridIndices;
  emxArray_int32_T_AutomatedPar_T *c;
  emxArray_real_T_AutomatedPark_T *x;
  int32_T vstride;
  int32_T i2;
  int32_T iy;
  int32_T i1;
  int32_T j;
  int32_T ix;
  emxArray_real_T_AutomatedPark_T *xyPoints_0;
  real_T mapLocation_idx_0;
  boolean_T exitg1;
  AutomatedParking_emxInit_real_T(&xyPoints, 2);
  mapLocation_idx_0 = 4.0 * (real_T)vehiclePoses->size[0];
  i1 = xyPoints->size[0] * xyPoints->size[1];
  vstride = (int32_T)mapLocation_idx_0;
  xyPoints->size[0] = vstride;
  xyPoints->size[1] = 2;
  Automa_emxEnsureCapacity_real_T(xyPoints, i1);
  iy = (vstride << 1) - 1;
  for (i1 = 0; i1 <= iy; i1++) {
    xyPoints->data[i1] = 0.0;
  }

  AutomatedParking_emxInit_real_T(&idx, 2);
  if (vehiclePoses->size[0] < 1) {
    idx->size[0] = 1;
    idx->size[1] = 0;
  } else {
    i1 = vehiclePoses->size[0];
    vstride = idx->size[0] * idx->size[1];
    idx->size[0] = 1;
    iy = (int32_T)((real_T)i1 - 1.0);
    idx->size[1] = iy + 1;
    Automa_emxEnsureCapacity_real_T(idx, vstride);
    for (i1 = 0; i1 <= iy; i1++) {
      idx->data[i1] = (real_T)i1 + 1.0;
    }
  }

  AutomatedParking_emxInit_real_T(&gridIndices, 1);
  AutomatedParking_emxInit_real_T(&x, 1);
  iy = vehiclePoses->size[0];
  i1 = gridIndices->size[0];
  gridIndices->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(gridIndices, i1);
  for (i1 = 0; i1 < iy; i1++) {
    gridIndices->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    gridIndices->data[iy] = cos(gridIndices->data[iy]);
  }

  iy = vehiclePoses->size[0];
  i1 = x->size[0];
  x->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(x, i1);
  for (i1 = 0; i1 < iy; i1++) {
    x->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    x->data[iy] = sin(x->data[iy]);
  }

  iy = vehiclePoses->size[0];
  vstride = vehiclePoses->size[0];
  for (i1 = 0; i1 < iy; i1++) {
    xyPoints->data[(int32_T)idx->data[i1] - 1] = this->CollisionCheckOffsets[0] *
      gridIndices->data[i1] + vehiclePoses->data[i1];
  }

  for (i1 = 0; i1 < vstride; i1++) {
    xyPoints->data[((int32_T)idx->data[i1] + xyPoints->size[0]) - 1] =
      vehiclePoses->data[i1 + vehiclePoses->size[0]] +
      this->CollisionCheckOffsets[0] * x->data[i1];
  }

  iy = idx->size[0] * idx->size[1];
  i1 = idx->size[0] * idx->size[1];
  idx->size[0] = 1;
  Automa_emxEnsureCapacity_real_T(idx, i1);
  vstride = vehiclePoses->size[0];
  iy--;
  for (i1 = 0; i1 <= iy; i1++) {
    idx->data[i1] += (real_T)vstride;
  }

  iy = vehiclePoses->size[0];
  i1 = gridIndices->size[0];
  gridIndices->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(gridIndices, i1);
  for (i1 = 0; i1 < iy; i1++) {
    gridIndices->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    gridIndices->data[iy] = cos(gridIndices->data[iy]);
  }

  iy = vehiclePoses->size[0];
  i1 = x->size[0];
  x->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(x, i1);
  for (i1 = 0; i1 < iy; i1++) {
    x->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    x->data[iy] = sin(x->data[iy]);
  }

  iy = vehiclePoses->size[0];
  vstride = vehiclePoses->size[0];
  for (i1 = 0; i1 < iy; i1++) {
    xyPoints->data[(int32_T)idx->data[i1] - 1] = this->CollisionCheckOffsets[1] *
      gridIndices->data[i1] + vehiclePoses->data[i1];
  }

  for (i1 = 0; i1 < vstride; i1++) {
    xyPoints->data[((int32_T)idx->data[i1] + xyPoints->size[0]) - 1] =
      vehiclePoses->data[i1 + vehiclePoses->size[0]] +
      this->CollisionCheckOffsets[1] * x->data[i1];
  }

  iy = idx->size[0] * idx->size[1];
  i1 = idx->size[0] * idx->size[1];
  idx->size[0] = 1;
  Automa_emxEnsureCapacity_real_T(idx, i1);
  vstride = vehiclePoses->size[0];
  iy--;
  for (i1 = 0; i1 <= iy; i1++) {
    idx->data[i1] += (real_T)vstride;
  }

  iy = vehiclePoses->size[0];
  i1 = gridIndices->size[0];
  gridIndices->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(gridIndices, i1);
  for (i1 = 0; i1 < iy; i1++) {
    gridIndices->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    gridIndices->data[iy] = cos(gridIndices->data[iy]);
  }

  iy = vehiclePoses->size[0];
  i1 = x->size[0];
  x->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(x, i1);
  for (i1 = 0; i1 < iy; i1++) {
    x->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    x->data[iy] = sin(x->data[iy]);
  }

  iy = vehiclePoses->size[0];
  vstride = vehiclePoses->size[0];
  for (i1 = 0; i1 < iy; i1++) {
    xyPoints->data[(int32_T)idx->data[i1] - 1] = this->CollisionCheckOffsets[2] *
      gridIndices->data[i1] + vehiclePoses->data[i1];
  }

  for (i1 = 0; i1 < vstride; i1++) {
    xyPoints->data[((int32_T)idx->data[i1] + xyPoints->size[0]) - 1] =
      vehiclePoses->data[i1 + vehiclePoses->size[0]] +
      this->CollisionCheckOffsets[2] * x->data[i1];
  }

  iy = idx->size[0] * idx->size[1];
  i1 = idx->size[0] * idx->size[1];
  idx->size[0] = 1;
  Automa_emxEnsureCapacity_real_T(idx, i1);
  vstride = vehiclePoses->size[0];
  iy--;
  for (i1 = 0; i1 <= iy; i1++) {
    idx->data[i1] += (real_T)vstride;
  }

  iy = vehiclePoses->size[0];
  i1 = gridIndices->size[0];
  gridIndices->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(gridIndices, i1);
  for (i1 = 0; i1 < iy; i1++) {
    gridIndices->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    gridIndices->data[iy] = cos(gridIndices->data[iy]);
  }

  iy = vehiclePoses->size[0];
  i1 = x->size[0];
  x->size[0] = iy;
  Automa_emxEnsureCapacity_real_T(x, i1);
  for (i1 = 0; i1 < iy; i1++) {
    x->data[i1] = vehiclePoses->data[(vehiclePoses->size[0] << 1) + i1];
  }

  for (iy = 0; iy < vehiclePoses->size[0]; iy++) {
    x->data[iy] = sin(x->data[iy]);
  }

  iy = vehiclePoses->size[0];
  vstride = vehiclePoses->size[0];
  for (i1 = 0; i1 < iy; i1++) {
    xyPoints->data[(int32_T)idx->data[i1] - 1] = this->CollisionCheckOffsets[3] *
      gridIndices->data[i1] + vehiclePoses->data[i1];
  }

  for (i1 = 0; i1 < vstride; i1++) {
    xyPoints->data[((int32_T)idx->data[i1] + xyPoints->size[0]) - 1] =
      vehiclePoses->data[i1 + vehiclePoses->size[0]] +
      this->CollisionCheckOffsets[3] * x->data[i1];
  }

  iy = idx->size[0] * idx->size[1];
  i1 = idx->size[0] * idx->size[1];
  idx->size[0] = 1;
  Automa_emxEnsureCapacity_real_T(idx, i1);
  vstride = vehiclePoses->size[0];
  iy--;
  for (i1 = 0; i1 <= iy; i1++) {
    idx->data[i1] += (real_T)vstride;
  }

  AutomatedParking_emxFree_real_T(&x);
  AutomatedParking_emxFree_real_T(&idx);
  AutomatedPark_emxInit_boolean_T(&insideMap, 1);
  iy = xyPoints->size[0];
  i1 = insideMap->size[0];
  insideMap->size[0] = iy;
  Aut_emxEnsureCapacity_boolean_T(insideMap, i1);
  for (i1 = 0; i1 < iy; i1++) {
    insideMap->data[i1] = ((xyPoints->data[i1] >= this->MapLocation[0]) &&
      (xyPoints->data[i1] <= this->MapLocation[0] + 75.0) && (xyPoints->data[i1
      + xyPoints->size[0]] >= this->MapLocation[1]) && (xyPoints->data[i1 +
      xyPoints->size[0]] <= this->MapLocation[1] + 50.0));
  }

  AutomatedPark_emxInit_boolean_T(&freeMat, 1);
  mapLocation_idx_0 = insideMap->size[0];
  i1 = freeMat->size[0];
  freeMat->size[0] = (int32_T)mapLocation_idx_0;
  Aut_emxEnsureCapacity_boolean_T(freeMat, i1);
  iy = (int32_T)mapLocation_idx_0;
  for (i1 = 0; i1 < iy; i1++) {
    freeMat->data[i1] = false;
  }

  vstride = insideMap->size[0] - 1;
  iy = 0;
  for (i1 = 0; i1 <= vstride; i1++) {
    if (insideMap->data[i1]) {
      iy++;
    }
  }

  AutomatedParkin_emxInit_int32_T(&c, 1);
  i1 = c->size[0];
  c->size[0] = iy;
  Autom_emxEnsureCapacity_int32_T(c, i1);
  iy = 0;
  for (i1 = 0; i1 <= vstride; i1++) {
    if (insideMap->data[i1]) {
      c->data[iy] = i1 + 1;
      iy++;
    }
  }

  AutomatedParking_emxInit_real_T(&xyPoints_0, 2);
  i1 = xyPoints_0->size[0] * xyPoints_0->size[1];
  xyPoints_0->size[0] = c->size[0];
  xyPoints_0->size[1] = 2;
  Automa_emxEnsureCapacity_real_T(xyPoints_0, i1);
  iy = c->size[0];
  for (i1 = 0; i1 < iy; i1++) {
    xyPoints_0->data[i1] = xyPoints->data[c->data[i1] - 1];
  }

  iy = c->size[0];
  for (i1 = 0; i1 < iy; i1++) {
    xyPoints_0->data[i1 + xyPoints_0->size[0]] = xyPoints->data[(c->data[i1] +
      xyPoints->size[0]) - 1];
  }

  AutomatedParkin_emxFree_int32_T(&c);
  AutomatedParking_emxFree_real_T(&xyPoints);
  VehicleCostmapImpl_xyPointsToGr(this, xyPoints_0, gridIndices);
  vstride = 0;
  iy = 0;
  AutomatedParking_emxFree_real_T(&xyPoints_0);
  while (iy <= insideMap->size[0] - 1) {
    if (insideMap->data[iy]) {
      freeMat->data[iy] = this->FreeMap[(int32_T)gridIndices->data[vstride] - 1];
      vstride++;
    }

    iy++;
  }

  AutomatedParking_emxFree_real_T(&gridIndices);
  AutomatedPark_emxFree_boolean_T(&insideMap);
  mapLocation_idx_0 = vehiclePoses->size[0];
  i1 = b_free->size[0];
  b_free->size[0] = (int32_T)mapLocation_idx_0;
  Aut_emxEnsureCapacity_boolean_T(b_free, i1);
  iy = (int32_T)mapLocation_idx_0;
  for (i1 = 0; i1 < iy; i1++) {
    b_free->data[i1] = true;
  }

  vstride = vehiclePoses->size[0];
  iy = -1;
  i1 = 0;
  i2 = 3 * vehiclePoses->size[0];
  for (j = 0; j < vstride; j++) {
    i1++;
    i2++;
    iy++;
    ix = i1;
    exitg1 = false;
    while ((!exitg1) && ((vstride > 0) && (ix <= i2))) {
      if (!freeMat->data[ix - 1]) {
        b_free->data[iy] = false;
        exitg1 = true;
      } else {
        ix += vstride;
      }
    }
  }

  AutomatedPark_emxFree_boolean_T(&freeMat);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void Autom_NeighborSearcher_distance(d_matlabshared_planning_inter_T
  *this, const emxArray_real_T_AutomatedPark_T *from, const real_T to[3],
  emxArray_real_T_AutomatedPark_T *d)
{
  c_matlabshared_planning_inter_T *b_this;
  real_T turningRadius;
  int32_T tmp;
  b_this = this->ConnectionMechanism;
  turningRadius = b_this->TurningRadius;
  tmp = d->size[0];
  d->size[0] = (int32_T)fmax(from->size[0], 1.0);
  Automa_emxEnsureCapacity_real_T(d, tmp);
  autonomousDubinsDistanceCodegen_real64(&from->data[0], (uint32_T)from->size[0],
    to, 1U, turningRadius, &d->data[0]);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkin_sortedInsertion(real_T x, int32_T ix,
  emxArray_real_T_AutomatedPark_T *b, int32_T *nb, int32_T blen, int32_T
  idx_data[])
{
  int32_T ja;
  int32_T jb;
  int32_T jc;
  if (*nb == 0) {
    *nb = 1;
    idx_data[0] = ix;
    b->data[0] = x;
  } else if ((x >= b->data[0]) || rtIsNaN(x)) {
    if ((*nb > 1) && (!(x >= b->data[*nb - 1])) && (!rtIsNaN(x))) {
      ja = 1;
      jb = *nb;
      while (ja < jb) {
        jc = ((jb - ja) >> 1) + ja;
        if (jc == ja) {
          ja = jb;
        } else if ((x >= b->data[jc - 1]) || rtIsNaN(x)) {
          ja = jc;
        } else {
          jb = jc;
        }
      }

      if (*nb < blen) {
        (*nb)++;
      }

      for (jb = *nb - 1; jb + 1 >= ja + 1; jb--) {
        b->data[jb] = b->data[jb - 1];
        idx_data[jb] = idx_data[jb - 1];
      }

      b->data[ja - 1] = x;
      idx_data[ja - 1] = ix;
    } else {
      if (*nb < blen) {
        (*nb)++;
        b->data[*nb - 1] = x;
        idx_data[*nb - 1] = ix;
      }
    }
  } else {
    if (*nb < blen) {
      (*nb)++;
    }

    for (ja = *nb - 1; ja + 1 > 1; ja--) {
      idx_data[ja] = idx_data[ja - 1];
      b->data[ja] = b->data[ja - 1];
    }

    b->data[0] = x;
    idx_data[0] = ix;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static boolean_T AutomatedParkingValet_sortLE(const
  emxArray_real_T_AutomatedPark_T *v, int32_T idx1, int32_T idx2)
{
  boolean_T p;
  if ((v->data[idx1 - 1] <= v->data[idx2 - 1]) || rtIsNaN(v->data[idx2 - 1])) {
    p = true;
  } else {
    p = false;
  }

  return p;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_mergesort(int32_T idx_data[], const
  emxArray_real_T_AutomatedPark_T *x, int32_T n)
{
  int32_T k;
  int32_T i;
  int32_T i2;
  int32_T j;
  int32_T pEnd;
  int32_T p;
  int32_T q;
  int32_T qEnd;
  int32_T kEnd;
  int32_T tmp;
  int32_T tmp_0;
  for (i = 1; i <= n - 1; i += 2) {
    if (AutomatedParkingValet_sortLE(x, i, i + 1)) {
      idx_data[i - 1] = i;
      idx_data[i] = i + 1;
    } else {
      idx_data[i - 1] = i + 1;
      idx_data[i] = i;
    }
  }

  if ((n & 1U) != 0U) {
    idx_data[n - 1] = n;
  }

  i = 2;
  while (i < n) {
    i2 = i << 1;
    j = 1;
    pEnd = i + 1;
    while (pEnd < n + 1) {
      p = j;
      q = pEnd;
      qEnd = j + i2;
      if (qEnd > n + 1) {
        qEnd = n + 1;
      }

      k = 0;
      kEnd = qEnd - j;
      while (k + 1 <= kEnd) {
        tmp = idx_data[q - 1];
        tmp_0 = idx_data[p - 1];
        if (AutomatedParkingValet_sortLE(x, tmp_0, tmp)) {
          AutomatedParkingValet_B.iwork_data[k] = tmp_0;
          p++;
          if (p == pEnd) {
            while (q < qEnd) {
              k++;
              AutomatedParkingValet_B.iwork_data[k] = idx_data[q - 1];
              q++;
            }
          }
        } else {
          AutomatedParkingValet_B.iwork_data[k] = tmp;
          q++;
          if (q == qEnd) {
            while (p < pEnd) {
              k++;
              AutomatedParkingValet_B.iwork_data[k] = idx_data[p - 1];
              p++;
            }
          }
        }

        k++;
      }

      for (pEnd = -1; pEnd < kEnd - 1; pEnd++) {
        idx_data[j + pEnd] = AutomatedParkingValet_B.iwork_data[pEnd + 1];
      }

      j = qEnd;
      pEnd = qEnd + i;
    }

    i = i2;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_sortIdx(const emxArray_real_T_AutomatedPark_T *
  x, int32_T idx_data[], int32_T *idx_size)
{
  int16_T b_idx_0;
  b_idx_0 = (int16_T)x->size[0];
  *idx_size = b_idx_0;
  if (0 <= b_idx_0 - 1) {
    memset(&idx_data[0], 0, b_idx_0 * sizeof(int32_T));
  }

  AutomatedParkingValet_mergesort(idx_data, x, x->size[0]);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_exkib(const emxArray_real_T_AutomatedPark_T *a,
  int32_T k, int32_T idx_data[], int32_T *idx_size,
  emxArray_real_T_AutomatedPark_T *b)
{
  int32_T unusedU2;
  int32_T c_j;
  *idx_size = k;
  if (0 <= k - 1) {
    memset(&idx_data[0], 0, k * sizeof(int32_T));
  }

  c_j = b->size[0];
  b->size[0] = k;
  Automa_emxEnsureCapacity_real_T(b, c_j);
  for (c_j = 0; c_j < k; c_j++) {
    b->data[c_j] = 0.0;
  }

  if (k != 0) {
    if ((k > 64) && (k > (a->size[0] >> 6))) {
      AutomatedParkingValet_sortIdx(a, AutomatedParkingValet_B.itmp_data, &c_j);
      c_j = b->size[0];
      b->size[0] = k;
      Automa_emxEnsureCapacity_real_T(b, c_j);
      for (c_j = 0; c_j < k; c_j++) {
        idx_data[c_j] = AutomatedParkingValet_B.itmp_data[c_j];
        b->data[c_j] = a->data[AutomatedParkingValet_B.itmp_data[c_j] - 1];
      }
    } else {
      for (c_j = 0; c_j < k; c_j++) {
        unusedU2 = c_j;
        AutomatedParkin_sortedInsertion(a->data[c_j], c_j + 1, b, &unusedU2, k,
          idx_data);
      }

      for (c_j = k + 1; c_j <= a->size[0]; c_j++) {
        unusedU2 = k;
        AutomatedParkin_sortedInsertion(a->data[c_j - 1], c_j, b, &unusedU2, k,
          idx_data);
      }
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void SqrtApproxNeighborSearcher_near(d_matlabshared_planning_inter_T
  *this, const real_T nodeBuffer[30003], real_T numNodes, const real_T node[3],
  real_T K, emxArray_real_T_AutomatedPark_T *nearNodes,
  emxArray_real_T_AutomatedPark_T *nearIds)
{
  real_T offset;
  real_T step;
  int32_T b;
  int32_T c;
  int32_T d;
  emxArray_real_T_AutomatedPark_T *a;
  emxArray_real_T_AutomatedPark_T *b_b;
  emxArray_real_T_AutomatedPark_T *nodeBuffer_0;
  int32_T K_0;
  int32_T loop_ub;
  SqrtApproxNeighborSearcher_comp(this, &numNodes, &offset, &step);
  if ((step == 0.0) || (((step > 0.0) && (offset > numNodes)) || ((0.0 > step) &&
        (numNodes > offset)))) {
    d = 0;
    c = 1;
    b = -1;
  } else {
    d = (int32_T)offset - 1;
    c = (int32_T)step;
    b = (int32_T)numNodes - 1;
  }

  AutomatedParking_emxInit_real_T(&nodeBuffer_0, 2);
  K_0 = nodeBuffer_0->size[0] * nodeBuffer_0->size[1];
  loop_ub = div_s32_floor(b - d, c);
  nodeBuffer_0->size[0] = loop_ub + 1;
  nodeBuffer_0->size[1] = 3;
  Automa_emxEnsureCapacity_real_T(nodeBuffer_0, K_0);
  for (K_0 = 0; K_0 < 3; K_0++) {
    for (b = 0; b <= loop_ub; b++) {
      nodeBuffer_0->data[b + nodeBuffer_0->size[0] * K_0] = nodeBuffer[(c * b +
        d) + 10001 * K_0];
    }
  }

  AutomatedParking_emxInit_real_T(&a, 1);
  AutomatedParking_emxInit_real_T(&b_b, 1);
  Autom_NeighborSearcher_distance(this, nodeBuffer_0, node, a);
  if (K <= a->size[0]) {
    K_0 = (int32_T)K;
  } else {
    K_0 = a->size[0];
  }

  AutomatedParkingValet_exkib(a, K_0, AutomatedParkingValet_B.idx_data, &b, b_b);
  K_0 = nearIds->size[0];
  nearIds->size[0] = b;
  Automa_emxEnsureCapacity_real_T(nearIds, K_0);
  AutomatedParking_emxFree_real_T(&nodeBuffer_0);
  AutomatedParking_emxFree_real_T(&b_b);
  AutomatedParking_emxFree_real_T(&a);
  for (K_0 = 0; K_0 < b; K_0++) {
    nearIds->data[K_0] = ((real_T)AutomatedParkingValet_B.idx_data[K_0] - 1.0) *
      step + offset;
  }

  K_0 = nearNodes->size[0] * nearNodes->size[1];
  nearNodes->size[0] = nearIds->size[0];
  nearNodes->size[1] = 3;
  Automa_emxEnsureCapacity_real_T(nearNodes, K_0);
  for (K_0 = 0; K_0 < 3; K_0++) {
    loop_ub = nearIds->size[0];
    for (b = 0; b < loop_ub; b++) {
      nearNodes->data[b + nearNodes->size[0] * K_0] = nodeBuffer[(10001 * K_0 +
        (int32_T)nearIds->data[b]) - 1];
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static real_T AutomatedParking_RRTTree_costTo(const
  f_matlabshared_planning_inter_T *this, real_T id)
{
  real_T cost;
  if (id < 2.0) {
    cost = 0.0;
  } else {
    cost = this->CostBuffer[(int32_T)(id - 1.0) - 1];
  }

  return cost;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void DubinsConnectionMechanism_dista(const
  c_matlabshared_planning_inter_T *this, const emxArray_real_T_AutomatedPark_T
  *from, const real_T to[3], emxArray_real_T_AutomatedPark_T *d)
{
  int32_T tmp;
  tmp = d->size[0];
  d->size[0] = (int32_T)fmax(from->size[0], 1.0);
  Automa_emxEnsureCapacity_real_T(d, tmp);
  autonomousDubinsDistanceCodegen_real64(&from->data[0], (uint32_T)from->size[0],
    to, 1U, this->TurningRadius, &d->data[0]);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkin_RRTTree_addEdge(f_matlabshared_planning_inter_T
  *this, real_T fromId, real_T toId)
{
  real_T edgeId;
  real_T cost;
  real_T b_cost;
  d_matlabshared_planning_inter_T *b_this;
  real_T from[3];
  real_T to[3];
  c_matlabshared_planning_inter_T *c_this;
  real_T turningRadius;
  int32_T fromId_0;
  int32_T edgeId_tmp;
  edgeId = this->EdgeIndex;
  edgeId_tmp = (int32_T)edgeId - 1;
  cost = rt_roundd_snf(fromId);
  if (cost < 4.294967296E+9) {
    if (cost >= 0.0) {
      this->EdgeBuffer[edgeId_tmp] = (uint32_T)cost;
    } else {
      this->EdgeBuffer[edgeId_tmp] = 0U;
    }
  } else {
    this->EdgeBuffer[edgeId_tmp] = MAX_uint32_T;
  }

  cost = rt_roundd_snf(toId);
  if (cost < 4.294967296E+9) {
    if (cost >= 0.0) {
      this->EdgeBuffer[edgeId_tmp + 10001] = (uint32_T)cost;
    } else {
      this->EdgeBuffer[edgeId_tmp + 10001] = 0U;
    }
  } else {
    this->EdgeBuffer[edgeId_tmp + 10001] = MAX_uint32_T;
  }

  if (fromId < 2.0) {
    cost = 0.0;
  } else {
    cost = this->CostBuffer[(int32_T)(fromId - 1.0) - 1];
  }

  b_this = this->NeighborSearcher;
  fromId_0 = (int32_T)fromId;
  from[0] = this->NodeBuffer[fromId_0 - 1];
  from[1] = this->NodeBuffer[fromId_0 + 10000];
  from[2] = this->NodeBuffer[fromId_0 + 20001];
  fromId_0 = (int32_T)toId;
  to[0] = this->NodeBuffer[fromId_0 - 1];
  to[1] = this->NodeBuffer[fromId_0 + 10000];
  to[2] = this->NodeBuffer[fromId_0 + 20001];
  c_this = b_this->ConnectionMechanism;
  turningRadius = c_this->TurningRadius;
  autonomousDubinsDistanceCodegen_real64(from, 1U, to, 1U, turningRadius,
    &b_cost);
  this->CostBuffer[edgeId_tmp] = cost + b_cost;
  this->EdgeIndex = edgeId + 1.0;
}

static void AutomatedParki_emxInit_uint32_T(emxArray_uint32_T_AutomatedPa_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_uint32_T_AutomatedPa_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_uint32_T_AutomatedPa_T *)malloc(sizeof
    (emxArray_uint32_T_AutomatedPa_T));
  emxArray = *pEmxArray;
  emxArray->data = (uint32_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

static void AutomatedParki_emxFree_uint32_T(emxArray_uint32_T_AutomatedPa_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_uint32_T_AutomatedPa_T *)NULL) {
    if (((*pEmxArray)->data != (uint32_T *)NULL) && (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_uint32_T_AutomatedPa_T *)NULL;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void Automate_RRTPlanner_interpolate(g_matlabshared_planning_inter_T
  *this, const real_T from[3], const real_T towards[3], real_T pose[3],
  boolean_T *inCollision)
{
  emxArray_real_T_AutomatedPark_T *posesInterp;
  emxArray_boolean_T_AutomatedP_T *b_free;
  c_matlabshared_planning_inter_T *b_this;
  boolean_T y;
  real_T connectionDistance;
  real_T numSteps;
  real_T turningRadius;
  int32_T posesInterp_0;
  uint32_T tmp;
  boolean_T exitg1;
  AutomatedParking_emxInit_real_T(&posesInterp, 2);
  AutomatedPark_emxInit_boolean_T(&b_free, 1);
  b_this = this->ConnectionMechanism;
  connectionDistance = b_this->ConnectionDistance;
  numSteps = b_this->NumSteps;
  turningRadius = b_this->TurningRadius;
  posesInterp_0 = posesInterp->size[0] * posesInterp->size[1];
  posesInterp->size[0] = (int32_T)(numSteps + 2.0);
  posesInterp->size[1] = 3;
  Automa_emxEnsureCapacity_real_T(posesInterp, posesInterp_0);
  numSteps = rt_roundd_snf(numSteps);
  if (numSteps < 4.294967296E+9) {
    if (numSteps >= 0.0) {
      tmp = (uint32_T)numSteps;
    } else {
      tmp = 0U;
    }
  } else {
    tmp = MAX_uint32_T;
  }

  autonomousDubinsInterpolateCodegen_real64(from, towards, connectionDistance,
    tmp, turningRadius, &posesInterp->data[0]);
  VehicleCostmapImpl_checkFreePos(this->Costmap, posesInterp, b_free);
  posesInterp_0 = posesInterp->size[0];
  pose[0] = posesInterp->data[posesInterp_0 - 1];
  pose[1] = posesInterp->data[(posesInterp_0 + posesInterp->size[0]) - 1];
  pose[2] = posesInterp->data[((posesInterp->size[0] << 1) + posesInterp_0) - 1];
  AutomatedParking_emxFree_real_T(&posesInterp);
  y = true;
  posesInterp_0 = 1;
  exitg1 = false;
  while ((!exitg1) && (posesInterp_0 <= b_free->size[0])) {
    if (!b_free->data[posesInterp_0 - 1]) {
      y = false;
      exitg1 = true;
    } else {
      posesInterp_0++;
    }
  }

  AutomatedPark_emxFree_boolean_T(&b_free);
  *inCollision = !y;
}

static void Auto_emxEnsureCapacity_uint32_T(emxArray_uint32_T_AutomatedPa_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(uint32_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(uint32_T) * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (uint32_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void Automated_RRTPlanner_rewireTree(g_matlabshared_planning_inter_T
  *this, const emxArray_real_T_AutomatedPark_T *nearPoses, const
  emxArray_real_T_AutomatedPark_T *nearIds, const real_T newPose[3], real_T
  newId)
{
  f_matlabshared_planning_inter_T *treeLocal;
  real_T thetaTol;
  real_T newCost;
  real_T maxDist;
  emxArray_real_T_AutomatedPark_T *forwardDistances;
  emxArray_real_T_AutomatedPark_T *reverseDistances;
  real_T nearPose[3];
  real_T nearCost;
  real_T finalPose[3];
  boolean_T inCollision;
  int32_T n;
  c_matlabshared_planning_inter_T *b_this;
  real_T b_cost;
  int32_T numEdges;
  emxArray_real_T_AutomatedPark_T *stack_d;
  int32_T stack_n;
  uint32_T parentId;
  uint32_T childId;
  emxArray_uint32_T_AutomatedPa_T *b;
  int32_T b_n;
  d_matlabshared_planning_inter_T *d_this;
  real_T c_turningRadius;
  real_T finalPose_0[2];
  int32_T newId_0;
  int32_T loop_ub;
  int32_T loop_ub_0;
  int32_T loop_ub_1;
  int32_T parentId_tmp;
  AutomatedParking_emxInit_real_T(&forwardDistances, 1);
  AutomatedParking_emxInit_real_T(&reverseDistances, 1);
  treeLocal = &this->Tree;
  thetaTol = this->GoalTolerance[2];
  if (newId < 2.0) {
    newCost = 0.0;
  } else {
    newCost = this->Tree.CostBuffer[(int32_T)(newId - 1.0) - 1];
  }

  maxDist = this->ConnectionMechanism->ConnectionDistance;
  b_this = this->ConnectionMechanism;
  nearCost = b_this->TurningRadius;
  newId_0 = forwardDistances->size[0];
  forwardDistances->size[0] = (int32_T)fmax(nearPoses->size[0], 1.0);
  Automa_emxEnsureCapacity_real_T(forwardDistances, newId_0);
  autonomousDubinsDistanceCodegen_real64(&nearPoses->data[0], (uint32_T)
    nearPoses->size[0], newPose, 1U, nearCost, &forwardDistances->data[0]);
  b_this = this->ConnectionMechanism;
  nearCost = b_this->TurningRadius;
  newId_0 = reverseDistances->size[0];
  reverseDistances->size[0] = (int32_T)fmax(1.0, nearPoses->size[0]);
  Automa_emxEnsureCapacity_real_T(reverseDistances, newId_0);
  autonomousDubinsDistanceCodegen_real64(newPose, 1U, &nearPoses->data[0],
    (uint32_T)nearPoses->size[0], nearCost, &reverseDistances->data[0]);
  n = 0;
  AutomatedParking_emxInit_real_T(&stack_d, 1);
  AutomatedParki_emxInit_uint32_T(&b, 2);
  while (n <= nearIds->size[0] - 1) {
    if (nearIds->data[n] < 2.0) {
      nearCost = 0.0;
    } else {
      nearCost = treeLocal->CostBuffer[(int32_T)(nearIds->data[n] - 1.0) - 1];
    }

    if ((newCost + reverseDistances->data[n] < nearCost) &&
        (forwardDistances->data[n] <= maxDist)) {
      nearPose[0] = nearPoses->data[n];
      nearPose[1] = nearPoses->data[n + nearPoses->size[0]];
      nearPose[2] = nearPoses->data[(nearPoses->size[0] << 1) + n];
      Automate_RRTPlanner_interpolate(this, newPose, nearPose, finalPose,
        &inCollision);
      if (!inCollision) {
        finalPose_0[0] = finalPose[0] - nearPoses->data[n];
        finalPose_0[1] = finalPose[1] - nearPoses->data[n + nearPoses->size[0]];
        if (norm_Sv0LdesD(finalPose_0) <= 0.5) {
          nearCost = (nearPoses->data[(nearPoses->size[0] << 1) + n] -
                      finalPose[2]) + 3.1415926535897931;
          angleUtilities_wrapTo2_bbViJ3IV(&nearCost);
          if (fabs(nearCost - 3.1415926535897931) <= thetaTol) {
            c_turningRadius = rt_roundd_snf(newId);
            if (c_turningRadius < 4.294967296E+9) {
              if (c_turningRadius >= 0.0) {
                treeLocal->EdgeBuffer[(int32_T)(nearIds->data[n] - 1.0) - 1] =
                  (uint32_T)c_turningRadius;
              } else {
                treeLocal->EdgeBuffer[(int32_T)(nearIds->data[n] - 1.0) - 1] =
                  0U;
              }
            } else {
              treeLocal->EdgeBuffer[(int32_T)(nearIds->data[n] - 1.0) - 1] =
                MAX_uint32_T;
            }

            if (newId < 2.0) {
              nearCost = 0.0;
            } else {
              nearCost = treeLocal->CostBuffer[(int32_T)(newId - 1.0) - 1];
            }

            d_this = treeLocal->NeighborSearcher;
            newId_0 = (int32_T)newId;
            nearPose[0] = treeLocal->NodeBuffer[newId_0 - 1];
            nearPose[1] = treeLocal->NodeBuffer[newId_0 + 10000];
            nearPose[2] = treeLocal->NodeBuffer[newId_0 + 20001];
            newId_0 = (int32_T)nearIds->data[n];
            finalPose[0] = treeLocal->NodeBuffer[newId_0 - 1];
            finalPose[1] = treeLocal->NodeBuffer[newId_0 + 10000];
            finalPose[2] = treeLocal->NodeBuffer[newId_0 + 20001];
            b_this = d_this->ConnectionMechanism;
            c_turningRadius = b_this->TurningRadius;
            autonomousDubinsDistanceCodegen_real64(nearPose, 1U, finalPose, 1U,
              c_turningRadius, &b_cost);
            treeLocal->CostBuffer[(int32_T)(nearIds->data[n] - 1.0) - 1] =
              nearCost + b_cost;
            nearCost = treeLocal->EdgeIndex - 1.0;
            if (1.0 > nearCost) {
              loop_ub = -1;
            } else {
              loop_ub = (int32_T)nearCost - 1;
            }

            newId_0 = b->size[0] * b->size[1];
            b->size[0] = loop_ub + 1;
            b->size[1] = 2;
            Auto_emxEnsureCapacity_uint32_T(b, newId_0);
            for (newId_0 = 0; newId_0 <= loop_ub; newId_0++) {
              b->data[newId_0] = treeLocal->EdgeBuffer[newId_0];
            }

            for (newId_0 = 0; newId_0 <= loop_ub; newId_0++) {
              b->data[newId_0 + b->size[0]] = treeLocal->EdgeBuffer[newId_0 +
                10001];
            }

            numEdges = b->size[0] - 1;
            stack_n = 0;
            stack_d->size[0] = 0;
            if (0 <= numEdges) {
              nearCost = treeLocal->EdgeIndex - 1.0;
              if (1.0 > nearCost) {
                loop_ub_0 = -1;
              } else {
                loop_ub_0 = (int32_T)nearCost - 1;
              }
            }

            for (b_n = 0; b_n <= numEdges; b_n++) {
              newId_0 = b->size[0] * b->size[1];
              b->size[0] = loop_ub_0 + 1;
              b->size[1] = 2;
              Auto_emxEnsureCapacity_uint32_T(b, newId_0);
              for (newId_0 = 0; newId_0 <= loop_ub_0; newId_0++) {
                b->data[newId_0] = treeLocal->EdgeBuffer[newId_0];
              }

              for (newId_0 = 0; newId_0 <= loop_ub_0; newId_0++) {
                b->data[newId_0 + b->size[0]] = treeLocal->EdgeBuffer[newId_0 +
                  10001];
              }

              if (b->data[b_n] == nearIds->data[n]) {
                if (stack_n == stack_d->size[0]) {
                  newId_0 = stack_d->size[0];
                  loop_ub = stack_d->size[0];
                  stack_d->size[0] = newId_0 + 1;
                  Automa_emxEnsureCapacity_real_T(stack_d, loop_ub);
                  stack_d->data[newId_0] = (real_T)b_n + 1.0;
                } else {
                  stack_d->data[stack_n] = (real_T)b_n + 1.0;
                }

                stack_n++;
              }
            }

            while (stack_n != 0) {
              nearCost = stack_d->data[stack_n - 1];
              stack_n--;
              c_turningRadius = treeLocal->EdgeIndex - 1.0;
              if (1.0 > c_turningRadius) {
                loop_ub = -1;
              } else {
                loop_ub = (int32_T)c_turningRadius - 1;
              }

              newId_0 = b->size[0] * b->size[1];
              b->size[0] = loop_ub + 1;
              b->size[1] = 2;
              Auto_emxEnsureCapacity_uint32_T(b, newId_0);
              for (newId_0 = 0; newId_0 <= loop_ub; newId_0++) {
                b->data[newId_0] = treeLocal->EdgeBuffer[newId_0];
              }

              for (newId_0 = 0; newId_0 <= loop_ub; newId_0++) {
                b->data[newId_0 + b->size[0]] = treeLocal->EdgeBuffer[newId_0 +
                  10001];
              }

              parentId_tmp = (int32_T)nearCost;
              b_n = parentId_tmp - 1;
              parentId = b->data[b_n];
              c_turningRadius = treeLocal->EdgeIndex - 1.0;
              if (1.0 > c_turningRadius) {
                loop_ub = -1;
              } else {
                loop_ub = (int32_T)c_turningRadius - 1;
              }

              newId_0 = b->size[0] * b->size[1];
              b->size[0] = loop_ub + 1;
              b->size[1] = 2;
              Auto_emxEnsureCapacity_uint32_T(b, newId_0);
              for (newId_0 = 0; newId_0 <= loop_ub; newId_0++) {
                b->data[newId_0] = treeLocal->EdgeBuffer[newId_0];
              }

              for (newId_0 = 0; newId_0 <= loop_ub; newId_0++) {
                b->data[newId_0 + b->size[0]] = treeLocal->EdgeBuffer[newId_0 +
                  10001];
              }

              childId = b->data[(parentId_tmp + b->size[0]) - 1];
              if (parentId < 2U) {
                c_turningRadius = 0.0;
              } else {
                c_turningRadius = treeLocal->CostBuffer[(int32_T)parentId - 2];
              }

              d_this = treeLocal->NeighborSearcher;
              newId_0 = (int32_T)parentId;
              nearPose[0] = treeLocal->NodeBuffer[newId_0 - 1];
              nearPose[1] = treeLocal->NodeBuffer[newId_0 + 10000];
              nearPose[2] = treeLocal->NodeBuffer[newId_0 + 20001];
              newId_0 = (int32_T)childId;
              finalPose[0] = treeLocal->NodeBuffer[newId_0 - 1];
              finalPose[1] = treeLocal->NodeBuffer[newId_0 + 10000];
              finalPose[2] = treeLocal->NodeBuffer[newId_0 + 20001];
              b_this = d_this->ConnectionMechanism;
              b_cost = b_this->TurningRadius;
              autonomousDubinsDistanceCodegen_real64(nearPose, 1U, finalPose, 1U,
                b_cost, &nearCost);
              treeLocal->CostBuffer[b_n] = c_turningRadius + nearCost;
              if (0 <= numEdges) {
                nearCost = treeLocal->EdgeIndex - 1.0;
                if (1.0 > nearCost) {
                  loop_ub_1 = -1;
                } else {
                  loop_ub_1 = (int32_T)nearCost - 1;
                }
              }

              for (b_n = 0; b_n <= numEdges; b_n++) {
                newId_0 = b->size[0] * b->size[1];
                b->size[0] = loop_ub_1 + 1;
                b->size[1] = 2;
                Auto_emxEnsureCapacity_uint32_T(b, newId_0);
                for (newId_0 = 0; newId_0 <= loop_ub_1; newId_0++) {
                  b->data[newId_0] = treeLocal->EdgeBuffer[newId_0];
                }

                for (newId_0 = 0; newId_0 <= loop_ub_1; newId_0++) {
                  b->data[newId_0 + b->size[0]] = treeLocal->EdgeBuffer[newId_0
                    + 10001];
                }

                if (b->data[b_n] == childId) {
                  if (stack_n == stack_d->size[0]) {
                    newId_0 = stack_d->size[0];
                    loop_ub = stack_d->size[0];
                    stack_d->size[0] = newId_0 + 1;
                    Automa_emxEnsureCapacity_real_T(stack_d, loop_ub);
                    stack_d->data[newId_0] = (real_T)b_n + 1.0;
                  } else {
                    stack_d->data[stack_n] = (real_T)b_n + 1.0;
                  }

                  stack_n++;
                }
              }
            }
          }
        }
      }
    }

    n++;
  }

  AutomatedParki_emxFree_uint32_T(&b);
  AutomatedParking_emxFree_real_T(&stack_d);
  AutomatedParking_emxFree_real_T(&reverseDistances);
  AutomatedParking_emxFree_real_T(&forwardDistances);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static boolean_T AutomatedParkingVal_ifWhileCond(const boolean_T x_data[], const
  int32_T *x_size)
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = (*x_size != 0);
  if (y) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k <= *x_size - 1)) {
      if (!x_data[0]) {
        y = false;
        exitg1 = true;
      } else {
        k = 1;
      }
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingVal_mergesort_c(int32_T idx_data[], const uint32_T
  x_data[], int32_T n)
{
  int32_T k;
  int32_T i;
  int32_T i2;
  int32_T j;
  int32_T pEnd;
  int32_T p;
  int32_T q;
  int32_T qEnd;
  int32_T kEnd;
  int32_T tmp;
  int32_T tmp_0;
  for (i = 1; i <= n - 1; i += 2) {
    if (x_data[i - 1] <= x_data[i]) {
      idx_data[i - 1] = i;
      idx_data[i] = i + 1;
    } else {
      idx_data[i - 1] = i + 1;
      idx_data[i] = i;
    }
  }

  if ((n & 1U) != 0U) {
    idx_data[n - 1] = n;
  }

  i = 2;
  while (i < n) {
    i2 = i << 1;
    j = 1;
    pEnd = i + 1;
    while (pEnd < n + 1) {
      p = j;
      q = pEnd;
      qEnd = j + i2;
      if (qEnd > n + 1) {
        qEnd = n + 1;
      }

      k = 0;
      kEnd = qEnd - j;
      while (k + 1 <= kEnd) {
        tmp = idx_data[q - 1];
        tmp_0 = idx_data[p - 1];
        if (x_data[tmp_0 - 1] <= x_data[tmp - 1]) {
          AutomatedParkingValet_B.iwork_data_k[k] = tmp_0;
          p++;
          if (p == pEnd) {
            while (q < qEnd) {
              k++;
              AutomatedParkingValet_B.iwork_data_k[k] = idx_data[q - 1];
              q++;
            }
          }
        } else {
          AutomatedParkingValet_B.iwork_data_k[k] = tmp;
          q++;
          if (q == qEnd) {
            while (p < pEnd) {
              k++;
              AutomatedParkingValet_B.iwork_data_k[k] = idx_data[p - 1];
              p++;
            }
          }
        }

        k++;
      }

      for (pEnd = -1; pEnd < kEnd - 1; pEnd++) {
        idx_data[j + pEnd] = AutomatedParkingValet_B.iwork_data_k[pEnd + 1];
      }

      j = qEnd;
      pEnd = qEnd + i;
    }

    i = i2;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static int32_T AutomatedParkin_nonSingletonDim(const int32_T *x_size)
{
  int32_T dim;
  dim = 2;
  if (*x_size != 1) {
    dim = 1;
  }

  return dim;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_merge(int32_T idx_data[], int32_T x_data[],
  int32_T offset, int32_T np, int32_T nq, int32_T iwork_data[], int32_T
  xwork_data[])
{
  int32_T n;
  int32_T q;
  int32_T iout;
  int32_T n_tmp;
  int32_T exitg1;
  if (nq != 0) {
    n_tmp = np + nq;
    for (q = 0; q < n_tmp; q++) {
      iout = offset + q;
      iwork_data[q] = idx_data[iout];
      xwork_data[q] = x_data[iout];
    }

    n = 0;
    q = np;
    iout = offset - 1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork_data[n] <= xwork_data[q]) {
        idx_data[iout] = iwork_data[n];
        x_data[iout] = xwork_data[n];
        if (n + 1 < np) {
          n++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx_data[iout] = iwork_data[q];
        x_data[iout] = xwork_data[q];
        if (q + 1 < n_tmp) {
          q++;
        } else {
          q = iout - n;
          while (n + 1 <= np) {
            iout = (q + n) + 1;
            idx_data[iout] = iwork_data[n];
            x_data[iout] = xwork_data[n];
            n++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingVal_merge_block(int32_T idx_data[], int32_T x_data[],
  int32_T offset, int32_T n, int32_T preSortLevel, int32_T iwork_data[], int32_T
  xwork_data[])
{
  int32_T bLen;
  int32_T tailOffset;
  int32_T nTail;
  int32_T nPairs;
  nPairs = n >> preSortLevel;
  bLen = 1 << preSortLevel;
  while (nPairs > 1) {
    if ((nPairs & 1U) != 0U) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        AutomatedParkingValet_merge(idx_data, x_data, offset + tailOffset, bLen,
          nTail - bLen, iwork_data, xwork_data);
      }
    }

    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 0; nTail < nPairs; nTail++) {
      AutomatedParkingValet_merge(idx_data, x_data, offset + nTail * tailOffset,
        bLen, bLen, iwork_data, xwork_data);
    }

    bLen = tailOffset;
  }

  if (n > bLen) {
    AutomatedParkingValet_merge(idx_data, x_data, offset, bLen, n - bLen,
      iwork_data, xwork_data);
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParki_merge_pow2_block(int32_T idx_data[], int32_T x_data[],
  int32_T offset)
{
  int32_T iwork[256];
  int32_T xwork[256];
  int32_T bLen;
  int32_T bLen2;
  int32_T nPairs;
  int32_T blockOffset;
  int32_T p;
  int32_T q;
  int32_T b;
  int32_T k;
  int32_T exitg1;
  for (b = 0; b < 6; b++) {
    bLen = 1 << (b + 2);
    bLen2 = bLen << 1;
    nPairs = 256 >> (b + 3);
    for (k = 0; k < nPairs; k++) {
      blockOffset = (k * bLen2 + offset) - 1;
      for (p = 0; p < bLen2; p++) {
        q = (blockOffset + p) + 1;
        iwork[p] = idx_data[q];
        xwork[p] = x_data[q];
      }

      p = 0;
      q = bLen;
      do {
        exitg1 = 0;
        blockOffset++;
        if (xwork[p] <= xwork[q]) {
          idx_data[blockOffset] = iwork[p];
          x_data[blockOffset] = xwork[p];
          if (p + 1 < bLen) {
            p++;
          } else {
            exitg1 = 1;
          }
        } else {
          idx_data[blockOffset] = iwork[q];
          x_data[blockOffset] = xwork[q];
          if (q + 1 < bLen2) {
            q++;
          } else {
            blockOffset -= p;
            while (p + 1 <= bLen) {
              q = (blockOffset + p) + 1;
              idx_data[q] = iwork[p];
              x_data[q] = xwork[p];
              p++;
            }

            exitg1 = 1;
          }
        }
      } while (exitg1 == 0);
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_sortIdx_j(int32_T x_data[], int32_T *x_size,
  int32_T idx_data[], int32_T *idx_size)
{
  int32_T x4[4];
  int16_T idx4[4];
  int8_T perm[4];
  int32_T nQuartets;
  int32_T i;
  int32_T nLeft;
  int32_T i1;
  int32_T i2;
  int32_T i3;
  int32_T i4;
  int32_T b_x_size;
  int16_T b_idx_0;
  int32_T tmp;
  int32_T tmp_0;
  b_idx_0 = (int16_T)*x_size;
  *idx_size = b_idx_0;
  if (0 <= b_idx_0 - 1) {
    memset(&idx_data[0], 0, b_idx_0 * sizeof(int32_T));
  }

  if (*x_size != 0) {
    b_x_size = *x_size;
    if (0 <= *x_size - 1) {
      memcpy(&AutomatedParkingValet_B.b_x_data[0], &x_data[0], *x_size * sizeof
             (int32_T));
    }

    x4[0] = 0;
    idx4[0] = 0;
    x4[1] = 0;
    idx4[1] = 0;
    x4[2] = 0;
    idx4[2] = 0;
    x4[3] = 0;
    idx4[3] = 0;
    nQuartets = *x_size >> 2;
    for (nLeft = 0; nLeft < nQuartets; nLeft++) {
      i = nLeft << 2;
      idx4[0] = (int16_T)(i + 1);
      idx4[1] = (int16_T)(i + 2);
      idx4[2] = (int16_T)(i + 3);
      idx4[3] = (int16_T)(i + 4);
      x4[0] = AutomatedParkingValet_B.b_x_data[i];
      x4[1] = AutomatedParkingValet_B.b_x_data[i + 1];
      x4[2] = AutomatedParkingValet_B.b_x_data[i + 2];
      x4[3] = AutomatedParkingValet_B.b_x_data[i + 3];
      if (AutomatedParkingValet_B.b_x_data[i] <=
          AutomatedParkingValet_B.b_x_data[i + 1]) {
        i1 = 1;
        i2 = 2;
      } else {
        i1 = 2;
        i2 = 1;
      }

      if (AutomatedParkingValet_B.b_x_data[i + 2] <=
          AutomatedParkingValet_B.b_x_data[i + 3]) {
        i3 = 3;
        i4 = 4;
      } else {
        i3 = 4;
        i4 = 3;
      }

      tmp = x4[i1 - 1];
      tmp_0 = x4[i3 - 1];
      if (tmp <= tmp_0) {
        tmp = x4[i2 - 1];
        if (tmp <= tmp_0) {
          perm[0] = (int8_T)i1;
          perm[1] = (int8_T)i2;
          perm[2] = (int8_T)i3;
          perm[3] = (int8_T)i4;
        } else if (tmp <= x4[i4 - 1]) {
          perm[0] = (int8_T)i1;
          perm[1] = (int8_T)i3;
          perm[2] = (int8_T)i2;
          perm[3] = (int8_T)i4;
        } else {
          perm[0] = (int8_T)i1;
          perm[1] = (int8_T)i3;
          perm[2] = (int8_T)i4;
          perm[3] = (int8_T)i2;
        }
      } else {
        tmp_0 = x4[i4 - 1];
        if (tmp <= tmp_0) {
          if (x4[i2 - 1] <= tmp_0) {
            perm[0] = (int8_T)i3;
            perm[1] = (int8_T)i1;
            perm[2] = (int8_T)i2;
            perm[3] = (int8_T)i4;
          } else {
            perm[0] = (int8_T)i3;
            perm[1] = (int8_T)i1;
            perm[2] = (int8_T)i4;
            perm[3] = (int8_T)i2;
          }
        } else {
          perm[0] = (int8_T)i3;
          perm[1] = (int8_T)i4;
          perm[2] = (int8_T)i1;
          perm[3] = (int8_T)i2;
        }
      }

      i1 = perm[0] - 1;
      idx_data[i] = idx4[i1];
      i2 = perm[1] - 1;
      idx_data[i + 1] = idx4[i2];
      i3 = perm[2] - 1;
      idx_data[i + 2] = idx4[i3];
      i4 = perm[3] - 1;
      idx_data[i + 3] = idx4[i4];
      AutomatedParkingValet_B.b_x_data[i] = x4[i1];
      AutomatedParkingValet_B.b_x_data[i + 1] = x4[i2];
      AutomatedParkingValet_B.b_x_data[i + 2] = x4[i3];
      AutomatedParkingValet_B.b_x_data[i + 3] = x4[i4];
    }

    nQuartets <<= 2;
    nLeft = *x_size - nQuartets;
    if (nLeft > 0) {
      for (i = 0; i < nLeft; i++) {
        i1 = nQuartets + i;
        idx4[i] = (int16_T)(i1 + 1);
        x4[i] = AutomatedParkingValet_B.b_x_data[i1];
      }

      perm[1] = 0;
      perm[2] = 0;
      perm[3] = 0;
      if (nLeft == 1) {
        perm[0] = 1;
      } else if (nLeft == 2) {
        if (x4[0] <= x4[1]) {
          perm[0] = 1;
          perm[1] = 2;
        } else {
          perm[0] = 2;
          perm[1] = 1;
        }
      } else if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }

      for (i = 0; i < nLeft; i++) {
        i1 = perm[i] - 1;
        i2 = nQuartets + i;
        idx_data[i2] = idx4[i1];
        AutomatedParkingValet_B.b_x_data[i2] = x4[i1];
      }
    }

    if (0 <= b_idx_0 - 1) {
      memset(&AutomatedParkingValet_B.iwork_data_c[0], 0, b_idx_0 * sizeof
             (int32_T));
    }

    nQuartets = (int16_T)*x_size;
    if (0 <= nQuartets - 1) {
      memset(&AutomatedParkingValet_B.xwork_data[0], 0, nQuartets * sizeof
             (int32_T));
    }

    nLeft = 2;
    if (*x_size > 1) {
      if (*x_size >= 256) {
        nQuartets = *x_size >> 8;
        if (nQuartets > 0) {
          for (nLeft = 0; nLeft < nQuartets; nLeft++) {
            AutomatedParki_merge_pow2_block(idx_data,
              AutomatedParkingValet_B.b_x_data, nLeft << 8);
          }

          nQuartets <<= 8;
          nLeft = *x_size - nQuartets;
          if (nLeft > 0) {
            AutomatedParkingVal_merge_block(idx_data,
              AutomatedParkingValet_B.b_x_data, nQuartets, nLeft, 2,
              AutomatedParkingValet_B.iwork_data_c,
              AutomatedParkingValet_B.xwork_data);
          }

          nLeft = 8;
        }
      }

      AutomatedParkingVal_merge_block(idx_data, AutomatedParkingValet_B.b_x_data,
        0, *x_size, nLeft, AutomatedParkingValet_B.iwork_data_c,
        AutomatedParkingValet_B.xwork_data);
    }

    if (0 <= b_x_size - 1) {
      memcpy(&x_data[0], &AutomatedParkingValet_B.b_x_data[0], b_x_size * sizeof
             (int32_T));
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingValet_sort(int32_T x_data[], const int32_T *x_size,
  int32_T idx_data[], int32_T *idx_size)
{
  int32_T dim;
  int32_T vstride;
  int32_T b;
  int32_T c_k;
  int32_T vwork_size;
  int32_T tmp;
  dim = AutomatedParkin_nonSingletonDim(x_size);
  if (dim <= 1) {
    b = *x_size - 1;
  } else {
    b = 0;
  }

  vwork_size = b + 1;
  *idx_size = *x_size;
  vstride = 1;
  for (c_k = 0; c_k <= dim - 2; c_k++) {
    vstride *= *x_size;
  }

  for (dim = 0; dim < vstride; dim++) {
    for (c_k = 0; c_k <= b; c_k++) {
      AutomatedParkingValet_B.vwork_data[c_k] = x_data[c_k * vstride + dim];
    }

    AutomatedParkingValet_sortIdx_j(AutomatedParkingValet_B.vwork_data,
      &vwork_size, AutomatedParkingValet_B.iidx_data, &c_k);
    for (c_k = 0; c_k <= b; c_k++) {
      tmp = dim + c_k * vstride;
      x_data[tmp] = AutomatedParkingValet_B.vwork_data[c_k];
      idx_data[tmp] = AutomatedParkingValet_B.iidx_data[c_k];
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParkingVale_do_vectors(const uint32_T a_data[], const
  int32_T a_size[2], const emxArray_real_T_AutomatedPark_T *b, uint32_T c_data[],
  int32_T c_size[2], int32_T ia_data[], int32_T *ia_size, int32_T ib_data[],
  int32_T *ib_size)
{
  int32_T ncmax;
  emxArray_int32_T_AutomatedPar_T *bperm;
  int32_T k;
  uint32_T ak;
  real_T bk;
  int32_T b_k;
  int32_T n;
  emxArray_int32_T_AutomatedPar_T *iwork;
  int32_T c_k;
  int32_T i;
  int32_T i2;
  int32_T j;
  int32_T pEnd;
  int32_T b_p;
  int32_T q;
  int32_T qEnd;
  int32_T kEnd;
  real_T absx;
  boolean_T exitg1;
  ncmax = b->size[1];
  if (a_size[1] < ncmax) {
    ncmax = a_size[1];
  }

  c_size[0] = 1;
  c_size[1] = ncmax;
  *ia_size = ncmax;
  i2 = a_size[1] - 1;
  if (0 <= i2) {
    memset(&AutomatedParkingValet_B.aperm_data[0], 0, (i2 + 1) * sizeof(int32_T));
  }

  if (a_size[1] != 0) {
    AutomatedParkingVal_mergesort_c(AutomatedParkingValet_B.aperm_data, a_data,
      a_size[1]);
  }

  AutomatedParkin_emxInit_int32_T(&bperm, 2);
  n = b->size[1] + 1;
  i = bperm->size[0] * bperm->size[1];
  bperm->size[0] = 1;
  bperm->size[1] = b->size[1];
  Autom_emxEnsureCapacity_int32_T(bperm, i);
  i2 = b->size[1] - 1;
  for (i = 0; i <= i2; i++) {
    bperm->data[i] = 0;
  }

  if (b->size[1] != 0) {
    AutomatedParkin_emxInit_int32_T(&iwork, 1);
    i = iwork->size[0];
    iwork->size[0] = b->size[1];
    Autom_emxEnsureCapacity_int32_T(iwork, i);
    for (i = 1; i <= n - 2; i += 2) {
      if ((b->data[i - 1] <= b->data[i]) || rtIsNaN(b->data[i])) {
        bperm->data[i - 1] = i;
        bperm->data[i] = i + 1;
      } else {
        bperm->data[i - 1] = i + 1;
        bperm->data[i] = i;
      }
    }

    if ((b->size[1] & 1U) != 0U) {
      bperm->data[b->size[1] - 1] = b->size[1];
    }

    i = 2;
    while (i < n - 1) {
      i2 = i << 1;
      j = 1;
      pEnd = i + 1;
      while (pEnd < n) {
        b_p = j;
        q = pEnd - 1;
        qEnd = j + i2;
        if (qEnd > n) {
          qEnd = n;
        }

        c_k = 0;
        kEnd = qEnd - j;
        while (c_k + 1 <= kEnd) {
          if ((b->data[bperm->data[b_p - 1] - 1] <= b->data[bperm->data[q] - 1])
              || rtIsNaN(b->data[bperm->data[q] - 1])) {
            iwork->data[c_k] = bperm->data[b_p - 1];
            b_p++;
            if (b_p == pEnd) {
              while (q + 1 < qEnd) {
                c_k++;
                iwork->data[c_k] = bperm->data[q];
                q++;
              }
            }
          } else {
            iwork->data[c_k] = bperm->data[q];
            q++;
            if (q + 1 == qEnd) {
              while (b_p < pEnd) {
                c_k++;
                iwork->data[c_k] = bperm->data[b_p - 1];
                b_p++;
              }
            }
          }

          c_k++;
        }

        for (pEnd = -1; pEnd < kEnd - 1; pEnd++) {
          bperm->data[j + pEnd] = iwork->data[pEnd + 1];
        }

        j = qEnd;
        pEnd = qEnd + i;
      }

      i = i2;
    }

    AutomatedParkin_emxFree_int32_T(&iwork);
  }

  n = 0;
  i = 0;
  i2 = 1;
  j = 0;
  qEnd = 1;
  while ((i2 <= a_size[1]) && (qEnd <= b->size[1])) {
    c_k = i2;
    ak = a_data[AutomatedParkingValet_B.aperm_data[i2 - 1] - 1];
    while ((c_k < a_size[1]) && (a_data[AutomatedParkingValet_B.aperm_data[c_k]
            - 1] == ak)) {
      c_k++;
    }

    i2 = c_k;
    kEnd = qEnd;
    bk = b->data[bperm->data[qEnd - 1] - 1];
    exitg1 = false;
    while ((!exitg1) && (kEnd < b->size[1])) {
      absx = fabs(bk / 2.0);
      if ((!rtIsInf(absx)) && (!rtIsNaN(absx))) {
        if (absx <= 2.2250738585072014E-308) {
          absx = 4.94065645841247E-324;
        } else {
          frexp(absx, &b_k);
          absx = ldexp(1.0, b_k - 53);
        }
      } else {
        absx = (rtNaN);
      }

      if ((fabs(bk - b->data[bperm->data[kEnd] - 1]) < absx) || (rtIsInf(b->
            data[bperm->data[kEnd] - 1]) && rtIsInf(bk) && ((b->data[bperm->
             data[kEnd] - 1] > 0.0) == (bk > 0.0)))) {
        kEnd++;
      } else {
        exitg1 = true;
      }
    }

    qEnd = kEnd;
    absx = fabs(bk / 2.0);
    if ((!rtIsInf(absx)) && (!rtIsNaN(absx))) {
      if (absx <= 2.2250738585072014E-308) {
        absx = 4.94065645841247E-324;
      } else {
        frexp(absx, &k);
        absx = ldexp(1.0, k - 53);
      }
    } else {
      absx = (rtNaN);
    }

    if (fabs(bk - (real_T)ak) < absx) {
      n++;
      ia_data[n - 1] = AutomatedParkingValet_B.aperm_data[i];
      ib_data[n - 1] = bperm->data[j];
      i2 = c_k + 1;
      i = c_k;
      qEnd = kEnd + 1;
      j = kEnd;
    } else if (rtIsNaN(bk) || (ak < bk)) {
      i2 = c_k + 1;
      i = c_k;
    } else {
      qEnd = kEnd + 1;
      j = kEnd;
    }
  }

  AutomatedParkin_emxFree_int32_T(&bperm);
  if (ncmax > 0) {
    if (1 > n) {
      *ia_size = 0;
    } else {
      *ia_size = n;
    }
  }

  AutomatedParkingValet_sort(ia_data, ia_size,
    AutomatedParkingValet_B.aperm_data, &i2);
  for (b_k = 0; b_k < n; b_k++) {
    c_data[b_k] = a_data[ia_data[b_k] - 1];
  }

  for (i = 0; i < i2; i++) {
    AutomatedParkingValet_B.ib_data_c[i] =
      ib_data[AutomatedParkingValet_B.aperm_data[i] - 1];
  }

  *ib_size = i2;
  if (0 <= i2 - 1) {
    memcpy(&ib_data[0], &AutomatedParkingValet_B.ib_data_c[0], i2 * sizeof
           (int32_T));
  }

  if (ncmax > 0) {
    if (1 > n) {
      c_size[1] = 0;
    } else {
      c_size[1] = n;
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedParki_RRTTree_costTo_g(const
  f_matlabshared_planning_inter_T *this, const real_T id_data[], const int32_T
  id_size[2], real_T cost_data[], int32_T cost_size[2])
{
  boolean_T y;
  boolean_T x_data;
  int32_T k;
  int32_T loop_ub_tmp;
  int32_T loop_ub_tmp_0;
  boolean_T exitg1;
  loop_ub_tmp = id_size[0] * id_size[1];
  loop_ub_tmp_0 = loop_ub_tmp - 1;
  for (k = 0; k <= loop_ub_tmp_0; k++) {
    x_data = (id_data[k] < 2.0);
  }

  y = ((id_size[0] != 0) && (id_size[1] != 0));
  if (y) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k <= loop_ub_tmp - 1)) {
      if (!x_data) {
        y = false;
        exitg1 = true;
      } else {
        k = 1;
      }
    }
  }

  if (y) {
    cost_size[0] = 1;
    cost_size[1] = 1;
    cost_data[0] = 0.0;
  } else {
    cost_size[0] = id_size[0];
    cost_size[1] = id_size[1];
    for (k = 0; k <= loop_ub_tmp_0; k++) {
      cost_data[k] = this->CostBuffer[(int32_T)(id_data[k] - 1.0) - 1];
    }
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedPa_RRTPlanner_planPath(g_matlabshared_planning_inter_T
  *this, const real_T startPose[3], const real_T goalPose[3],
  emxArray_real_T_AutomatedPark_T *varargout_1)
{
  emxArray_real_T_AutomatedPark_T *goalNodes;
  real_T bestGoalNode_data;
  real_T bestCost;
  real_T randPose_data[9];
  emxArray_real_T_AutomatedPark_T *b;
  real_T id;
  real_T edgeId_data;
  uint32_T parentId_data;
  emxArray_real_T_AutomatedPark_T *posesInterp;
  emxArray_boolean_T_AutomatedP_T *b_free;
  real_T numNodes;
  emxArray_real_T_AutomatedPark_T *nearNodes;
  emxArray_real_T_AutomatedPark_T *nearIds;
  f_matlabshared_planning_inter_T *treeLocal;
  real_T minCost;
  real_T minCostId;
  real_T maxDist;
  emxArray_real_T_AutomatedPark_T *distances;
  real_T nearCost;
  real_T b_goalPose[3];
  real_T goalTol[3];
  d_matlabshared_planning_inter_T *b_this;
  e_matlabshared_planning_inter_T *c_this;
  boolean_T collisionFree;
  uint32_T b_varargin_1_data;
  c_matlabshared_planning_inter_T *d_this;
  int32_T ix;
  boolean_T i;
  int32_T nx;
  int32_T i_0;
  boolean_T parentId_data_0;
  real_T posesInterp_0[3];
  int32_T numNodes_0;
  int32_T bestGoalNode_size[2];
  int32_T randPose_size[2];
  int32_T b_path_size[2];
  emxArray_real_T_1x1_Automated_T this_0;
  uint32_T qY;
  int32_T b_path_size_tmp;
  boolean_T exitg1;
  boolean_T exitg2;
  int32_T exitg3;
  this->StartPose[0] = startPose[0];
  this->StartPose[1] = startPose[1];
  this->StartPose[2] = startPose[2];
  this->GoalPose[0] = goalPose[0];
  this->GoalPose[1] = goalPose[1];
  this->GoalPose[2] = goalPose[2];
  this->Tree.NodeIndex = 1.0;
  this->Tree.EdgeIndex = 1.0;
  b_this = this->Tree.NeighborSearcher;
  b_this->Offset = 0.0;
  UniformPoseSampler_fillPoseBuff(&this->Sampler);
  AutomatedParkingValet_rand_n(AutomatedParkingValet_B.r_p);
  for (i_0 = 0; i_0 < 5000; i_0++) {
    this->Sampler.GoalBiasBuffer[i_0] = AutomatedParkingValet_B.r_p[i_0];
  }

  this->Sampler.GoalBiasIndex = 1.0;
  varargout_1->size[0] = 0;
  varargout_1->size[1] = 3;
  AutomatedParking_emxInit_real_T(&goalNodes, 2);
  goalNodes->size[0] = 1;
  goalNodes->size[1] = 0;
  bestGoalNode_size[0] = 0;
  bestGoalNode_size[1] = 0;
  bestCost = (rtInf);
  UniformPoseSampler_checkForColl(&this->Sampler);
  for (i_0 = 0; i_0 < 5000; i_0++) {
    AutomatedParkingValet_B.x[i_0] = this->Sampler.CollisionFree[i_0];
  }

  collisionFree = false;
  nx = 0;
  exitg1 = false;
  while ((!exitg1) && (nx < 5000)) {
    if (!AutomatedParkingValet_B.x[nx]) {
      nx++;
    } else {
      collisionFree = true;
      exitg1 = true;
    }
  }

  if (!collisionFree) {
    UniformPoseSampler_attemptResam(&this->Sampler);
  }

  id = this->Tree.NodeIndex;
  i_0 = (int32_T)id;
  this->Tree.NodeBuffer[i_0 - 1] = startPose[0];
  this->Tree.NodeBuffer[i_0 + 10000] = startPose[1];
  this->Tree.NodeBuffer[i_0 + 20001] = startPose[2];
  this->Tree.NodeIndex = id + 1.0;
  id = this->MaxIterations;
  nx = 0;
  AutomatedParking_emxInit_real_T(&posesInterp, 2);
  AutomatedPark_emxInit_boolean_T(&b_free, 1);
  AutomatedParking_emxInit_real_T(&nearNodes, 2);
  AutomatedParking_emxInit_real_T(&nearIds, 1);
  AutomatedParking_emxInit_real_T(&distances, 1);
  exitg1 = false;
  while ((!exitg1) && (nx <= (int32_T)id - 1)) {
    minCostId = this->Sampler.GoalBiasBuffer[(int32_T)
      this->Sampler.GoalBiasIndex - 1];
    this->Sampler.GoalBiasIndex++;
    if (this->Sampler.GoalBiasIndex > 5000.0) {
      AutomatedParkingValet_rand_n(AutomatedParkingValet_B.r_p);
      for (i_0 = 0; i_0 < 5000; i_0++) {
        this->Sampler.GoalBiasBuffer[i_0] = AutomatedParkingValet_B.r_p[i_0];
      }

      this->Sampler.GoalBiasIndex = 1.0;
    }

    if (minCostId > this->GoalBias) {
      c_this = &this->Sampler;
      randPose_size[0] = 3;
      randPose_size[1] = 1;
      randPose_data[0] = (rtNaN);
      randPose_data[1] = (rtNaN);
      randPose_data[2] = (rtNaN);
      collisionFree = false;
      while (!collisionFree) {
        collisionFree = c_this->CollisionFree[(int32_T)c_this->PoseIndex - 1];
        if (collisionFree) {
          i_0 = (int32_T)c_this->PoseIndex;
          randPose_size[0] = 1;
          randPose_size[1] = 3;
          i_0 = (i_0 - 1) * 3;
          randPose_data[0] = c_this->PoseBuffer[i_0];
          randPose_data[1] = c_this->PoseBuffer[i_0 + 1];
          randPose_data[2] = c_this->PoseBuffer[i_0 + 2];
        } else {
          randPose_size[0] = 3;
          randPose_size[1] = 1;
          randPose_data[0] = (rtNaN);
          randPose_data[1] = (rtNaN);
          randPose_data[2] = (rtNaN);
        }

        c_this->PoseIndex++;
        if (c_this->PoseIndex > 5000.0) {
          UniformPoseSampler_fillPoseBuff(c_this);
          for (i_0 = 0; i_0 < 5000; i_0++) {
            AutomatedParkingValet_B.x[i_0] = c_this->CollisionFree[i_0];
          }

          i = false;
          ix = 0;
          exitg2 = false;
          while ((!exitg2) && (ix < 5000)) {
            if (!AutomatedParkingValet_B.x[ix]) {
              ix++;
            } else {
              i = true;
              exitg2 = true;
            }
          }

          if (!i) {
            UniformPoseSampler_attemptResam(c_this);
          }
        }
      }
    } else {
      randPose_size[0] = 1;
      randPose_size[1] = 3;
      randPose_data[0] = this->GoalPose[0];
      randPose_data[1] = this->GoalPose[1];
      randPose_data[2] = this->GoalPose[2];
    }

    AutomatedParkin_RRTTree_nearest(&this->Tree, randPose_data, randPose_size,
      b_goalPose, &minCostId);
    d_this = this->ConnectionMechanism;
    numNodes = d_this->ConnectionDistance;
    minCost = d_this->NumSteps;
    maxDist = d_this->TurningRadius;
    i_0 = posesInterp->size[0] * posesInterp->size[1];
    posesInterp->size[0] = (int32_T)(minCost + 2.0);
    posesInterp->size[1] = 3;
    Automa_emxEnsureCapacity_real_T(posesInterp, i_0);
    minCost = rt_roundd_snf(minCost);
    if (minCost < 4.294967296E+9) {
      if (minCost >= 0.0) {
        qY = (uint32_T)minCost;
      } else {
        qY = 0U;
      }
    } else {
      qY = MAX_uint32_T;
    }

    autonomousDubinsInterpolateCodegen_real64(b_goalPose, &randPose_data[0],
      numNodes, qY, maxDist, &posesInterp->data[0]);
    VehicleCostmapImpl_checkFreePos(this->Costmap, posesInterp, b_free);
    i_0 = posesInterp->size[0];
    goalTol[0] = posesInterp->data[i_0 - 1];
    goalTol[1] = posesInterp->data[(i_0 + posesInterp->size[0]) - 1];
    goalTol[2] = posesInterp->data[((posesInterp->size[0] << 1) + i_0) - 1];
    collisionFree = true;
    ix = 1;
    exitg2 = false;
    while ((!exitg2) && (ix <= b_free->size[0])) {
      if (!b_free->data[ix - 1]) {
        collisionFree = false;
        exitg2 = true;
      } else {
        ix++;
      }
    }

    if (!collisionFree) {
      nx++;
    } else {
      numNodes = this->Tree.NodeIndex - 1.0;
      i_0 = posesInterp->size[0];
      posesInterp_0[0] = posesInterp->data[i_0 - 1];
      posesInterp_0[1] = posesInterp->data[(i_0 + posesInterp->size[0]) - 1];
      posesInterp_0[2] = posesInterp->data[((posesInterp->size[0] << 1) + i_0) -
        1];
      memcpy(&AutomatedParkingValet_B.this[0], &this->Tree.NodeBuffer[0], 30003U
             * sizeof(real_T));
      SqrtApproxNeighborSearcher_near(this->Tree.NeighborSearcher,
        AutomatedParkingValet_B.this, this->Tree.NodeIndex - 1.0, posesInterp_0,
        ceil(32.61938194150855 * log(numNodes + 1.0)), nearNodes, nearIds);
      numNodes = this->Tree.NodeIndex;
      i_0 = posesInterp->size[0];
      numNodes_0 = (int32_T)numNodes;
      this->Tree.NodeBuffer[numNodes_0 - 1] = posesInterp->data[i_0 - 1];
      this->Tree.NodeBuffer[numNodes_0 + 10000] = posesInterp->data[(i_0 +
        posesInterp->size[0]) - 1];
      this->Tree.NodeBuffer[numNodes_0 + 20001] = posesInterp->data
        [((posesInterp->size[0] << 1) + i_0) - 1];
      this->Tree.NodeIndex = numNodes + 1.0;
      treeLocal = &this->Tree;
      d_this = this->ConnectionMechanism;
      minCost = d_this->TurningRadius;
      autonomousDubinsDistanceCodegen_real64(b_goalPose, 1U, goalTol, 1U,
        minCost, &maxDist);
      minCost = AutomatedParking_RRTTree_costTo(&this->Tree, minCostId) +
        maxDist;
      maxDist = this->ConnectionMechanism->ConnectionDistance;
      i_0 = posesInterp->size[0];
      posesInterp_0[0] = posesInterp->data[i_0 - 1];
      posesInterp_0[1] = posesInterp->data[(i_0 + posesInterp->size[0]) - 1];
      posesInterp_0[2] = posesInterp->data[((posesInterp->size[0] << 1) + i_0) -
        1];
      DubinsConnectionMechanism_dista(this->ConnectionMechanism, nearNodes,
        posesInterp_0, distances);
      for (ix = 0; ix < nearIds->size[0]; ix++) {
        nearCost = AutomatedParking_RRTTree_costTo(treeLocal, nearIds->data[ix])
          + distances->data[ix];
        if ((nearCost < minCost) && (distances->data[ix] <= maxDist)) {
          posesInterp_0[0] = nearNodes->data[ix];
          posesInterp_0[1] = nearNodes->data[ix + nearNodes->size[0]];
          posesInterp_0[2] = nearNodes->data[(nearNodes->size[0] << 1) + ix];
          Automate_RRTPlanner_interpolate(this, posesInterp_0, goalTol,
            b_goalPose, &collisionFree);
          if (!collisionFree) {
            minCost = nearCost;
            minCostId = nearIds->data[ix];
          }
        }
      }

      AutomatedParkin_RRTTree_addEdge(treeLocal, minCostId, numNodes);
      i_0 = posesInterp->size[0];
      posesInterp_0[0] = posesInterp->data[i_0 - 1];
      posesInterp_0[1] = posesInterp->data[(i_0 + posesInterp->size[0]) - 1];
      posesInterp_0[2] = posesInterp->data[((posesInterp->size[0] << 1) + i_0) -
        1];
      Automated_RRTPlanner_rewireTree(this, nearNodes, nearIds, posesInterp_0,
        numNodes);
      b_goalPose[0] = this->GoalPose[0];
      b_goalPose[1] = this->GoalPose[1];
      b_goalPose[2] = this->GoalPose[2];
      goalTol[0] = this->GoalTolerance[0];
      goalTol[1] = this->GoalTolerance[1];
      goalTol[2] = this->GoalTolerance[2];
      i_0 = posesInterp->size[0];
      if (fabs(posesInterp->data[i_0 - 1] - b_goalPose[0]) <= goalTol[0]) {
        i_0 = posesInterp->size[0];
        if (fabs(posesInterp->data[(i_0 + posesInterp->size[0]) - 1] -
                 b_goalPose[1]) <= goalTol[1]) {
          i_0 = posesInterp->size[0];
          minCostId = (b_goalPose[2] - posesInterp->data[((posesInterp->size[0] <<
            1) + i_0) - 1]) + 3.1415926535897931;
          angleUtilities_wrapTo2_bbViJ3IV(&minCostId);
          if (fabs(minCostId - 3.1415926535897931) <= goalTol[2]) {
            ix = goalNodes->size[1];
            i_0 = goalNodes->size[0] * goalNodes->size[1];
            goalNodes->size[1] = ix + 1;
            Automa_emxEnsureCapacity_real_T(goalNodes, i_0);
            goalNodes->data[ix] = numNodes;
            if (numNodes < 2.0) {
              minCostId = 0.0;
            } else {
              minCostId = this->Tree.CostBuffer[(int32_T)(numNodes - 1.0) - 1];
            }

            if (minCostId < bestCost) {
              bestGoalNode_size[0] = 1;
              bestGoalNode_size[1] = 1;
              bestGoalNode_data = numNodes;
              bestCost = minCostId;
            }

            collisionFree = ((real_T)nx + 1.0 >= this->MinIterations);
            if (collisionFree) {
              exitg1 = true;
            } else {
              nx++;
            }
          } else {
            nx++;
          }
        } else {
          nx++;
        }
      } else {
        nx++;
      }
    }
  }

  AutomatedParking_emxFree_real_T(&distances);
  AutomatedParking_emxFree_real_T(&nearIds);
  AutomatedParking_emxFree_real_T(&nearNodes);
  AutomatedPark_emxFree_boolean_T(&b_free);
  AutomatedParking_emxFree_real_T(&posesInterp);
  if (goalNodes->size[1] != 0) {
    if (0 <= bestGoalNode_size[0] * bestGoalNode_size[1] - 1) {
      edgeId_data = bestGoalNode_data - 1.0;
    }

    nx = (int8_T)bestGoalNode_size[0] * (int8_T)bestGoalNode_size[1];
    if (0 <= nx - 1) {
      edgeId_data = fmax(edgeId_data, 1.0);
    }

    if (0 <= nx - 1) {
      parentId_data = this->Tree.EdgeBuffer[(int32_T)edgeId_data - 1];
    }

    if (0 <= nx - 1) {
      b_varargin_1_data = this->Tree.EdgeBuffer[(int32_T)edgeId_data + 10000];
    }

    numNodes_0 = 2;
    if (0 <= nx - 1) {
      AutomatedParkingValet_B.path_data[0] = b_varargin_1_data;
      AutomatedParkingValet_B.path_data[nx] = parentId_data;
    }

    do {
      exitg3 = 0;
      if (0 <= nx - 1) {
        parentId_data_0 = (parentId_data != 1U);
      }

      if (AutomatedParkingVal_ifWhileCond(&parentId_data_0, &nx)) {
        for (i_0 = 0; i_0 < nx; i_0++) {
          qY = parentId_data - 1U;
          if (qY > parentId_data) {
            qY = 0U;
          }

          parentId_data = this->Tree.EdgeBuffer[(int32_T)qY - 1];
        }

        if (numNodes_0 == 0) {
          numNodes_0 = 0;
        }

        i_0 = (nx != 0);
        ix = numNodes_0 + i_0;
        if (0 <= numNodes_0 - 1) {
          memcpy(&AutomatedParkingValet_B.path_data_m[0],
                 &AutomatedParkingValet_B.path_data[0], numNodes_0 * sizeof
                 (uint32_T));
        }

        if (0 <= i_0 - 1) {
          AutomatedParkingValet_B.path_data_m[numNodes_0] = parentId_data;
        }

        numNodes_0 = ix;
        if (0 <= ix - 1) {
          memcpy(&AutomatedParkingValet_B.path_data[0],
                 &AutomatedParkingValet_B.path_data_m[0], ix * sizeof(uint32_T));
        }
      } else {
        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (1 > numNodes_0) {
      nx = 0;
      ix = 1;
      i_0 = -1;
    } else {
      nx = numNodes_0 - 1;
      ix = -1;
      i_0 = 0;
    }

    b_path_size[0] = 1;
    b_path_size_tmp = div_s32_floor(i_0 - nx, ix);
    numNodes_0 = b_path_size_tmp + 1;
    b_path_size[1] = numNodes_0;
    for (i_0 = 0; i_0 <= b_path_size_tmp; i_0++) {
      AutomatedParkingValet_B.b_path_data[i_0] =
        AutomatedParkingValet_B.path_data[ix * i_0 + nx];
    }

    for (i_0 = 0; i_0 <= b_path_size_tmp; i_0++) {
      AutomatedParkingValet_B.path_data_m[i_0] =
        AutomatedParkingValet_B.path_data[ix * i_0 + nx];
    }

    if (0 <= numNodes_0 - 1) {
      memcpy(&AutomatedParkingValet_B.path_data[0],
             &AutomatedParkingValet_B.path_data_m[0], numNodes_0 * sizeof
             (uint32_T));
    }

    AutomatedParkingVale_do_vectors(AutomatedParkingValet_B.b_path_data,
      b_path_size, goalNodes, AutomatedParkingValet_B.path_data_m, randPose_size,
      AutomatedParkingValet_B.ia_data, &nx, AutomatedParkingValet_B.ib_data,
      &i_0);
    if (nx != 0) {
      if (1 > AutomatedParkingValet_B.ia_data[0]) {
        numNodes_0 = 0;
      } else {
        numNodes_0 = AutomatedParkingValet_B.ia_data[0];
      }
    }

    AutomatedParking_emxInit_real_T(&b, 2);
    AutomatedParki_RRTTree_costTo_g(&this->Tree, &bestGoalNode_data,
      bestGoalNode_size, &this_0.data, this_0.size);
    bestCost = this->Tree.NodeIndex - 1.0;
    if (1.0 > bestCost) {
      ix = -1;
    } else {
      ix = (int32_T)bestCost - 1;
    }

    i_0 = b->size[0] * b->size[1];
    b->size[0] = ix + 1;
    b->size[1] = 3;
    Automa_emxEnsureCapacity_real_T(b, i_0);
    for (i_0 = 0; i_0 < 3; i_0++) {
      for (nx = 0; nx <= ix; nx++) {
        b->data[nx + b->size[0] * i_0] = this->Tree.NodeBuffer[10001 * i_0 + nx];
      }
    }

    i_0 = varargout_1->size[0] * varargout_1->size[1];
    varargout_1->size[0] = numNodes_0;
    varargout_1->size[1] = 3;
    Automa_emxEnsureCapacity_real_T(varargout_1, i_0);
    for (i_0 = 0; i_0 < 3; i_0++) {
      for (nx = 0; nx < numNodes_0; nx++) {
        varargout_1->data[nx + varargout_1->size[0] * i_0] = b->data[(b->size[0]
          * i_0 + (int32_T)AutomatedParkingValet_B.path_data[nx]) - 1];
      }
    }

    AutomatedParking_emxFree_real_T(&b);
  }

  AutomatedParking_emxFree_real_T(&goalNodes);
}

static void emxFree_c_driving_internal_plan(emxArray_c_driving_internal_p_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_c_driving_internal_p_T *)NULL) {
    if (((*pEmxArray)->data != (c_driving_internal_planning_D_T *)NULL) &&
        (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_c_driving_internal_p_T *)NULL;
  }
}

static void emxEnsureCapacity_cell_wrap_38(emxArray_cell_wrap_38_Automat_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(cell_wrap_38_AutomatedParking_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(cell_wrap_38_AutomatedParking_T)
             * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (cell_wrap_38_AutomatedParking_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static boolean_T Autom_OneDimArrayBehavior_isrow(const
  emxArray_c_driving_internal_p_T *this_Data)
{
  return this_Data->size[0] == 1;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static boolean_T AutomatedParkingValet_vectorAny(const boolean_T x_data[], const
  int32_T x_size[2])
{
  boolean_T y;
  int32_T k;
  boolean_T exitg1;
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k <= x_size[1] - 1)) {
    if (!x_data[k]) {
      k++;
    } else {
      y = true;
      exitg1 = true;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void Autom_pathPlannerRRT_createPath(const
  pathPlannerRRT_AutomatedParki_T *this, const emxArray_real_T_AutomatedPark_T
  *pathPoses, emxArray_c_driving_internal_p_T *refPath_PathSegments_Data)
{
  e_driving_internal_planning_D_T conn;
  emxArray_c_driving_internal_p_T *pathSeg_Data;
  int32_T n;
  real_T radius;
  emxArray_c_driving_internal_p_T *data;
  real_T b_this_StartPoseInternal[3];
  real_T b_this_GoalPoseInternal[3];
  real_T startPose[3];
  real_T goalPose[3];
  real_T rho;
  emxArray_cell_wrap_38_Automat_T *disabledTypes;
  real_T cost;
  real_T motionLengths[3];
  real_T b_motionTypes[3];
  boolean_T allPathTypes[6];
  boolean_T match[6];
  int32_T i;
  int32_T ret;
  static const char_T b_b[3] = { 'L', 'S', 'L' };

  static const char_T c_b[3] = { 'L', 'S', 'R' };

  static const char_T d_b[3] = { 'R', 'S', 'L' };

  static const char_T e_b[3] = { 'R', 'S', 'R' };

  static const char_T f_b[3] = { 'R', 'L', 'R' };

  static const char_T g_b[3] = { 'L', 'R', 'L' };

  c_driving_internal_planning_D_T expl_temp;
  c_driving_internal_planning_D_T expl_temp_0;
  int32_T loop_ub;
  char_T motionTypes_idx_0;
  char_T motionTypes_idx_1;
  char_T motionTypes_idx_2;
  static const char_T c[3] = { 'L', 'R', 'S' };

  static const int32_T tmp[2] = { 1, 6 };

  emxInitStruct_e_driving_interna(&conn);
  emxInit_c_driving_internal_plan(&pathSeg_Data, 2);
  Automat_DubinsConnection_create(&conn);
  radius = this->InternalPlanner.ConnectionMechanism->TurningRadius;
  conn.MinTurningRadius = radius;
  DubinsPathSegmentCodegen_makeem(pathSeg_Data);
  n = 0;
  emxInit_c_driving_internal_plan(&data, 2);
  AutomatedP_emxInit_cell_wrap_38(&disabledTypes, 2);
  while (n <= pathPoses->size[0] - 2) {
    startPose[0] = pathPoses->data[n];
    startPose[1] = pathPoses->data[n + pathPoses->size[0]];
    startPose[2] = pathPoses->data[(pathPoses->size[0] << 1) + n] *
      0.017453292519943295;
    angleUtilities_wrapTo2_bbViJ3IV(&startPose[2]);
    goalPose[0] = pathPoses->data[n + 1];
    goalPose[1] = pathPoses->data[(n + pathPoses->size[0]) + 1];
    goalPose[2] = pathPoses->data[((pathPoses->size[0] << 1) + n) + 1] *
      0.017453292519943295;
    angleUtilities_wrapTo2_bbViJ3IV(&goalPose[2]);
    radius = conn.MinTurningRadius;
    b_this_StartPoseInternal[0] = startPose[0];
    b_this_StartPoseInternal[1] = startPose[1];
    b_this_StartPoseInternal[2] = startPose[2];
    angleUtilities_wrapTo2_bbViJ3IV(&b_this_StartPoseInternal[2]);
    b_this_GoalPoseInternal[0] = goalPose[0];
    b_this_GoalPoseInternal[1] = goalPose[1];
    b_this_GoalPoseInternal[2] = goalPose[2];
    angleUtilities_wrapTo2_bbViJ3IV(&b_this_GoalPoseInternal[2]);
    rho = conn.MinTurningRadius;
    ret = disabledTypes->size[0] * disabledTypes->size[1];
    disabledTypes->size[0] = conn.DisabledPathTypesInternal->size[0];
    disabledTypes->size[1] = conn.DisabledPathTypesInternal->size[1];
    emxEnsureCapacity_cell_wrap_38(disabledTypes, ret);
    loop_ub = conn.DisabledPathTypesInternal->size[0] *
      conn.DisabledPathTypesInternal->size[1] - 1;
    for (ret = 0; ret <= loop_ub; ret++) {
      disabledTypes->data[ret] = conn.DisabledPathTypesInternal->data[ret];
    }

    for (ret = 0; ret < 6; ret++) {
      allPathTypes[ret] = true;
    }

    if ((disabledTypes->size[0] == 0) || (disabledTypes->size[1] == 0)) {
      loop_ub = -1;
    } else {
      ret = disabledTypes->size[0];
      loop_ub = disabledTypes->size[1];
      if (ret > loop_ub) {
        loop_ub = ret;
      }

      loop_ub--;
    }

    for (i = 0; i <= loop_ub; i++) {
      ret = memcmp(&disabledTypes->data[i].f1[0], &b_b[0], 3);
      match[0] = (ret == 0);
      ret = memcmp(&disabledTypes->data[i].f1[0], &c_b[0], 3);
      match[1] = (ret == 0);
      ret = memcmp(&disabledTypes->data[i].f1[0], &d_b[0], 3);
      match[2] = (ret == 0);
      ret = memcmp(&disabledTypes->data[i].f1[0], &e_b[0], 3);
      match[3] = (ret == 0);
      ret = memcmp(&disabledTypes->data[i].f1[0], &f_b[0], 3);
      match[4] = (ret == 0);
      ret = memcmp(&disabledTypes->data[i].f1[0], &g_b[0], 3);
      match[5] = (ret == 0);
      if (AutomatedParkingValet_vectorAny(match, tmp)) {
        for (ret = 0; ret < 6; ret++) {
          if (match[ret]) {
            allPathTypes[ret] = false;
          }
        }
      }
    }

    autonomousDubinsSegmentsCodegen_real64(startPose, 1U, goalPose, 1U, rho,
      allPathTypes, true, 3U, &cost, motionLengths, b_motionTypes);
    motionTypes_idx_0 = c[(int32_T)(b_motionTypes[0] + 1.0) - 1];
    motionTypes_idx_1 = c[(int32_T)(b_motionTypes[1] + 1.0) - 1];
    motionTypes_idx_2 = c[(int32_T)(b_motionTypes[2] + 1.0) - 1];
    if (n + 1 > pathSeg_Data->size[0] * pathSeg_Data->size[1]) {
      if (Autom_OneDimArrayBehavior_isrow(pathSeg_Data)) {
        ret = data->size[0] * data->size[1];
        data->size[0] = 1;
        data->size[1] = n + 1;
        emxEnsureCapacity_c_driving_int(data, ret);
      } else {
        ret = data->size[0] * data->size[1];
        data->size[0] = n + 1;
        data->size[1] = 1;
        emxEnsureCapacity_c_driving_int(data, ret);
      }

      loop_ub = pathSeg_Data->size[0] * pathSeg_Data->size[1];
      for (i = 0; i < loop_ub; i++) {
        data->data[i] = pathSeg_Data->data[i];
      }

      expl_temp.MinTurningRadius = radius;
      expl_temp.StartPoseInternal[0] = b_this_StartPoseInternal[0];
      expl_temp.GoalPoseInternal[0] = b_this_GoalPoseInternal[0];
      expl_temp.MotionLengths[0] = motionLengths[0];
      expl_temp.MotionTypes[0] = motionTypes_idx_0;
      expl_temp.StartPoseInternal[1] = b_this_StartPoseInternal[1];
      expl_temp.GoalPoseInternal[1] = b_this_GoalPoseInternal[1];
      expl_temp.MotionLengths[1] = motionLengths[1];
      expl_temp.MotionTypes[1] = motionTypes_idx_1;
      expl_temp.StartPoseInternal[2] = b_this_StartPoseInternal[2];
      expl_temp.GoalPoseInternal[2] = b_this_GoalPoseInternal[2];
      expl_temp.MotionLengths[2] = motionLengths[2];
      expl_temp.MotionTypes[2] = motionTypes_idx_2;
      data->data[n] = expl_temp;
      ret = pathSeg_Data->size[0] * pathSeg_Data->size[1];
      pathSeg_Data->size[0] = data->size[0];
      pathSeg_Data->size[1] = data->size[1];
      emxEnsureCapacity_c_driving_int(pathSeg_Data, ret);
      loop_ub = data->size[0] * data->size[1] - 1;
      for (ret = 0; ret <= loop_ub; ret++) {
        pathSeg_Data->data[ret] = data->data[ret];
      }
    } else {
      expl_temp_0.MinTurningRadius = radius;
      expl_temp_0.StartPoseInternal[0] = b_this_StartPoseInternal[0];
      expl_temp_0.GoalPoseInternal[0] = b_this_GoalPoseInternal[0];
      expl_temp_0.MotionLengths[0] = motionLengths[0];
      expl_temp_0.MotionTypes[0] = motionTypes_idx_0;
      expl_temp_0.StartPoseInternal[1] = b_this_StartPoseInternal[1];
      expl_temp_0.GoalPoseInternal[1] = b_this_GoalPoseInternal[1];
      expl_temp_0.MotionLengths[1] = motionLengths[1];
      expl_temp_0.MotionTypes[1] = motionTypes_idx_1;
      expl_temp_0.StartPoseInternal[2] = b_this_StartPoseInternal[2];
      expl_temp_0.GoalPoseInternal[2] = b_this_GoalPoseInternal[2];
      expl_temp_0.MotionLengths[2] = motionLengths[2];
      expl_temp_0.MotionTypes[2] = motionTypes_idx_2;
      pathSeg_Data->data[n] = expl_temp_0;
    }

    n++;
  }

  AutomatedP_emxFree_cell_wrap_38(&disabledTypes);
  emxFree_c_driving_internal_plan(&data);
  ret = refPath_PathSegments_Data->size[0] * refPath_PathSegments_Data->size[1];
  refPath_PathSegments_Data->size[0] = pathSeg_Data->size[0];
  refPath_PathSegments_Data->size[1] = pathSeg_Data->size[1];
  emxEnsureCapacity_c_driving_int(refPath_PathSegments_Data, ret);
  loop_ub = pathSeg_Data->size[0] * pathSeg_Data->size[1] - 1;
  for (ret = 0; ret <= loop_ub; ret++) {
    refPath_PathSegments_Data->data[ret] = pathSeg_Data->data[ret];
  }

  emxFree_c_driving_internal_plan(&pathSeg_Data);
  emxFreeStruct_e_driving_interna(&conn);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void OneDimArrayBehavior_parenRefere(d_driving_internal_planning_D_T
  *this)
{
  c_driving_internal_planning_D_T data_data;
  int32_T tmp;
  data_data = this->Data->data[0];
  tmp = this->Data->size[0] * this->Data->size[1];
  this->Data->size[0] = 1;
  this->Data->size[1] = 1;
  emxEnsureCapacity_c_driving_int(this->Data, tmp);
  this->Data->data[0] = data_data;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static real_T AutomatedParkin_Path_get_Length(const
  emxArray_c_driving_internal_p_T *this_PathSegments_Data)
{
  real_T len;
  emxArray_real_T_AutomatedPark_T *b_len;
  int32_T numObj;
  int32_T n;
  real_T c_len;
  if (this_PathSegments_Data->size[0] * this_PathSegments_Data->size[1] == 0) {
    len = 0.0;
  } else {
    AutomatedParking_emxInit_real_T(&b_len, 1);
    numObj = this_PathSegments_Data->size[0] * this_PathSegments_Data->size[1];
    if (numObj == 0) {
      b_len->size[0] = 0;
    } else {
      n = b_len->size[0];
      b_len->size[0] = numObj;
      Automa_emxEnsureCapacity_real_T(b_len, n);
      for (n = 0; n < numObj; n++) {
        c_len = this_PathSegments_Data->data[n].MotionLengths[0];
        c_len += this_PathSegments_Data->data[n].MotionLengths[1];
        c_len += this_PathSegments_Data->data[n].MotionLengths[2];
        b_len->data[n] = c_len;
      }
    }

    if (b_len->size[0] == 0) {
      len = 0.0;
    } else {
      len = b_len->data[0];
      for (numObj = 2; numObj <= b_len->size[0]; numObj++) {
        len += b_len->data[numObj - 1];
      }
    }

    AutomatedParking_emxFree_real_T(&b_len);
  }

  return len;
}

static void emxFreeStruct_d_driving_interna(d_driving_internal_planning_D_T
  *pStruct)
{
  emxFree_c_driving_internal_plan(&pStruct->Data);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void OneDimArrayBehavior_parenRefe_j(d_driving_internal_planning_D_T
  *this, real_T idx)
{
  c_driving_internal_planning_D_T data_data;
  int32_T tmp;
  data_data = this->Data->data[(int32_T)idx - 1];
  tmp = this->Data->size[0] * this->Data->size[1];
  this->Data->size[0] = 1;
  this->Data->size[1] = 1;
  emxEnsureCapacity_c_driving_int(this->Data, tmp);
  this->Data->data[0] = data_data;
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void DubinsPathSegmentCodegen_get_Le(const
  emxArray_c_driving_internal_p_T *this_Data, real_T len_data[], int32_T
  *len_size)
{
  real_T b_len;
  *len_size = 1;
  b_len = this_Data->data[0].MotionLengths[0];
  b_len += this_Data->data[0].MotionLengths[1];
  len_data[0] = b_len + this_Data->data[0].MotionLengths[2];
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void interpolateInternalInputValidat(const
  emxArray_real_T_AutomatedPark_T *varargin_1, boolean_T varargin_2,
  emxArray_real_T_AutomatedPark_T *samples)
{
  emxArray_real_T_AutomatedPark_T *a;
  int32_T na;
  emxArray_int32_T_AutomatedPar_T *idx;
  real_T x;
  int32_T j;
  int32_T n;
  emxArray_int32_T_AutomatedPar_T *iwork;
  int32_T d_k;
  int32_T i;
  int32_T i2;
  int32_T b_j;
  int32_T pEnd;
  int32_T b_p;
  int32_T q;
  int32_T qEnd;
  int32_T kEnd;
  real_T absx;
  uint32_T c_idx_0;
  int32_T exitg1;
  i = samples->size[0];
  samples->size[0] = varargin_1->size[0];
  Automa_emxEnsureCapacity_real_T(samples, i);
  i2 = varargin_1->size[0];
  for (i = 0; i < i2; i++) {
    samples->data[i] = varargin_1->data[i];
  }

  if (!varargin_2) {
    i = samples->size[0];
    samples->size[0] = varargin_1->size[0] + 1;
    Automa_emxEnsureCapacity_real_T(samples, i);
    samples->data[0] = 0.0;
    i2 = varargin_1->size[0];
    for (i = 0; i < i2; i++) {
      samples->data[i + 1] = varargin_1->data[i];
    }
  }

  AutomatedParking_emxInit_real_T(&a, 1);
  i = a->size[0];
  a->size[0] = samples->size[0];
  Automa_emxEnsureCapacity_real_T(a, i);
  i2 = samples->size[0];
  for (i = 0; i < i2; i++) {
    a->data[i] = samples->data[i];
  }

  AutomatedParkin_emxInit_int32_T(&idx, 1);
  na = samples->size[0];
  n = samples->size[0] + 1;
  c_idx_0 = (uint32_T)samples->size[0];
  i = idx->size[0];
  idx->size[0] = (int32_T)c_idx_0;
  Autom_emxEnsureCapacity_int32_T(idx, i);
  i2 = (int32_T)c_idx_0;
  for (i = 0; i < i2; i++) {
    idx->data[i] = 0;
  }

  if (samples->size[0] != 0) {
    AutomatedParkin_emxInit_int32_T(&iwork, 1);
    i = iwork->size[0];
    iwork->size[0] = (int32_T)c_idx_0;
    Autom_emxEnsureCapacity_int32_T(iwork, i);
    for (i = 1; i <= n - 2; i += 2) {
      if ((samples->data[i - 1] <= samples->data[i]) || rtIsNaN(samples->data[i]))
      {
        idx->data[i - 1] = i;
        idx->data[i] = i + 1;
      } else {
        idx->data[i - 1] = i + 1;
        idx->data[i] = i;
      }
    }

    if ((samples->size[0] & 1U) != 0U) {
      idx->data[samples->size[0] - 1] = samples->size[0];
    }

    i = 2;
    while (i < n - 1) {
      i2 = i << 1;
      b_j = 1;
      pEnd = i + 1;
      while (pEnd < n) {
        b_p = b_j;
        q = pEnd - 1;
        qEnd = b_j + i2;
        if (qEnd > n) {
          qEnd = n;
        }

        d_k = 0;
        kEnd = qEnd - b_j;
        while (d_k + 1 <= kEnd) {
          if ((samples->data[idx->data[b_p - 1] - 1] <= samples->data[idx->
               data[q] - 1]) || rtIsNaN(samples->data[idx->data[q] - 1])) {
            iwork->data[d_k] = idx->data[b_p - 1];
            b_p++;
            if (b_p == pEnd) {
              while (q + 1 < qEnd) {
                d_k++;
                iwork->data[d_k] = idx->data[q];
                q++;
              }
            }
          } else {
            iwork->data[d_k] = idx->data[q];
            q++;
            if (q + 1 == qEnd) {
              while (b_p < pEnd) {
                d_k++;
                iwork->data[d_k] = idx->data[b_p - 1];
                b_p++;
              }
            }
          }

          d_k++;
        }

        for (pEnd = -1; pEnd < kEnd - 1; pEnd++) {
          idx->data[b_j + pEnd] = iwork->data[pEnd + 1];
        }

        b_j = qEnd;
        pEnd = qEnd + i;
      }

      i = i2;
    }

    AutomatedParkin_emxFree_int32_T(&iwork);
  }

  i = samples->size[0];
  samples->size[0] = (int32_T)c_idx_0;
  Automa_emxEnsureCapacity_real_T(samples, i);
  for (n = 0; n < na; n++) {
    samples->data[n] = a->data[idx->data[n] - 1];
  }

  AutomatedParkin_emxFree_int32_T(&idx);
  AutomatedParking_emxFree_real_T(&a);
  i2 = 0;
  while ((i2 + 1 <= na) && rtIsInf(samples->data[i2]) && (samples->data[i2] <
          0.0)) {
    i2++;
  }

  n = i2;
  i2 = na;
  while ((i2 >= 1) && rtIsNaN(samples->data[i2 - 1])) {
    i2--;
  }

  i = na - i2;
  while ((i2 >= 1) && rtIsInf(samples->data[i2 - 1]) && (samples->data[i2 - 1] >
          0.0)) {
    i2--;
  }

  b_j = (na - i2) - i;
  na = -1;
  if (n > 0) {
    na = 0;
  }

  while (n + 1 <= i2) {
    x = samples->data[n];
    do {
      exitg1 = 0;
      n++;
      if (n + 1 > i2) {
        exitg1 = 1;
      } else {
        absx = fabs(x / 2.0);
        if ((!rtIsInf(absx)) && (!rtIsNaN(absx))) {
          if (absx <= 2.2250738585072014E-308) {
            absx = 4.94065645841247E-324;
          } else {
            frexp(absx, &j);
            absx = ldexp(1.0, j - 53);
          }
        } else {
          absx = (rtNaN);
        }

        if ((fabs(x - samples->data[n]) < absx) || (rtIsInf(samples->data[n]) &&
             rtIsInf(x) && ((samples->data[n] > 0.0) == (x > 0.0)))) {
        } else {
          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);

    na++;
    samples->data[na] = x;
  }

  if (b_j > 0) {
    na++;
    samples->data[na] = samples->data[i2];
  }

  n = i2 + b_j;
  for (j = 0; j < i; j++) {
    na++;
    samples->data[na] = samples->data[n + j];
  }

  i = samples->size[0];
  if (1 > na + 1) {
    samples->size[0] = 0;
  } else {
    samples->size[0] = na + 1;
  }

  Automa_emxEnsureCapacity_real_T(samples, i);
}

/* Function for MATLAB Function: '<Root>/motionPlanning' */
static void AutomatedPar_Path_interpolateCG(const
  d_driving_internal_planning_D_T this_PathSegments,
  emxArray_real_T_AutomatedPark_T *poses, emxArray_real_T_AutomatedPark_T
  *directions)
{
  int32_T numSegments;
  emxArray_real_T_AutomatedPark_T *transitionSamples;
  real_T t;
  real_T accum;
  emxArray_real_T_AutomatedPark_T *samplesAll;
  emxArray_real_T_AutomatedPark_T *accumLengths;
  emxArray_real_T_AutomatedPark_T *segmentSamples;
  real_T segLen_data;
  emxArray_int32_T_AutomatedPar_T *d;
  emxArray_real_T_AutomatedPark_T *varargout_1;
  c_driving_internal_planning_D_T f_data;
  int32_T na;
  emxArray_int32_T_AutomatedPar_T *idx;
  int32_T j;
  int32_T c_n;
  uint32_T motionTypesMap[3];
  int8_T l_data[3];
  int8_T o_data[3];
  emxArray_int32_T_AutomatedPar_T *iwork;
  int32_T e_k;
  int32_T h_i;
  int32_T i2;
  int32_T c_j;
  int32_T pEnd;
  int32_T b_p;
  int32_T q;
  int32_T qEnd;
  int32_T kEnd;
  emxArray_real_T_AutomatedPark_T *b_z1;
  boolean_T u[3];
  d_driving_internal_planning_D_T v;
  emxArray_real_T_AutomatedPark_T *poses_0;
  boolean_T u_0;
  uint32_T h_idx_0;
  real_T motionLens_data_idx_0;
  static const int32_T tmp[2] = { 1, 3 };

  int32_T exitg1;
  boolean_T exitg2;
  AutomatedParking_emxInit_real_T(&transitionSamples, 2);
  emxInitStruct_d_driving_interna(&v);
  numSegments = this_PathSegments.Data->size[0] * this_PathSegments.Data->size[1];
  emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
  OneDimArrayBehavior_parenRefere(&v);
  emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
  OneDimArrayBehavior_parenRefere(&v);
  h_i = transitionSamples->size[0] * transitionSamples->size[1];
  transitionSamples->size[0] = 1;
  transitionSamples->size[1] = numSegments * 3;
  Automa_emxEnsureCapacity_real_T(transitionSamples, h_i);
  t = 1.0;
  accum = 0.0;
  for (na = 0; na < numSegments; na++) {
    emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
    OneDimArrayBehavior_parenRefe_j(&v, (real_T)na + 1.0);
    motionLens_data_idx_0 = v.Data->data[0].MotionLengths[0];
    h_i = (int32_T)t - 1;
    transitionSamples->data[h_i] = accum + motionLens_data_idx_0;
    accum = transitionSamples->data[h_i];
    t++;
    motionLens_data_idx_0 = v.Data->data[0].MotionLengths[1];
    h_i = (int32_T)t - 1;
    transitionSamples->data[h_i] = accum + motionLens_data_idx_0;
    accum = transitionSamples->data[h_i];
    t++;
    motionLens_data_idx_0 = v.Data->data[0].MotionLengths[2];
    h_i = (int32_T)t - 1;
    transitionSamples->data[h_i] = accum + motionLens_data_idx_0;
    accum = transitionSamples->data[h_i];
    t++;
  }

  AutomatedParking_emxInit_real_T(&segmentSamples, 1);
  AutomatedParkin_emxInit_int32_T(&idx, 1);
  na = transitionSamples->size[1];
  c_n = transitionSamples->size[1] + 1;
  h_idx_0 = (uint32_T)transitionSamples->size[1];
  h_i = idx->size[0];
  idx->size[0] = (int32_T)h_idx_0;
  Autom_emxEnsureCapacity_int32_T(idx, h_i);
  i2 = (int32_T)h_idx_0;
  for (h_i = 0; h_i < i2; h_i++) {
    idx->data[h_i] = 0;
  }

  if (transitionSamples->size[1] != 0) {
    AutomatedParkin_emxInit_int32_T(&iwork, 1);
    h_i = iwork->size[0];
    iwork->size[0] = (int32_T)h_idx_0;
    Autom_emxEnsureCapacity_int32_T(iwork, h_i);
    for (h_i = 1; h_i <= c_n - 2; h_i += 2) {
      if ((transitionSamples->data[h_i - 1] <= transitionSamples->data[h_i]) ||
          rtIsNaN(transitionSamples->data[h_i])) {
        idx->data[h_i - 1] = h_i;
        idx->data[h_i] = h_i + 1;
      } else {
        idx->data[h_i - 1] = h_i + 1;
        idx->data[h_i] = h_i;
      }
    }

    if ((transitionSamples->size[1] & 1U) != 0U) {
      idx->data[transitionSamples->size[1] - 1] = transitionSamples->size[1];
    }

    h_i = 2;
    while (h_i < c_n - 1) {
      i2 = h_i << 1;
      c_j = 1;
      pEnd = h_i + 1;
      while (pEnd < c_n) {
        b_p = c_j;
        q = pEnd - 1;
        qEnd = c_j + i2;
        if (qEnd > c_n) {
          qEnd = c_n;
        }

        e_k = 0;
        kEnd = qEnd - c_j;
        while (e_k + 1 <= kEnd) {
          if ((transitionSamples->data[idx->data[b_p - 1] - 1] <=
               transitionSamples->data[idx->data[q] - 1]) || rtIsNaN
              (transitionSamples->data[idx->data[q] - 1])) {
            iwork->data[e_k] = idx->data[b_p - 1];
            b_p++;
            if (b_p == pEnd) {
              while (q + 1 < qEnd) {
                e_k++;
                iwork->data[e_k] = idx->data[q];
                q++;
              }
            }
          } else {
            iwork->data[e_k] = idx->data[q];
            q++;
            if (q + 1 == qEnd) {
              while (b_p < pEnd) {
                e_k++;
                iwork->data[e_k] = idx->data[b_p - 1];
                b_p++;
              }
            }
          }

          e_k++;
        }

        for (pEnd = -1; pEnd < kEnd - 1; pEnd++) {
          idx->data[c_j + pEnd] = iwork->data[pEnd + 1];
        }

        c_j = qEnd;
        pEnd = qEnd + h_i;
      }

      h_i = i2;
    }

    AutomatedParkin_emxFree_int32_T(&iwork);
  }

  h_i = segmentSamples->size[0];
  segmentSamples->size[0] = transitionSamples->size[1];
  Automa_emxEnsureCapacity_real_T(segmentSamples, h_i);
  for (c_n = 0; c_n < na; c_n++) {
    segmentSamples->data[c_n] = transitionSamples->data[idx->data[c_n] - 1];
  }

  c_n = 0;
  while ((c_n + 1 <= na) && rtIsInf(segmentSamples->data[c_n]) &&
         (segmentSamples->data[c_n] < 0.0)) {
    c_n++;
  }

  na = c_n;
  c_n = transitionSamples->size[1];
  while ((c_n >= 1) && rtIsNaN(segmentSamples->data[c_n - 1])) {
    c_n--;
  }

  h_i = transitionSamples->size[1] - c_n;
  while ((c_n >= 1) && rtIsInf(segmentSamples->data[c_n - 1]) &&
         (segmentSamples->data[c_n - 1] > 0.0)) {
    c_n--;
  }

  c_j = (transitionSamples->size[1] - c_n) - h_i;
  i2 = -1;
  if (na > 0) {
    i2 = 0;
  }

  while (na + 1 <= c_n) {
    t = segmentSamples->data[na];
    do {
      exitg1 = 0;
      na++;
      if (na + 1 > c_n) {
        exitg1 = 1;
      } else {
        accum = fabs(t / 2.0);
        if ((!rtIsInf(accum)) && (!rtIsNaN(accum))) {
          if (accum <= 2.2250738585072014E-308) {
            accum = 4.94065645841247E-324;
          } else {
            frexp(accum, &j);
            accum = ldexp(1.0, j - 53);
          }
        } else {
          accum = (rtNaN);
        }

        if ((fabs(t - segmentSamples->data[na]) < accum) || (rtIsInf
             (segmentSamples->data[na]) && rtIsInf(t) && ((segmentSamples->
               data[na] > 0.0) == (t > 0.0)))) {
        } else {
          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);

    i2++;
    segmentSamples->data[i2] = t;
  }

  if (c_j > 0) {
    i2++;
    segmentSamples->data[i2] = segmentSamples->data[c_n];
  }

  na = c_n + c_j;
  for (j = 0; j < h_i; j++) {
    i2++;
    segmentSamples->data[i2] = segmentSamples->data[na + j];
  }

  AutomatedParking_emxInit_real_T(&samplesAll, 1);
  AutomatedParking_emxInit_real_T(&b_z1, 1);
  if (1 > i2 + 1) {
    j = 0;
  } else {
    j = i2 + 1;
  }

  h_i = segmentSamples->size[0];
  segmentSamples->size[0] = j;
  Automa_emxEnsureCapacity_real_T(segmentSamples, h_i);
  t = AutomatedParkin_Path_get_Length(this_PathSegments.Data);
  h_i = samplesAll->size[0];
  samplesAll->size[0] = j;
  Automa_emxEnsureCapacity_real_T(samplesAll, h_i);
  h_i = b_z1->size[0];
  b_z1->size[0] = samplesAll->size[0];
  Automa_emxEnsureCapacity_real_T(b_z1, h_i);
  i2 = samplesAll->size[0];
  for (h_i = 0; h_i < i2; h_i++) {
    b_z1->data[h_i] = samplesAll->data[h_i];
  }

  for (na = 0; na < j; na++) {
    b_z1->data[na] = fmin(segmentSamples->data[na], t);
  }

  AutomatedParking_emxInit_real_T(&accumLengths, 1);
  emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
  OneDimArrayBehavior_parenRefere(&v);
  h_i = accumLengths->size[0];
  accumLengths->size[0] = numSegments + 1;
  Automa_emxEnsureCapacity_real_T(accumLengths, h_i);
  accumLengths->data[0] = 0.0;
  for (j = 0; j < numSegments; j++) {
    emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
    OneDimArrayBehavior_parenRefe_j(&v, (real_T)j + 1.0);
    DubinsPathSegmentCodegen_get_Le(v.Data, &segLen_data, &h_i);
    accumLengths->data[j + 1] = accumLengths->data[j] + segLen_data;
  }

  h_i = idx->size[0];
  idx->size[0] = b_z1->size[0];
  Autom_emxEnsureCapacity_int32_T(idx, h_i);
  numSegments = accumLengths->size[0] - 2;
  for (j = 0; j < b_z1->size[0]; j++) {
    na = 0;
    exitg2 = false;
    while ((!exitg2) && (na <= numSegments - 1)) {
      if ((b_z1->data[j] >= accumLengths->data[na]) && (b_z1->data[j] <
           accumLengths->data[na + 1])) {
        idx->data[j] = na + 1;
        exitg2 = true;
      } else {
        na++;
      }
    }

    if (b_z1->data[j] >= accumLengths->data[numSegments]) {
      idx->data[j] = numSegments + 1;
    }
  }

  if (this_PathSegments.Data->size[0] * this_PathSegments.Data->size[1] != 0) {
    emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
    OneDimArrayBehavior_parenRefere(&v);
  }

  poses->size[0] = 0;
  poses->size[1] = 3;
  directions->size[0] = 0;
  directions->size[1] = 1;
  numSegments = this_PathSegments.Data->size[0] * this_PathSegments.Data->size[1];
  j = 0;
  AutomatedParkin_emxInit_int32_T(&d, 1);
  AutomatedParking_emxInit_real_T(&varargout_1, 2);
  AutomatedParking_emxInit_real_T(&poses_0, 2);
  while (j <= numSegments - 1) {
    na = idx->size[0] - 1;
    c_n = 0;
    for (h_i = 0; h_i <= na; h_i++) {
      if ((real_T)j + 1.0 == idx->data[h_i]) {
        c_n++;
      }
    }

    h_i = d->size[0];
    d->size[0] = c_n;
    Autom_emxEnsureCapacity_int32_T(d, h_i);
    c_n = 0;
    for (h_i = 0; h_i <= na; h_i++) {
      if ((real_T)j + 1.0 == idx->data[h_i]) {
        d->data[c_n] = h_i + 1;
        c_n++;
      }
    }

    t = accumLengths->data[j];
    h_i = segmentSamples->size[0];
    segmentSamples->size[0] = d->size[0];
    Automa_emxEnsureCapacity_real_T(segmentSamples, h_i);
    i2 = d->size[0];
    for (h_i = 0; h_i < i2; h_i++) {
      segmentSamples->data[h_i] = b_z1->data[d->data[h_i] - 1] - t;
    }

    emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
    OneDimArrayBehavior_parenRefe_j(&v, (real_T)j + 1.0);
    DubinsPathSegmentCodegen_get_Le(v.Data, &segLen_data, &h_i);
    na = segmentSamples->size[0];
    for (c_n = 0; c_n < na; c_n++) {
      t = fmin(segmentSamples->data[c_n], segLen_data);
      segmentSamples->data[c_n] = t;
    }

    emxCopyStruct_d_driving_interna(&v, &this_PathSegments);
    OneDimArrayBehavior_parenRefe_j(&v, (real_T)j + 1.0);
    f_data = v.Data->data[0];
    u[0] = rtIsNaN(v.Data->data[0].MotionLengths[0]);
    u[1] = rtIsNaN(v.Data->data[0].MotionLengths[1]);
    u[2] = rtIsNaN(v.Data->data[0].MotionLengths[2]);
    if (AutomatedParkingValet_vectorAny(u, tmp)) {
      varargout_1->size[0] = 0;
      varargout_1->size[1] = 3;
      samplesAll->size[0] = 0;
    } else {
      interpolateInternalInputValidat(segmentSamples, (real_T)j + 1.0 > 1.0,
        samplesAll);
      na = 0;
      motionTypesMap[0] = 1U;
      u_0 = false;
      if (!(v.Data->data[0].MotionTypes[0] != 'R')) {
        u_0 = true;
      }

      if (u_0) {
        na = 1;
      }

      u[0] = u_0;
      motionTypesMap[1] = 1U;
      u_0 = false;
      if (!(v.Data->data[0].MotionTypes[1] != 'R')) {
        u_0 = true;
      }

      if (u_0) {
        na++;
      }

      u[1] = u_0;
      motionTypesMap[2] = 1U;
      u_0 = false;
      if (!(v.Data->data[0].MotionTypes[2] != 'R')) {
        u_0 = true;
      }

      if (u_0) {
        na++;
      }

      c_n = na;
      na = 0;
      if (u[0]) {
        l_data[0] = 1;
        na = 1;
      }

      if (u[1]) {
        l_data[na] = 2;
        na++;
      }

      if (u_0) {
        l_data[na] = 3;
      }

      for (h_i = 0; h_i < c_n; h_i++) {
        motionTypesMap[l_data[h_i] - 1] = 2U;
      }

      u[0] = false;
      if (!(v.Data->data[0].MotionTypes[0] != 'S')) {
        u[0] = true;
      }

      u[1] = false;
      if (!(v.Data->data[0].MotionTypes[1] != 'S')) {
        u[1] = true;
      }

      u[2] = false;
      if (!(v.Data->data[0].MotionTypes[2] != 'S')) {
        u[2] = true;
      }

      na = 0;
      if (u[0]) {
        na = 1;
      }

      if (u[1]) {
        na++;
      }

      if (u[2]) {
        na++;
      }

      c_n = na;
      na = 0;
      if (u[0]) {
        o_data[0] = 1;
        na = 1;
      }

      if (u[1]) {
        o_data[na] = 2;
        na++;
      }

      if (u[2]) {
        o_data[na] = 3;
      }

      for (h_i = 0; h_i < c_n; h_i++) {
        motionTypesMap[o_data[h_i] - 1] = 3U;
      }

      h_i = transitionSamples->size[0] * transitionSamples->size[1];
      transitionSamples->size[0] = 1;
      transitionSamples->size[1] = samplesAll->size[0];
      Automa_emxEnsureCapacity_real_T(transitionSamples, h_i);
      i2 = samplesAll->size[0];
      for (h_i = 0; h_i < i2; h_i++) {
        transitionSamples->data[h_i] = samplesAll->data[h_i];
      }

      motionTypesMap[0]--;
      motionTypesMap[1]--;
      motionTypesMap[2]--;
      h_idx_0 = (uint32_T)samplesAll->size[0];
      h_i = varargout_1->size[0] * varargout_1->size[1];
      varargout_1->size[0] = (int32_T)h_idx_0;
      varargout_1->size[1] = 3;
      Automa_emxEnsureCapacity_real_T(varargout_1, h_i);
      h_idx_0 = (uint32_T)samplesAll->size[0];
      autonomousDubinsInterpolateSegmentsCodegen_real64(f_data.StartPoseInternal,
        f_data.GoalPoseInternal, &transitionSamples->data[0], h_idx_0,
        v.Data->data[0].MinTurningRadius, f_data.MotionLengths, motionTypesMap,
        &varargout_1->data[0]);
      na = samplesAll->size[0];
      h_i = samplesAll->size[0];
      samplesAll->size[0] = na;
      Automa_emxEnsureCapacity_real_T(samplesAll, h_i);
      for (h_i = 0; h_i < na; h_i++) {
        samplesAll->data[h_i] = 1.0;
      }
    }

    h_i = poses_0->size[0] * poses_0->size[1];
    poses_0->size[0] = poses->size[0] + varargout_1->size[0];
    poses_0->size[1] = 3;
    Automa_emxEnsureCapacity_real_T(poses_0, h_i);
    for (h_i = 0; h_i < 3; h_i++) {
      i2 = poses->size[0];
      for (na = 0; na < i2; na++) {
        poses_0->data[na + poses_0->size[0] * h_i] = poses->data[poses->size[0] *
          h_i + na];
      }
    }

    for (h_i = 0; h_i < 3; h_i++) {
      i2 = varargout_1->size[0];
      for (na = 0; na < i2; na++) {
        poses_0->data[(na + poses->size[0]) + poses_0->size[0] * h_i] =
          varargout_1->data[varargout_1->size[0] * h_i + na];
      }
    }

    h_i = poses->size[0] * poses->size[1];
    poses->size[0] = poses_0->size[0];
    poses->size[1] = 3;
    Automa_emxEnsureCapacity_real_T(poses, h_i);
    i2 = poses_0->size[0] * poses_0->size[1];
    for (h_i = 0; h_i < i2; h_i++) {
      poses->data[h_i] = poses_0->data[h_i];
    }

    h_i = segmentSamples->size[0];
    segmentSamples->size[0] = directions->size[0] + samplesAll->size[0];
    Automa_emxEnsureCapacity_real_T(segmentSamples, h_i);
    i2 = directions->size[0];
    for (h_i = 0; h_i < i2; h_i++) {
      segmentSamples->data[h_i] = directions->data[h_i];
    }

    i2 = samplesAll->size[0];
    for (h_i = 0; h_i < i2; h_i++) {
      segmentSamples->data[h_i + directions->size[0]] = samplesAll->data[h_i];
    }

    h_i = directions->size[0] * directions->size[1];
    directions->size[0] = segmentSamples->size[0];
    directions->size[1] = 1;
    Automa_emxEnsureCapacity_real_T(directions, h_i);
    i2 = segmentSamples->size[0] - 1;
    for (h_i = 0; h_i <= i2; h_i++) {
      directions->data[h_i] = segmentSamples->data[h_i];
    }

    j++;
  }

  AutomatedParking_emxFree_real_T(&poses_0);
  emxFreeStruct_d_driving_interna(&v);
  AutomatedParking_emxFree_real_T(&b_z1);
  AutomatedParkin_emxFree_int32_T(&idx);
  AutomatedParking_emxFree_real_T(&varargout_1);
  AutomatedParkin_emxFree_int32_T(&d);
  AutomatedParking_emxFree_real_T(&segmentSamples);
  AutomatedParking_emxFree_real_T(&accumLengths);
  AutomatedParking_emxFree_real_T(&samplesAll);
  AutomatedParking_emxFree_real_T(&transitionSamples);
}

static void Auto_emxFreeStruct_driving_Path(driving_Path_AutomatedParking_T
  *pStruct)
{
  emxFreeStruct_d_driving_interna(&pStruct->PathSegments);
}

static void SystemCore_systemblock_prestep(driving_internal_planning_Pat_T *obj,
  const int32_T varargin_1_size[2], const int32_T *varargin_2_size)
{
  int32_T i;
  if (!obj->CacheInputSizes) {
    obj->CacheInputSizes = true;
    i = varargin_1_size[0];
    if (varargin_1_size[0] < 0) {
      i = 0;
    }

    obj->inputVarSize[0].f1[0] = (uint32_T)i;
    i = varargin_1_size[1];
    if (varargin_1_size[1] < 0) {
      i = 0;
    }

    obj->inputVarSize[0].f1[1] = (uint32_T)i;
    i = *varargin_2_size;
    if (*varargin_2_size < 0) {
      i = 0;
    }

    obj->inputVarSize[1].f1[0] = (uint32_T)i;
    obj->inputVarSize[1].f1[1] = 1U;
    for (i = 0; i < 6; i++) {
      obj->inputVarSize[0].f1[i + 2] = 1U;
      obj->inputVarSize[1].f1[i + 2] = 1U;
    }
  }
}

static boolean_T SystemCore_detectInputSizeChang(driving_internal_planning_Pat_T
  *obj, const int32_T varargin_1_size[2], const int32_T *varargin_2_size)
{
  boolean_T anyInputSizeChanged;
  uint32_T inSize[8];
  int32_T b_k;
  boolean_T exitg1;
  anyInputSizeChanged = false;
  b_k = varargin_1_size[0];
  if (varargin_1_size[0] < 0) {
    b_k = 0;
  }

  inSize[0] = (uint32_T)b_k;
  b_k = varargin_1_size[1];
  if (varargin_1_size[1] < 0) {
    b_k = 0;
  }

  inSize[1] = (uint32_T)b_k;
  for (b_k = 0; b_k < 6; b_k++) {
    inSize[b_k + 2] = 1U;
  }

  b_k = 0;
  exitg1 = false;
  while ((!exitg1) && (b_k < 8)) {
    if (obj->inputVarSize[0].f1[b_k] != inSize[b_k]) {
      anyInputSizeChanged = true;
      for (b_k = 0; b_k < 8; b_k++) {
        obj->inputVarSize[0].f1[b_k] = inSize[b_k];
      }

      exitg1 = true;
    } else {
      b_k++;
    }
  }

  b_k = *varargin_2_size;
  if (*varargin_2_size < 0) {
    b_k = 0;
  }

  inSize[0] = (uint32_T)b_k;
  inSize[1] = 1U;
  for (b_k = 0; b_k < 6; b_k++) {
    inSize[b_k + 2] = 1U;
  }

  b_k = 0;
  exitg1 = false;
  while ((!exitg1) && (b_k < 8)) {
    if (obj->inputVarSize[1].f1[b_k] != inSize[b_k]) {
      anyInputSizeChanged = true;
      for (b_k = 0; b_k < 8; b_k++) {
        obj->inputVarSize[1].f1[b_k] = inSize[b_k];
      }

      exitg1 = true;
    } else {
      b_k++;
    }
  }

  return anyInputSizeChanged;
}

static boolean_T AutomatedParkingValet_isequaln(const real_T varargin_1_data[],
  const int32_T varargin_1_size[2], const emxArray_real_T_AutomatedPark_T
  *varargin_2)
{
  boolean_T p;
  int32_T b_k;
  boolean_T p_0;
  boolean_T exitg1;
  p = false;
  p_0 = false;
  if ((varargin_1_size[0] != varargin_2->size[0]) || (varargin_1_size[1] !=
       varargin_2->size[1])) {
  } else {
    p_0 = true;
    if ((varargin_1_size[0] != 0) && (varargin_1_size[1] != 0) &&
        ((varargin_2->size[0] != 0) && (varargin_2->size[1] != 0))) {
      b_k = 0;
      exitg1 = false;
      while ((!exitg1) && (b_k <= varargin_2->size[0] * varargin_2->size[1] - 1))
      {
        if ((varargin_1_data[b_k] == varargin_2->data[b_k]) || (rtIsNaN
             (varargin_1_data[b_k]) && rtIsNaN(varargin_2->data[b_k]))) {
          b_k++;
        } else {
          p_0 = false;
          exitg1 = true;
        }
      }
    }
  }

  if (p_0) {
    p = true;
  }

  return p;
}

static boolean_T AutomatedParkingVale_isequaln_p(const real_T varargin_1_data[],
  const int32_T *varargin_1_size, const emxArray_real_T_AutomatedPark_T
  *varargin_2)
{
  boolean_T p;
  int32_T b_k;
  boolean_T p_0;
  boolean_T exitg1;
  p = false;
  p_0 = false;
  if (*varargin_1_size == varargin_2->size[0]) {
    p_0 = true;
  }

  if (p_0 && (*varargin_1_size != 0) && (varargin_2->size[0] != 0)) {
    b_k = 0;
    exitg1 = false;
    while ((!exitg1) && (b_k <= varargin_2->size[0] - 1)) {
      if ((varargin_1_data[b_k] == varargin_2->data[b_k]) || (rtIsNaN
           (varargin_1_data[b_k]) && rtIsNaN(varargin_2->data[b_k]))) {
        b_k++;
      } else {
        p_0 = false;
        exitg1 = true;
      }
    }
  }

  if (p_0) {
    p = true;
  }

  return p;
}

static void AutomatedParkingValet_power_p(const real_T a_data[], const int32_T
  *a_size, real_T y_data[], int32_T *y_size)
{
  int32_T nx;
  int32_T b_k;
  *y_size = *a_size;
  nx = *a_size - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    y_data[b_k] = a_data[b_k] * a_data[b_k];
  }
}

static void AutomatedParkingVal_filterPoses(const real_T refPoses_data[], const
  int32_T refPoses_size[2], const real_T refDirections_data[], const int32_T
  *refDirections_size, real_T poses_data[], int32_T poses_size[2], real_T
  directions_data[], int32_T *directions_size)
{
  real_T squaredSeparations_data[100];
  int32_T c;
  int32_T d;
  int32_T f;
  int32_T j;
  int32_T k;
  int32_T y_data[100];
  int32_T ab_data[100];
  real_T tmp_data[99];
  real_T tmp_data_0[99];
  real_T refPoses_data_0[99];
  int32_T refPoses_size_0;
  if (2 > refPoses_size[0]) {
    d = 0;
    c = -1;
    k = 0;
    j = -1;
  } else {
    d = 1;
    c = refPoses_size[0] - 1;
    k = 1;
    j = refPoses_size[0] - 1;
  }

  c -= d;
  refPoses_size_0 = c + 1;
  for (f = 0; f <= c; f++) {
    refPoses_data_0[f] = refPoses_data[d + f] - refPoses_data[f];
  }

  AutomatedParkingValet_power_p(refPoses_data_0, &refPoses_size_0, tmp_data, &d);
  c = j - k;
  j = c + 1;
  for (f = 0; f <= c; f++) {
    refPoses_data_0[f] = refPoses_data[(k + f) + refPoses_size[0]] -
      refPoses_data[f + refPoses_size[0]];
  }

  AutomatedParkingValet_power_p(refPoses_data_0, &j, tmp_data_0,
    &refPoses_size_0);
  squaredSeparations_data[0] = 1.0E-6;
  for (f = 0; f < d; f++) {
    squaredSeparations_data[f + 1] = tmp_data[f] + tmp_data_0[f];
  }

  c = 0;
  for (f = 0; f <= d; f++) {
    if (squaredSeparations_data[f] >= 1.0E-6) {
      c++;
    }
  }

  k = c;
  c = 0;
  for (f = 0; f <= d; f++) {
    if (squaredSeparations_data[f] >= 1.0E-6) {
      y_data[c] = f + 1;
      c++;
    }
  }

  j = refPoses_size[1];
  poses_size[0] = k;
  poses_size[1] = refPoses_size[1];
  for (f = 0; f < j; f++) {
    for (c = 0; c < k; c++) {
      poses_data[c + k * f] = refPoses_data[(refPoses_size[0] * f + y_data[c]) -
        1];
    }
  }

  c = 0;
  for (f = 0; f <= d; f++) {
    if (squaredSeparations_data[f] >= 1.0E-6) {
      c++;
    }
  }

  j = c;
  c = 0;
  for (f = 0; f <= d; f++) {
    if (squaredSeparations_data[f] >= 1.0E-6) {
      ab_data[c] = f + 1;
      c++;
    }
  }

  *directions_size = j;
  for (f = 0; f < j; f++) {
    directions_data[f] = refDirections_data[ab_data[f] - 1];
  }

  c = 0;
  for (f = 0; f <= d; f++) {
    if (squaredSeparations_data[f] >= 1.0E-6) {
      c++;
    }
  }

  j = refPoses_size[1];
  for (f = 0; f < j; f++) {
    poses_data[(c + k * f) - 1] = refPoses_data[(refPoses_size[0] * f +
      refPoses_size[0]) - 1];
  }

  c = 0;
  for (f = 0; f <= d; f++) {
    if (squaredSeparations_data[f] >= 1.0E-6) {
      c++;
    }
  }

  directions_data[c - 1] = refDirections_data[*refDirections_size - 1];
}

static void getSegmentBoundaryPointIndex_p(const real_T directions_data[], const
  int32_T *directions_size, real_T segStartIdx_data[], int32_T *segStartIdx_size,
  real_T segEndIdx_data[], int32_T *segEndIdx_size)
{
  int32_T e;
  boolean_T x_data[99];
  int32_T ii_data[99];
  int32_T nx;
  int32_T idx;
  int32_T x_size_idx_0;
  boolean_T exitg1;
  if (1.0 > (real_T)*directions_size - 1.0) {
    nx = -1;
  } else {
    nx = *directions_size - 2;
  }

  if (2 > *directions_size) {
    idx = 0;
  } else {
    idx = 1;
  }

  x_size_idx_0 = nx + 1;
  for (e = 0; e <= nx; e++) {
    x_data[e] = (directions_data[idx + e] + directions_data[e] == 0.0);
  }

  idx = 0;
  e = 1;
  exitg1 = false;
  while ((!exitg1) && (e - 1 <= x_size_idx_0 - 1)) {
    if (x_data[e - 1]) {
      idx++;
      ii_data[idx - 1] = e;
      if (idx >= x_size_idx_0) {
        exitg1 = true;
      } else {
        e++;
      }
    } else {
      e++;
    }
  }

  if (x_size_idx_0 == 1) {
    if (idx == 0) {
      x_size_idx_0 = 0;
    }
  } else {
    if (1 > idx) {
      idx = 0;
    }

    x_size_idx_0 = idx;
  }

  *segStartIdx_size = x_size_idx_0 + 1;
  segStartIdx_data[0] = 1.0;
  *segEndIdx_size = x_size_idx_0 + 1;
  for (e = 0; e < x_size_idx_0; e++) {
    segStartIdx_data[e + 1] = ii_data[e];
    segEndIdx_data[e] = ii_data[e];
  }

  segEndIdx_data[x_size_idx_0] = *directions_size;
}

static void AutomatedParkingVale_sqrt_pmhul(real_T x_data[], const int32_T
  *x_size)
{
  int32_T nx;
  int32_T b_k;
  nx = *x_size - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    x_data[b_k] = sqrt(x_data[b_k]);
  }
}

static void Au_computeCumulativeChordLength(const real_T poses_data[], const
  int32_T poses_size[2], real_T cumChordLength_data[], int32_T
  *cumChordLength_size)
{
  int32_T c;
  int32_T d;
  int32_T j;
  int32_T k;
  real_T tmp_data[99];
  real_T tmp_data_0[99];
  real_T poses_data_0[99];
  int32_T poses_size_0;
  int32_T poses_size_tmp;
  if (2 > poses_size[0]) {
    d = 0;
    c = -1;
    k = 0;
    j = -1;
  } else {
    d = 1;
    c = poses_size[0] - 1;
    k = 1;
    j = poses_size[0] - 1;
  }

  poses_size_tmp = c - d;
  poses_size_0 = poses_size_tmp + 1;
  for (c = 0; c <= poses_size_tmp; c++) {
    poses_data_0[c] = poses_data[d + c] - poses_data[c];
  }

  AutomatedParkingValet_power_p(poses_data_0, &poses_size_0, tmp_data, &d);
  poses_size_tmp = j - k;
  j = poses_size_tmp + 1;
  for (c = 0; c <= poses_size_tmp; c++) {
    poses_data_0[c] = poses_data[(k + c) + poses_size[0]] - poses_data[c +
      poses_size[0]];
  }

  AutomatedParkingValet_power_p(poses_data_0, &j, tmp_data_0, &poses_size_0);
  for (c = 0; c < d; c++) {
    tmp_data[c] += tmp_data_0[c];
  }

  AutomatedParkingVale_sqrt_pmhul(tmp_data, &d);
  *cumChordLength_size = d + 1;
  cumChordLength_data[0] = 0.0;
  if (0 <= d - 1) {
    memcpy(&cumChordLength_data[1], &tmp_data[0], d * sizeof(real_T));
  }

  if ((*cumChordLength_size != 1) && (*cumChordLength_size != 1)) {
    d = *cumChordLength_size - 2;
    for (c = 0; c <= d; c++) {
      cumChordLength_data[c + 1] += cumChordLength_data[c];
    }
  }
}

static void Automa_setSegmentNumSmoothPoses(const real_T
  chordLengthOfSegments_data[], const int32_T *chordLengthOfSegments_size,
  real_T numPosesSeg_data[], int32_T *numPosesSeg_size)
{
  real_T y;
  int32_T vlen;
  int32_T k;
  vlen = *chordLengthOfSegments_size;
  if ((*chordLengthOfSegments_size == 0) || (*chordLengthOfSegments_size == 0))
  {
    y = 0.0;
  } else {
    y = chordLengthOfSegments_data[0];
    for (k = 2; k <= vlen; k++) {
      y += chordLengthOfSegments_data[k - 1];
    }
  }

  *numPosesSeg_size = *chordLengthOfSegments_size;
  k = *chordLengthOfSegments_size;
  for (vlen = 0; vlen < k; vlen++) {
    numPosesSeg_data[vlen] = chordLengthOfSegments_data[vlen] * 500.0 / y;
  }

  vlen = *chordLengthOfSegments_size - 1;
  for (k = 0; k <= vlen; k++) {
    numPosesSeg_data[k] = floor(numPosesSeg_data[k]);
  }

  if (1.0 > (real_T)*chordLengthOfSegments_size - 1.0) {
    vlen = 0;
  } else {
    vlen = *chordLengthOfSegments_size - 1;
  }

  if ((vlen == 0) || (vlen == 0)) {
    y = 0.0;
  } else {
    y = numPosesSeg_data[0];
    for (k = 2; k <= vlen; k++) {
      y += numPosesSeg_data[k - 1];
    }
  }

  numPosesSeg_data[*chordLengthOfSegments_size - 1] = 500.0 - y;
}

static void AutomatedParkingValet_pwchcore(const real_T x_data[], const int32_T *
  x_size, const real_T y_data[], int32_T yoffset, const real_T s_data[], const
  int32_T s_size[2], const real_T dx_data[], const real_T divdif_data[], real_T
  pp_breaks_data[], int32_T pp_breaks_size[2], real_T pp_coefs_data[], int32_T
  pp_coefs_size[2])
{
  int32_T nxm1;
  int32_T cpage;
  real_T dzzdx;
  real_T dzdxdx;
  int32_T loop_ub;
  nxm1 = *x_size - 2;
  pp_breaks_size[0] = 1;
  pp_breaks_size[1] = *x_size;
  if (0 <= *x_size - 1) {
    memcpy(&pp_breaks_data[0], &x_data[0], *x_size * sizeof(real_T));
  }

  cpage = s_size[1] - 1;
  pp_coefs_size[0] = s_size[1] - 1;
  pp_coefs_size[1] = 4;
  for (loop_ub = 0; loop_ub <= nxm1; loop_ub++) {
    dzzdx = (divdif_data[loop_ub] - s_data[loop_ub]) / dx_data[loop_ub];
    dzdxdx = (s_data[loop_ub + 1] - divdif_data[loop_ub]) / dx_data[loop_ub];
    pp_coefs_data[loop_ub] = (dzdxdx - dzzdx) / dx_data[loop_ub];
    pp_coefs_data[cpage + loop_ub] = 2.0 * dzzdx - dzdxdx;
    pp_coefs_data[(cpage << 1) + loop_ub] = s_data[loop_ub];
    pp_coefs_data[3 * cpage + loop_ub] = y_data[yoffset + loop_ub];
  }
}

static void AutomatedParki_degenerateSpline(const real_T x_data[], const int32_T
  *x_size, const real_T y_data[], const int32_T y_size[2], real_T
  pp_breaks_data[], int32_T pp_breaks_size[2], real_T pp_coefs_data[], int32_T
  pp_coefs_size[2])
{
  real_T c_data[4];
  real_T endslopes[2];
  real_T pp1_coefs[4];
  real_T d21;
  real_T dvdf1;
  int32_T nxm1;
  real_T divdifij;
  int32_T c_size_idx_1;
  real_T divdifij_tmp;
  if (*x_size <= 2) {
    if (*x_size + 2 == y_size[1]) {
      endslopes[0] = y_data[0];
      endslopes[1] = y_data[y_size[1] - 1];
      nxm1 = *x_size - 2;
      for (c_size_idx_1 = 0; c_size_idx_1 <= nxm1; c_size_idx_1++) {
        d21 = x_data[c_size_idx_1 + 1] - x_data[c_size_idx_1];
        divdifij_tmp = y_data[c_size_idx_1 + 1];
        divdifij = (y_data[c_size_idx_1 + 2] - divdifij_tmp) / d21;
        dvdf1 = (divdifij - endslopes[c_size_idx_1]) / d21;
        divdifij = (endslopes[1] - divdifij) / d21;
        pp1_coefs[c_size_idx_1] = (divdifij - dvdf1) / d21;
        pp1_coefs[c_size_idx_1 + 1] = 2.0 * dvdf1 - divdifij;
        pp1_coefs[c_size_idx_1 + 2] = endslopes[c_size_idx_1];
        pp1_coefs[3] = divdifij_tmp;
      }

      c_size_idx_1 = 4;
      memcpy(&c_data[0], &pp1_coefs[0], sizeof(real_T) << 2);
    } else {
      c_size_idx_1 = 2;
      c_data[0] = (y_data[1] - y_data[0]) / (x_data[1] - x_data[0]);
      c_data[1] = y_data[0];
    }

    pp_breaks_size[0] = 1;
    pp_breaks_size[1] = *x_size;
    if (0 <= *x_size - 1) {
      memcpy(&pp_breaks_data[0], &x_data[0], *x_size * sizeof(real_T));
    }

    pp_coefs_size[0] = 1;
    pp_coefs_size[1] = c_size_idx_1;
    nxm1 = c_size_idx_1 - 1;
    if (0 <= nxm1) {
      memcpy(&pp_coefs_data[0], &c_data[0], (nxm1 + 1) * sizeof(real_T));
    }
  } else {
    d21 = x_data[1] - x_data[0];
    dvdf1 = (y_data[1] - y_data[0]) / d21;
    c_data[0] = ((y_data[2] - y_data[1]) / (x_data[2] - x_data[1]) - dvdf1) /
      (x_data[2] - x_data[0]);
    c_data[1] = dvdf1 - c_data[0] * d21;
    c_data[2] = y_data[0];
    pp_breaks_size[0] = 1;
    pp_breaks_size[1] = 2;
    pp_breaks_data[0] = x_data[0];
    pp_breaks_data[1] = x_data[2];
    pp_coefs_size[0] = 1;
    pp_coefs_size[1] = 3;
    for (c_size_idx_1 = 0; c_size_idx_1 < 3; c_size_idx_1++) {
      pp_coefs_data[c_size_idx_1] = c_data[c_size_idx_1];
    }
  }
}

static void AutomatedParkingValet_spline(const real_T x_data[], const int32_T
  *x_size, const real_T y_data[], const int32_T *y_size, real_T
  output_breaks_data[], int32_T output_breaks_size[2], real_T output_coefs_data[],
  int32_T output_coefs_size[2])
{
  boolean_T has_endslopes;
  int32_T nxm1;
  int32_T yoffset;
  real_T s_data[102];
  real_T dvdf_data[101];
  real_T dx_data[198];
  real_T dnnm2;
  real_T md_data[199];
  real_T r;
  int32_T b_k;
  real_T f_coefs_data[4];
  real_T g_coefs_data[404];
  real_T y_data_0[102];
  int32_T s_size[2];
  int32_T g_coefs_size[2];
  real_T szs_idx_1;
  int32_T dvdf_data_tmp;
  real_T s_data_tmp;
  has_endslopes = (*x_size + 2 == *y_size);
  if ((*x_size <= 2) || ((*x_size <= 3) && (!has_endslopes))) {
    s_size[0] = 1;
    s_size[1] = *y_size;
    if (0 <= *y_size - 1) {
      memcpy(&y_data_0[0], &y_data[0], *y_size * sizeof(real_T));
    }

    AutomatedParki_degenerateSpline(x_data, x_size, y_data_0, s_size,
      output_breaks_data, output_breaks_size, f_coefs_data, g_coefs_size);
    output_coefs_size[0] = 1;
    output_coefs_size[1] = g_coefs_size[1];
    nxm1 = g_coefs_size[0] * g_coefs_size[1] - 1;
    if (0 <= nxm1) {
      memcpy(&output_coefs_data[0], &f_coefs_data[0], (nxm1 + 1) * sizeof(real_T));
    }
  } else {
    nxm1 = *x_size - 1;
    if (has_endslopes) {
      szs_idx_1 = (real_T)*y_size - 2.0;
      yoffset = 1;
    } else {
      szs_idx_1 = *y_size;
      yoffset = 0;
    }

    s_size[0] = 1;
    s_size[1] = (int32_T)szs_idx_1;
    for (b_k = 0; b_k < nxm1; b_k++) {
      szs_idx_1 = x_data[b_k + 1] - x_data[b_k];
      dvdf_data_tmp = yoffset + b_k;
      dvdf_data[b_k] = (y_data[dvdf_data_tmp + 1] - y_data[dvdf_data_tmp]) /
        szs_idx_1;
      dx_data[b_k] = szs_idx_1;
    }

    for (b_k = 2; b_k <= nxm1; b_k++) {
      s_data[b_k - 1] = (dx_data[b_k - 1] * dvdf_data[b_k - 2] + dx_data[b_k - 2]
                         * dvdf_data[b_k - 1]) * 3.0;
    }

    if (has_endslopes) {
      szs_idx_1 = 0.0;
      dnnm2 = 0.0;
      s_data[0] = dx_data[1] * y_data[0];
      s_data[*x_size - 1] = dx_data[*x_size - 3] * y_data[*x_size + 1];
    } else {
      szs_idx_1 = x_data[2] - x_data[0];
      dnnm2 = x_data[*x_size - 1] - x_data[*x_size - 3];
      s_data[0] = ((2.0 * szs_idx_1 + dx_data[0]) * dx_data[1] * dvdf_data[0] +
                   dx_data[0] * dx_data[0] * dvdf_data[1]) / szs_idx_1;
      s_data_tmp = dx_data[*x_size - 2];
      s_data[*x_size - 1] = ((s_data_tmp + 2.0 * dnnm2) * dx_data[*x_size - 3] *
        dvdf_data[*x_size - 2] + s_data_tmp * s_data_tmp * dvdf_data[*x_size - 3])
        / dnnm2;
    }

    md_data[0] = dx_data[1];
    s_data_tmp = dx_data[*x_size - 3];
    md_data[*x_size - 1] = s_data_tmp;
    for (b_k = 2; b_k <= nxm1; b_k++) {
      md_data[b_k - 1] = (dx_data[b_k - 1] + dx_data[b_k - 2]) * 2.0;
    }

    r = dx_data[1] / md_data[0];
    md_data[1] -= r * szs_idx_1;
    s_data[1] -= r * s_data[0];
    for (b_k = 3; b_k <= nxm1; b_k++) {
      r = dx_data[b_k - 1] / md_data[b_k - 2];
      md_data[b_k - 1] -= dx_data[b_k - 3] * r;
      s_data[b_k - 1] -= s_data[b_k - 2] * r;
    }

    r = dnnm2 / md_data[*x_size - 2];
    md_data[*x_size - 1] -= s_data_tmp * r;
    s_data[*x_size - 1] -= s_data[*x_size - 2] * r;
    s_data[*x_size - 1] /= md_data[*x_size - 1];
    for (b_k = nxm1; b_k >= 2; b_k--) {
      s_data[b_k - 1] = (s_data[b_k - 1] - dx_data[b_k - 2] * s_data[b_k]) /
        md_data[b_k - 1];
    }

    s_data[0] = (s_data[0] - szs_idx_1 * s_data[1]) / md_data[0];
    if (0 <= *y_size - 1) {
      memcpy(&y_data_0[0], &y_data[0], *y_size * sizeof(real_T));
    }

    AutomatedParkingValet_pwchcore(x_data, x_size, y_data_0, yoffset, s_data,
      s_size, dx_data, dvdf_data, output_breaks_data, output_breaks_size,
      g_coefs_data, g_coefs_size);
    output_coefs_size[0] = g_coefs_size[0];
    output_coefs_size[1] = 4;
    nxm1 = g_coefs_size[0] * g_coefs_size[1] - 1;
    if (0 <= nxm1) {
      memcpy(&output_coefs_data[0], &g_coefs_data[0], (nxm1 + 1) * sizeof(real_T));
    }
  }
}

static void AutomatedParkingValet_bsxfun(const real_T a_data[], const int32_T
  a_size[2], real_T c_data[], int32_T c_size[2])
{
  int32_T k;
  int32_T acoef;
  int32_T k_0;
  int32_T csz_idx_0;
  int32_T c_data_tmp;
  csz_idx_0 = a_size[0];
  c_size[0] = a_size[0];
  c_size[1] = 3;
  if (a_size[0] != 0) {
    acoef = (a_size[0] != 1);
    for (k = 0; k < 3; k++) {
      for (k_0 = 0; k_0 < csz_idx_0; k_0++) {
        c_data_tmp = a_size[0] * k;
        c_data[k_0 + c_data_tmp] = a_data[acoef * k_0 + c_data_tmp] * (3.0 -
          (real_T)k);
      }
    }
  }
}

static void Aut_fitSplineAndFirstDerivative(const real_T refPoses_data[], const
  int32_T refPoses_size[2], const real_T t_data[], const int32_T *t_size, real_T
  direction, real_T splineX_breaks_data[], int32_T splineX_breaks_size[2],
  real_T splineX_coefs_data[], int32_T splineX_coefs_size[2], real_T
  splineY_breaks_data[], int32_T splineY_breaks_size[2], real_T
  splineY_coefs_data[], int32_T splineY_coefs_size[2], real_T
  splineDx_breaks_data[], int32_T splineDx_breaks_size[2], real_T
  splineDx_coefs_data[], int32_T splineDx_coefs_size[3], real_T
  splineDy_breaks_data[], int32_T splineDy_breaks_size[2], real_T
  splineDy_coefs_data[], int32_T splineDy_coefs_size[3])
{
  real_T tmp_data[102];
  int32_T loop_ub;
  int32_T tmp_size[2];
  int32_T tmp_size_0;
  int32_T splineX_coefs_size_0[2];
  int32_T splineY_coefs_size_0[2];
  int32_T tmp_data_tmp;
  int32_T tmp_data_tmp_0;
  int32_T loop_ub_tmp;
  loop_ub = refPoses_size[0];
  tmp_size_0 = refPoses_size[0] + 2;
  tmp_data_tmp = refPoses_size[0] << 1;
  tmp_data[0] = cos(refPoses_data[tmp_data_tmp]) * direction;
  if (0 <= loop_ub - 1) {
    memcpy(&tmp_data[1], &refPoses_data[0], loop_ub * sizeof(real_T));
  }

  tmp_data_tmp_0 = (tmp_data_tmp + refPoses_size[0]) - 1;
  tmp_data[refPoses_size[0] + 1] = cos(refPoses_data[tmp_data_tmp_0]) *
    direction;
  AutomatedParkingValet_spline(t_data, t_size, tmp_data, &tmp_size_0,
    splineX_breaks_data, splineX_breaks_size, splineX_coefs_data,
    splineX_coefs_size);
  loop_ub = refPoses_size[0];
  tmp_size_0 = refPoses_size[0] + 2;
  tmp_data[0] = sin(refPoses_data[tmp_data_tmp]) * direction;
  for (tmp_data_tmp = 0; tmp_data_tmp < loop_ub; tmp_data_tmp++) {
    tmp_data[tmp_data_tmp + 1] = refPoses_data[tmp_data_tmp + refPoses_size[0]];
  }

  tmp_data[refPoses_size[0] + 1] = sin(refPoses_data[tmp_data_tmp_0]) *
    direction;
  AutomatedParkingValet_spline(t_data, t_size, tmp_data, &tmp_size_0,
    splineY_breaks_data, splineY_breaks_size, splineY_coefs_data,
    splineY_coefs_size);
  splineDx_breaks_size[0] = 1;
  splineDx_breaks_size[1] = *t_size;
  if (0 <= *t_size - 1) {
    memcpy(&splineDx_breaks_data[0], &t_data[0], *t_size * sizeof(real_T));
  }

  tmp_size_0 = *t_size - 1;
  loop_ub = *t_size - 1;
  splineX_coefs_size_0[0] = loop_ub;
  splineX_coefs_size_0[1] = 3;
  for (tmp_data_tmp = 0; tmp_data_tmp < 3; tmp_data_tmp++) {
    for (tmp_data_tmp_0 = 0; tmp_data_tmp_0 < loop_ub; tmp_data_tmp_0++) {
      AutomatedParkingValet_B.splineX_coefs_data[tmp_data_tmp_0 + loop_ub *
        tmp_data_tmp] = splineX_coefs_data[tmp_size_0 * tmp_data_tmp +
        tmp_data_tmp_0];
    }
  }

  AutomatedParkingValet_bsxfun(AutomatedParkingValet_B.splineX_coefs_data,
    splineX_coefs_size_0, AutomatedParkingValet_B.tmp_data, tmp_size);
  splineDx_coefs_size[0] = 1;
  splineDx_coefs_size[1] = *t_size - 1;
  splineDx_coefs_size[2] = 3;
  loop_ub_tmp = (*t_size - 1) * 3;
  if (0 <= loop_ub_tmp - 1) {
    memcpy(&splineDx_coefs_data[0], &AutomatedParkingValet_B.tmp_data[0],
           loop_ub_tmp * sizeof(real_T));
  }

  splineDy_breaks_size[0] = 1;
  splineDy_breaks_size[1] = *t_size;
  if (0 <= *t_size - 1) {
    memcpy(&splineDy_breaks_data[0], &t_data[0], *t_size * sizeof(real_T));
  }

  tmp_size_0 = *t_size - 1;
  loop_ub = *t_size - 1;
  splineY_coefs_size_0[0] = loop_ub;
  splineY_coefs_size_0[1] = 3;
  for (tmp_data_tmp = 0; tmp_data_tmp < 3; tmp_data_tmp++) {
    for (tmp_data_tmp_0 = 0; tmp_data_tmp_0 < loop_ub; tmp_data_tmp_0++) {
      AutomatedParkingValet_B.splineX_coefs_data[tmp_data_tmp_0 + loop_ub *
        tmp_data_tmp] = splineY_coefs_data[tmp_size_0 * tmp_data_tmp +
        tmp_data_tmp_0];
    }
  }

  AutomatedParkingValet_bsxfun(AutomatedParkingValet_B.splineX_coefs_data,
    splineY_coefs_size_0, AutomatedParkingValet_B.tmp_data, tmp_size);
  splineDy_coefs_size[0] = 1;
  splineDy_coefs_size[1] = *t_size - 1;
  splineDy_coefs_size[2] = 3;
  if (0 <= loop_ub_tmp - 1) {
    memcpy(&splineDy_coefs_data[0], &AutomatedParkingValet_B.tmp_data[0],
           loop_ub_tmp * sizeof(real_T));
  }
}

static void AutomatedParkingValet_linspace(real_T d2, real_T n1,
  emxArray_real_T_AutomatedPark_T *y)
{
  int32_T n;
  real_T delta1;
  int32_T d_k;
  if (n1 < 0.0) {
    n1 = 0.0;
  }

  n = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = (int32_T)floor(n1);
  Automa_emxEnsureCapacity_real_T(y, n);
  n = y->size[1];
  if (y->size[1] >= 1) {
    y->data[y->size[1] - 1] = d2;
    if (y->size[1] >= 2) {
      y->data[0] = 0.0;
      if (y->size[1] >= 3) {
        if ((0.0 == -d2) && (n > 2)) {
          for (d_k = 2; d_k < n; d_k++) {
            y->data[d_k - 1] = (real_T)(((d_k << 1) - n) - 1) / ((real_T)n - 1.0)
              * d2;
          }

          if ((n & 1) == 1) {
            y->data[n >> 1] = 0.0;
          }
        } else if ((d2 < 0.0) && (fabs(d2) > 8.9884656743115785E+307)) {
          delta1 = d2 / ((real_T)y->size[1] - 1.0);
          n = y->size[1] - 3;
          for (d_k = 0; d_k <= n; d_k++) {
            y->data[(int32_T)(((real_T)d_k + 1.0) + 1.0) - 1] = ((real_T)d_k +
              1.0) * delta1;
          }
        } else {
          delta1 = d2 / ((real_T)y->size[1] - 1.0);
          n = y->size[1] - 3;
          for (d_k = 0; d_k <= n; d_k++) {
            y->data[(int32_T)(((real_T)d_k + 1.0) + 1.0) - 1] = ((real_T)d_k +
              1.0) * delta1;
          }
        }
      }
    }
  }
}

static int32_T AutomatedParkingValet_bsearch(const real_T x_data[], const
  int32_T x_size[2], real_T xi)
{
  int32_T n;
  int32_T low_ip1;
  int32_T high_i;
  int32_T mid_i;
  n = 1;
  low_ip1 = 1;
  high_i = x_size[1];
  while (high_i > low_ip1 + 1) {
    mid_i = (n >> 1) + (high_i >> 1);
    if (((n & 1) == 1) && ((high_i & 1) == 1)) {
      mid_i++;
    }

    if (xi >= x_data[mid_i - 1]) {
      n = mid_i;
      low_ip1 = mid_i;
    } else {
      high_i = mid_i;
    }
  }

  return n;
}

static void AutomatedParkingValet_ppval(const real_T pp_breaks_data[], const
  int32_T pp_breaks_size[2], const real_T pp_coefs_data[], const int32_T
  pp_coefs_size[2], const real_T x_data[], const int32_T x_size[2], real_T
  v_data[], int32_T v_size[2])
{
  int32_T numTerms;
  int32_T nx;
  int32_T b_ix;
  real_T v;
  int32_T ip;
  real_T xloc;
  int32_T ic;
  numTerms = pp_coefs_size[1];
  v_size[0] = x_size[0];
  v_size[1] = x_size[1];
  nx = x_size[1] - 1;
  for (b_ix = 0; b_ix <= nx; b_ix++) {
    if (rtIsNaN(x_data[b_ix])) {
      v = x_data[b_ix];
    } else {
      ip = AutomatedParkingValet_bsearch(pp_breaks_data, pp_breaks_size,
        x_data[b_ix]) - 1;
      xloc = x_data[b_ix] - pp_breaks_data[ip];
      v = pp_coefs_data[ip];
      for (ic = 2; ic <= numTerms; ic++) {
        v = pp_coefs_data[(ic - 1) * (pp_breaks_size[1] - 1) + ip] + xloc * v;
      }
    }

    v_data[b_ix] = v;
  }
}

static void AutomatedParkingValet_ppval_p(const real_T pp_breaks_data[], const
  int32_T pp_breaks_size[2], const real_T pp_coefs_data[], const int32_T
  pp_coefs_size[3], const emxArray_real_T_AutomatedPark_T *x,
  emxArray_real_T_AutomatedPark_T *v)
{
  int32_T numTerms;
  int32_T nx;
  real_T v_0;
  int32_T ip;
  real_T xloc;
  int32_T ic;
  int32_T szv_idx_1;
  numTerms = pp_coefs_size[2];
  szv_idx_1 = x->size[1];
  ic = v->size[0] * v->size[1];
  v->size[0] = 1;
  v->size[1] = szv_idx_1;
  Automa_emxEnsureCapacity_real_T(v, ic);
  nx = x->size[1] - 1;
  for (szv_idx_1 = 0; szv_idx_1 <= nx; szv_idx_1++) {
    if (rtIsNaN(x->data[szv_idx_1])) {
      v_0 = x->data[szv_idx_1];
    } else {
      ip = AutomatedParkingValet_bsearch(pp_breaks_data, pp_breaks_size, x->
        data[szv_idx_1]) - 1;
      xloc = x->data[szv_idx_1] - pp_breaks_data[ip];
      v_0 = pp_coefs_data[ip];
      for (ic = 2; ic <= numTerms; ic++) {
        v_0 = pp_coefs_data[(ic - 1) * (pp_breaks_size[1] - 1) + ip] + xloc *
          v_0;
      }
    }

    v->data[szv_idx_1] = v_0;
  }
}

static void AutomatedParkingValet_atan2(const real_T y_data[], const int32_T
  y_size[2], const real_T x_data[], const int32_T x_size[2], real_T r_data[],
  int32_T r_size[2])
{
  real_T b_z1_data[500];
  int32_T nx;
  int32_T loop_ub;
  int32_T csz_idx_1;
  if (y_size[1] <= x_size[1]) {
    csz_idx_1 = y_size[1];
  } else {
    csz_idx_1 = x_size[1];
  }

  loop_ub = csz_idx_1 - 1;
  if (0 <= loop_ub) {
    memcpy(&b_z1_data[0], &r_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  nx = csz_idx_1 - 1;
  for (loop_ub = 0; loop_ub <= nx; loop_ub++) {
    b_z1_data[loop_ub] = rt_atan2d_snf(y_data[loop_ub], x_data[loop_ub]);
  }

  r_size[0] = 1;
  r_size[1] = csz_idx_1;
  loop_ub = csz_idx_1 - 1;
  if (0 <= loop_ub) {
    memcpy(&r_data[0], &b_z1_data[0], (loop_ub + 1) * sizeof(real_T));
  }
}

static void AutomatedParkingValet_mod(const real_T x_data[], const int32_T
  x_size[2], real_T r_data[], int32_T r_size[2])
{
  real_T b_z1_data[500];
  int32_T nx;
  real_T r;
  boolean_T rEQ0;
  real_T q;
  int32_T loop_ub;
  loop_ub = x_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&b_z1_data[0], &r_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  nx = x_size[1] - 1;
  for (loop_ub = 0; loop_ub <= nx; loop_ub++) {
    if (rtIsNaN(x_data[loop_ub]) || rtIsInf(x_data[loop_ub])) {
      r = (rtNaN);
    } else if (x_data[loop_ub] == 0.0) {
      r = 0.0;
    } else {
      r = fmod(x_data[loop_ub], 6.2831853071795862);
      rEQ0 = (r == 0.0);
      if (!rEQ0) {
        q = fabs(x_data[loop_ub] / 6.2831853071795862);
        rEQ0 = !(fabs(q - floor(q + 0.5)) > 2.2204460492503131E-16 * q);
      }

      if (rEQ0) {
        r = 0.0;
      } else {
        if (x_data[loop_ub] < 0.0) {
          r += 6.2831853071795862;
        }
      }
    }

    b_z1_data[loop_ub] = r;
  }

  r_size[0] = 1;
  r_size[1] = x_size[1];
  loop_ub = x_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&r_data[0], &b_z1_data[0], (loop_ub + 1) * sizeof(real_T));
  }
}

static void Automa_angleUtilities_wrapTo2Pi(const real_T theta_data[], const
  int32_T theta_size[2], real_T b_theta_data[], int32_T b_theta_size[2])
{
  int32_T i;
  int32_T loop_ub;
  AutomatedParkingValet_mod(theta_data, theta_size, b_theta_data, b_theta_size);
  i = b_theta_size[0] * b_theta_size[1];
  b_theta_size[0] = 1;
  loop_ub = i - 1;
  for (i = 0; i <= loop_ub; i++) {
    b_theta_data[i] += (real_T)((b_theta_data[i] == 0.0) && (theta_data[i] > 0.0))
      * 6.2831853071795862;
  }
}

static void AutomatedParki_interpolatePoses(const real_T splineX_breaks_data[],
  const int32_T splineX_breaks_size[2], const real_T splineX_coefs_data[], const
  int32_T splineX_coefs_size[2], const real_T splineY_breaks_data[], const
  int32_T splineY_breaks_size[2], const real_T splineY_coefs_data[], const
  int32_T splineY_coefs_size[2], const real_T splineDx_breaks_data[], const
  int32_T splineDx_breaks_size[2], const real_T splineDx_coefs_data[], const
  int32_T splineDx_coefs_size[3], const real_T splineDy_breaks_data[], const
  int32_T splineDy_breaks_size[2], const real_T splineDy_coefs_data[], const
  int32_T splineDy_coefs_size[3], const real_T tQuery_data[], const int32_T
  tQuery_size[2], real_T direction, real_T poses_data[], int32_T poses_size[2])
{
  real_T x_data[500];
  real_T y_data[500];
  real_T theta_data[500];
  real_T y;
  emxArray_real_T_AutomatedPark_T *tmp;
  emxArray_real_T_AutomatedPark_T *tmp_0;
  int32_T loop_ub;
  int32_T loop_ub_0;
  real_T theta_data_0[500];
  int32_T i;
  int32_T loop_ub_1;
  int32_T x_size[2];
  int32_T y_size[2];
  int32_T theta_size[2];
  int32_T theta_size_0[2];
  emxArray_real_T_AutomatedPark_T tQuery_data_0;
  emxArray_real_T_AutomatedPark_T tQuery_data_1;
  AutomatedParking_emxInit_real_T(&tmp, 2);
  AutomatedParking_emxInit_real_T(&tmp_0, 2);
  AutomatedParkingValet_ppval(splineX_breaks_data, splineX_breaks_size,
    splineX_coefs_data, splineX_coefs_size, tQuery_data, tQuery_size, x_data,
    x_size);
  AutomatedParkingValet_ppval(splineY_breaks_data, splineY_breaks_size,
    splineY_coefs_data, splineY_coefs_size, tQuery_data, tQuery_size, y_data,
    y_size);
  y = (real_T)(direction == -1.0) * 3.1415926535897931;
  tQuery_data_0.data = (real_T *)&tQuery_data[0];
  tQuery_data_0.size = (int32_T *)&tQuery_size[0];
  tQuery_data_0.allocatedSize = -1;
  tQuery_data_0.numDimensions = 2;
  tQuery_data_0.canFreeData = false;
  AutomatedParkingValet_ppval_p(splineDy_breaks_data, splineDy_breaks_size,
    splineDy_coefs_data, splineDy_coefs_size, &tQuery_data_0, tmp);
  tQuery_data_1.data = (real_T *)&tQuery_data[0];
  tQuery_data_1.size = (int32_T *)&tQuery_size[0];
  tQuery_data_1.allocatedSize = -1;
  tQuery_data_1.numDimensions = 2;
  tQuery_data_1.canFreeData = false;
  AutomatedParkingValet_ppval_p(splineDx_breaks_data, splineDx_breaks_size,
    splineDx_coefs_data, splineDx_coefs_size, &tQuery_data_1, tmp_0);
  AutomatedParkingValet_atan2(tmp->data, tmp->size, tmp_0->data, tmp_0->size,
    theta_data, theta_size);
  theta_size_0[0] = 1;
  theta_size_0[1] = theta_size[1];
  loop_ub_1 = theta_size[0] * theta_size[1];
  AutomatedParking_emxFree_real_T(&tmp_0);
  AutomatedParking_emxFree_real_T(&tmp);
  for (i = 0; i < loop_ub_1; i++) {
    theta_data_0[i] = theta_data[i] - y;
  }

  Automa_angleUtilities_wrapTo2Pi(theta_data_0, theta_size_0, theta_data,
    theta_size);
  poses_size[0] = x_size[1];
  poses_size[1] = 3;
  loop_ub_1 = x_size[1];
  loop_ub = y_size[1];
  loop_ub_0 = theta_size[1] - 1;
  if (0 <= loop_ub_1 - 1) {
    memcpy(&poses_data[0], &x_data[0], loop_ub_1 * sizeof(real_T));
  }

  for (i = 0; i < loop_ub; i++) {
    poses_data[i + loop_ub_1] = y_data[i];
  }

  for (i = 0; i <= loop_ub_0; i++) {
    poses_data[(i + loop_ub_1) + loop_ub] = theta_data[i];
  }
}

static real_T AutomatedParkingValet_sum_p(const real_T x_data[], const int32_T
  *x_size)
{
  real_T y;
  int32_T vlen;
  int32_T k;
  vlen = *x_size;
  if ((*x_size == 0) || (*x_size == 0)) {
    y = 0.0;
  } else {
    y = x_data[0];
    for (k = 2; k <= vlen; k++) {
      y += x_data[k - 1];
    }
  }

  return y;
}

static void AutomatedParkingValet_power_pm(const emxArray_real_T_AutomatedPark_T
  *a, emxArray_real_T_AutomatedPark_T *y)
{
  emxArray_real_T_AutomatedPark_T *b_z1;
  int32_T nx;
  int32_T b_k;
  AutomatedParking_emxInit_real_T(&b_z1, 2);
  b_k = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = a->size[1];
  Automa_emxEnsureCapacity_real_T(y, b_k);
  b_k = b_z1->size[0] * b_z1->size[1];
  b_z1->size[0] = 1;
  b_z1->size[1] = y->size[1];
  Automa_emxEnsureCapacity_real_T(b_z1, b_k);
  nx = y->size[0] * y->size[1] - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    b_z1->data[b_k] = y->data[b_k];
  }

  nx = a->size[1] - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    b_z1->data[b_k] = a->data[b_k] * a->data[b_k];
  }

  b_k = y->size[0] * y->size[1];
  y->size[0] = 1;
  y->size[1] = b_z1->size[1];
  Automa_emxEnsureCapacity_real_T(y, b_k);
  nx = b_z1->size[0] * b_z1->size[1] - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    y->data[b_k] = b_z1->data[b_k];
  }

  AutomatedParking_emxFree_real_T(&b_z1);
}

static void AutomatedParkingValet_sqrt_pmh(const emxArray_real_T_AutomatedPark_T
  *x, emxArray_real_T_AutomatedPark_T *b_x)
{
  int32_T nx;
  int32_T b_k;
  b_k = b_x->size[0] * b_x->size[1];
  b_x->size[0] = 1;
  b_x->size[1] = x->size[1];
  Automa_emxEnsureCapacity_real_T(b_x, b_k);
  nx = x->size[0] * x->size[1] - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    b_x->data[b_k] = x->data[b_k];
  }

  nx = x->size[1] - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    b_x->data[b_k] = sqrt(b_x->data[b_k]);
  }
}

static void AutomatedParkingValet_cumtrapz(const emxArray_real_T_AutomatedPark_T
  *x, emxArray_real_T_AutomatedPark_T *z)
{
  int32_T iystart;
  real_T s;
  real_T ylast;
  int32_T i;
  int32_T c;
  int32_T k;
  i = z->size[0] * z->size[1];
  z->size[0] = 1;
  z->size[1] = x->size[1];
  Automa_emxEnsureCapacity_real_T(z, i);
  if (x->size[1] != 0) {
    iystart = -1;
    for (i = 0; i < 1; i++) {
      iystart++;
      s = 0.0;
      ylast = x->data[iystart];
      z->data[iystart] = 0.0;
      c = x->size[1] - 2;
      for (k = 0; k <= c; k++) {
        iystart++;
        s += (ylast + x->data[iystart]) / 2.0;
        ylast = x->data[iystart];
        z->data[iystart] = s;
      }
    }
  }
}

static void Aut_computeCumulativePathLength(const real_T splineDx_breaks_data[],
  const int32_T splineDx_breaks_size[2], const real_T splineDx_coefs_data[],
  const int32_T splineDx_coefs_size[3], const real_T splineDy_breaks_data[],
  const int32_T splineDy_breaks_size[2], const real_T splineDy_coefs_data[],
  const int32_T splineDy_coefs_size[3], const real_T tQuery_data[], const
  int32_T tQuery_size[2], real_T cumLengths_data[], int32_T cumLengths_size[2])
{
  real_T tSpacing;
  real_T stepSize;
  emxArray_real_T_AutomatedPark_T *tInteg;
  real_T y_data[499];
  emxArray_real_T_AutomatedPark_T *tmp;
  emxArray_real_T_AutomatedPark_T *tmp_0;
  emxArray_real_T_AutomatedPark_T *tmp_1;
  int32_T tmp_data[500];
  int32_T loop_ub;
  int32_T i;
  int32_T y_size_idx_1;
  AutomatedParking_emxInit_real_T(&tInteg, 2);
  AutomatedParking_emxInit_real_T(&tmp, 2);
  AutomatedParking_emxInit_real_T(&tmp_0, 2);
  AutomatedParking_emxInit_real_T(&tmp_1, 2);
  tSpacing = tQuery_data[1] - tQuery_data[0];
  stepSize = tSpacing / fmax(ceil(tSpacing / 0.01), 10.0);
  tSpacing = rt_roundd_snf(tSpacing / stepSize);
  AutomatedParkingValet_linspace(tQuery_data[tQuery_size[1] - 1], tSpacing *
    ((real_T)tQuery_size[1] - 1.0) + 1.0, tInteg);
  AutomatedParkingValet_ppval_p(splineDx_breaks_data, splineDx_breaks_size,
    splineDx_coefs_data, splineDx_coefs_size, tInteg, tmp);
  AutomatedParkingValet_power_pm(tmp, tmp_0);
  AutomatedParkingValet_ppval_p(splineDy_breaks_data, splineDy_breaks_size,
    splineDy_coefs_data, splineDy_coefs_size, tInteg, tmp);
  AutomatedParkingValet_power_pm(tmp, tInteg);
  i = tmp_1->size[0] * tmp_1->size[1];
  tmp_1->size[0] = 1;
  tmp_1->size[1] = tmp_0->size[1];
  Automa_emxEnsureCapacity_real_T(tmp_1, i);
  loop_ub = tmp_0->size[0] * tmp_0->size[1];
  for (i = 0; i < loop_ub; i++) {
    tmp_1->data[i] = tmp_0->data[i] + tInteg->data[i];
  }

  AutomatedParking_emxFree_real_T(&tmp_0);
  AutomatedParkingValet_sqrt_pmh(tmp_1, tmp);
  AutomatedParkingValet_cumtrapz(tmp, tInteg);
  i = tInteg->size[0] * tInteg->size[1];
  loop_ub = tInteg->size[0] * tInteg->size[1];
  tInteg->size[0] = 1;
  Automa_emxEnsureCapacity_real_T(tInteg, loop_ub);
  loop_ub = i - 1;
  AutomatedParking_emxFree_real_T(&tmp_1);
  AutomatedParking_emxFree_real_T(&tmp);
  for (i = 0; i <= loop_ub; i++) {
    tInteg->data[i] *= stepSize;
  }

  if ((real_T)tQuery_size[1] - 1.0 < 1.0) {
    y_size_idx_1 = 0;
  } else {
    loop_ub = (int32_T)(((real_T)tQuery_size[1] - 1.0) - 1.0);
    y_size_idx_1 = loop_ub + 1;
    for (i = 0; i <= loop_ub; i++) {
      y_data[i] = (real_T)i + 1.0;
    }
  }

  cumLengths_size[0] = 1;
  cumLengths_size[1] = y_size_idx_1 + 1;
  loop_ub = y_size_idx_1 - 1;
  y_size_idx_1 = loop_ub + 2;
  tmp_data[0] = 0;
  for (i = 0; i <= loop_ub; i++) {
    tmp_data[i + 1] = (int32_T)(tSpacing * y_data[i] + 1.0) - 1;
  }

  for (i = 0; i < y_size_idx_1; i++) {
    cumLengths_data[i] = tInteg->data[tmp_data[i]];
  }

  AutomatedParking_emxFree_real_T(&tInteg);
}

static void AutomatedParkingValet_bsxfun_p(const real_T a_data[], const int32_T
  a_size[2], real_T c_data[], int32_T c_size[2])
{
  int32_T acoef;
  int32_T d;
  int32_T k;
  c_size[0] = a_size[0];
  c_size[1] = 2;
  acoef = (a_size[0] != 1);
  d = a_size[0];
  for (k = 0; k < d; k++) {
    c_data[k] = a_data[acoef * k] * 2.0;
  }

  acoef = (a_size[0] != 1);
  d = a_size[0];
  for (k = 0; k < d; k++) {
    c_data[k + a_size[0]] = a_data[acoef * k + a_size[0]];
  }
}

static void AutomatedParkingValet_power_pmh(const real_T a_data[], const int32_T
  a_size[2], real_T y_data[], int32_T y_size[2])
{
  real_T b_z1_data[500];
  int32_T nx;
  int32_T loop_ub;
  loop_ub = a_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&b_z1_data[0], &y_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  nx = a_size[1] - 1;
  for (loop_ub = 0; loop_ub <= nx; loop_ub++) {
    b_z1_data[loop_ub] = rt_powd_snf(a_data[loop_ub], 1.5);
  }

  y_size[0] = 1;
  y_size[1] = a_size[1];
  loop_ub = a_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&y_data[0], &b_z1_data[0], (loop_ub + 1) * sizeof(real_T));
  }
}

static void Automated_computePathCurvatures(const real_T splineDx_breaks_data[],
  const int32_T splineDx_breaks_size[2], const real_T splineDx_coefs_data[],
  const int32_T splineDx_coefs_size[3], const real_T splineDy_breaks_data[],
  const int32_T splineDy_breaks_size[2], const real_T splineDy_coefs_data[],
  const int32_T splineDy_coefs_size[3], const real_T tQuery_data[], const
  int32_T tQuery_size[2], real_T curvatures_data[], int32_T curvatures_size[2])
{
  int32_T b;
  int32_T b_0;
  emxArray_real_T_AutomatedPark_T *curvatures_tmp;
  emxArray_real_T_AutomatedPark_T *curvatures_tmp_0;
  real_T tmp_data[396];
  emxArray_real_T_AutomatedPark_T *tmp;
  emxArray_real_T_AutomatedPark_T *tmp_0;
  emxArray_real_T_AutomatedPark_T *tmp_1;
  emxArray_real_T_AutomatedPark_T *tmp_2;
  real_T splineDy_coefs_data_0[396];
  int32_T tmp_3[3];
  real_T splineDx_breaks_data_0[199];
  real_T tmp_data_0[500];
  int32_T tmp_size[2];
  int32_T splineDy_coefs_size_0[2];
  int32_T splineDx_breaks_size_0[2];
  int32_T splineDx_coefs_size_0[2];
  int32_T splineDx_breaks_size_1[2];
  int32_T tmp_size_0[2];
  emxArray_real_T_AutomatedPark_T tQuery_data_0;
  emxArray_real_T_AutomatedPark_T tQuery_data_1;
  emxArray_real_T_AutomatedPark_T tQuery_data_2;
  emxArray_real_T_AutomatedPark_T tQuery_data_3;
  int32_T i;
  real_T curvatures_data_0;
  AutomatedParking_emxInit_real_T(&curvatures_tmp, 2);
  AutomatedParking_emxInit_real_T(&curvatures_tmp_0, 2);
  b = splineDx_coefs_size[1] * 3 / 3;
  b_0 = splineDy_coefs_size[1] * 3 / 3;
  tQuery_data_0.data = (real_T *)&tQuery_data[0];
  tQuery_data_0.size = (int32_T *)&tQuery_size[0];
  tQuery_data_0.allocatedSize = -1;
  tQuery_data_0.numDimensions = 2;
  tQuery_data_0.canFreeData = false;
  AutomatedParkingValet_ppval_p(splineDx_breaks_data, splineDx_breaks_size,
    splineDx_coefs_data, splineDx_coefs_size, &tQuery_data_0, curvatures_tmp);
  tQuery_data_1.data = (real_T *)&tQuery_data[0];
  tQuery_data_1.size = (int32_T *)&tQuery_size[0];
  tQuery_data_1.allocatedSize = -1;
  tQuery_data_1.numDimensions = 2;
  tQuery_data_1.canFreeData = false;
  AutomatedParkingValet_ppval_p(splineDy_breaks_data, splineDy_breaks_size,
    splineDy_coefs_data, splineDy_coefs_size, &tQuery_data_1, curvatures_tmp_0);
  splineDy_coefs_size_0[0] = b_0;
  splineDy_coefs_size_0[1] = 2;
  for (i = 0; i < b_0; i++) {
    splineDy_coefs_data_0[i] = splineDy_coefs_data[i];
    splineDy_coefs_data_0[i + b_0] = splineDy_coefs_data[i +
      splineDy_coefs_size[1]];
  }

  AutomatedParkingValet_bsxfun_p(splineDy_coefs_data_0, splineDy_coefs_size_0,
    tmp_data, tmp_size);
  i = splineDx_breaks_size[1];
  tmp_3[0] = 1;
  tmp_3[1] = splineDx_breaks_size[1] - 1;
  tmp_3[2] = 2;
  splineDx_breaks_size_0[0] = 1;
  splineDx_breaks_size_0[1] = splineDx_breaks_size[1];
  if (0 <= i - 1) {
    memcpy(&splineDx_breaks_data_0[0], &splineDx_breaks_data[0], i * sizeof
           (real_T));
  }

  AutomatedParking_emxInit_real_T(&tmp, 2);
  tQuery_data_2.data = (real_T *)&tQuery_data[0];
  tQuery_data_2.size = (int32_T *)&tQuery_size[0];
  tQuery_data_2.allocatedSize = -1;
  tQuery_data_2.numDimensions = 2;
  tQuery_data_2.canFreeData = false;
  AutomatedParkingValet_ppval_p(splineDx_breaks_data_0, splineDx_breaks_size_0,
    tmp_data, tmp_3, &tQuery_data_2, tmp);
  splineDx_coefs_size_0[0] = b;
  splineDx_coefs_size_0[1] = 2;
  for (i = 0; i < b; i++) {
    splineDy_coefs_data_0[i] = splineDx_coefs_data[i];
    splineDy_coefs_data_0[i + b] = splineDx_coefs_data[i + splineDx_coefs_size[1]];
  }

  AutomatedParkingValet_bsxfun_p(splineDy_coefs_data_0, splineDx_coefs_size_0,
    tmp_data, tmp_size);
  i = splineDx_breaks_size[1];
  tmp_3[0] = 1;
  tmp_3[1] = splineDx_breaks_size[1] - 1;
  tmp_3[2] = 2;
  splineDx_breaks_size_1[0] = 1;
  splineDx_breaks_size_1[1] = splineDx_breaks_size[1];
  if (0 <= i - 1) {
    memcpy(&splineDx_breaks_data_0[0], &splineDx_breaks_data[0], i * sizeof
           (real_T));
  }

  AutomatedParking_emxInit_real_T(&tmp_0, 2);
  AutomatedParking_emxInit_real_T(&tmp_1, 2);
  AutomatedParking_emxInit_real_T(&tmp_2, 2);
  tQuery_data_3.data = (real_T *)&tQuery_data[0];
  tQuery_data_3.size = (int32_T *)&tQuery_size[0];
  tQuery_data_3.allocatedSize = -1;
  tQuery_data_3.numDimensions = 2;
  tQuery_data_3.canFreeData = false;
  AutomatedParkingValet_ppval_p(splineDx_breaks_data_0, splineDx_breaks_size_1,
    tmp_data, tmp_3, &tQuery_data_3, tmp_0);
  AutomatedParkingValet_power_pm(curvatures_tmp, tmp_1);
  AutomatedParkingValet_power_pm(curvatures_tmp_0, tmp_2);
  tmp_size_0[0] = 1;
  tmp_size_0[1] = tmp_1->size[1];
  b = tmp_1->size[0] * tmp_1->size[1];
  for (i = 0; i < b; i++) {
    tmp_data_0[i] = tmp_1->data[i] + tmp_2->data[i];
  }

  AutomatedParking_emxFree_real_T(&tmp_2);
  AutomatedParking_emxFree_real_T(&tmp_1);
  AutomatedParkingValet_power_pmh(tmp_data_0, tmp_size_0, curvatures_data,
    curvatures_size);
  i = curvatures_tmp->size[0] * curvatures_tmp->size[1];
  curvatures_size[0] = 1;
  curvatures_size[1] = curvatures_tmp->size[1];
  b = i - 1;
  for (i = 0; i <= b; i++) {
    curvatures_data_0 = (curvatures_tmp->data[i] * tmp->data[i] -
                         curvatures_tmp_0->data[i] * tmp_0->data[i]) /
      curvatures_data[i];
    curvatures_data[i] = curvatures_data_0;
  }

  AutomatedParking_emxFree_real_T(&tmp_0);
  AutomatedParking_emxFree_real_T(&tmp);
  AutomatedParking_emxFree_real_T(&curvatures_tmp_0);
  AutomatedParking_emxFree_real_T(&curvatures_tmp);
}

static void AutomatedParki_smoothPathSpline(real_T refPoses_data[], int32_T
  refPoses_size[2], const real_T refDirections_data[], const int32_T
  *refDirections_size, real_T poses[1500], real_T directions[500], real_T
  varargout_1[500], real_T varargout_2[500])
{
  real_T cumChordLength_data[199];
  real_T chordLengthOfSegments_data[100];
  real_T numPosesSeg_data[100];
  real_T tQuery_data[500];
  real_T endIdx;
  real_T startIdx;
  real_T b_refPoses_data[300];
  real_T b_refDirections_data[100];
  real_T segStartIdx_data[100];
  real_T segEndIdx_data[100];
  real_T splineX_breaks_data[199];
  real_T splineX_coefs_data[404];
  real_T splineY_breaks_data[199];
  real_T splineY_coefs_data[404];
  real_T splineDx_breaks_data[199];
  real_T splineDy_breaks_data[199];
  int32_T d;
  int32_T b_j;
  int32_T g;
  int32_T h;
  int32_T l;
  emxArray_real_T_AutomatedPark_T *tmp;
  int32_T loop_ub;
  real_T cumChordLength_data_0[199];
  real_T numPosesSeg_data_0[100];
  real_T tmp_data[500];
  int32_T loop_ub_0;
  int32_T loop_ub_1;
  int32_T tQuery_size[2];
  int32_T posesSeg_size[2];
  int32_T b_refPoses_size[2];
  int32_T b_refDirections_size;
  int32_T segStartIdx_size;
  int32_T segEndIdx_size;
  int32_T splineX_breaks_size[2];
  int32_T splineX_coefs_size[2];
  int32_T splineY_breaks_size[2];
  int32_T splineY_coefs_size[2];
  int32_T splineDx_coefs_size[3];
  int32_T splineDy_coefs_size[3];
  int32_T refPoses_size_0[2];
  int32_T refPoses_size_1[2];
  int32_T refPoses_size_tmp;
  AutomatedParkingVal_filterPoses(refPoses_data, refPoses_size,
    refDirections_data, refDirections_size, b_refPoses_data, b_refPoses_size,
    b_refDirections_data, &b_refDirections_size);
  refPoses_size[0] = b_refPoses_size[0];
  loop_ub = b_refPoses_size[0] * b_refPoses_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&refPoses_data[0], &b_refPoses_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  getSegmentBoundaryPointIndex_p(b_refDirections_data, &b_refDirections_size,
    segStartIdx_data, &segStartIdx_size, segEndIdx_data, &segEndIdx_size);
  loop_ub = b_refPoses_size[0];
  for (segEndIdx_size = 0; segEndIdx_size < loop_ub; segEndIdx_size++) {
    refPoses_data[segEndIdx_size + (refPoses_size[0] << 1)] = b_refPoses_data
      [(b_refPoses_size[0] << 1) + segEndIdx_size] * 0.017453292519943295;
  }

  memset(&poses[0], 0, 1500U * sizeof(real_T));
  memset(&directions[0], 0, 500U * sizeof(real_T));
  loop_ub = (int32_T)(((real_T)b_refPoses_size[0] + (real_T)segStartIdx_size) -
                      1.0);
  if (0 <= loop_ub - 1) {
    memset(&cumChordLength_data[0], 0, loop_ub * sizeof(real_T));
  }

  memset(&varargout_1[0], 0, 500U * sizeof(real_T));
  memset(&varargout_2[0], 0, 500U * sizeof(real_T));
  d = segStartIdx_size - 1;
  if (0 <= d) {
    loop_ub_0 = b_refPoses_size[1];
    refPoses_size_0[1] = b_refPoses_size[1];
  }

  for (b_j = 0; b_j <= d; b_j++) {
    if (segStartIdx_data[b_j] > segEndIdx_data[b_j]) {
      h = 0;
      g = -1;
    } else {
      h = (int32_T)segStartIdx_data[b_j] - 1;
      g = (int32_T)segEndIdx_data[b_j] - 1;
    }

    endIdx = (((real_T)b_j + 1.0) + segStartIdx_data[b_j]) - 1.0;
    startIdx = (((real_T)b_j + 1.0) + segEndIdx_data[b_j]) - 1.0;
    if (endIdx > startIdx) {
      loop_ub = 0;
      l = 0;
    } else {
      loop_ub = (int32_T)endIdx - 1;
      l = (int32_T)startIdx;
    }

    refPoses_size_tmp = g - h;
    refPoses_size_0[0] = refPoses_size_tmp + 1;
    for (segEndIdx_size = 0; segEndIdx_size < loop_ub_0; segEndIdx_size++) {
      for (b_refDirections_size = 0; b_refDirections_size <= refPoses_size_tmp;
           b_refDirections_size++) {
        b_refPoses_data[b_refDirections_size + refPoses_size_0[0] *
          segEndIdx_size] = refPoses_data[(h + b_refDirections_size) +
          refPoses_size[0] * segEndIdx_size];
      }
    }

    Au_computeCumulativeChordLength(b_refPoses_data, refPoses_size_0,
      numPosesSeg_data, &b_refDirections_size);
    b_refDirections_size = l - loop_ub;
    for (segEndIdx_size = 0; segEndIdx_size < b_refDirections_size;
         segEndIdx_size++) {
      cumChordLength_data[loop_ub + segEndIdx_size] =
        numPosesSeg_data[segEndIdx_size];
    }

    chordLengthOfSegments_data[b_j] = cumChordLength_data[(int32_T)startIdx - 1];
  }

  Automa_setSegmentNumSmoothPoses(chordLengthOfSegments_data, &segStartIdx_size,
    numPosesSeg_data, &b_refDirections_size);
  AutomatedParking_emxInit_real_T(&tmp, 2);
  if (0 <= d) {
    loop_ub_1 = b_refPoses_size[1];
    refPoses_size_1[1] = b_refPoses_size[1];
    tQuery_size[0] = 1;
  }

  for (b_j = 0; b_j <= d; b_j++) {
    endIdx = (((real_T)b_j + 1.0) + segStartIdx_data[b_j]) - 1.0;
    startIdx = (((real_T)b_j + 1.0) + segEndIdx_data[b_j]) - 1.0;
    if (endIdx > startIdx) {
      h = 0;
      g = -1;
    } else {
      h = (int32_T)endIdx - 1;
      g = (int32_T)startIdx - 1;
    }

    if (segStartIdx_data[b_j] > segEndIdx_data[b_j]) {
      loop_ub = 0;
      l = -1;
    } else {
      loop_ub = (int32_T)segStartIdx_data[b_j] - 1;
      l = (int32_T)segEndIdx_data[b_j] - 1;
    }

    refPoses_size_tmp = l - loop_ub;
    refPoses_size_1[0] = refPoses_size_tmp + 1;
    for (segEndIdx_size = 0; segEndIdx_size < loop_ub_1; segEndIdx_size++) {
      for (b_refDirections_size = 0; b_refDirections_size <= refPoses_size_tmp;
           b_refDirections_size++) {
        b_refPoses_data[b_refDirections_size + refPoses_size_1[0] *
          segEndIdx_size] = refPoses_data[(loop_ub + b_refDirections_size) +
          refPoses_size[0] * segEndIdx_size];
      }
    }

    b_refDirections_size = g - h;
    segStartIdx_size = b_refDirections_size + 1;
    for (segEndIdx_size = 0; segEndIdx_size <= b_refDirections_size;
         segEndIdx_size++) {
      cumChordLength_data_0[segEndIdx_size] = cumChordLength_data[h +
        segEndIdx_size];
    }

    Aut_fitSplineAndFirstDerivative(b_refPoses_data, refPoses_size_1,
      cumChordLength_data_0, &segStartIdx_size, b_refDirections_data[(int32_T)
      segEndIdx_data[b_j] - 1], splineX_breaks_data, splineX_breaks_size,
      splineX_coefs_data, splineX_coefs_size, splineY_breaks_data,
      splineY_breaks_size, splineY_coefs_data, splineY_coefs_size,
      splineDx_breaks_data, b_refPoses_size,
      AutomatedParkingValet_B.splineDx_coefs_data, splineDx_coefs_size,
      splineDy_breaks_data, refPoses_size_0,
      AutomatedParkingValet_B.splineDy_coefs_data, splineDy_coefs_size);
    AutomatedParkingValet_linspace(chordLengthOfSegments_data[b_j],
      numPosesSeg_data[b_j], tmp);
    tQuery_size[1] = tmp->size[1];
    loop_ub = tmp->size[0] * tmp->size[1];
    for (segEndIdx_size = 0; segEndIdx_size < loop_ub; segEndIdx_size++) {
      tQuery_data[segEndIdx_size] = tmp->data[segEndIdx_size];
    }

    AutomatedParki_interpolatePoses(splineX_breaks_data, splineX_breaks_size,
      splineX_coefs_data, splineX_coefs_size, splineY_breaks_data,
      splineY_breaks_size, splineY_coefs_data, splineY_coefs_size,
      splineDx_breaks_data, b_refPoses_size,
      AutomatedParkingValet_B.splineDx_coefs_data, splineDx_coefs_size,
      splineDy_breaks_data, refPoses_size_0,
      AutomatedParkingValet_B.splineDy_coefs_data, splineDy_coefs_size,
      tQuery_data, tQuery_size, b_refDirections_data[(int32_T)segEndIdx_data[b_j]
      - 1], AutomatedParkingValet_B.posesSeg_data, posesSeg_size);
    b_refDirections_size = b_j + 1;
    for (segEndIdx_size = 0; segEndIdx_size <= b_j; segEndIdx_size++) {
      numPosesSeg_data_0[segEndIdx_size] = numPosesSeg_data[segEndIdx_size];
    }

    endIdx = AutomatedParkingValet_sum_p(numPosesSeg_data_0,
      &b_refDirections_size);
    startIdx = (endIdx - numPosesSeg_data[b_j]) + 1.0;
    if (startIdx > endIdx) {
      h = 0;
    } else {
      h = (int32_T)startIdx - 1;
    }

    Aut_computeCumulativePathLength(splineDx_breaks_data, b_refPoses_size,
      AutomatedParkingValet_B.splineDx_coefs_data, splineDx_coefs_size,
      splineDy_breaks_data, refPoses_size_0,
      AutomatedParkingValet_B.splineDy_coefs_data, splineDy_coefs_size,
      tQuery_data, tQuery_size, tmp_data, splineX_breaks_size);
    loop_ub = splineX_breaks_size[1];
    for (segEndIdx_size = 0; segEndIdx_size < loop_ub; segEndIdx_size++) {
      varargout_1[h + segEndIdx_size] = tmp_data[segEndIdx_size];
    }

    if (startIdx > endIdx) {
      h = 0;
      g = 0;
    } else {
      h = (int32_T)startIdx - 1;
      g = (int32_T)endIdx;
    }

    Automated_computePathCurvatures(splineDx_breaks_data, b_refPoses_size,
      AutomatedParkingValet_B.splineDx_coefs_data, splineDx_coefs_size,
      splineDy_breaks_data, refPoses_size_0,
      AutomatedParkingValet_B.splineDy_coefs_data, splineDy_coefs_size,
      tQuery_data, tQuery_size, tmp_data, splineX_breaks_size);
    b_refDirections_size = g - h;
    for (segEndIdx_size = 0; segEndIdx_size < b_refDirections_size;
         segEndIdx_size++) {
      varargout_2[h + segEndIdx_size] = tmp_data[segEndIdx_size];
    }

    if (startIdx > endIdx) {
      h = 0;
    } else {
      h = (int32_T)startIdx - 1;
    }

    loop_ub = posesSeg_size[0];
    for (segEndIdx_size = 0; segEndIdx_size < 3; segEndIdx_size++) {
      for (b_refDirections_size = 0; b_refDirections_size < loop_ub;
           b_refDirections_size++) {
        poses[(h + b_refDirections_size) + 500 * segEndIdx_size] =
          AutomatedParkingValet_B.posesSeg_data[posesSeg_size[0] *
          segEndIdx_size + b_refDirections_size];
      }
    }

    if (startIdx > endIdx) {
      h = 0;
    } else {
      h = (int32_T)startIdx - 1;
    }

    b_refDirections_size = posesSeg_size[0];
    endIdx = b_refDirections_data[(int32_T)segEndIdx_data[b_j] - 1];
    for (segEndIdx_size = 0; segEndIdx_size < b_refDirections_size;
         segEndIdx_size++) {
      directions[h + segEndIdx_size] = endIdx;
    }
  }

  AutomatedParking_emxFree_real_T(&tmp);
  for (segEndIdx_size = 0; segEndIdx_size < 500; segEndIdx_size++) {
    poses[segEndIdx_size + 1000] *= 57.295779513082323;
  }
}

static void Aut_PathSmootherSpline_stepImpl(driving_internal_planning_Pat_T *obj,
  const real_T refPoses_data[], const int32_T refPoses_size[2], const real_T
  refDirections_data[], const int32_T *refDirections_size, real_T poses[1500],
  real_T directions[500], real_T varargout_1[500], real_T varargout_2[500])
{
  int32_T loop_ub;
  real_T refPoses_data_0[300];
  int32_T refPoses_size_0[2];
  int32_T i;
  int32_T loop_ub_tmp;
  if (AutomatedParkingValet_isequaln(refPoses_data, refPoses_size,
       obj->RefPosesInternal) && AutomatedParkingVale_isequaln_p
      (refDirections_data, refDirections_size, obj->RefDirectionsInternal)) {
    memcpy(&poses[0], &obj->LastPosesOutput[0], 1500U * sizeof(real_T));
    memcpy(&directions[0], &obj->LastDirectionsOutput[0], 500U * sizeof(real_T));
    memcpy(&varargout_1[0], &obj->LastCumLengthsOutput[0], 500U * sizeof(real_T));
    memcpy(&varargout_2[0], &obj->LastCurvaturesOutput[0], 500U * sizeof(real_T));
  } else {
    i = obj->RefPosesInternal->size[0] * obj->RefPosesInternal->size[1];
    obj->RefPosesInternal->size[0] = refPoses_size[0];
    obj->RefPosesInternal->size[1] = refPoses_size[1];
    Automa_emxEnsureCapacity_real_T(obj->RefPosesInternal, i);
    loop_ub_tmp = refPoses_size[0] * refPoses_size[1];
    loop_ub = loop_ub_tmp - 1;
    for (i = 0; i <= loop_ub; i++) {
      obj->RefPosesInternal->data[i] = refPoses_data[i];
    }

    i = obj->RefDirectionsInternal->size[0];
    obj->RefDirectionsInternal->size[0] = *refDirections_size;
    Automa_emxEnsureCapacity_real_T(obj->RefDirectionsInternal, i);
    loop_ub = *refDirections_size;
    for (i = 0; i < loop_ub; i++) {
      obj->RefDirectionsInternal->data[i] = refDirections_data[i];
    }

    refPoses_size_0[0] = refPoses_size[0];
    refPoses_size_0[1] = refPoses_size[1];
    if (0 <= loop_ub_tmp - 1) {
      memcpy(&refPoses_data_0[0], &refPoses_data[0], loop_ub_tmp * sizeof(real_T));
    }

    AutomatedParki_smoothPathSpline(refPoses_data_0, refPoses_size_0,
      refDirections_data, refDirections_size, poses, directions, varargout_1,
      varargout_2);
    memcpy(&obj->LastPosesOutput[0], &poses[0], 1500U * sizeof(real_T));
    memcpy(&obj->LastDirectionsOutput[0], &directions[0], 500U * sizeof(real_T));
    memcpy(&obj->LastCumLengthsOutput[0], &varargout_1[0], 500U * sizeof(real_T));
    memcpy(&obj->LastCurvaturesOutput[0], &varargout_2[0], 500U * sizeof(real_T));
  }
}

static void AutomatedParkin_SystemCore_step(driving_internal_planning_Pat_T *obj,
  const real_T varargin_1_data[], const int32_T varargin_1_size[2], const real_T
  varargin_2_data[], const int32_T *varargin_2_size, real_T varargout_1[1500],
  real_T varargout_2[500], real_T varargout_3[500], real_T varargout_4[500])
{
  SystemCore_systemblock_prestep(obj, varargin_1_size, varargin_2_size);
  SystemCore_detectInputSizeChang(obj, varargin_1_size, varargin_2_size);
  Aut_PathSmootherSpline_stepImpl(obj, varargin_1_data, varargin_1_size,
    varargin_2_data, varargin_2_size, varargout_1, varargout_2, varargout_3,
    varargout_4);
}

static boolean_T AutomatedParkingValet_isequal_p(const real_T varargin_1_data[],
  const int32_T *varargin_1_size, const emxArray_real_T_AutomatedPark_T
  *varargin_2)
{
  boolean_T p;
  int32_T b_k;
  boolean_T p_0;
  boolean_T exitg1;
  p = false;
  p_0 = false;
  if (*varargin_1_size == varargin_2->size[0]) {
    p_0 = true;
  }

  if (p_0 && (*varargin_1_size != 0) && (varargin_2->size[0] != 0)) {
    b_k = 0;
    exitg1 = false;
    while ((!exitg1) && (b_k <= varargin_2->size[0] - 1)) {
      if (!(varargin_1_data[b_k] == varargin_2->data[b_k])) {
        p_0 = false;
        exitg1 = true;
      } else {
        b_k++;
      }
    }
  }

  if (p_0) {
    p = true;
  }

  return p;
}

static boolean_T Auto_VelocityProfiler_isPathNew(const
  driving_internal_planning_Vel_T *obj, const real_T directions_data[], const
  int32_T *directions_size, const real_T cumLengths_data[], const int32_T
  *cumLengths_size, const real_T curvatures_data[], const int32_T
  *curvatures_size, real_T startVelocity, real_T endVelocity)
{
  boolean_T isNew;
  boolean_T p;
  if (AutomatedParkingValet_isequal_p(cumLengths_data, cumLengths_size,
       obj->LastCumLengths)) {
    p = false;
    if (startVelocity == obj->LastStartVelocity) {
      p = true;
    }

    if (p) {
      p = false;
      if (endVelocity == obj->LastEndVelocity) {
        p = true;
      }

      if (p && AutomatedParkingValet_isequal_p(directions_data, directions_size,
           obj->LastDirections) && AutomatedParkingValet_isequal_p
          (curvatures_data, curvatures_size, obj->LastCurvatures)) {
        isNew = true;
      } else {
        isNew = false;
      }
    } else {
      isNew = false;
    }
  } else {
    isNew = false;
  }

  return isNew;
}

static void AutomatedParkingVal_parseInputs(real_T varargin_2, real_T *maxSpeed,
  real_T *maxLatAccel, real_T *maxLonAccel, real_T *maxLonDecel, real_T
  *maxLonJerk)
{
  *maxSpeed = varargin_2;
  *maxLatAccel = 2.0;
  *maxLonAccel = 2.0;
  *maxLonDecel = 4.0;
  *maxLonJerk = 1.0;
}

static void Au_getSegmentBoundaryPointIndex(const real_T directions_data[],
  const int32_T *directions_size, real_T segStartIdx_data[], int32_T
  *segStartIdx_size, real_T segEndIdx_data[], int32_T *segEndIdx_size)
{
  int32_T e;
  boolean_T x_data[499];
  int32_T ii_data[499];
  int32_T nx;
  int32_T idx;
  int32_T x_size_idx_0;
  boolean_T exitg1;
  if (1.0 > (real_T)*directions_size - 1.0) {
    nx = -1;
  } else {
    nx = *directions_size - 2;
  }

  if (2 > *directions_size) {
    idx = 0;
  } else {
    idx = 1;
  }

  x_size_idx_0 = nx + 1;
  for (e = 0; e <= nx; e++) {
    x_data[e] = (directions_data[idx + e] + directions_data[e] == 0.0);
  }

  idx = 0;
  e = 1;
  exitg1 = false;
  while ((!exitg1) && (e - 1 <= x_size_idx_0 - 1)) {
    if (x_data[e - 1]) {
      idx++;
      ii_data[idx - 1] = e;
      if (idx >= x_size_idx_0) {
        exitg1 = true;
      } else {
        e++;
      }
    } else {
      e++;
    }
  }

  if (x_size_idx_0 == 1) {
    if (idx == 0) {
      x_size_idx_0 = 0;
    }
  } else {
    if (1 > idx) {
      idx = 0;
    }

    x_size_idx_0 = idx;
  }

  *segStartIdx_size = x_size_idx_0 + 1;
  segStartIdx_data[0] = 1.0;
  *segEndIdx_size = x_size_idx_0 + 1;
  for (e = 0; e < x_size_idx_0; e++) {
    segStartIdx_data[e + 1] = (real_T)ii_data[e] + 1.0;
    segEndIdx_data[e] = ii_data[e];
  }

  segEndIdx_data[x_size_idx_0] = *directions_size;
}

static void AutomatedParkingValet_abs(const real_T x_data[], const int32_T
  *x_size, real_T y_data[], int32_T *y_size)
{
  int32_T nx;
  int32_T b_k;
  nx = *x_size - 1;
  *y_size = *x_size;
  for (b_k = 0; b_k <= nx; b_k++) {
    y_data[b_k] = fabs(x_data[b_k]);
  }
}

static void AutomatedParkingValet_sqrt_pmhu(real_T x_data[], const int32_T
  *x_size)
{
  int32_T nx;
  int32_T b_k;
  nx = *x_size - 1;
  for (b_k = 0; b_k <= nx; b_k++) {
    x_data[b_k] = sqrt(x_data[b_k]);
  }
}

static void getNonConstSpeedIntervalDistanc(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3])
{
  real_T deltaS2;
  real_T aMaxNew;
  real_T S_tmp;
  aMaxNew = aMax * aMax;
  if (aMaxNew + vBound <= vMax) {
    deltaS2 = (vMax - vBound) / aMax - aMax;
    aMaxNew = aMaxNew * 0.5 + vBound;
    S_tmp = 0.16666666666666666 * rt_powd_snf(aMax, 3.0);
    S[0] = aMax * vBound + S_tmp;
    S[1] = ((deltaS2 * aMax + aMaxNew) + aMaxNew) * (deltaS2 / 2.0);
    S[2] = aMax * vMax - S_tmp;
  } else {
    aMaxNew = sqrt(vMax - vBound);
    S[0] = aMaxNew * vBound + 0.16666666666666666 * rt_powd_snf(aMaxNew, 3.0);
    S[1] = 0.0;
    S[2] = aMaxNew * vMax - 0.16666666666666666 * rt_powd_snf(aMaxNew, 3.0);
  }
}

static void getNonConstSpeedIntervalDista_p(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3])
{
  real_T deltaS2;
  real_T aMaxNew;
  real_T S_tmp;
  aMaxNew = aMax * aMax;
  if (aMaxNew + vBound <= vMax) {
    deltaS2 = (vMax - vBound) / aMax - aMax;
    aMaxNew = aMaxNew * 0.5 + vBound;
    S_tmp = 0.16666666666666666 * rt_powd_snf(aMax, 3.0);
    S[2] = aMax * vBound + S_tmp;
    S[1] = ((deltaS2 * aMax + aMaxNew) + aMaxNew) * (deltaS2 / 2.0);
    S[0] = aMax * vMax - S_tmp;
  } else {
    aMaxNew = sqrt(vMax - vBound);
    S[2] = aMaxNew * vBound + 0.16666666666666666 * rt_powd_snf(aMaxNew, 3.0);
    S[1] = 0.0;
    S[0] = aMaxNew * vMax - 0.16666666666666666 * rt_powd_snf(aMaxNew, 3.0);
  }
}

static real_T AutomatedParkingValet_sum(const real_T x[3])
{
  return (x[0] + x[1]) + x[2];
}

static real_T Automa_calculateNewMaximumSpeed(real_T vStart, real_T vEnd, real_T
  accelMax, real_T decelMax, real_T distance)
{
  real_T vMax;
  real_T A;
  real_T B;
  boolean_T solFound;
  real_T sAccel[3];
  real_T sDecel[3];
  B = accelMax + decelMax;
  A = B / (2.0 * accelMax * decelMax);
  B /= 2.0;
  vMax = (sqrt(B * B - (((accelMax * vStart + decelMax * vEnd) / 2.0 - (vStart *
              vStart / (2.0 * accelMax) + vEnd * vEnd / (2.0 * decelMax))) -
                        distance) * (4.0 * A)) - B) / (2.0 * A);
  if ((vMax >= accelMax * accelMax + vStart) && (vMax >= decelMax * decelMax +
       vEnd)) {
  } else {
    solFound = false;
    A = fmax(vEnd, vStart);
    while (!solFound) {
      A += 0.1;
      getNonConstSpeedIntervalDistanc(vStart, A, accelMax, sAccel);
      getNonConstSpeedIntervalDista_p(vEnd, A, decelMax, sDecel);
      solFound = (((sAccel[0] + sAccel[1]) + sAccel[2]) + ((sDecel[0] + sDecel[1])
        + sDecel[2]) > distance);
    }

    vMax = A - 0.1;
  }

  return vMax;
}

static void getNonConstSpeedIntervalDist_pm(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3], real_T T[3], real_T V[3])
{
  real_T deltaT2;
  real_T v1;
  real_T v2;
  real_T aMaxNew;
  real_T S_tmp;
  if (aMax * aMax + vBound <= vMax) {
    aMaxNew = aMax;
    deltaT2 = (vMax - vBound) / aMax - aMax;
    v1 = aMax * aMax * 0.5 + vBound;
    v2 = deltaT2 * aMax + v1;
    S[0] = aMax * vBound + 0.16666666666666666 * rt_powd_snf(aMax, 3.0);
    S[1] = deltaT2 / 2.0 * (v1 + v2);
    S[2] = aMax * vMax - 0.16666666666666666 * rt_powd_snf(aMax, 3.0);
  } else {
    aMaxNew = sqrt(vMax - vBound);
    deltaT2 = 0.0;
    v1 = aMaxNew * aMaxNew * 0.5 + vBound;
    v2 = v1;
    S_tmp = 0.16666666666666666 * rt_powd_snf(aMaxNew, 3.0);
    S[0] = aMaxNew * vBound + S_tmp;
    S[1] = 0.0;
    S[2] = aMaxNew * vMax - S_tmp;
  }

  T[0] = aMaxNew;
  T[1] = deltaT2;
  T[2] = aMaxNew;
  V[0] = v1;
  V[1] = v2;
  V[2] = vMax;
}

static void getNonConstSpeedIntervalDis_pmh(real_T vBound, real_T vMax, real_T
  aMax, real_T S[3], real_T T[3], real_T V[3])
{
  real_T deltaT2;
  real_T v1;
  real_T v2;
  real_T aMaxNew;
  real_T S_tmp;
  if (aMax * aMax + vBound <= vMax) {
    aMaxNew = aMax;
    deltaT2 = (vMax - vBound) / aMax - aMax;
    v1 = aMax * aMax * 0.5 + vBound;
    v2 = deltaT2 * aMax + v1;
    S[2] = aMax * vBound + 0.16666666666666666 * rt_powd_snf(aMax, 3.0);
    S[1] = deltaT2 / 2.0 * (v1 + v2);
    S[0] = aMax * vMax - 0.16666666666666666 * rt_powd_snf(aMax, 3.0);
  } else {
    aMaxNew = sqrt(vMax - vBound);
    deltaT2 = 0.0;
    v1 = aMaxNew * aMaxNew * 0.5 + vBound;
    v2 = v1;
    S_tmp = 0.16666666666666666 * rt_powd_snf(aMaxNew, 3.0);
    S[2] = aMaxNew * vBound + S_tmp;
    S[1] = 0.0;
    S[0] = aMaxNew * vMax - S_tmp;
  }

  T[0] = aMaxNew;
  T[1] = deltaT2;
  T[2] = aMaxNew;
  V[0] = vMax;
  V[1] = v2;
  V[2] = v1;
}

static boolean_T AutomatedParkingVa_anyNonFinite(const creal_T x_data[], const
  int32_T x_size[2])
{
  boolean_T p;
  int32_T nx;
  int32_T b_k;
  nx = x_size[0] * x_size[1] - 1;
  p = true;
  for (b_k = 0; b_k <= nx; b_k++) {
    if (p && ((!rtIsInf(x_data[b_k].re)) && (!rtIsInf(x_data[b_k].im)) &&
              ((!rtIsNaN(x_data[b_k].re)) && (!rtIsNaN(x_data[b_k].im))))) {
    } else {
      p = false;
    }
  }

  return !p;
}

static real_T AutomatedParkingValet_xzlanhs(const creal_T A_data[], const
  int32_T A_size[2], int32_T ilo, int32_T ihi)
{
  real_T f;
  real_T scale;
  real_T sumsq;
  boolean_T firstNonZero;
  real_T reAij;
  real_T temp2;
  int32_T j;
  int32_T b;
  int32_T i;
  int32_T reAij_tmp;
  f = 0.0;
  if (ilo <= ihi) {
    scale = 0.0;
    sumsq = 0.0;
    firstNonZero = true;
    for (j = ilo; j <= ihi; j++) {
      b = j + 1;
      if (ihi < j + 1) {
        b = ihi;
      }

      for (i = ilo; i <= b; i++) {
        reAij_tmp = ((j - 1) * A_size[0] + i) - 1;
        if (A_data[reAij_tmp].re != 0.0) {
          reAij = fabs(A_data[reAij_tmp].re);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = reAij;
            firstNonZero = false;
          } else if (scale < reAij) {
            temp2 = scale / reAij;
            sumsq = sumsq * temp2 * temp2 + 1.0;
            scale = reAij;
          } else {
            temp2 = reAij / scale;
            sumsq += temp2 * temp2;
          }
        }

        if (A_data[reAij_tmp].im != 0.0) {
          reAij = fabs(A_data[reAij_tmp].im);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = reAij;
            firstNonZero = false;
          } else if (scale < reAij) {
            temp2 = scale / reAij;
            sumsq = sumsq * temp2 * temp2 + 1.0;
            scale = reAij;
          } else {
            temp2 = reAij / scale;
            sumsq += temp2 * temp2;
          }
        }
      }
    }

    f = scale * sqrt(sumsq);
  }

  return f;
}

static creal_T AutomatedParkingValet_sqrt_p(const creal_T x)
{
  creal_T b_x;
  real_T xr;
  real_T absxr;
  xr = x.re;
  if (x.im == 0.0) {
    if (x.re < 0.0) {
      absxr = 0.0;
      xr = sqrt(-x.re);
    } else {
      absxr = sqrt(x.re);
      xr = 0.0;
    }
  } else if (x.re == 0.0) {
    if (x.im < 0.0) {
      absxr = sqrt(-x.im / 2.0);
      xr = -absxr;
    } else {
      absxr = sqrt(x.im / 2.0);
      xr = absxr;
    }
  } else if (rtIsNaN(x.re)) {
    absxr = x.re;
  } else if (rtIsNaN(x.im)) {
    absxr = x.im;
    xr = x.im;
  } else if (rtIsInf(x.im)) {
    absxr = fabs(x.im);
    xr = x.im;
  } else if (rtIsInf(x.re)) {
    if (x.re < 0.0) {
      absxr = 0.0;
      xr = x.im * -x.re;
    } else {
      absxr = x.re;
      xr = 0.0;
    }
  } else {
    absxr = fabs(x.re);
    xr = fabs(x.im);
    if ((absxr > 4.4942328371557893E+307) || (xr > 4.4942328371557893E+307)) {
      absxr *= 0.5;
      xr *= 0.5;
      xr = rt_hypotd_snf(absxr, xr);
      if (xr > absxr) {
        absxr = sqrt(absxr / xr + 1.0) * sqrt(xr);
      } else {
        absxr = sqrt(xr) * 1.4142135623730951;
      }
    } else {
      absxr = sqrt((rt_hypotd_snf(absxr, xr) + absxr) * 0.5);
    }

    if (x.re > 0.0) {
      xr = x.im / absxr * 0.5;
    } else {
      if (x.im < 0.0) {
        xr = -absxr;
      } else {
        xr = absxr;
      }

      absxr = x.im / xr * 0.5;
    }
  }

  b_x.re = absxr;
  b_x.im = xr;
  return b_x;
}

static void AutomatedParkingValet_xzlartg(const creal_T f, const creal_T g,
  real_T *cs, creal_T *sn, creal_T *r)
{
  real_T scale;
  int32_T count;
  real_T rescaledir;
  real_T f2;
  real_T g2;
  int32_T b_i;
  real_T fs_re;
  real_T fs_im;
  real_T gs_re;
  real_T gs_im;
  real_T scale_tmp;
  real_T f2_tmp;
  boolean_T guard1 = false;
  scale_tmp = fabs(f.re);
  scale = scale_tmp;
  f2_tmp = fabs(f.im);
  if (f2_tmp > scale_tmp) {
    scale = f2_tmp;
  }

  f2 = fabs(g.re);
  g2 = fabs(g.im);
  if (g2 > f2) {
    f2 = g2;
  }

  if (f2 > scale) {
    scale = f2;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  count = -1;
  rescaledir = 0.0;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      count++;
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    rescaledir = 1.0;
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
      *r = f;
    } else {
      do {
        count++;
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      rescaledir = -1.0;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    f2 = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    scale = g2;
    if (1.0 > g2) {
      scale = 1.0;
    }

    if (f2 <= scale * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        r->re = rt_hypotd_snf(g.re, g.im);
        r->im = 0.0;
        f2 = rt_hypotd_snf(gs_re, gs_im);
        sn->re = gs_re / f2;
        sn->im = -gs_im / f2;
      } else {
        rescaledir = sqrt(g2);
        *cs = rt_hypotd_snf(fs_re, fs_im) / rescaledir;
        f2 = scale_tmp;
        if (f2_tmp > scale_tmp) {
          f2 = f2_tmp;
        }

        if (f2 > 1.0) {
          f2 = rt_hypotd_snf(f.re, f.im);
          fs_re = f.re / f2;
          fs_im = f.im / f2;
        } else {
          g2 = 7.4428285367870146E+137 * f.re;
          scale = 7.4428285367870146E+137 * f.im;
          f2 = rt_hypotd_snf(g2, scale);
          fs_re = g2 / f2;
          fs_im = scale / f2;
        }

        gs_re /= rescaledir;
        gs_im = -gs_im / rescaledir;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
        r->re = (sn->re * g.re - sn->im * g.im) + *cs * f.re;
        r->im = (sn->re * g.im + sn->im * g.re) + *cs * f.im;
      }
    } else {
      scale = sqrt(g2 / f2 + 1.0);
      r->re = scale * fs_re;
      r->im = scale * fs_im;
      *cs = 1.0 / scale;
      f2 += g2;
      scale_tmp = r->re / f2;
      f2 = r->im / f2;
      sn->re = scale_tmp * gs_re - f2 * -gs_im;
      sn->im = scale_tmp * -gs_im + f2 * gs_re;
      if (rescaledir > 0.0) {
        for (b_i = 0; b_i <= count; b_i++) {
          r->re *= 7.4428285367870146E+137;
          r->im *= 7.4428285367870146E+137;
        }
      } else {
        if (rescaledir < 0.0) {
          for (b_i = 0; b_i <= count; b_i++) {
            r->re *= 1.3435752215134178E-138;
            r->im *= 1.3435752215134178E-138;
          }
        }
      }
    }
  }
}

static void AutomatedParkingValet_xzhgeqz(const creal_T A_data[], const int32_T
  A_size[2], int32_T ilo, int32_T ihi, int32_T *info, creal_T alpha1_data[],
  int32_T *alpha1_size, creal_T beta1_data[], int32_T *beta1_size)
{
  int32_T n;
  real_T anorm;
  real_T b_atol;
  real_T bscale;
  boolean_T failed;
  int32_T j;
  int32_T ifirst;
  int32_T istart;
  int32_T ilastm1;
  int32_T iiter;
  boolean_T goto60;
  boolean_T goto70;
  boolean_T goto90;
  int32_T jp1;
  creal_T ad11;
  real_T temp;
  creal_T shift;
  real_T temp2;
  real_T tempr;
  creal_T b_A_data[9];
  int32_T jiter;
  int32_T b_A_size_idx_0;
  creal_T t1;
  real_T ai;
  real_T t1_re;
  real_T t1_im;
  real_T eshift_re;
  real_T eshift_im;
  real_T ctemp_re;
  real_T ctemp_im;
  int32_T ctemp_re_tmp;
  int32_T ctemp_re_tmp_tmp;
  real_T t1_tmp;
  int32_T t1_re_tmp;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  int32_T exitg1;
  boolean_T exitg2;
  boolean_T guard11 = false;
  b_A_size_idx_0 = A_size[0];
  ifirst = A_size[0] * A_size[1] - 1;
  if (0 <= ifirst) {
    memcpy(&b_A_data[0], &A_data[0], (ifirst + 1) * sizeof(creal_T));
  }

  *info = 0;
  if ((A_size[0] == 1) && (A_size[1] == 1)) {
    ihi = 1;
  }

  n = A_size[0];
  *alpha1_size = A_size[0];
  ifirst = A_size[0];
  if (0 <= ifirst - 1) {
    memset(&alpha1_data[0], 0, ifirst * sizeof(creal_T));
  }

  *beta1_size = A_size[0];
  ifirst = A_size[0];
  for (ctemp_re_tmp_tmp = 0; ctemp_re_tmp_tmp < ifirst; ctemp_re_tmp_tmp++) {
    beta1_data[ctemp_re_tmp_tmp].re = 1.0;
    beta1_data[ctemp_re_tmp_tmp].im = 0.0;
  }

  eshift_re = 0.0;
  eshift_im = 0.0;
  ctemp_re = 0.0;
  ctemp_im = 0.0;
  anorm = AutomatedParkingValet_xzlanhs(A_data, A_size, ilo, ihi);
  tempr = 2.2204460492503131E-16 * anorm;
  b_atol = 2.2250738585072014E-308;
  if (tempr > 2.2250738585072014E-308) {
    b_atol = tempr;
  }

  temp = 2.2250738585072014E-308;
  if (anorm > 2.2250738585072014E-308) {
    temp = anorm;
  }

  anorm = 1.0 / temp;
  bscale = 1.0 / sqrt(A_size[0]);
  failed = true;
  for (ifirst = ihi + 1; ifirst <= n; ifirst++) {
    alpha1_data[ifirst - 1] = A_data[((ifirst - 1) * A_size[0] + ifirst) - 1];
  }

  guard1 = false;
  guard2 = false;
  if (ihi >= ilo) {
    ifirst = ilo;
    istart = ilo;
    n = ihi - 1;
    ilastm1 = ihi - 2;
    iiter = 0;
    goto60 = false;
    goto70 = false;
    goto90 = false;
    jiter = 0;
    do {
      exitg1 = 0;
      if (jiter <= ((ihi - ilo) + 1) * 30 - 1) {
        guard11 = false;
        if (n + 1 == ilo) {
          goto60 = true;
          guard11 = true;
        } else {
          ctemp_re_tmp_tmp = b_A_size_idx_0 * ilastm1 + n;
          if (fabs(b_A_data[ctemp_re_tmp_tmp].re) + fabs
              (b_A_data[ctemp_re_tmp_tmp].im) <= b_atol) {
            b_A_data[ctemp_re_tmp_tmp].re = 0.0;
            b_A_data[ctemp_re_tmp_tmp].im = 0.0;
            goto60 = true;
            guard11 = true;
          } else {
            j = ilastm1 + 1;
            guard3 = false;
            exitg2 = false;
            while ((!exitg2) && (j >= ilo)) {
              if (j == ilo) {
                guard3 = true;
                exitg2 = true;
              } else {
                ctemp_re_tmp_tmp = ((j - 2) * b_A_size_idx_0 + j) - 1;
                if (fabs(b_A_data[ctemp_re_tmp_tmp].re) + fabs
                    (b_A_data[ctemp_re_tmp_tmp].im) <= b_atol) {
                  b_A_data[ctemp_re_tmp_tmp].re = 0.0;
                  b_A_data[ctemp_re_tmp_tmp].im = 0.0;
                  guard3 = true;
                  exitg2 = true;
                } else {
                  j--;
                  guard3 = false;
                }
              }
            }

            if (guard3) {
              ifirst = j;
              goto70 = true;
            }

            if (goto70) {
              guard11 = true;
            } else {
              n = *alpha1_size;
              for (ctemp_re_tmp_tmp = 0; ctemp_re_tmp_tmp < n; ctemp_re_tmp_tmp
                   ++) {
                alpha1_data[ctemp_re_tmp_tmp].re = (rtNaN);
                alpha1_data[ctemp_re_tmp_tmp].im = 0.0;
              }

              n = *beta1_size;
              for (ctemp_re_tmp_tmp = 0; ctemp_re_tmp_tmp < n; ctemp_re_tmp_tmp
                   ++) {
                beta1_data[ctemp_re_tmp_tmp].re = (rtNaN);
                beta1_data[ctemp_re_tmp_tmp].im = 0.0;
              }

              *info = 1;
              exitg1 = 1;
            }
          }
        }

        if (guard11) {
          if (goto60) {
            goto60 = false;
            alpha1_data[n] = b_A_data[b_A_size_idx_0 * n + n];
            n = ilastm1;
            ilastm1--;
            if (n + 1 < ilo) {
              failed = false;
              guard2 = true;
              exitg1 = 1;
            } else {
              iiter = 0;
              eshift_re = 0.0;
              eshift_im = 0.0;
              jiter++;
            }
          } else {
            if (goto70) {
              goto70 = false;
              iiter++;
              if (iiter - iiter / 10 * 10 != 0) {
                j = b_A_size_idx_0 * ilastm1 + ilastm1;
                tempr = b_A_data[j].re * anorm;
                ai = b_A_data[j].im * anorm;
                if (ai == 0.0) {
                  ad11.re = tempr / bscale;
                  ad11.im = 0.0;
                } else if (tempr == 0.0) {
                  ad11.re = 0.0;
                  ad11.im = ai / bscale;
                } else {
                  ad11.re = tempr / bscale;
                  ad11.im = ai / bscale;
                }

                j = b_A_size_idx_0 * n + n;
                tempr = b_A_data[j].re * anorm;
                ai = b_A_data[j].im * anorm;
                if (ai == 0.0) {
                  shift.re = tempr / bscale;
                  shift.im = 0.0;
                } else if (tempr == 0.0) {
                  shift.re = 0.0;
                  shift.im = ai / bscale;
                } else {
                  shift.re = tempr / bscale;
                  shift.im = ai / bscale;
                }

                t1_re = (ad11.re + shift.re) * 0.5;
                t1_im = (ad11.im + shift.im) * 0.5;
                j = b_A_size_idx_0 * n + ilastm1;
                tempr = b_A_data[j].re * anorm;
                ai = b_A_data[j].im * anorm;
                if (ai == 0.0) {
                  temp = tempr / bscale;
                  temp2 = 0.0;
                } else if (tempr == 0.0) {
                  temp = 0.0;
                  temp2 = ai / bscale;
                } else {
                  temp = tempr / bscale;
                  temp2 = ai / bscale;
                }

                j = b_A_size_idx_0 * ilastm1 + n;
                tempr = b_A_data[j].re * anorm;
                ai = b_A_data[j].im * anorm;
                if (ai == 0.0) {
                  tempr /= bscale;
                  ai = 0.0;
                } else if (tempr == 0.0) {
                  tempr = 0.0;
                  ai /= bscale;
                } else {
                  tempr /= bscale;
                  ai /= bscale;
                }

                t1.re = ((t1_re * t1_re - t1_im * t1_im) + (temp * tempr - temp2
                          * ai)) - (ad11.re * shift.re - ad11.im * shift.im);
                t1_tmp = t1_re * t1_im;
                t1.im = ((t1_tmp + t1_tmp) + (temp * ai + temp2 * tempr)) -
                  (ad11.re * shift.im + ad11.im * shift.re);
                ad11 = AutomatedParkingValet_sqrt_p(t1);
                if ((t1_re - shift.re) * ad11.re + (t1_im - shift.im) * ad11.im <=
                    0.0) {
                  shift.re = t1_re + ad11.re;
                  shift.im = t1_im + ad11.im;
                } else {
                  shift.re = t1_re - ad11.re;
                  shift.im = t1_im - ad11.im;
                }
              } else {
                j = b_A_size_idx_0 * ilastm1 + n;
                tempr = b_A_data[j].re * anorm;
                ai = b_A_data[j].im * anorm;
                if (ai == 0.0) {
                  temp = tempr / bscale;
                  temp2 = 0.0;
                } else if (tempr == 0.0) {
                  temp = 0.0;
                  temp2 = ai / bscale;
                } else {
                  temp = tempr / bscale;
                  temp2 = ai / bscale;
                }

                eshift_re += temp;
                eshift_im += temp2;
                shift.re = eshift_re;
                shift.im = eshift_im;
              }

              j = ilastm1;
              jp1 = ilastm1 + 1;
              exitg2 = false;
              while ((!exitg2) && (j + 1 > ifirst)) {
                istart = j + 1;
                ctemp_re_tmp_tmp = b_A_size_idx_0 * j;
                ctemp_re_tmp = ctemp_re_tmp_tmp + j;
                ctemp_re = b_A_data[ctemp_re_tmp].re * anorm - shift.re * bscale;
                ctemp_im = b_A_data[ctemp_re_tmp].im * anorm - shift.im * bscale;
                temp = fabs(ctemp_re) + fabs(ctemp_im);
                jp1 += ctemp_re_tmp_tmp;
                temp2 = (fabs(b_A_data[jp1].re) + fabs(b_A_data[jp1].im)) *
                  anorm;
                tempr = temp;
                if (temp2 > temp) {
                  tempr = temp2;
                }

                if ((tempr < 1.0) && (tempr != 0.0)) {
                  temp /= tempr;
                  temp2 /= tempr;
                }

                ctemp_re_tmp_tmp = (j - 1) * b_A_size_idx_0 + j;
                if ((fabs(b_A_data[ctemp_re_tmp_tmp].re) + fabs
                     (b_A_data[ctemp_re_tmp_tmp].im)) * temp2 <= temp * b_atol)
                {
                  goto90 = true;
                  exitg2 = true;
                } else {
                  jp1 = j;
                  j--;
                }
              }

              if (!goto90) {
                istart = ifirst;
                ctemp_re_tmp = ((ifirst - 1) * b_A_size_idx_0 + ifirst) - 1;
                ctemp_re = b_A_data[ctemp_re_tmp].re * anorm - shift.re * bscale;
                ctemp_im = b_A_data[ctemp_re_tmp].im * anorm - shift.im * bscale;
              }

              goto90 = false;
              j = (istart - 1) * b_A_size_idx_0 + istart;
              shift.re = b_A_data[j].re * anorm;
              shift.im = b_A_data[j].im * anorm;
              ai = fabs(ctemp_re);
              temp = ai;
              t1_tmp = fabs(ctemp_im);
              if (t1_tmp > ai) {
                temp = t1_tmp;
              }

              tempr = fabs(shift.re);
              t1_re = fabs(shift.im);
              if (t1_re > tempr) {
                tempr = t1_re;
              }

              if (tempr > temp) {
                temp = tempr;
              }

              t1_re = ctemp_re;
              t1_im = ctemp_im;
              guard3 = false;
              if (temp >= 7.4428285367870146E+137) {
                do {
                  t1_re *= 1.3435752215134178E-138;
                  t1_im *= 1.3435752215134178E-138;
                  shift.re *= 1.3435752215134178E-138;
                  shift.im *= 1.3435752215134178E-138;
                  temp *= 1.3435752215134178E-138;
                } while (!(temp < 7.4428285367870146E+137));

                guard3 = true;
              } else if (temp <= 1.3435752215134178E-138) {
                if ((shift.re == 0.0) && (shift.im == 0.0)) {
                  temp = 1.0;
                  shift.re = 0.0;
                  shift.im = 0.0;
                } else {
                  do {
                    t1_re *= 7.4428285367870146E+137;
                    t1_im *= 7.4428285367870146E+137;
                    shift.re *= 7.4428285367870146E+137;
                    shift.im *= 7.4428285367870146E+137;
                    temp *= 7.4428285367870146E+137;
                  } while (!(temp > 1.3435752215134178E-138));

                  guard3 = true;
                }
              } else {
                guard3 = true;
              }

              if (guard3) {
                temp2 = t1_re * t1_re + t1_im * t1_im;
                tempr = shift.re * shift.re + shift.im * shift.im;
                temp = tempr;
                if (1.0 > tempr) {
                  temp = 1.0;
                }

                if (temp2 <= temp * 2.0041683600089728E-292) {
                  if ((ctemp_re == 0.0) && (ctemp_im == 0.0)) {
                    temp = 0.0;
                    tempr = rt_hypotd_snf(shift.re, shift.im);
                    shift.re /= tempr;
                    shift.im = -shift.im / tempr;
                  } else {
                    temp2 = sqrt(tempr);
                    temp = rt_hypotd_snf(t1_re, t1_im) / temp2;
                    tempr = ai;
                    if (t1_tmp > ai) {
                      tempr = t1_tmp;
                    }

                    if (tempr > 1.0) {
                      tempr = rt_hypotd_snf(ctemp_re, ctemp_im);
                      t1_re = ctemp_re / tempr;
                      t1_im = ctemp_im / tempr;
                    } else {
                      t1_re = 7.4428285367870146E+137 * ctemp_re;
                      t1_im = 7.4428285367870146E+137 * ctemp_im;
                      tempr = rt_hypotd_snf(t1_re, t1_im);
                      t1_re /= tempr;
                      t1_im /= tempr;
                    }

                    tempr = shift.re / temp2;
                    temp2 = -shift.im / temp2;
                    shift.re = t1_re * tempr - t1_im * temp2;
                    shift.im = t1_re * temp2 + t1_im * tempr;
                  }
                } else {
                  temp = sqrt(tempr / temp2 + 1.0);
                  t1_re *= temp;
                  t1_im *= temp;
                  temp = 1.0 / temp;
                  tempr += temp2;
                  t1_re /= tempr;
                  t1_im /= tempr;
                  tempr = shift.re;
                  shift.re = t1_re * shift.re - t1_im * -shift.im;
                  shift.im = t1_re * -shift.im + t1_im * tempr;
                }
              }

              j = istart;
              jp1 = istart - 2;
              while (j < n + 1) {
                if (j > istart) {
                  AutomatedParkingValet_xzlartg(b_A_data[b_A_size_idx_0 * jp1 +
                    1], b_A_data[j + b_A_size_idx_0 * jp1], &temp, &shift,
                    &b_A_data[b_A_size_idx_0 * jp1 + 1]);
                  ctemp_re_tmp_tmp = j + b_A_size_idx_0 * jp1;
                  b_A_data[ctemp_re_tmp_tmp].re = 0.0;
                  b_A_data[ctemp_re_tmp_tmp].im = 0.0;
                }

                for (jp1 = j; jp1 <= n + 1; jp1++) {
                  ctemp_re_tmp = (jp1 - 1) * b_A_size_idx_0 + j;
                  t1_re_tmp = ctemp_re_tmp - 1;
                  t1_re = b_A_data[t1_re_tmp].re * temp + (b_A_data[ctemp_re_tmp]
                    .re * shift.re - b_A_data[ctemp_re_tmp].im * shift.im);
                  t1_im = b_A_data[t1_re_tmp].im * temp + (b_A_data[ctemp_re_tmp]
                    .im * shift.re + b_A_data[ctemp_re_tmp].re * shift.im);
                  ctemp_re_tmp_tmp = (jp1 - 1) * b_A_size_idx_0 + j;
                  ctemp_re_tmp = ctemp_re_tmp_tmp - 1;
                  temp2 = b_A_data[ctemp_re_tmp].re;
                  b_A_data[ctemp_re_tmp_tmp].re = b_A_data[ctemp_re_tmp_tmp].re *
                    temp - (b_A_data[ctemp_re_tmp].re * shift.re +
                            b_A_data[ctemp_re_tmp].im * shift.im);
                  ctemp_re_tmp_tmp = (jp1 - 1) * b_A_size_idx_0 + j;
                  ctemp_re_tmp = ctemp_re_tmp_tmp - 1;
                  b_A_data[ctemp_re_tmp_tmp].im = b_A_data[ctemp_re_tmp_tmp].im *
                    temp - (b_A_data[ctemp_re_tmp].im * shift.re - shift.im *
                            temp2);
                  b_A_data[ctemp_re_tmp].re = t1_re;
                  b_A_data[ctemp_re_tmp].im = t1_im;
                }

                shift.re = -shift.re;
                shift.im = -shift.im;
                jp1 = j + 2;
                if (n + 1 < j + 2) {
                  jp1 = n + 1;
                }

                for (ctemp_re_tmp_tmp = ifirst; ctemp_re_tmp_tmp <= jp1;
                     ctemp_re_tmp_tmp++) {
                  ctemp_re_tmp = ((j - 1) * b_A_size_idx_0 + ctemp_re_tmp_tmp) -
                    1;
                  t1_re_tmp = (b_A_size_idx_0 * j + ctemp_re_tmp_tmp) - 1;
                  t1_re = (b_A_data[ctemp_re_tmp].re * shift.re -
                           b_A_data[ctemp_re_tmp].im * shift.im) +
                    b_A_data[t1_re_tmp].re * temp;
                  t1_im = (b_A_data[ctemp_re_tmp].im * shift.re +
                           b_A_data[ctemp_re_tmp].re * shift.im) +
                    b_A_data[t1_re_tmp].im * temp;
                  temp2 = b_A_data[t1_re_tmp].re;
                  b_A_data[ctemp_re_tmp].re = b_A_data[ctemp_re_tmp].re * temp -
                    (b_A_data[t1_re_tmp].re * shift.re + b_A_data[t1_re_tmp].im *
                     shift.im);
                  b_A_data[ctemp_re_tmp].im = b_A_data[ctemp_re_tmp].im * temp -
                    (b_A_data[t1_re_tmp].im * shift.re - shift.im * temp2);
                  b_A_data[t1_re_tmp].re = t1_re;
                  b_A_data[t1_re_tmp].im = t1_im;
                }

                jp1 = j - 1;
                j++;
              }
            }

            jiter++;
          }
        }
      } else {
        guard2 = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    guard1 = true;
  }

  if (guard2) {
    if (failed) {
      *info = n + 1;
      for (j = 0; j <= n; j++) {
        alpha1_data[j].re = (rtNaN);
        alpha1_data[j].im = 0.0;
        beta1_data[j].re = (rtNaN);
        beta1_data[j].im = 0.0;
      }
    } else {
      guard1 = true;
    }
  }

  if (guard1) {
    n = ilo - 2;
    for (ifirst = 0; ifirst <= n; ifirst++) {
      alpha1_data[ifirst] = b_A_data[b_A_size_idx_0 * ifirst + ifirst];
    }
  }
}

static void AutomatedParkingValet_xzgeev(const creal_T A_data[], const int32_T
  A_size[2], int32_T *info, creal_T alpha1_data[], int32_T *alpha1_size, creal_T
  beta1_data[], int32_T *beta1_size)
{
  creal_T At_data[9];
  real_T anrm;
  boolean_T ilascl;
  real_T anrmto;
  creal_T c_A_data[9];
  int32_T ihi;
  real_T absxk;
  int32_T b_k;
  real_T ctoc;
  boolean_T notdone;
  creal_T s;
  int32_T jcol;
  real_T cto1;
  real_T mul;
  int32_T ii;
  int32_T k;
  int32_T At_size[2];
  int32_T c_A_size_idx_1;
  real_T atmp_im;
  creal_T alpha1_data_0;
  int32_T loop_ub_tmp;
  int32_T loop_ub_tmp_0;
  int32_T atmp_re_tmp;
  int32_T At_data_tmp;
  boolean_T guard1 = false;
  boolean_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  boolean_T exitg4;
  At_size[0] = A_size[0];
  At_size[1] = A_size[1];
  loop_ub_tmp = A_size[0] * A_size[1];
  loop_ub_tmp_0 = loop_ub_tmp - 1;
  if (0 <= loop_ub_tmp_0) {
    memcpy(&At_data[0], &A_data[0], (loop_ub_tmp_0 + 1) * sizeof(creal_T));
  }

  *info = 0;
  anrm = 0.0;
  b_k = 0;
  exitg1 = false;
  while ((!exitg1) && (b_k <= loop_ub_tmp - 1)) {
    absxk = rt_hypotd_snf(A_data[b_k].re, A_data[b_k].im);
    if (rtIsNaN(absxk)) {
      anrm = (rtNaN);
      exitg1 = true;
    } else {
      if (absxk > anrm) {
        anrm = absxk;
      }

      b_k++;
    }
  }

  if (rtIsInf(anrm) || rtIsNaN(anrm)) {
    *alpha1_size = A_size[0];
    b_k = A_size[0];
    for (atmp_re_tmp = 0; atmp_re_tmp < b_k; atmp_re_tmp++) {
      alpha1_data[atmp_re_tmp].re = (rtNaN);
      alpha1_data[atmp_re_tmp].im = 0.0;
    }

    *beta1_size = A_size[0];
    b_k = A_size[0];
    for (atmp_re_tmp = 0; atmp_re_tmp < b_k; atmp_re_tmp++) {
      beta1_data[atmp_re_tmp].re = (rtNaN);
      beta1_data[atmp_re_tmp].im = 0.0;
    }
  } else {
    ilascl = false;
    anrmto = anrm;
    guard1 = false;
    if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
      anrmto = 6.7178761075670888E-139;
      ilascl = true;
      guard1 = true;
    } else {
      if (anrm > 1.4885657073574029E+138) {
        anrmto = 1.4885657073574029E+138;
        ilascl = true;
        guard1 = true;
      }
    }

    if (guard1) {
      At_size[0] = A_size[0];
      At_size[1] = A_size[1];
      if (0 <= loop_ub_tmp_0) {
        memcpy(&At_data[0], &A_data[0], (loop_ub_tmp_0 + 1) * sizeof(creal_T));
      }

      absxk = anrm;
      ctoc = anrmto;
      notdone = true;
      while (notdone) {
        atmp_im = absxk * 2.0041683600089728E-292;
        cto1 = ctoc / 4.9896007738368E+291;
        if ((atmp_im > ctoc) && (ctoc != 0.0)) {
          mul = 2.0041683600089728E-292;
          absxk = atmp_im;
        } else if (cto1 > absxk) {
          mul = 4.9896007738368E+291;
          ctoc = cto1;
        } else {
          mul = ctoc / absxk;
          notdone = false;
        }

        b_k = At_size[0] * At_size[1] - 1;
        for (atmp_re_tmp = 0; atmp_re_tmp <= b_k; atmp_re_tmp++) {
          s.re = mul * At_data[atmp_re_tmp].re;
          s.im = mul * At_data[atmp_re_tmp].im;
          At_data[atmp_re_tmp] = s;
        }
      }
    }

    loop_ub_tmp_0 = At_size[0];
    c_A_size_idx_1 = At_size[1];
    loop_ub_tmp = At_size[0] * At_size[1] - 1;
    if (0 <= loop_ub_tmp) {
      memcpy(&c_A_data[0], &At_data[0], (loop_ub_tmp + 1) * sizeof(creal_T));
    }

    loop_ub_tmp = 1;
    ihi = At_size[0];
    if (At_size[0] <= 1) {
      ihi = 1;
    } else {
      do {
        exitg3 = 0;
        k = -1;
        jcol = 0;
        notdone = false;
        ii = ihi;
        exitg1 = false;
        while ((!exitg1) && (ii > 0)) {
          absxk = 0.0;
          k = ii - 1;
          jcol = ihi;
          b_k = 1;
          exitg4 = false;
          while ((!exitg4) && (b_k - 1 <= ihi - 1)) {
            atmp_re_tmp = ((b_k - 1) * loop_ub_tmp_0 + ii) - 1;
            if ((c_A_data[atmp_re_tmp].re != 0.0) || (c_A_data[atmp_re_tmp].im
                 != 0.0) || (ii == b_k)) {
              if (absxk == 0.0) {
                jcol = b_k;
                absxk = 1.0;
                b_k++;
              } else {
                absxk = 2.0;
                exitg4 = true;
              }
            } else {
              b_k++;
            }
          }

          if (absxk < 2.0) {
            notdone = true;
            exitg1 = true;
          } else {
            ii--;
          }
        }

        if (!notdone) {
          exitg3 = 2;
        } else {
          b_k = loop_ub_tmp_0 * c_A_size_idx_1 - 1;
          if (0 <= b_k) {
            memcpy(&At_data[0], &c_A_data[0], (b_k + 1) * sizeof(creal_T));
          }

          if (k + 1 != ihi) {
            for (b_k = 1; b_k <= loop_ub_tmp_0; b_k++) {
              ii = (b_k - 1) * loop_ub_tmp_0;
              atmp_re_tmp = ii + k;
              ctoc = At_data[atmp_re_tmp].re;
              atmp_im = At_data[atmp_re_tmp].im;
              At_data_tmp = (ii + ihi) - 1;
              At_data[atmp_re_tmp] = At_data[At_data_tmp];
              At_data[At_data_tmp].re = ctoc;
              At_data[At_data_tmp].im = atmp_im;
            }
          }

          if (jcol != ihi) {
            for (ii = 0; ii < ihi; ii++) {
              atmp_re_tmp = (jcol - 1) * loop_ub_tmp_0;
              ctoc = At_data[atmp_re_tmp + ii].re;
              k = atmp_re_tmp + ii;
              atmp_im = At_data[k].im;
              At_data_tmp = (ihi - 1) * loop_ub_tmp_0 + ii;
              At_data[k] = At_data[At_data_tmp];
              At_data[At_data_tmp].re = ctoc;
              At_data[At_data_tmp].im = atmp_im;
            }
          }

          b_k = loop_ub_tmp_0 * c_A_size_idx_1 - 1;
          if (0 <= b_k) {
            memcpy(&c_A_data[0], &At_data[0], (b_k + 1) * sizeof(creal_T));
          }

          ihi--;
          if (ihi == 1) {
            exitg3 = 1;
          }
        }
      } while (exitg3 == 0);

      if (exitg3 == 1) {
      } else {
        do {
          exitg2 = 0;
          k = 0;
          jcol = -1;
          notdone = false;
          b_k = loop_ub_tmp;
          exitg1 = false;
          while ((!exitg1) && (b_k <= ihi)) {
            absxk = 0.0;
            k = ihi;
            jcol = b_k - 1;
            ii = loop_ub_tmp;
            exitg4 = false;
            while ((!exitg4) && (ii <= ihi)) {
              atmp_re_tmp = ((b_k - 1) * loop_ub_tmp_0 + ii) - 1;
              if ((c_A_data[atmp_re_tmp].re != 0.0) || (c_A_data[atmp_re_tmp].im
                   != 0.0) || (ii == b_k)) {
                if (absxk == 0.0) {
                  k = ii;
                  absxk = 1.0;
                  ii++;
                } else {
                  absxk = 2.0;
                  exitg4 = true;
                }
              } else {
                ii++;
              }
            }

            if (absxk < 2.0) {
              notdone = true;
              exitg1 = true;
            } else {
              b_k++;
            }
          }

          if (!notdone) {
            exitg2 = 1;
          } else {
            b_k = loop_ub_tmp_0 * c_A_size_idx_1 - 1;
            if (0 <= b_k) {
              memcpy(&At_data[0], &c_A_data[0], (b_k + 1) * sizeof(creal_T));
            }

            if (k != loop_ub_tmp) {
              for (b_k = loop_ub_tmp; b_k <= loop_ub_tmp_0; b_k++) {
                ii = (b_k - 1) * loop_ub_tmp_0;
                atmp_re_tmp = (ii + k) - 1;
                ctoc = At_data[atmp_re_tmp].re;
                atmp_im = At_data[atmp_re_tmp].im;
                At_data_tmp = (ii + loop_ub_tmp) - 1;
                At_data[atmp_re_tmp] = At_data[At_data_tmp];
                At_data[At_data_tmp].re = ctoc;
                At_data[At_data_tmp].im = atmp_im;
              }
            }

            if (jcol + 1 != loop_ub_tmp) {
              for (ii = 0; ii < ihi; ii++) {
                atmp_re_tmp = loop_ub_tmp_0 * jcol + ii;
                ctoc = At_data[atmp_re_tmp].re;
                atmp_im = At_data[atmp_re_tmp].im;
                At_data_tmp = (loop_ub_tmp - 1) * loop_ub_tmp_0 + ii;
                At_data[atmp_re_tmp] = At_data[At_data_tmp];
                At_data[At_data_tmp].re = ctoc;
                At_data[At_data_tmp].im = atmp_im;
              }
            }

            b_k = loop_ub_tmp_0 * c_A_size_idx_1 - 1;
            if (0 <= b_k) {
              memcpy(&c_A_data[0], &At_data[0], (b_k + 1) * sizeof(creal_T));
            }

            loop_ub_tmp++;
            if (loop_ub_tmp == ihi) {
              exitg2 = 1;
            }
          }
        } while (exitg2 == 0);
      }
    }

    b_k = loop_ub_tmp_0 * c_A_size_idx_1 - 1;
    if (0 <= b_k) {
      memcpy(&At_data[0], &c_A_data[0], (b_k + 1) * sizeof(creal_T));
    }

    if ((loop_ub_tmp_0 > 1) && (ihi >= loop_ub_tmp + 2)) {
      jcol = loop_ub_tmp;
      while (jcol < 2) {
        AutomatedParkingValet_xzlartg(At_data[1], At_data[2], &absxk, &s,
          &At_data[1]);
        At_data[2].re = 0.0;
        At_data[2].im = 0.0;
        for (jcol = 2; jcol <= loop_ub_tmp_0; jcol++) {
          ii = (jcol - 1) * loop_ub_tmp_0;
          atmp_re_tmp = ii + 2;
          b_k = ii + 1;
          ctoc = (At_data[atmp_re_tmp].re * s.re - At_data[atmp_re_tmp].im *
                  s.im) + At_data[b_k].re * absxk;
          atmp_im = (At_data[atmp_re_tmp].im * s.re + At_data[atmp_re_tmp].re *
                     s.im) + At_data[b_k].im * absxk;
          atmp_re_tmp = (jcol - 1) * loop_ub_tmp_0;
          b_k = atmp_re_tmp + 1;
          cto1 = At_data[b_k].re;
          atmp_re_tmp += 2;
          At_data[atmp_re_tmp].re = At_data[atmp_re_tmp].re * absxk -
            (At_data[b_k].re * s.re + At_data[b_k].im * s.im);
          atmp_re_tmp = (jcol - 1) * loop_ub_tmp_0;
          b_k = atmp_re_tmp + 2;
          atmp_re_tmp++;
          At_data[b_k].im = At_data[b_k].im * absxk - (At_data[atmp_re_tmp].im *
            s.re - s.im * cto1);
          At_data[atmp_re_tmp].re = ctoc;
          At_data[atmp_re_tmp].im = atmp_im;
        }

        s.re = -s.re;
        s.im = -s.im;
        for (k = 1; k < 4; k++) {
          atmp_re_tmp = (k + loop_ub_tmp_0) - 1;
          ii = loop_ub_tmp_0 << 1;
          b_k = (ii + k) - 1;
          ctoc = At_data[b_k].re * absxk + (At_data[atmp_re_tmp].re * s.re -
            At_data[atmp_re_tmp].im * s.im);
          atmp_im = At_data[b_k].im * absxk + (At_data[atmp_re_tmp].im * s.re +
            At_data[atmp_re_tmp].re * s.im);
          atmp_re_tmp = (ii + k) - 1;
          cto1 = At_data[atmp_re_tmp].re;
          b_k = (k + loop_ub_tmp_0) - 1;
          At_data[b_k].re = At_data[b_k].re * absxk - (At_data[atmp_re_tmp].re *
            s.re + At_data[atmp_re_tmp].im * s.im);
          At_data[b_k].im = At_data[b_k].im * absxk - (At_data[atmp_re_tmp].im *
            s.re - s.im * cto1);
          atmp_re_tmp = (k + ii) - 1;
          At_data[atmp_re_tmp].re = ctoc;
          At_data[atmp_re_tmp].im = atmp_im;
        }

        jcol = 2;
      }
    }

    AutomatedParkingValet_xzhgeqz(At_data, At_size, loop_ub_tmp, ihi, info,
      alpha1_data, alpha1_size, beta1_data, beta1_size);
    if ((*info == 0) && ilascl) {
      notdone = true;
      while (notdone) {
        atmp_im = anrmto * 2.0041683600089728E-292;
        cto1 = anrm / 4.9896007738368E+291;
        if ((atmp_im > anrm) && (anrm != 0.0)) {
          mul = 2.0041683600089728E-292;
          anrmto = atmp_im;
        } else if (cto1 > anrmto) {
          mul = 4.9896007738368E+291;
          anrm = cto1;
        } else {
          mul = anrm / anrmto;
          notdone = false;
        }

        b_k = *alpha1_size;
        for (atmp_re_tmp = 0; atmp_re_tmp < b_k; atmp_re_tmp++) {
          alpha1_data_0.re = mul * alpha1_data[atmp_re_tmp].re;
          alpha1_data_0.im = mul * alpha1_data[atmp_re_tmp].im;
          alpha1_data[atmp_re_tmp] = alpha1_data_0;
        }
      }
    }
  }
}

static real_T AutomatedParkingValet_xdlapy3(real_T x1, real_T x2, real_T x3)
{
  real_T y;
  real_T a;
  real_T b;
  real_T c;
  a = fabs(x1);
  b = fabs(x2);
  c = fabs(x3);
  y = fmax(a, b);
  if (c > y) {
    y = c;
  }

  if ((y > 0.0) && (!rtIsInf(y))) {
    a /= y;
    b /= y;
    c /= y;
    y *= sqrt((a * a + c * c) + b * b);
  } else {
    y = (a + b) + c;
  }

  return y;
}

static creal_T AutomatedParkingValet_recip(const creal_T y)
{
  creal_T z;
  real_T br;
  real_T brm;
  real_T bim;
  brm = fabs(y.re);
  bim = fabs(y.im);
  if (y.im == 0.0) {
    z.re = 1.0 / y.re;
    z.im = 0.0;
  } else if (y.re == 0.0) {
    z.re = 0.0;
    z.im = -1.0 / y.im;
  } else if (brm > bim) {
    brm = y.im / y.re;
    bim = brm * y.im + y.re;
    z.re = 1.0 / bim;
    z.im = -brm / bim;
  } else if (brm == bim) {
    bim = 0.5;
    if (y.re < 0.0) {
      bim = -0.5;
    }

    br = 0.5;
    if (y.im < 0.0) {
      br = -0.5;
    }

    z.re = bim / brm;
    z.im = -br / brm;
  } else {
    brm = y.re / y.im;
    bim = brm * y.re + y.im;
    z.re = brm / bim;
    z.im = -1.0 / bim;
  }

  return z;
}

static void AutomatedParkingValet_xgehrd(const creal_T a_data[], const int32_T
  a_size[2], creal_T b_a_data[], int32_T b_a_size[2])
{
  creal_T c_a_data[9];
  creal_T tau_data[2];
  int32_T n;
  creal_T work_data[3];
  int32_T in;
  int32_T ia0;
  creal_T b_alpha1;
  creal_T c_a_data_0[9];
  creal_T e_a_data[9];
  int32_T e;
  real_T xnorm;
  int32_T knt;
  int32_T lastc;
  int32_T rowleft;
  int32_T rowright;
  int32_T iy;
  int32_T iac;
  int32_T d;
  int32_T jy;
  int32_T c_a_size_idx_0;
  int32_T c_a_size_idx_1;
  int32_T d_idx_0;
  creal_T c_a_data_1;
  creal_T tmp;
  creal_T b_alpha1_0;
  real_T c_im;
  real_T e_a_data_im;
  real_T alpha1_re;
  real_T alpha1_im;
  int32_T im1n_tmp;
  int32_T c_tmp;
  int32_T c_tmp_tmp;
  int32_T exitg1;
  boolean_T exitg2;
  c_a_size_idx_0 = a_size[0];
  c_a_size_idx_1 = a_size[1];
  rowleft = a_size[0] * a_size[1] - 1;
  if (0 <= rowleft) {
    memcpy(&c_a_data[0], &a_data[0], (rowleft + 1) * sizeof(creal_T));
  }

  n = a_size[0];
  d_idx_0 = a_size[0];
  if (0 <= d_idx_0 - 1) {
    memset(&work_data[0], 0, d_idx_0 * sizeof(creal_T));
  }

  e = a_size[0] - 2;
  for (d_idx_0 = 0; d_idx_0 <= e; d_idx_0++) {
    im1n_tmp = d_idx_0 * n;
    in = (d_idx_0 + 1) * n;
    ia0 = (im1n_tmp + n) - 1;
    c_tmp_tmp = n - d_idx_0;
    c_tmp = c_tmp_tmp - 2;
    jy = c_a_size_idx_0 * c_a_size_idx_1 - 1;
    if (0 <= jy) {
      memcpy(&c_a_data_0[0], &c_a_data[0], (jy + 1) * sizeof(creal_T));
    }

    lastc = (c_a_size_idx_0 * d_idx_0 + d_idx_0) + 1;
    b_alpha1 = c_a_data[lastc];
    tau_data[d_idx_0].re = 0.0;
    tau_data[d_idx_0].im = 0.0;
    if (c_tmp + 1 > 0) {
      xnorm = 0.0;
      if (c_tmp >= 1) {
        xnorm = rt_hypotd_snf(c_a_data[ia0].re, c_a_data[ia0].im);
      }

      if ((xnorm != 0.0) || (c_a_data[lastc].im != 0.0)) {
        xnorm = AutomatedParkingValet_xdlapy3(c_a_data[lastc].re, c_a_data[lastc]
          .im, xnorm);
        if (c_a_data[lastc].re >= 0.0) {
          xnorm = -xnorm;
        }

        if (fabs(xnorm) < 1.0020841800044864E-292) {
          knt = -1;
          rowleft = ia0 + c_tmp;
          do {
            knt++;
            for (lastc = ia0 + 1; lastc <= rowleft; lastc++) {
              c_im = c_a_data_0[lastc - 1].im * 9.9792015476736E+291 +
                c_a_data_0[lastc - 1].re * 0.0;
              c_a_data_0[lastc - 1].re = c_a_data_0[lastc - 1].re *
                9.9792015476736E+291 - c_a_data_0[lastc - 1].im * 0.0;
              c_a_data_0[lastc - 1].im = c_im;
            }

            xnorm *= 9.9792015476736E+291;
            b_alpha1.re *= 9.9792015476736E+291;
            b_alpha1.im *= 9.9792015476736E+291;
          } while (!(fabs(xnorm) >= 1.0020841800044864E-292));

          xnorm = 0.0;
          if (c_tmp >= 1) {
            xnorm = rt_hypotd_snf(c_a_data_0[ia0].re, c_a_data_0[ia0].im);
          }

          xnorm = AutomatedParkingValet_xdlapy3(b_alpha1.re, b_alpha1.im, xnorm);
          if (b_alpha1.re >= 0.0) {
            xnorm = -xnorm;
          }

          c_im = xnorm - b_alpha1.re;
          if (0.0 - b_alpha1.im == 0.0) {
            tau_data[d_idx_0].re = c_im / xnorm;
            tau_data[d_idx_0].im = 0.0;
          } else if (c_im == 0.0) {
            tau_data[d_idx_0].re = 0.0;
            tau_data[d_idx_0].im = (0.0 - b_alpha1.im) / xnorm;
          } else {
            tau_data[d_idx_0].re = c_im / xnorm;
            tau_data[d_idx_0].im = (0.0 - b_alpha1.im) / xnorm;
          }

          b_alpha1_0.re = b_alpha1.re - xnorm;
          b_alpha1_0.im = b_alpha1.im;
          b_alpha1 = AutomatedParkingValet_recip(b_alpha1_0);
          alpha1_re = b_alpha1.re;
          alpha1_im = b_alpha1.im;
          for (lastc = ia0 + 1; lastc <= rowleft; lastc++) {
            c_im = c_a_data_0[lastc - 1].im * alpha1_re + c_a_data_0[lastc - 1].
              re * alpha1_im;
            c_a_data_0[lastc - 1].re = c_a_data_0[lastc - 1].re * alpha1_re -
              c_a_data_0[lastc - 1].im * alpha1_im;
            c_a_data_0[lastc - 1].im = c_im;
          }

          for (lastc = 0; lastc <= knt; lastc++) {
            xnorm *= 1.0020841800044864E-292;
          }

          b_alpha1.re = xnorm;
          b_alpha1.im = 0.0;
        } else {
          c_im = xnorm - c_a_data[lastc].re;
          if (0.0 - c_a_data[lastc].im == 0.0) {
            tau_data[d_idx_0].re = c_im / xnorm;
            tau_data[d_idx_0].im = 0.0;
          } else if (c_im == 0.0) {
            tau_data[d_idx_0].re = 0.0;
            tau_data[d_idx_0].im = (0.0 - c_a_data[lastc].im) / xnorm;
          } else {
            tau_data[d_idx_0].re = c_im / xnorm;
            tau_data[d_idx_0].im = (0.0 - c_a_data[lastc].im) / xnorm;
          }

          c_a_data_1.re = c_a_data[lastc].re - xnorm;
          c_a_data_1.im = c_a_data[lastc].im;
          tmp = AutomatedParkingValet_recip(c_a_data_1);
          alpha1_re = tmp.re;
          alpha1_im = tmp.im;
          if (0 <= jy) {
            memcpy(&c_a_data_0[0], &c_a_data[0], (jy + 1) * sizeof(creal_T));
          }

          rowleft = ia0 + c_tmp;
          for (lastc = ia0 + 1; lastc <= rowleft; lastc++) {
            c_im = c_a_data_0[lastc - 1].im * alpha1_re + c_a_data_0[lastc - 1].
              re * alpha1_im;
            c_a_data_0[lastc - 1].re = c_a_data_0[lastc - 1].re * alpha1_re -
              c_a_data_0[lastc - 1].im * alpha1_im;
            c_a_data_0[lastc - 1].im = c_im;
          }

          b_alpha1.re = xnorm;
          b_alpha1.im = 0.0;
        }
      }
    }

    rowleft = c_a_size_idx_0 * c_a_size_idx_1 - 1;
    if (0 <= rowleft) {
      memcpy(&c_a_data[0], &c_a_data_0[0], (rowleft + 1) * sizeof(creal_T));
    }

    ia0 = (d_idx_0 + c_a_size_idx_0 * d_idx_0) + 1;
    c_a_data[ia0].re = 1.0;
    c_a_data[ia0].im = 0.0;
    ia0 = c_tmp;
    im1n_tmp = (d_idx_0 + im1n_tmp) + 2;
    jy = im1n_tmp - 1;
    rowleft = c_a_size_idx_0 * c_a_size_idx_1 - 1;
    if (0 <= rowleft) {
      memcpy(&c_a_data_0[0], &c_a_data[0], (rowleft + 1) * sizeof(creal_T));
    }

    if ((tau_data[d_idx_0].re != 0.0) || (tau_data[d_idx_0].im != 0.0)) {
      lastc = jy + c_tmp;
      while ((ia0 + 1 > 0) && ((c_a_data[lastc].re == 0.0) && (c_a_data[lastc].
               im == 0.0))) {
        ia0--;
        lastc--;
      }

      lastc = n;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        rowleft = in + lastc;
        rowright = ia0 * n + rowleft;
        do {
          exitg1 = 0;
          if (((n > 0) && (rowleft <= rowright)) || ((n < 0) && (rowleft >=
                rowright))) {
            if ((c_a_data[rowleft - 1].re != 0.0) || (c_a_data[rowleft - 1].im
                 != 0.0)) {
              exitg1 = 1;
            } else {
              rowleft += n;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);

        if (exitg1 == 1) {
          exitg2 = true;
        }
      }

      rowleft = c_a_size_idx_0 * c_a_size_idx_1 - 1;
      if (0 <= rowleft) {
        memcpy(&c_a_data_0[0], &c_a_data[0], (rowleft + 1) * sizeof(creal_T));
      }
    } else {
      ia0 = -1;
      lastc = 0;
    }

    if (ia0 + 1 > 0) {
      if (lastc != 0) {
        if (0 <= lastc - 1) {
          memset(&work_data[0], 0, lastc * sizeof(creal_T));
        }

        knt = jy;
        rowleft = n * ia0 + in;
        for (iac = in + 1; n < 0 ? iac >= rowleft + 1 : iac <= rowleft + 1; iac +=
             n) {
          xnorm = c_a_data_0[knt].re - 0.0 * c_a_data_0[knt].im;
          c_im = 0.0 * c_a_data_0[knt].re + c_a_data_0[knt].im;
          iy = 0;
          d = iac + lastc;
          for (rowright = iac; rowright < d; rowright++) {
            work_data[iy].re += c_a_data_0[rowright - 1].re * xnorm -
              c_a_data_0[rowright - 1].im * c_im;
            work_data[iy].im += c_a_data_0[rowright - 1].re * c_im +
              c_a_data_0[rowright - 1].im * xnorm;
            iy++;
          }

          knt++;
        }
      }

      alpha1_re = -tau_data[d_idx_0].re;
      alpha1_im = -tau_data[d_idx_0].im;
      if ((!(-tau_data[d_idx_0].re == 0.0)) || (!(-tau_data[d_idx_0].im == 0.0)))
      {
        rowright = in;
        for (iac = 0; iac <= ia0; iac++) {
          if ((c_a_data_0[jy].re != 0.0) || (c_a_data_0[jy].im != 0.0)) {
            xnorm = c_a_data_0[jy].re * alpha1_re + c_a_data_0[jy].im *
              alpha1_im;
            c_im = c_a_data_0[jy].re * alpha1_im - c_a_data_0[jy].im * alpha1_re;
            knt = 0;
            rowleft = lastc + rowright;
            for (iy = rowright + 1; iy <= rowleft; iy++) {
              c_a_data_0[iy - 1].re += work_data[knt].re * xnorm - work_data[knt]
                .im * c_im;
              c_a_data_0[iy - 1].im += work_data[knt].re * c_im + work_data[knt]
                .im * xnorm;
              knt++;
            }
          }

          jy++;
          rowright += n;
        }
      }
    }

    ia0 = c_tmp_tmp - 1;
    in = (d_idx_0 + in) + 2;
    alpha1_re = tau_data[d_idx_0].re;
    alpha1_im = -tau_data[d_idx_0].im;
    jy = c_a_size_idx_0 * c_a_size_idx_1 - 1;
    if (0 <= jy) {
      memcpy(&e_a_data[0], &c_a_data_0[0], (jy + 1) * sizeof(creal_T));
    }

    if ((tau_data[d_idx_0].re != 0.0) || (-tau_data[d_idx_0].im != 0.0)) {
      lastc = (im1n_tmp + ia0) - 2;
      while ((ia0 > 0) && ((c_a_data_0[lastc].re == 0.0) && (c_a_data_0[lastc].
               im == 0.0))) {
        ia0--;
        lastc--;
      }

      lastc = c_tmp;
      exitg2 = false;
      while ((!exitg2) && (lastc + 1 > 0)) {
        rowleft = lastc * n + in;
        rowright = rowleft;
        do {
          exitg1 = 0;
          if (rowright <= (rowleft + ia0) - 1) {
            if ((c_a_data_0[rowright - 1].re != 0.0) || (c_a_data_0[rowright - 1]
                 .im != 0.0)) {
              exitg1 = 1;
            } else {
              rowright++;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);

        if (exitg1 == 1) {
          exitg2 = true;
        }
      }

      if (0 <= jy) {
        memcpy(&e_a_data[0], &c_a_data_0[0], (jy + 1) * sizeof(creal_T));
      }
    } else {
      ia0 = 0;
      lastc = -1;
    }

    if (ia0 > 0) {
      if (lastc + 1 != 0) {
        if (0 <= lastc) {
          memset(&work_data[0], 0, (lastc + 1) * sizeof(creal_T));
        }

        iy = 0;
        rowleft = n * lastc + in;
        for (iac = in; n < 0 ? iac >= rowleft : iac <= rowleft; iac += n) {
          knt = im1n_tmp - 1;
          xnorm = 0.0;
          c_im = 0.0;
          d = iac + ia0;
          for (rowright = iac; rowright < d; rowright++) {
            xnorm += e_a_data[rowright - 1].re * e_a_data[knt].re +
              e_a_data[rowright - 1].im * e_a_data[knt].im;
            c_im += e_a_data[rowright - 1].re * e_a_data[knt].im -
              e_a_data[rowright - 1].im * e_a_data[knt].re;
            knt++;
          }

          work_data[iy].re += xnorm - 0.0 * c_im;
          work_data[iy].im += 0.0 * xnorm + c_im;
          iy++;
        }
      }

      if ((!(-tau_data[d_idx_0].re == 0.0)) || (!(tau_data[d_idx_0].im == 0.0)))
      {
        rowright = in;
        jy = 0;
        for (iac = 0; iac <= lastc; iac++) {
          if ((work_data[jy].re != 0.0) || (work_data[jy].im != 0.0)) {
            xnorm = work_data[jy].re * -alpha1_re + work_data[jy].im *
              -alpha1_im;
            c_im = work_data[jy].re * -alpha1_im - work_data[jy].im * -alpha1_re;
            knt = im1n_tmp - 1;
            in = (ia0 + rowright) - 1;
            for (iy = rowright; iy <= in; iy++) {
              e_a_data_im = e_a_data[knt].re * c_im + e_a_data[knt].im * xnorm;
              e_a_data[iy - 1].re += e_a_data[knt].re * xnorm - e_a_data[knt].im
                * c_im;
              e_a_data[iy - 1].im += e_a_data_im;
              knt++;
            }
          }

          jy++;
          rowright += n;
        }
      }
    }

    rowleft = c_a_size_idx_0 * c_a_size_idx_1 - 1;
    if (0 <= rowleft) {
      memcpy(&c_a_data[0], &e_a_data[0], (rowleft + 1) * sizeof(creal_T));
    }

    c_a_data[(d_idx_0 + c_a_size_idx_0 * d_idx_0) + 1] = b_alpha1;
  }

  b_a_size[0] = c_a_size_idx_0;
  b_a_size[1] = c_a_size_idx_1;
  rowleft = c_a_size_idx_0 * c_a_size_idx_1 - 1;
  if (0 <= rowleft) {
    memcpy(&b_a_data[0], &c_a_data[0], (rowleft + 1) * sizeof(creal_T));
  }
}

static void AutomatedParkingValet_xhseqr(const creal_T h_data[], const int32_T
  h_size[2], creal_T b_h_data[], int32_T b_h_size[2], int32_T *info)
{
  creal_T c_h_data[9];
  int32_T n;
  int32_T ldh;
  int32_T i;
  real_T SMLNUM;
  int32_T L;
  boolean_T goto140;
  real_T tst;
  real_T htmp1;
  real_T ab;
  real_T ba;
  creal_T x2;
  boolean_T goto70;
  int32_T m;
  int32_T d;
  int32_T its;
  int32_T knt;
  int32_T b;
  int32_T c_h_size_idx_0;
  creal_T tmp;
  creal_T tmp_0;
  creal_T x2_0;
  creal_T v_idx_0;
  creal_T x2_1;
  real_T sc_re;
  real_T sc_im;
  real_T u2_re;
  real_T u2_im;
  real_T v_idx_0_re;
  real_T v_idx_0_im;
  real_T v_idx_1_re;
  real_T v_idx_1_im;
  int32_T loop_ub_tmp;
  int32_T tst_tmp;
  int32_T knt_tmp;
  real_T x2_tmp;
  boolean_T exitg1;
  boolean_T exitg2;
  boolean_T exitg3;
  c_h_size_idx_0 = h_size[0];
  loop_ub_tmp = h_size[0] * h_size[1] - 1;
  if (0 <= loop_ub_tmp) {
    memcpy(&c_h_data[0], &h_data[0], (loop_ub_tmp + 1) * sizeof(creal_T));
  }

  n = h_size[0];
  ldh = h_size[0];
  *info = 0;
  if (1 != h_size[0]) {
    d = h_size[0] - 4;
    for (i = 0; i <= d; i++) {
      tst_tmp = i + c_h_size_idx_0 * i;
      L = tst_tmp + 2;
      c_h_data[L].re = 0.0;
      c_h_data[L].im = 0.0;
      tst_tmp += 3;
      c_h_data[tst_tmp].re = 0.0;
      c_h_data[tst_tmp].im = 0.0;
    }

    if (1 <= h_size[0] - 2) {
      c_h_data[h_size[0] - 1].re = 0.0;
      c_h_data[h_size[0] - 1].im = 0.0;
    }

    for (i = 2; i <= n; i++) {
      if (c_h_data[((i - 2) * c_h_size_idx_0 + i) - 1].im != 0.0) {
        d = ((i - 2) * c_h_size_idx_0 + i) - 1;
        L = ((i - 2) * c_h_size_idx_0 + i) - 1;
        tst = fabs(c_h_data[L].re) + fabs(c_h_data[L].im);
        if (c_h_data[d].im == 0.0) {
          sc_re = c_h_data[d].re / tst;
          sc_im = 0.0;
        } else if (c_h_data[d].re == 0.0) {
          sc_re = 0.0;
          sc_im = c_h_data[d].im / tst;
        } else {
          sc_re = c_h_data[d].re / tst;
          sc_im = c_h_data[d].im / tst;
        }

        tst = rt_hypotd_snf(sc_re, sc_im);
        if (-sc_im == 0.0) {
          ba = sc_re / tst;
          htmp1 = 0.0;
        } else if (sc_re == 0.0) {
          ba = 0.0;
          htmp1 = -sc_im / tst;
        } else {
          ba = sc_re / tst;
          htmp1 = -sc_im / tst;
        }

        c_h_data[L].re = rt_hypotd_snf(c_h_data[L].re, c_h_data[L].im);
        c_h_data[L].im = 0.0;
        knt_tmp = (i - 1) * ldh;
        knt = knt_tmp + i;
        b = (n - i) * ldh + knt;
        for (d = knt; ldh < 0 ? d >= b : d <= b; d += ldh) {
          ab = c_h_data[d - 1].im * ba + c_h_data[d - 1].re * htmp1;
          c_h_data[d - 1].re = c_h_data[d - 1].re * ba - c_h_data[d - 1].im *
            htmp1;
          c_h_data[d - 1].im = ab;
        }

        b = knt_tmp + n;
        for (d = knt_tmp + 1; d <= b; d++) {
          ab = c_h_data[d - 1].im * ba + c_h_data[d - 1].re * -htmp1;
          c_h_data[d - 1].re = c_h_data[d - 1].re * ba - c_h_data[d - 1].im *
            -htmp1;
          c_h_data[d - 1].im = ab;
        }
      }
    }

    SMLNUM = (real_T)h_size[0] / 2.2204460492503131E-16 *
      2.2250738585072014E-308;
    i = h_size[0] - 1;
    exitg1 = false;
    while ((!exitg1) && (i + 1 >= 1)) {
      L = 1;
      goto140 = false;
      its = 0;
      exitg2 = false;
      while ((!exitg2) && (its < 301)) {
        d = i;
        exitg3 = false;
        while ((!exitg3) && (d + 1 > L)) {
          tst_tmp = (d - 1) * c_h_size_idx_0 + d;
          ab = fabs(c_h_data[tst_tmp].re);
          ba = ab + fabs(c_h_data[tst_tmp].im);
          if (ba <= SMLNUM) {
            exitg3 = true;
          } else {
            m = tst_tmp - 1;
            tst_tmp = c_h_size_idx_0 * d + d;
            htmp1 = fabs(c_h_data[tst_tmp].re) + fabs(c_h_data[tst_tmp].im);
            tst = (fabs(c_h_data[m].re) + fabs(c_h_data[m].im)) + htmp1;
            if (tst == 0.0) {
              if (d - 1 >= 1) {
                tst = fabs(c_h_data[((d - 2) * c_h_size_idx_0 + d) - 1].re);
              }

              if (d + 2 <= n) {
                tst += fabs(c_h_data[(c_h_size_idx_0 * d + d) + 1].re);
              }
            }

            if (ab <= 2.2204460492503131E-16 * tst) {
              knt = tst_tmp - 1;
              tst = fabs(c_h_data[knt].re) + fabs(c_h_data[knt].im);
              if (ba > tst) {
                ab = ba;
                ba = tst;
              } else {
                ab = tst;
              }

              tst = fabs(c_h_data[m].re - c_h_data[tst_tmp].re) + fabs
                (c_h_data[m].im - c_h_data[tst_tmp].im);
              if (htmp1 > tst) {
                sc_re = htmp1;
                htmp1 = tst;
              } else {
                sc_re = tst;
              }

              tst = sc_re + ab;
              if (ab / tst * ba <= fmax(SMLNUM, sc_re / tst * htmp1 *
                   2.2204460492503131E-16)) {
                exitg3 = true;
              } else {
                d--;
              }
            } else {
              d--;
            }
          }
        }

        L = d + 1;
        if (d + 1 > 1) {
          tst_tmp = d + c_h_size_idx_0 * (d - 1);
          c_h_data[tst_tmp].re = 0.0;
          c_h_data[tst_tmp].im = 0.0;
        }

        if (d + 1 >= i + 1) {
          goto140 = true;
          exitg2 = true;
        } else {
          if (its == 10) {
            m = c_h_size_idx_0 * d + d;
            sc_re = fabs(c_h_data[m + 1].re) * 0.75 + c_h_data[m].re;
            sc_im = c_h_data[m].im;
          } else if (its == 20) {
            m = c_h_size_idx_0 * i + i;
            sc_re = fabs(c_h_data[(i - 1) * c_h_size_idx_0 + i].re) * 0.75 +
              c_h_data[m].re;
            sc_im = c_h_data[m].im;
          } else {
            m = c_h_size_idx_0 * i + i;
            sc_re = c_h_data[m].re;
            sc_im = c_h_data[m].im;
            tmp = AutomatedParkingValet_sqrt_p(c_h_data[m - 1]);
            tst_tmp = (i - 1) * c_h_size_idx_0 + i;
            tmp_0 = AutomatedParkingValet_sqrt_p(c_h_data[tst_tmp]);
            ba = tmp.re * tmp_0.re - tmp.im * tmp_0.im;
            ab = tmp.re * tmp_0.im + tmp.im * tmp_0.re;
            tst = fabs(ba) + fabs(ab);
            if (tst != 0.0) {
              tst_tmp--;
              sc_re = (c_h_data[tst_tmp].re - c_h_data[m].re) * 0.5;
              sc_im = (c_h_data[tst_tmp].im - c_h_data[m].im) * 0.5;
              htmp1 = fabs(sc_re) + fabs(sc_im);
              tst = fmax(tst, htmp1);
              if (sc_im == 0.0) {
                x2.re = sc_re / tst;
                x2.im = 0.0;
              } else if (sc_re == 0.0) {
                x2.re = 0.0;
                x2.im = sc_im / tst;
              } else {
                x2.re = sc_re / tst;
                x2.im = sc_im / tst;
              }

              if (ab == 0.0) {
                u2_re = ba / tst;
                u2_im = 0.0;
              } else if (ba == 0.0) {
                u2_re = 0.0;
                u2_im = ab / tst;
              } else {
                u2_re = ba / tst;
                u2_im = ab / tst;
              }

              x2_0.re = (x2.re * x2.re - x2.im * x2.im) + (u2_re * u2_re - u2_im
                * u2_im);
              x2_tmp = x2.re * x2.im;
              u2_im *= u2_re;
              x2_0.im = (x2_tmp + x2_tmp) + (u2_im + u2_im);
              tmp = AutomatedParkingValet_sqrt_p(x2_0);
              u2_re = tst * tmp.re;
              u2_im = tst * tmp.im;
              if (htmp1 > 0.0) {
                if (sc_im == 0.0) {
                  x2.re = sc_re / htmp1;
                  x2.im = 0.0;
                } else if (sc_re == 0.0) {
                  x2.re = 0.0;
                  x2.im = sc_im / htmp1;
                } else {
                  x2.re = sc_re / htmp1;
                  x2.im = sc_im / htmp1;
                }

                if (x2.re * u2_re + x2.im * u2_im < 0.0) {
                  u2_re = -u2_re;
                  u2_im = -u2_im;
                }
              }

              tst = sc_re + u2_re;
              sc_re = sc_im + u2_im;
              if (sc_re == 0.0) {
                if (ab == 0.0) {
                  sc_im = ba / tst;
                  tst = 0.0;
                } else if (ba == 0.0) {
                  sc_im = 0.0;
                  tst = ab / tst;
                } else {
                  sc_im = ba / tst;
                  tst = ab / tst;
                }
              } else if (tst == 0.0) {
                if (ba == 0.0) {
                  sc_im = ab / sc_re;
                  tst = 0.0;
                } else if (ab == 0.0) {
                  sc_im = 0.0;
                  tst = -(ba / sc_re);
                } else {
                  sc_im = ab / sc_re;
                  tst = -(ba / sc_re);
                }
              } else {
                htmp1 = fabs(tst);
                sc_im = fabs(sc_re);
                if (htmp1 > sc_im) {
                  htmp1 = sc_re / tst;
                  tst += htmp1 * sc_re;
                  sc_im = (htmp1 * ab + ba) / tst;
                  tst = (ab - htmp1 * ba) / tst;
                } else if (sc_im == htmp1) {
                  tst = tst > 0.0 ? 0.5 : -0.5;
                  sc_re = sc_re > 0.0 ? 0.5 : -0.5;
                  sc_im = (ba * tst + ab * sc_re) / htmp1;
                  tst = (ab * tst - ba * sc_re) / htmp1;
                } else {
                  htmp1 = tst / sc_re;
                  tst = htmp1 * tst + sc_re;
                  sc_im = (htmp1 * ba + ab) / tst;
                  tst = (htmp1 * ab - ba) / tst;
                }
              }

              sc_re = c_h_data[m].re - (ba * sc_im - ab * tst);
              sc_im = c_h_data[m].im - (ba * tst + ab * sc_im);
            }
          }

          goto70 = false;
          m = i;
          exitg3 = false;
          while ((!exitg3) && (m > d + 1)) {
            ba = c_h_data[c_h_size_idx_0 + 1].re - sc_re;
            ab = c_h_data[c_h_size_idx_0 + 1].im - sc_im;
            htmp1 = c_h_data[c_h_size_idx_0 + 2].re;
            tst = (fabs(ba) + fabs(ab)) + fabs(htmp1);
            if (ab == 0.0) {
              v_idx_0_re = ba / tst;
              v_idx_0_im = 0.0;
            } else if (ba == 0.0) {
              v_idx_0_re = 0.0;
              v_idx_0_im = ab / tst;
            } else {
              v_idx_0_re = ba / tst;
              v_idx_0_im = ab / tst;
            }

            htmp1 /= tst;
            v_idx_1_re = htmp1;
            v_idx_1_im = 0.0;
            tst_tmp = (c_h_size_idx_0 << 1) + 2;
            if (fabs(c_h_data[1].re) * fabs(htmp1) <= ((fabs(c_h_data[tst_tmp].
                   re) + fabs(c_h_data[tst_tmp].im)) + (fabs
                  (c_h_data[c_h_size_idx_0 + 1].re) + fabs
                  (c_h_data[c_h_size_idx_0 + 1].im))) * (fabs(v_idx_0_re) + fabs
                 (v_idx_0_im)) * 2.2204460492503131E-16) {
              goto70 = true;
              exitg3 = true;
            } else {
              m = 1;
            }
          }

          if (!goto70) {
            tst_tmp = c_h_size_idx_0 * d + d;
            ba = c_h_data[tst_tmp].re - sc_re;
            ab = c_h_data[tst_tmp].im - sc_im;
            htmp1 = c_h_data[(c_h_size_idx_0 * d + d) + 1].re;
            tst = (fabs(ba) + fabs(ab)) + fabs(htmp1);
            if (ab == 0.0) {
              v_idx_0_re = ba / tst;
              v_idx_0_im = 0.0;
            } else if (ba == 0.0) {
              v_idx_0_re = 0.0;
              v_idx_0_im = ab / tst;
            } else {
              v_idx_0_re = ba / tst;
              v_idx_0_im = ab / tst;
            }

            v_idx_1_re = htmp1 / tst;
            v_idx_1_im = 0.0;
          }

          for (tst_tmp = m; tst_tmp <= i; tst_tmp++) {
            if (tst_tmp > m) {
              v_idx_0_re = c_h_data[1].re;
              v_idx_0_im = c_h_data[1].im;
              v_idx_1_re = c_h_data[2].re;
              v_idx_1_im = c_h_data[2].im;
            }

            ba = v_idx_1_re;
            ab = v_idx_1_im;
            x2.re = v_idx_0_re;
            x2.im = v_idx_0_im;
            sc_re = 0.0;
            sc_im = 0.0;
            tst = rt_hypotd_snf(v_idx_1_re, v_idx_1_im);
            if ((tst != 0.0) || (v_idx_0_im != 0.0)) {
              tst = AutomatedParkingValet_xdlapy3(v_idx_0_re, v_idx_0_im, tst);
              if (v_idx_0_re >= 0.0) {
                tst = -tst;
              }

              if (fabs(tst) < 1.0020841800044864E-292) {
                knt = -1;
                do {
                  knt++;
                  ba *= 9.9792015476736E+291;
                  ab *= 9.9792015476736E+291;
                  tst *= 9.9792015476736E+291;
                  x2.re *= 9.9792015476736E+291;
                  x2.im *= 9.9792015476736E+291;
                } while (!(fabs(tst) >= 1.0020841800044864E-292));

                tst = AutomatedParkingValet_xdlapy3(x2.re, x2.im, rt_hypotd_snf
                  (ba, ab));
                if (x2.re >= 0.0) {
                  tst = -tst;
                }

                htmp1 = tst - x2.re;
                if (0.0 - x2.im == 0.0) {
                  sc_re = htmp1 / tst;
                } else if (htmp1 == 0.0) {
                  sc_im = (0.0 - x2.im) / tst;
                } else {
                  sc_re = htmp1 / tst;
                  sc_im = (0.0 - x2.im) / tst;
                }

                x2_1.re = x2.re - tst;
                x2_1.im = x2.im;
                x2 = AutomatedParkingValet_recip(x2_1);
                htmp1 = x2.re * ab + x2.im * ba;
                ba = x2.re * ba - x2.im * ab;
                ab = htmp1;
                for (b = 0; b <= knt; b++) {
                  tst *= 1.0020841800044864E-292;
                }

                x2.re = tst;
                x2.im = 0.0;
              } else {
                htmp1 = tst - v_idx_0_re;
                if (0.0 - v_idx_0_im == 0.0) {
                  sc_re = htmp1 / tst;
                } else if (htmp1 == 0.0) {
                  sc_im = (0.0 - v_idx_0_im) / tst;
                } else {
                  sc_re = htmp1 / tst;
                  sc_im = (0.0 - v_idx_0_im) / tst;
                }

                v_idx_0.re = v_idx_0_re - tst;
                v_idx_0.im = v_idx_0_im;
                tmp = AutomatedParkingValet_recip(v_idx_0);
                ba = tmp.re * v_idx_1_re - tmp.im * v_idx_1_im;
                ab = tmp.re * v_idx_1_im + tmp.im * v_idx_1_re;
                x2.re = tst;
                x2.im = 0.0;
              }
            }

            v_idx_0_re = x2.re;
            v_idx_0_im = x2.im;
            v_idx_1_re = ba;
            v_idx_1_im = ab;
            if (tst_tmp > m) {
              c_h_data[1] = x2;
              c_h_data[2].re = 0.0;
              c_h_data[2].im = 0.0;
            }

            tst = sc_re * ba - sc_im * ab;
            for (knt = tst_tmp; knt <= n; knt++) {
              b = (knt - 1) * c_h_size_idx_0 + tst_tmp;
              knt_tmp = b - 1;
              x2.re = (c_h_data[knt_tmp].re * sc_re - c_h_data[knt_tmp].im *
                       -sc_im) + c_h_data[b].re * tst;
              x2.im = (c_h_data[knt_tmp].im * sc_re + c_h_data[knt_tmp].re *
                       -sc_im) + c_h_data[b].im * tst;
              c_h_data[knt_tmp].re -= x2.re;
              c_h_data[knt_tmp].im -= x2.im;
              c_h_data[b].re -= x2.re * ba - x2.im * ab;
              c_h_data[b].im -= x2.re * ab + x2.im * ba;
            }

            for (b = 0; b <= i; b++) {
              knt_tmp = (tst_tmp - 1) * c_h_size_idx_0 + b;
              knt = c_h_size_idx_0 * tst_tmp + b;
              x2.re = (c_h_data[knt_tmp].re * sc_re - c_h_data[knt_tmp].im *
                       sc_im) + c_h_data[knt].re * tst;
              x2.im = (c_h_data[knt_tmp].im * sc_re + c_h_data[knt_tmp].re *
                       sc_im) + c_h_data[knt].im * tst;
              c_h_data[knt_tmp].re -= x2.re;
              c_h_data[knt_tmp].im -= x2.im;
              c_h_data[knt].re -= x2.re * ba - x2.im * -ab;
              c_h_data[knt].im -= x2.re * -ab + x2.im * ba;
            }

            if ((tst_tmp == m) && (m > d + 1)) {
              sc_re = 1.0 - sc_re;
              sc_im = 0.0 - sc_im;
              tst = rt_hypotd_snf(sc_re, sc_im);
              if (sc_im == 0.0) {
                ba = sc_re / tst;
                htmp1 = 0.0;
              } else if (sc_re == 0.0) {
                ba = 0.0;
                htmp1 = sc_im / tst;
              } else {
                ba = sc_re / tst;
                htmp1 = sc_im / tst;
              }

              ab = c_h_data[c_h_size_idx_0 + 2].re * -htmp1 +
                c_h_data[c_h_size_idx_0 + 2].im * ba;
              c_h_data[c_h_size_idx_0 + 2].re = c_h_data[c_h_size_idx_0 + 2].re *
                ba - c_h_data[c_h_size_idx_0 + 2].im * -htmp1;
              c_h_data[c_h_size_idx_0 + 2].im = ab;
              if (4 <= i + 1) {
                knt = (c_h_size_idx_0 << 1) + 3;
                ab = c_h_data[knt].re * htmp1 + c_h_data[knt].im * ba;
                c_h_data[knt].re = c_h_data[knt].re * ba - c_h_data[knt].im *
                  htmp1;
                c_h_data[knt].im = ab;
              }

              for (knt = 2; knt <= i + 1; knt++) {
                if (knt != 3) {
                  if (n > 2) {
                    knt_tmp = ldh << 1;
                    for (b = knt_tmp + 2; ldh < 0 ? b >= knt_tmp + 2 : b <=
                         knt_tmp + 2; b += ldh) {
                      ab = c_h_data[b - 1].im * ba + c_h_data[b - 1].re * htmp1;
                      c_h_data[b - 1].re = c_h_data[b - 1].re * ba - c_h_data[b
                        - 1].im * htmp1;
                      c_h_data[b - 1].im = ab;
                    }
                  }

                  for (b = ldh + 1; b <= ldh + 1; b++) {
                    ab = c_h_data[b - 1].im * ba + c_h_data[b - 1].re * -htmp1;
                    c_h_data[b - 1].re = c_h_data[b - 1].re * ba - c_h_data[b -
                      1].im * -htmp1;
                    c_h_data[b - 1].im = ab;
                  }
                }
              }
            }
          }

          m = (i - 1) * c_h_size_idx_0 + i;
          sc_re = c_h_data[m].re;
          sc_im = c_h_data[m].im;
          if (c_h_data[m].im != 0.0) {
            tst = rt_hypotd_snf(c_h_data[m].re, c_h_data[m].im);
            c_h_data[m].re = tst;
            c_h_data[m].im = 0.0;
            if (sc_im == 0.0) {
              ba = sc_re / tst;
              htmp1 = 0.0;
            } else if (sc_re == 0.0) {
              ba = 0.0;
              htmp1 = sc_im / tst;
            } else {
              ba = sc_re / tst;
              htmp1 = sc_im / tst;
            }

            if (n > i + 1) {
              knt_tmp = ldh << 1;
              for (d = knt_tmp + 2; ldh < 0 ? d >= knt_tmp + 2 : d <= knt_tmp +
                   2; d += ldh) {
                ab = c_h_data[d - 1].im * ba + c_h_data[d - 1].re * -htmp1;
                c_h_data[d - 1].re = c_h_data[d - 1].re * ba - c_h_data[d - 1].
                  im * -htmp1;
                c_h_data[d - 1].im = ab;
              }
            }

            knt_tmp = i * ldh;
            b = knt_tmp + i;
            for (d = knt_tmp + 1; d <= b; d++) {
              ab = c_h_data[d - 1].im * ba + c_h_data[d - 1].re * htmp1;
              c_h_data[d - 1].re = c_h_data[d - 1].re * ba - c_h_data[d - 1].im *
                htmp1;
              c_h_data[d - 1].im = ab;
            }
          }

          its++;
        }
      }

      if (!goto140) {
        *info = i + 1;
        exitg1 = true;
      } else {
        i = L - 2;
      }
    }
  }

  b_h_size[0] = h_size[0];
  b_h_size[1] = h_size[1];
  if (0 <= loop_ub_tmp) {
    memcpy(&b_h_data[0], &c_h_data[0], (loop_ub_tmp + 1) * sizeof(creal_T));
  }
}

static void AutomatedParkingValet_roots(const real_T c[4], creal_T r_data[],
  int32_T *r_size)
{
  int32_T k1;
  int32_T k2;
  int32_T nTrailingZeros;
  int32_T companDim;
  real_T ctmp[4];
  int32_T j;
  creal_T a_data[9];
  creal_T eiga_data[3];
  creal_T beta1_data[3];
  boolean_T b_p;
  int32_T jend;
  creal_T tmp_data[9];
  int32_T a_size[2];
  int32_T tmp_size[2];
  real_T brm;
  real_T bim;
  real_T sgnbi;
  real_T d;
  int32_T companDim_0;
  creal_T eiga_data_0;
  boolean_T exitg1;
  boolean_T exitg2;
  int32_T exitg3;
  r_data[0].re = 0.0;
  r_data[0].im = 0.0;
  r_data[1].re = 0.0;
  r_data[1].im = 0.0;
  r_data[2].re = 0.0;
  r_data[2].im = 0.0;
  k1 = 1;
  while ((k1 <= 4) && (!(c[k1 - 1] != 0.0))) {
    k1++;
  }

  k2 = 4;
  while ((k2 >= k1) && (!(c[k2 - 1] != 0.0))) {
    k2--;
  }

  nTrailingZeros = 3 - k2;
  if (k1 < k2) {
    companDim = k2 - k1;
    exitg1 = false;
    while ((!exitg1) && (companDim > 0)) {
      j = 0;
      exitg2 = false;
      while ((!exitg2) && (j + 1 <= companDim)) {
        ctmp[j] = c[k1 + j] / c[k1 - 1];
        if (rtIsInf(fabs(ctmp[j]))) {
          exitg2 = true;
        } else {
          j++;
        }
      }

      if (j + 1 > companDim) {
        exitg1 = true;
      } else {
        k1++;
        companDim--;
      }
    }

    if (companDim < 1) {
      if (1 > 4 - k2) {
        nTrailingZeros = 0;
      } else {
        nTrailingZeros = 4 - k2;
      }

      *r_size = nTrailingZeros;
    } else {
      a_size[0] = companDim;
      a_size[1] = companDim;
      jend = companDim * companDim - 1;
      if (0 <= jend) {
        memset(&a_data[0], 0, (jend + 1) * sizeof(creal_T));
      }

      j = companDim - 2;
      for (k1 = 0; k1 <= j; k1++) {
        companDim_0 = companDim * k1;
        a_data[companDim_0].re = -ctmp[k1];
        a_data[companDim_0].im = 0.0;
        companDim_0 = (k1 + companDim_0) + 1;
        a_data[companDim_0].re = 1.0;
        a_data[companDim_0].im = 0.0;
      }

      companDim_0 = companDim * (companDim - 1);
      a_data[companDim_0].re = -ctmp[companDim - 1];
      a_data[companDim_0].im = 0.0;
      if (0 <= nTrailingZeros) {
        memset(&r_data[0], 0, (nTrailingZeros + 1) * sizeof(creal_T));
      }

      if (AutomatedParkingVa_anyNonFinite(a_data, a_size)) {
        if (companDim == 1) {
          eiga_data[0].re = (rtNaN);
          eiga_data[0].im = 0.0;
        } else {
          for (companDim_0 = 0; companDim_0 < companDim; companDim_0++) {
            eiga_data[companDim_0].re = (rtNaN);
            eiga_data[companDim_0].im = 0.0;
          }
        }
      } else if (companDim == 1) {
        eiga_data[0] = a_data[0];
      } else {
        b_p = true;
        nTrailingZeros = 0;
        exitg1 = false;
        while ((!exitg1) && (nTrailingZeros <= companDim - 1)) {
          j = 0;
          do {
            exitg3 = 0;
            if (j <= nTrailingZeros) {
              companDim_0 = companDim * nTrailingZeros + j;
              k1 = companDim * j + nTrailingZeros;
              if ((!(a_data[companDim_0].re == a_data[k1].re)) ||
                  (!(a_data[companDim_0].im == -a_data[k1].im))) {
                b_p = false;
                exitg3 = 1;
              } else {
                j++;
              }
            } else {
              nTrailingZeros++;
              exitg3 = 2;
            }
          } while (exitg3 == 0);

          if (exitg3 == 1) {
            exitg1 = true;
          }
        }

        if (b_p) {
          if (AutomatedParkingVa_anyNonFinite(a_data, a_size)) {
            a_size[0] = companDim;
            for (companDim_0 = 0; companDim_0 <= jend; companDim_0++) {
              a_data[companDim_0].re = (rtNaN);
              a_data[companDim_0].im = 0.0;
            }

            if (1 < companDim) {
              j = 2;
              if (companDim - 2 < companDim - 1) {
                companDim_0 = companDim - 1;
              } else {
                companDim_0 = companDim;
              }

              jend = companDim_0 - 1;
              for (nTrailingZeros = 0; nTrailingZeros <= jend; nTrailingZeros++)
              {
                for (k1 = j; k1 <= companDim; k1++) {
                  companDim_0 = (k1 + companDim * nTrailingZeros) - 1;
                  a_data[companDim_0].re = 0.0;
                  a_data[companDim_0].im = 0.0;
                }

                j++;
              }
            }
          } else {
            AutomatedParkingValet_xgehrd(a_data, a_size, tmp_data, tmp_size);
            AutomatedParkingValet_xhseqr(tmp_data, tmp_size, a_data, a_size, &j);
          }

          nTrailingZeros = a_size[0] - 1;
          for (k1 = 0; k1 <= nTrailingZeros; k1++) {
            eiga_data[k1].re = a_data[a_size[0] * k1 + k1].re;
            eiga_data[k1].im = 0.0;
          }
        } else {
          AutomatedParkingValet_xzgeev(a_data, a_size, &j, eiga_data, &k1,
            beta1_data, &companDim_0);
          for (companDim_0 = 0; companDim_0 < k1; companDim_0++) {
            if (beta1_data[companDim_0].im == 0.0) {
              if (eiga_data[companDim_0].im == 0.0) {
                bim = eiga_data[companDim_0].re / beta1_data[companDim_0].re;
                brm = 0.0;
              } else if (eiga_data[companDim_0].re == 0.0) {
                bim = 0.0;
                brm = eiga_data[companDim_0].im / beta1_data[companDim_0].re;
              } else {
                bim = eiga_data[companDim_0].re / beta1_data[companDim_0].re;
                brm = eiga_data[companDim_0].im / beta1_data[companDim_0].re;
              }
            } else if (beta1_data[companDim_0].re == 0.0) {
              if (eiga_data[companDim_0].re == 0.0) {
                bim = eiga_data[companDim_0].im / beta1_data[companDim_0].im;
                brm = 0.0;
              } else if (eiga_data[companDim_0].im == 0.0) {
                bim = 0.0;
                brm = -(eiga_data[companDim_0].re / beta1_data[companDim_0].im);
              } else {
                bim = eiga_data[companDim_0].im / beta1_data[companDim_0].im;
                brm = -(eiga_data[companDim_0].re / beta1_data[companDim_0].im);
              }
            } else {
              brm = fabs(beta1_data[companDim_0].re);
              bim = fabs(beta1_data[companDim_0].im);
              if (brm > bim) {
                brm = beta1_data[companDim_0].im / beta1_data[companDim_0].re;
                d = brm * beta1_data[companDim_0].im + beta1_data[companDim_0].
                  re;
                bim = (brm * eiga_data[companDim_0].im + eiga_data[companDim_0].
                       re) / d;
                brm = (eiga_data[companDim_0].im - brm * eiga_data[companDim_0].
                       re) / d;
              } else if (bim == brm) {
                d = beta1_data[companDim_0].re > 0.0 ? 0.5 : -0.5;
                sgnbi = beta1_data[companDim_0].im > 0.0 ? 0.5 : -0.5;
                bim = (eiga_data[companDim_0].re * d + eiga_data[companDim_0].im
                       * sgnbi) / brm;
                brm = (eiga_data[companDim_0].im * d - eiga_data[companDim_0].re
                       * sgnbi) / brm;
              } else {
                brm = beta1_data[companDim_0].re / beta1_data[companDim_0].im;
                d = brm * beta1_data[companDim_0].re + beta1_data[companDim_0].
                  im;
                bim = (brm * eiga_data[companDim_0].re + eiga_data[companDim_0].
                       im) / d;
                brm = (brm * eiga_data[companDim_0].im - eiga_data[companDim_0].
                       re) / d;
              }
            }

            eiga_data_0.re = bim;
            eiga_data_0.im = brm;
            eiga_data[companDim_0] = eiga_data_0;
          }
        }
      }

      for (nTrailingZeros = 0; nTrailingZeros < companDim; nTrailingZeros++) {
        r_data[(nTrailingZeros - k2) + 4] = eiga_data[nTrailingZeros];
      }

      *r_size = (companDim - k2) + 4;
    }
  } else {
    if (1 > 4 - k2) {
      nTrailingZeros = 0;
    } else {
      nTrailingZeros = 4 - k2;
    }

    *r_size = nTrailingZeros;
  }
}

static real_T Automat_computeTimeFromDistance(const real_T p[4], real_T tUpper)
{
  real_T t;
  creal_T r_data[3];
  int32_T c;
  real_T absx;
  int32_T b_exponent;
  int32_T r_size;
  AutomatedParkingValet_roots(p, r_data, &r_size);
  t = tUpper;
  c = r_size - 1;
  for (r_size = 0; r_size <= c; r_size++) {
    if ((r_data[r_size].re >= 0.0) && (r_data[r_size].re < t)) {
      if (r_data[r_size].re <= 2.2250738585072014E-308) {
        absx = 4.94065645841247E-324;
      } else {
        frexp(r_data[r_size].re, &b_exponent);
        absx = ldexp(1.0, b_exponent - 53);
      }

      if (fabs(r_data[r_size].im) <= sqrt(absx)) {
        t = r_data[r_size].re;
      }
    }
  }

  return t;
}

static void AutomatedParkingValet_arrayfun(const real_T
  fun_tunableEnvironment_f1[8], real_T fun_tunableEnvironment_f2, real_T
  fun_tunableEnvironment_f3, real_T fun_tunableEnvironment_f4, const real_T
  fun_tunableEnvironment_f5[8], const real_T fun_tunableEnvironment_f6[8], const
  real_T varargin_1_data[], const int32_T *varargin_1_size, real_T
  varargout_1_data[], int32_T *varargout_1_size, real_T varargout_2_data[],
  int32_T *varargout_2_size)
{
  int32_T n;
  real_T b_varargout_1;
  boolean_T x[7];
  int32_T ii_data;
  boolean_T y;
  boolean_T x_data;
  int32_T k;
  int32_T idx;
  int32_T b_ii;
  real_T tmp[4];
  real_T inputExamples_idx_0;
  int32_T ii_size_idx_1;
  boolean_T exitg1;
  if (*varargin_1_size == 0) {
    inputExamples_idx_0 = 0.0;
  } else {
    inputExamples_idx_0 = varargin_1_data[0];
  }

  if (inputExamples_idx_0 == fun_tunableEnvironment_f1[7]) {
    ii_size_idx_1 = 1;
    ii_data = 7;
  } else {
    for (ii_size_idx_1 = 0; ii_size_idx_1 < 7; ii_size_idx_1++) {
      x[ii_size_idx_1] = (fun_tunableEnvironment_f1[ii_size_idx_1 + 1] >
                          inputExamples_idx_0);
    }

    idx = 0;
    ii_size_idx_1 = 1;
    b_ii = 1;
    exitg1 = false;
    while ((!exitg1) && (b_ii - 1 < 7)) {
      if (x[b_ii - 1]) {
        idx = 1;
        ii_data = b_ii;
        exitg1 = true;
      } else {
        b_ii++;
      }
    }

    if (idx == 0) {
      ii_size_idx_1 = 0;
    }
  }

  if (0 <= ii_size_idx_1 - 1) {
    x_data = (ii_data == 1);
  }

  y = (ii_size_idx_1 != 0);
  if (y) {
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k <= ii_size_idx_1 - 1)) {
      if (!x_data) {
        y = false;
        exitg1 = true;
      } else {
        k = 1;
      }
    }
  }

  if (y) {
    tmp[0] = 0.16666666666666666;
    tmp[1] = 0.0;
    tmp[2] = fun_tunableEnvironment_f5[0];
    tmp[3] = -inputExamples_idx_0;
    Automat_computeTimeFromDistance(tmp, fun_tunableEnvironment_f6[1]);
  } else {
    if (0 <= ii_size_idx_1 - 1) {
      x_data = (ii_data == 2);
    }

    y = (ii_size_idx_1 != 0);
    if (y) {
      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k <= ii_size_idx_1 - 1)) {
        if (!x_data) {
          y = false;
          exitg1 = true;
        } else {
          k = 1;
        }
      }
    }

    if (!y) {
      if (0 <= ii_size_idx_1 - 1) {
        x_data = (ii_data == 3);
      }

      y = (ii_size_idx_1 != 0);
      if (y) {
        k = 0;
        exitg1 = false;
        while ((!exitg1) && (k <= ii_size_idx_1 - 1)) {
          if (!x_data) {
            y = false;
            exitg1 = true;
          } else {
            k = 1;
          }
        }
      }

      if (y) {
        tmp[0] = 0.16666666666666666;
        tmp[1] = 0.0;
        tmp[2] = -fun_tunableEnvironment_f4;
        tmp[3] = fun_tunableEnvironment_f1[3] - inputExamples_idx_0;
        Automat_computeTimeFromDistance(tmp, fun_tunableEnvironment_f6[3]);
      } else {
        if (0 <= ii_size_idx_1 - 1) {
          x_data = (ii_data == 4);
        }

        y = (ii_size_idx_1 != 0);
        if (y) {
          k = 0;
          exitg1 = false;
          while ((!exitg1) && (k <= ii_size_idx_1 - 1)) {
            if (!x_data) {
              y = false;
              exitg1 = true;
            } else {
              k = 1;
            }
          }
        }

        if (!y) {
          if (0 <= ii_size_idx_1 - 1) {
            x_data = (ii_data == 5);
          }

          y = (ii_size_idx_1 != 0);
          if (y) {
            k = 0;
            exitg1 = false;
            while ((!exitg1) && (k <= ii_size_idx_1 - 1)) {
              if (!x_data) {
                y = false;
                exitg1 = true;
              } else {
                k = 1;
              }
            }
          }

          if (y) {
            tmp[0] = 0.16666666666666666;
            tmp[1] = 0.0;
            tmp[2] = -fun_tunableEnvironment_f4;
            tmp[3] = inputExamples_idx_0 - fun_tunableEnvironment_f1[4];
            Automat_computeTimeFromDistance(tmp, fun_tunableEnvironment_f6[5]);
          } else {
            if (0 <= ii_size_idx_1 - 1) {
              x_data = (ii_data == 6);
            }

            y = (ii_size_idx_1 != 0);
            if (y) {
              k = 0;
              exitg1 = false;
              while ((!exitg1) && (k <= ii_size_idx_1 - 1)) {
                if (!x_data) {
                  y = false;
                  exitg1 = true;
                } else {
                  k = 1;
                }
              }
            }

            if (!y) {
              tmp[0] = 0.16666666666666666;
              tmp[1] = 0.0;
              tmp[2] = fun_tunableEnvironment_f5[7];
              tmp[3] = -(fun_tunableEnvironment_f1[7] - inputExamples_idx_0);
              Automat_computeTimeFromDistance(tmp, fun_tunableEnvironment_f6[7]);
            }
          }
        }
      }
    }
  }

  *varargout_1_size = *varargin_1_size;
  *varargout_2_size = *varargin_1_size;
  n = *varargin_1_size - 1;
  for (k = 0; k <= n; k++) {
    if (varargin_1_data[k] == fun_tunableEnvironment_f1[7]) {
      ii_size_idx_1 = 1;
      ii_data = 7;
    } else {
      for (ii_size_idx_1 = 0; ii_size_idx_1 < 7; ii_size_idx_1++) {
        x[ii_size_idx_1] = (fun_tunableEnvironment_f1[ii_size_idx_1 + 1] >
                            varargin_1_data[k]);
      }

      idx = 0;
      ii_size_idx_1 = 1;
      b_ii = 1;
      exitg1 = false;
      while ((!exitg1) && (b_ii - 1 < 7)) {
        if (x[b_ii - 1]) {
          idx = 1;
          ii_data = b_ii;
          exitg1 = true;
        } else {
          b_ii++;
        }
      }

      if (idx == 0) {
        ii_size_idx_1 = 0;
      }
    }

    if (0 <= ii_size_idx_1 - 1) {
      x_data = (ii_data == 1);
    }

    y = (ii_size_idx_1 != 0);
    if (y) {
      idx = 0;
      exitg1 = false;
      while ((!exitg1) && (idx <= ii_size_idx_1 - 1)) {
        if (!x_data) {
          y = false;
          exitg1 = true;
        } else {
          idx = 1;
        }
      }
    }

    if (y) {
      tmp[0] = 0.16666666666666666;
      tmp[1] = 0.0;
      tmp[2] = fun_tunableEnvironment_f5[0];
      tmp[3] = -varargin_1_data[k];
      inputExamples_idx_0 = Automat_computeTimeFromDistance(tmp,
        fun_tunableEnvironment_f6[1]);
      varargout_2_data[k] = inputExamples_idx_0;
      b_varargout_1 = inputExamples_idx_0 * inputExamples_idx_0 * 0.5 +
        fun_tunableEnvironment_f5[0];
    } else {
      if (0 <= ii_size_idx_1 - 1) {
        x_data = (ii_data == 2);
      }

      y = (ii_size_idx_1 != 0);
      if (y) {
        idx = 0;
        exitg1 = false;
        while ((!exitg1) && (idx <= ii_size_idx_1 - 1)) {
          if (!x_data) {
            y = false;
            exitg1 = true;
          } else {
            idx = 1;
          }
        }
      }

      if (y) {
        b_varargout_1 = sqrt((varargin_1_data[k] - fun_tunableEnvironment_f1[1])
                             * 2.0 * fun_tunableEnvironment_f2 +
                             fun_tunableEnvironment_f5[1] *
                             fun_tunableEnvironment_f5[1]);
        varargout_2_data[k] = (b_varargout_1 - fun_tunableEnvironment_f5[1]) /
          fun_tunableEnvironment_f2 + fun_tunableEnvironment_f6[1];
      } else {
        if (0 <= ii_size_idx_1 - 1) {
          x_data = (ii_data == 3);
        }

        y = (ii_size_idx_1 != 0);
        if (y) {
          idx = 0;
          exitg1 = false;
          while ((!exitg1) && (idx <= ii_size_idx_1 - 1)) {
            if (!x_data) {
              y = false;
              exitg1 = true;
            } else {
              idx = 1;
            }
          }
        }

        if (y) {
          tmp[0] = 0.16666666666666666;
          tmp[1] = 0.0;
          tmp[2] = -fun_tunableEnvironment_f4;
          tmp[3] = fun_tunableEnvironment_f1[3] - varargin_1_data[k];
          inputExamples_idx_0 = Automat_computeTimeFromDistance(tmp,
            fun_tunableEnvironment_f6[3]);
          b_varargout_1 = fun_tunableEnvironment_f5[3] - inputExamples_idx_0 *
            inputExamples_idx_0 * 0.5;
          varargout_2_data[k] = fun_tunableEnvironment_f6[3] -
            inputExamples_idx_0;
        } else {
          if (0 <= ii_size_idx_1 - 1) {
            x_data = (ii_data == 4);
          }

          y = (ii_size_idx_1 != 0);
          if (y) {
            idx = 0;
            exitg1 = false;
            while ((!exitg1) && (idx <= ii_size_idx_1 - 1)) {
              if (!x_data) {
                y = false;
                exitg1 = true;
              } else {
                idx = 1;
              }
            }
          }

          if (y) {
            b_varargout_1 = fun_tunableEnvironment_f4;
            varargout_2_data[k] = (varargin_1_data[k] -
              fun_tunableEnvironment_f1[3]) / fun_tunableEnvironment_f4 +
              fun_tunableEnvironment_f6[3];
          } else {
            if (0 <= ii_size_idx_1 - 1) {
              x_data = (ii_data == 5);
            }

            y = (ii_size_idx_1 != 0);
            if (y) {
              idx = 0;
              exitg1 = false;
              while ((!exitg1) && (idx <= ii_size_idx_1 - 1)) {
                if (!x_data) {
                  y = false;
                  exitg1 = true;
                } else {
                  idx = 1;
                }
              }
            }

            if (y) {
              tmp[0] = 0.16666666666666666;
              tmp[1] = 0.0;
              tmp[2] = -fun_tunableEnvironment_f4;
              tmp[3] = varargin_1_data[k] - fun_tunableEnvironment_f1[4];
              inputExamples_idx_0 = Automat_computeTimeFromDistance(tmp,
                fun_tunableEnvironment_f6[5]);
              b_varargout_1 = fun_tunableEnvironment_f5[4] - inputExamples_idx_0
                * inputExamples_idx_0 * 0.5;
              varargout_2_data[k] = fun_tunableEnvironment_f6[4] +
                inputExamples_idx_0;
            } else {
              if (0 <= ii_size_idx_1 - 1) {
                x_data = (ii_data == 6);
              }

              y = (ii_size_idx_1 != 0);
              if (y) {
                idx = 0;
                exitg1 = false;
                while ((!exitg1) && (idx <= ii_size_idx_1 - 1)) {
                  if (!x_data) {
                    y = false;
                    exitg1 = true;
                  } else {
                    idx = 1;
                  }
                }
              }

              if (y) {
                b_varargout_1 = sqrt((varargin_1_data[k] -
                                      fun_tunableEnvironment_f1[5]) * -2.0 *
                                     fun_tunableEnvironment_f3 +
                                     fun_tunableEnvironment_f5[5] *
                                     fun_tunableEnvironment_f5[5]);
                varargout_2_data[k] = (fun_tunableEnvironment_f5[5] -
                  b_varargout_1) / fun_tunableEnvironment_f3 +
                  fun_tunableEnvironment_f6[5];
              } else {
                tmp[0] = 0.16666666666666666;
                tmp[1] = 0.0;
                tmp[2] = fun_tunableEnvironment_f5[7];
                tmp[3] = -(fun_tunableEnvironment_f1[7] - varargin_1_data[k]);
                inputExamples_idx_0 = Automat_computeTimeFromDistance(tmp,
                  fun_tunableEnvironment_f6[7]);
                b_varargout_1 = inputExamples_idx_0 * inputExamples_idx_0 * 0.5
                  + fun_tunableEnvironment_f5[7];
                varargout_2_data[k] = fun_tunableEnvironment_f6[7] -
                  inputExamples_idx_0;
              }
            }
          }
        }
      }
    }

    varargout_1_data[k] = b_varargout_1;
  }
}

static void generateSegmentVelocityProfile(real_T vStart, real_T vEnd, const
  real_T segCumLengths_data[], const int32_T *segCumLengths_size, const real_T
  segCurvatures_data[], const int32_T *segCurvatures_size, real_T direction,
  real_T maxSpeed, real_T velocities_data[], int32_T *velocities_size, real_T
  times_data[], int32_T *times_size)
{
  real_T vMax;
  int32_T accelMax;
  real_T sConst;
  real_T sPoints[8];
  real_T b_sAccel[3];
  real_T tAccel[3];
  real_T vAccel[3];
  real_T b_sDecel[3];
  real_T tDecel[3];
  real_T vDecel[3];
  real_T varargin_1_data[500];
  real_T x[8];
  int32_T n;
  int32_T b_idx;
  real_T vStart_0[8];
  int32_T varargin_1_size;
  real_T tmp;
  boolean_T exitg1;
  AutomatedParkingValet_abs(segCurvatures_data, segCurvatures_size,
    varargin_1_data, &varargin_1_size);
  for (n = 0; n < varargin_1_size; n++) {
    varargin_1_data[n] = 2.0 / varargin_1_data[n];
  }

  AutomatedParkingValet_sqrt_pmhu(varargin_1_data, &varargin_1_size);
  if (varargin_1_size <= 2) {
    if (varargin_1_size == 1) {
      vMax = varargin_1_data[0];
    } else if ((varargin_1_data[0] > varargin_1_data[1]) || (rtIsNaN
                (varargin_1_data[0]) && (!rtIsNaN(varargin_1_data[1])))) {
      vMax = varargin_1_data[1];
    } else {
      vMax = varargin_1_data[0];
    }
  } else {
    if (!rtIsNaN(varargin_1_data[0])) {
      b_idx = 1;
    } else {
      b_idx = 0;
      accelMax = 2;
      exitg1 = false;
      while ((!exitg1) && (accelMax <= varargin_1_size)) {
        if (!rtIsNaN(varargin_1_data[accelMax - 1])) {
          b_idx = accelMax;
          exitg1 = true;
        } else {
          accelMax++;
        }
      }
    }

    if (b_idx == 0) {
      vMax = varargin_1_data[0];
    } else {
      vMax = varargin_1_data[b_idx - 1];
      for (accelMax = b_idx + 1; accelMax <= varargin_1_size; accelMax++) {
        tmp = varargin_1_data[accelMax - 1];
        if (vMax > tmp) {
          vMax = tmp;
        }
      }
    }
  }

  vMax = fmin(maxSpeed, vMax);
  if (direction == 1.0) {
    accelMax = 2;
    b_idx = 4;
  } else {
    accelMax = 4;
    b_idx = 2;
  }

  tmp = segCumLengths_data[*segCumLengths_size - 1];
  getNonConstSpeedIntervalDistanc(vStart, vMax, (real_T)accelMax, b_sAccel);
  getNonConstSpeedIntervalDista_p(vEnd, vMax, (real_T)b_idx, tAccel);
  if (AutomatedParkingValet_sum(b_sAccel) + AutomatedParkingValet_sum(tAccel) >
      tmp) {
    vMax = Automa_calculateNewMaximumSpeed(vStart, vEnd, (real_T)accelMax,
      (real_T)b_idx, tmp);
  }

  getNonConstSpeedIntervalDist_pm(vStart, vMax, (real_T)accelMax, b_sAccel,
    tAccel, vAccel);
  getNonConstSpeedIntervalDis_pmh(vEnd, vMax, (real_T)b_idx, b_sDecel, tDecel,
    vDecel);
  sConst = tmp - (AutomatedParkingValet_sum(b_sAccel) +
                  AutomatedParkingValet_sum(b_sDecel));
  x[0] = 0.0;
  x[4] = sConst / vMax;
  x[1] = tAccel[0];
  x[5] = tDecel[0];
  x[2] = tAccel[1];
  x[6] = tDecel[1];
  x[3] = tAccel[2];
  x[7] = tDecel[2];
  sPoints[0] = 0.0;
  sPoints[4] = sConst;
  sPoints[1] = b_sAccel[0];
  sPoints[5] = b_sDecel[0];
  sPoints[2] = b_sAccel[1];
  sPoints[6] = b_sDecel[1];
  sPoints[3] = b_sAccel[2];
  sPoints[7] = b_sDecel[2];
  for (n = 0; n < 7; n++) {
    x[n + 1] += x[n];
    sPoints[n + 1] += sPoints[n];
  }

  sPoints[7] = tmp;
  vStart_0[0] = vStart;
  vStart_0[1] = vAccel[0];
  vStart_0[4] = vDecel[0];
  vStart_0[2] = vAccel[1];
  vStart_0[5] = vDecel[1];
  vStart_0[3] = vAccel[2];
  vStart_0[6] = vDecel[2];
  vStart_0[7] = vEnd;
  AutomatedParkingValet_arrayfun(sPoints, (real_T)accelMax, (real_T)b_idx, vMax,
    vStart_0, x, segCumLengths_data, segCumLengths_size, velocities_data,
    velocities_size, times_data, times_size);
  accelMax = *velocities_size;
  for (n = 0; n < accelMax; n++) {
    velocities_data[n] *= direction;
  }
}

static void Automat_generateVelocityProfile(const real_T directions_data[],
  const int32_T *directions_size, const real_T cumLengths_data[], const int32_T *
  cumLengths_size, const real_T curvatures_data[], real_T startVelocity, real_T
  endVelocity, real_T varargin_2, real_T velocities_data[], int32_T
  *velocities_size, real_T times_data[], int32_T *times_size)
{
  real_T segStartSpeeds_data[500];
  real_T segEndSpeeds_data[500];
  real_T tPreviousSegment;
  real_T maxSpeed;
  real_T maxLonAccel;
  real_T maxLonDecel;
  real_T maxLonJerk;
  real_T segStartIndex_data[500];
  real_T segEndIndex_data[500];
  real_T b_data[500];
  real_T c_data[500];
  int32_T f;
  int32_T o;
  int32_T s;
  int32_T loop_ub;
  real_T cumLengths_data_0[500];
  real_T curvatures_data_0[500];
  int32_T segStartIndex_size;
  int32_T segEndIndex_size;
  int32_T i_tmp;
  int32_T cumLengths_size_tmp;
  int32_T curvatures_size_tmp;
  AutomatedParkingVal_parseInputs(varargin_2, &maxSpeed, &tPreviousSegment,
    &maxLonAccel, &maxLonDecel, &maxLonJerk);
  Au_getSegmentBoundaryPointIndex(directions_data, directions_size,
    segStartIndex_data, &segStartIndex_size, segEndIndex_data, &segEndIndex_size);
  loop_ub = segStartIndex_size - 2;
  segStartSpeeds_data[0] = fabs(startVelocity);
  if (0 <= loop_ub) {
    memset(&segStartSpeeds_data[1], 0, (loop_ub + 1) * sizeof(real_T));
  }

  loop_ub = segStartIndex_size - 1;
  if (0 <= loop_ub - 1) {
    memset(&segEndSpeeds_data[0], 0, loop_ub * sizeof(real_T));
  }

  segEndSpeeds_data[loop_ub] = fabs(endVelocity);
  *velocities_size = *cumLengths_size;
  *times_size = *cumLengths_size;
  if (0 <= *cumLengths_size - 1) {
    memset(&velocities_data[0], 0, *cumLengths_size * sizeof(real_T));
    memset(&times_data[0], 0, *cumLengths_size * sizeof(real_T));
  }

  tPreviousSegment = 0.0;
  f = segStartIndex_size - 1;
  for (loop_ub = 0; loop_ub <= f; loop_ub++) {
    if (segStartIndex_data[loop_ub] > segEndIndex_data[loop_ub]) {
      curvatures_size_tmp = 0;
      i_tmp = -1;
      o = 0;
      segEndIndex_size = -1;
      s = 0;
    } else {
      curvatures_size_tmp = (int32_T)segStartIndex_data[loop_ub] - 1;
      i_tmp = (int32_T)segEndIndex_data[loop_ub] - 1;
      o = curvatures_size_tmp;
      segEndIndex_size = i_tmp;
      s = curvatures_size_tmp;
    }

    cumLengths_size_tmp = i_tmp - curvatures_size_tmp;
    segStartIndex_size = cumLengths_size_tmp + 1;
    for (i_tmp = 0; i_tmp <= cumLengths_size_tmp; i_tmp++) {
      cumLengths_data_0[i_tmp] = cumLengths_data[curvatures_size_tmp + i_tmp];
    }

    curvatures_size_tmp = segEndIndex_size - o;
    segEndIndex_size = curvatures_size_tmp + 1;
    for (i_tmp = 0; i_tmp <= curvatures_size_tmp; i_tmp++) {
      curvatures_data_0[i_tmp] = curvatures_data[o + i_tmp];
    }

    generateSegmentVelocityProfile(segStartSpeeds_data[loop_ub],
      segEndSpeeds_data[loop_ub], cumLengths_data_0, &segStartIndex_size,
      curvatures_data_0, &segEndIndex_size, directions_data[s], maxSpeed, b_data,
      &i_tmp, c_data, &curvatures_size_tmp);
    if (segStartIndex_data[loop_ub] > segEndIndex_data[loop_ub]) {
      curvatures_size_tmp = 0;
      i_tmp = 0;
    } else {
      curvatures_size_tmp = (int32_T)segStartIndex_data[loop_ub] - 1;
      i_tmp = (int32_T)segEndIndex_data[loop_ub];
    }

    s = i_tmp - curvatures_size_tmp;
    for (i_tmp = 0; i_tmp < s; i_tmp++) {
      velocities_data[curvatures_size_tmp + i_tmp] = b_data[i_tmp];
    }

    if (segStartIndex_data[loop_ub] > segEndIndex_data[loop_ub]) {
      curvatures_size_tmp = 0;
      i_tmp = 0;
    } else {
      curvatures_size_tmp = (int32_T)segStartIndex_data[loop_ub] - 1;
      i_tmp = (int32_T)segEndIndex_data[loop_ub];
    }

    s = i_tmp - curvatures_size_tmp;
    for (i_tmp = 0; i_tmp < s; i_tmp++) {
      times_data[curvatures_size_tmp + i_tmp] = c_data[i_tmp];
    }

    if (segStartIndex_data[loop_ub] > segEndIndex_data[loop_ub]) {
      curvatures_size_tmp = 0;
      o = 0;
      segEndIndex_size = 0;
    } else {
      curvatures_size_tmp = (int32_T)segStartIndex_data[loop_ub] - 1;
      o = curvatures_size_tmp;
      segEndIndex_size = (int32_T)segEndIndex_data[loop_ub];
    }

    s = segEndIndex_size - o;
    for (i_tmp = 0; i_tmp < s; i_tmp++) {
      cumLengths_data_0[i_tmp] = times_data[curvatures_size_tmp + i_tmp] +
        tPreviousSegment;
    }

    for (i_tmp = 0; i_tmp < s; i_tmp++) {
      times_data[o + i_tmp] = cumLengths_data_0[i_tmp];
    }

    tPreviousSegment = times_data[(int32_T)segEndIndex_data[loop_ub] - 1];
  }
}

static void Autom_VelocityProfiler_stepImpl(driving_internal_planning_Vel_T *obj,
  const real_T directions_data[], const int32_T *directions_size, const real_T
  cumLengths_data[], const int32_T *cumLengths_size, const real_T
  curvatures_data[], const int32_T *curvatures_size, real_T startVelocity,
  real_T endVelocity, emxArray_real_T_AutomatedPark_T *varargout_1)
{
  real_T velocities_data[500];
  real_T times_data[500];
  int32_T loop_ub;
  int32_T velocities_size;
  int32_T times_size;
  if (Auto_VelocityProfiler_isPathNew(obj, directions_data, directions_size,
       cumLengths_data, cumLengths_size, curvatures_data, curvatures_size,
       startVelocity, endVelocity)) {
    times_size = varargout_1->size[0];
    varargout_1->size[0] = obj->LastVelocities->size[0];
    Automa_emxEnsureCapacity_real_T(varargout_1, times_size);
    loop_ub = obj->LastVelocities->size[0];
    for (times_size = 0; times_size < loop_ub; times_size++) {
      varargout_1->data[times_size] = obj->LastVelocities->data[times_size];
    }
  } else {
    Automat_generateVelocityProfile(directions_data, directions_size,
      cumLengths_data, cumLengths_size, curvatures_data, startVelocity,
      endVelocity, obj->MaxSpeed, velocities_data, &velocities_size, times_data,
      &times_size);
    times_size = obj->LastCumLengths->size[0];
    obj->LastCumLengths->size[0] = *cumLengths_size;
    Automa_emxEnsureCapacity_real_T(obj->LastCumLengths, times_size);
    loop_ub = *cumLengths_size;
    for (times_size = 0; times_size < loop_ub; times_size++) {
      obj->LastCumLengths->data[times_size] = cumLengths_data[times_size];
    }

    obj->LastStartVelocity = startVelocity;
    obj->LastEndVelocity = endVelocity;
    times_size = obj->LastCurvatures->size[0];
    obj->LastCurvatures->size[0] = *curvatures_size;
    Automa_emxEnsureCapacity_real_T(obj->LastCurvatures, times_size);
    loop_ub = *curvatures_size;
    for (times_size = 0; times_size < loop_ub; times_size++) {
      obj->LastCurvatures->data[times_size] = curvatures_data[times_size];
    }

    times_size = obj->LastDirections->size[0];
    obj->LastDirections->size[0] = *directions_size;
    Automa_emxEnsureCapacity_real_T(obj->LastDirections, times_size);
    loop_ub = *directions_size;
    for (times_size = 0; times_size < loop_ub; times_size++) {
      obj->LastDirections->data[times_size] = directions_data[times_size];
    }

    times_size = obj->LastVelocities->size[0];
    obj->LastVelocities->size[0] = velocities_size;
    Automa_emxEnsureCapacity_real_T(obj->LastVelocities, times_size);
    for (times_size = 0; times_size < velocities_size; times_size++) {
      obj->LastVelocities->data[times_size] = velocities_data[times_size];
    }

    times_size = varargout_1->size[0];
    varargout_1->size[0] = velocities_size;
    Automa_emxEnsureCapacity_real_T(varargout_1, times_size);
    for (times_size = 0; times_size < velocities_size; times_size++) {
      varargout_1->data[times_size] = velocities_data[times_size];
    }
  }
}

static boolean_T AutomatedParkingValet_isequal(const
  emxArray_real_T_AutomatedPark_T *varargin_1, const real_T varargin_2_data[],
  const int32_T varargin_2_size[2])
{
  boolean_T p;
  int32_T b_k;
  boolean_T p_0;
  boolean_T exitg1;
  p = false;
  p_0 = false;
  if ((varargin_1->size[0] != varargin_2_size[0]) || (varargin_1->size[1] !=
       varargin_2_size[1])) {
  } else {
    p_0 = true;
    if ((varargin_1->size[0] != 0) && (varargin_1->size[1] != 0) &&
        ((varargin_2_size[0] != 0) && (varargin_2_size[1] != 0))) {
      b_k = 0;
      exitg1 = false;
      while ((!exitg1) && (b_k <= varargin_2_size[0] * varargin_2_size[1] - 1))
      {
        if (!(varargin_1->data[b_k] == varargin_2_data[b_k])) {
          p_0 = false;
          exitg1 = true;
        } else {
          b_k++;
        }
      }
    }
  }

  if (p_0) {
    p = true;
  }

  return p;
}

static void AutomatedParkingValet_power(const emxArray_real_T_AutomatedPark_T *a,
  emxArray_real_T_AutomatedPark_T *y)
{
  int32_T nx;
  int32_T b_idx_0;
  b_idx_0 = a->size[0];
  nx = y->size[0];
  y->size[0] = b_idx_0;
  Automa_emxEnsureCapacity_real_T(y, nx);
  nx = b_idx_0 - 1;
  for (b_idx_0 = 0; b_idx_0 <= nx; b_idx_0++) {
    y->data[b_idx_0] = a->data[b_idx_0] * a->data[b_idx_0];
  }
}

static real_T HelperPathAnalyzer_findClosestP(const
  HelperPathAnalyzer_AutomatedP_T *obj, real_T pose[3],
  emxArray_real_T_AutomatedPark_T *refPoses)
{
  real_T closestIdx;
  emxArray_real_T_AutomatedPark_T *dis2PointsSquare;
  emxArray_boolean_T_AutomatedP_T *x;
  emxArray_real_T_AutomatedPark_T *refPoseF;
  int32_T b_i_data;
  int32_T nx;
  int32_T n;
  emxArray_real_T_AutomatedPark_T *tmp;
  emxArray_real_T_AutomatedPark_T *refPoses_0;
  emxArray_real_T_AutomatedPark_T *refPoses_1;
  emxArray_real_T_AutomatedPark_T *refPoses_2;
  emxArray_real_T_AutomatedPark_T *refPoses_3;
  int32_T loop_ub;
  real_T vec1_idx_0;
  real_T vec1_idx_1;
  real_T vec2_idx_0;
  real_T vec2_idx_1;
  boolean_T exitg1;
  int32_T exitg2;
  AutomatedParking_emxInit_real_T(&dis2PointsSquare, 1);
  if (obj->DirectionsInternal->data[(int32_T)obj->SegmentStartIndex->data
      [(int32_T)obj->CurrentSegmentIndex - 1] - 1] == 1.0) {
    pose[0] += 2.8 * cos(pose[2]);
    pose[1] += 2.8 * sin(pose[2]);
    loop_ub = refPoses->size[0];
    n = dis2PointsSquare->size[0];
    dis2PointsSquare->size[0] = loop_ub;
    Automa_emxEnsureCapacity_real_T(dis2PointsSquare, n);
    for (n = 0; n < loop_ub; n++) {
      dis2PointsSquare->data[n] = refPoses->data[(refPoses->size[0] << 1) + n];
    }

    nx = refPoses->size[0] - 1;
    for (n = 0; n <= nx; n++) {
      dis2PointsSquare->data[n] = cos(dis2PointsSquare->data[n]);
    }

    AutomatedParking_emxInit_real_T(&refPoses_2, 1);
    loop_ub = refPoses->size[0] - 1;
    n = refPoses_2->size[0];
    refPoses_2->size[0] = loop_ub + 1;
    Automa_emxEnsureCapacity_real_T(refPoses_2, n);
    for (n = 0; n <= loop_ub; n++) {
      refPoses_2->data[n] = 2.8 * dis2PointsSquare->data[n] + refPoses->data[n];
    }

    loop_ub = refPoses_2->size[0];
    for (n = 0; n < loop_ub; n++) {
      refPoses->data[n] = refPoses_2->data[n];
    }

    AutomatedParking_emxFree_real_T(&refPoses_2);
    loop_ub = refPoses->size[0];
    n = dis2PointsSquare->size[0];
    dis2PointsSquare->size[0] = loop_ub;
    Automa_emxEnsureCapacity_real_T(dis2PointsSquare, n);
    for (n = 0; n < loop_ub; n++) {
      dis2PointsSquare->data[n] = refPoses->data[(refPoses->size[0] << 1) + n];
    }

    nx = refPoses->size[0] - 1;
    for (n = 0; n <= nx; n++) {
      dis2PointsSquare->data[n] = sin(dis2PointsSquare->data[n]);
    }

    AutomatedParking_emxInit_real_T(&refPoses_3, 1);
    loop_ub = refPoses->size[0] - 1;
    n = refPoses_3->size[0];
    refPoses_3->size[0] = loop_ub + 1;
    Automa_emxEnsureCapacity_real_T(refPoses_3, n);
    for (n = 0; n <= loop_ub; n++) {
      refPoses_3->data[n] = refPoses->data[n + refPoses->size[0]] + 2.8 *
        dis2PointsSquare->data[n];
    }

    loop_ub = refPoses_3->size[0];
    for (n = 0; n < loop_ub; n++) {
      refPoses->data[n + refPoses->size[0]] = refPoses_3->data[n];
    }

    AutomatedParking_emxFree_real_T(&refPoses_3);
  }

  AutomatedParking_emxInit_real_T(&refPoses_0, 1);
  loop_ub = refPoses->size[0];
  n = refPoses_0->size[0];
  refPoses_0->size[0] = loop_ub;
  Automa_emxEnsureCapacity_real_T(refPoses_0, n);
  for (n = 0; n < loop_ub; n++) {
    refPoses_0->data[n] = refPoses->data[n] - pose[0];
  }

  AutomatedParking_emxInit_real_T(&refPoses_1, 1);
  AutomatedParkingValet_power(refPoses_0, dis2PointsSquare);
  loop_ub = refPoses->size[0];
  n = refPoses_1->size[0];
  refPoses_1->size[0] = loop_ub;
  Automa_emxEnsureCapacity_real_T(refPoses_1, n);
  AutomatedParking_emxFree_real_T(&refPoses_0);
  for (n = 0; n < loop_ub; n++) {
    refPoses_1->data[n] = refPoses->data[n + refPoses->size[0]] - pose[1];
  }

  AutomatedParking_emxInit_real_T(&tmp, 1);
  AutomatedParkingValet_power(refPoses_1, tmp);
  n = dis2PointsSquare->size[0];
  Automa_emxEnsureCapacity_real_T(dis2PointsSquare, n);
  loop_ub = dis2PointsSquare->size[0];
  AutomatedParking_emxFree_real_T(&refPoses_1);
  for (n = 0; n < loop_ub; n++) {
    dis2PointsSquare->data[n] += tmp->data[n];
  }

  AutomatedParking_emxFree_real_T(&tmp);
  n = dis2PointsSquare->size[0];
  if (dis2PointsSquare->size[0] <= 2) {
    if (dis2PointsSquare->size[0] == 1) {
      vec1_idx_0 = dis2PointsSquare->data[0];
    } else if ((dis2PointsSquare->data[0] > dis2PointsSquare->data[1]) ||
               (rtIsNaN(dis2PointsSquare->data[0]) && (!rtIsNaN
                 (dis2PointsSquare->data[1])))) {
      vec1_idx_0 = dis2PointsSquare->data[1];
    } else {
      vec1_idx_0 = dis2PointsSquare->data[0];
    }
  } else {
    if (!rtIsNaN(dis2PointsSquare->data[0])) {
      nx = 1;
    } else {
      nx = 0;
      loop_ub = 2;
      exitg1 = false;
      while ((!exitg1) && (loop_ub <= dis2PointsSquare->size[0])) {
        if (!rtIsNaN(dis2PointsSquare->data[loop_ub - 1])) {
          nx = loop_ub;
          exitg1 = true;
        } else {
          loop_ub++;
        }
      }
    }

    if (nx == 0) {
      vec1_idx_0 = dis2PointsSquare->data[0];
    } else {
      vec1_idx_0 = dis2PointsSquare->data[nx - 1];
      for (loop_ub = nx + 1; loop_ub <= n; loop_ub++) {
        if (vec1_idx_0 > dis2PointsSquare->data[loop_ub - 1]) {
          vec1_idx_0 = dis2PointsSquare->data[loop_ub - 1];
        }
      }
    }
  }

  AutomatedPark_emxInit_boolean_T(&x, 1);
  n = x->size[0];
  x->size[0] = dis2PointsSquare->size[0];
  Aut_emxEnsureCapacity_boolean_T(x, n);
  loop_ub = dis2PointsSquare->size[0];
  for (n = 0; n < loop_ub; n++) {
    x->data[n] = (dis2PointsSquare->data[n] == vec1_idx_0);
  }

  AutomatedParking_emxFree_real_T(&dis2PointsSquare);
  if (x->size[0] == 0) {
  } else {
    nx = 1;
    do {
      exitg2 = 0;
      if (x->data[nx - 1]) {
        b_i_data = nx;
        exitg2 = 1;
      } else {
        nx++;
        if (nx > x->size[0]) {
          exitg2 = 1;
        }
      }
    } while (exitg2 == 0);
  }

  AutomatedPark_emxFree_boolean_T(&x);
  closestIdx = b_i_data;
  if (obj->DirectionsInternal->data[0] == 1.0) {
    AutomatedParking_emxInit_real_T(&refPoseF, 2);
    loop_ub = refPoses->size[1];
    n = refPoseF->size[0] * refPoseF->size[1];
    refPoseF->size[0] = 1;
    refPoseF->size[1] = loop_ub;
    Automa_emxEnsureCapacity_real_T(refPoseF, n);
    for (n = 0; n < loop_ub; n++) {
      refPoseF->data[n] = refPoses->data[(refPoses->size[0] * n + b_i_data) - 1];
    }

    refPoseF->data[0] = cos(refPoses->data[((refPoses->size[0] << 1) + b_i_data)
      - 1]) * 2.8 + refPoses->data[b_i_data - 1];
    refPoseF->data[1] = sin(refPoses->data[((refPoses->size[0] << 1) + b_i_data)
      - 1]) * 2.8 + refPoses->data[(b_i_data + refPoses->size[0]) - 1];
    vec1_idx_0 = cos(refPoses->data[((refPoses->size[0] << 1) + b_i_data) - 1]);
    vec1_idx_1 = sin(refPoses->data[((refPoses->size[0] << 1) + b_i_data) - 1]);
    vec2_idx_0 = (2.8 * cos(pose[2]) + pose[0]) - refPoseF->data[0];
    vec2_idx_1 = (2.8 * sin(pose[2]) + pose[1]) - refPoseF->data[1];
    AutomatedParking_emxFree_real_T(&refPoseF);
  } else {
    vec1_idx_0 = cos(refPoses->data[((refPoses->size[0] << 1) + b_i_data) - 1]);
    vec1_idx_1 = sin(refPoses->data[((refPoses->size[0] << 1) + b_i_data) - 1]);
    vec2_idx_0 = pose[0] - refPoses->data[b_i_data - 1];
    vec2_idx_1 = pose[1] - refPoses->data[(b_i_data + refPoses->size[0]) - 1];
  }

  if (((vec1_idx_0 * vec2_idx_0 + vec1_idx_1 * vec2_idx_1) *
       obj->DirectionsInternal->data[0] > 0.0) && (b_i_data != refPoses->size[0]))
  {
    closestIdx = (real_T)b_i_data + 1.0;
  }

  return closestIdx;
}

static void Aut_HelperPathAnalyzer_stepImpl(HelperPathAnalyzer_AutomatedP_T *obj,
  const real_T currPose[3], real_T currVel, const real_T varargin_1_data[],
  const int32_T varargin_1_size[2], const real_T varargin_2_data[], const
  int32_T *varargin_2_size, const real_T varargin_3_data[], const int32_T
  *varargin_3_size, const real_T varargin_4_data[], const int32_T
  *varargin_4_size, real_T refPose[3], real_T *refVel, real_T *direction, real_T
  *curvature, real_T *varargout_1)
{
  emxArray_real_T_AutomatedPark_T *directions;
  emxArray_real_T_AutomatedPark_T *switchIndex;
  int32_T e;
  real_T pose[3];
  emxArray_real_T_AutomatedPark_T *segRefPoses;
  real_T segClosestPointIndex;
  boolean_T reachGoal;
  real_T distToGoal;
  emxArray_boolean_T_AutomatedP_T *x;
  emxArray_int32_T_AutomatedPar_T *ii;
  int32_T nx;
  int32_T idx;
  int8_T n;
  real_T scale;
  real_T absxk;
  real_T t;
  int32_T loop_ub;
  emxArray_int32_T_AutomatedPar_T *ii_0;
  int32_T obj_0;
  emxArray_real_T_AutomatedPark_T *segRefPoses_0;
  real_T x_idx_1;
  int32_T loop_ub_0;
  boolean_T exitg1;
  if (!AutomatedParkingValet_isequal(obj->RefPosesInternal, varargin_1_data,
       varargin_1_size)) {
    e = obj->RefPosesInternal->size[0] * obj->RefPosesInternal->size[1];
    obj->RefPosesInternal->size[0] = varargin_1_size[0];
    obj->RefPosesInternal->size[1] = varargin_1_size[1];
    Automa_emxEnsureCapacity_real_T(obj->RefPosesInternal, e);
    loop_ub = varargin_1_size[0] * varargin_1_size[1] - 1;
    for (e = 0; e <= loop_ub; e++) {
      obj->RefPosesInternal->data[e] = varargin_1_data[e];
    }

    e = obj->DirectionsInternal->size[0];
    obj->DirectionsInternal->size[0] = *varargin_2_size;
    Automa_emxEnsureCapacity_real_T(obj->DirectionsInternal, e);
    loop_ub = *varargin_2_size;
    for (e = 0; e < loop_ub; e++) {
      obj->DirectionsInternal->data[e] = varargin_2_data[e];
    }

    e = obj->CurvaturesInternal->size[0];
    obj->CurvaturesInternal->size[0] = *varargin_3_size;
    Automa_emxEnsureCapacity_real_T(obj->CurvaturesInternal, e);
    loop_ub = *varargin_3_size;
    for (e = 0; e < loop_ub; e++) {
      obj->CurvaturesInternal->data[e] = varargin_3_data[e];
    }

    e = obj->VelocityProfileInternal->size[0];
    obj->VelocityProfileInternal->size[0] = *varargin_4_size;
    Automa_emxEnsureCapacity_real_T(obj->VelocityProfileInternal, e);
    loop_ub = *varargin_4_size;
    for (e = 0; e < loop_ub; e++) {
      obj->VelocityProfileInternal->data[e] = varargin_4_data[e];
    }

    obj->CurrentSegmentIndex = 1.0;
    obj->ClosestPointIndex = 1.0;
  }

  AutomatedParking_emxInit_real_T(&directions, 1);

  /* ------------------------------------------------------------------ */
  /* findSegmentBoundaryPointIndex Divide the path to segments  */
  /* based on driving direction */
  e = directions->size[0];
  directions->size[0] = obj->DirectionsInternal->size[0];
  Automa_emxEnsureCapacity_real_T(directions, e);
  loop_ub = obj->DirectionsInternal->size[0];
  for (e = 0; e < loop_ub; e++) {
    directions->data[e] = obj->DirectionsInternal->data[e];
  }

  /*  Find the switching points */
  if (1.0 > (real_T)obj->DirectionsInternal->size[0] - 1.0) {
    nx = -1;
  } else {
    nx = obj->DirectionsInternal->size[0] - 2;
  }

  if (2 > obj->DirectionsInternal->size[0]) {
    idx = 0;
  } else {
    idx = 1;
  }

  AutomatedPark_emxInit_boolean_T(&x, 1);
  e = x->size[0];
  x->size[0] = nx + 1;
  Aut_emxEnsureCapacity_boolean_T(x, e);
  for (e = 0; e <= nx; e++) {
    x->data[e] = (obj->DirectionsInternal->data[idx + e] +
                  obj->DirectionsInternal->data[e] == 0.0);
  }

  AutomatedParkin_emxInit_int32_T(&ii, 1);
  nx = x->size[0];
  idx = 0;
  e = ii->size[0];
  ii->size[0] = x->size[0];
  Autom_emxEnsureCapacity_int32_T(ii, e);
  e = 1;
  exitg1 = false;
  while ((!exitg1) && (e - 1 <= nx - 1)) {
    if (x->data[e - 1]) {
      idx++;
      ii->data[idx - 1] = e;
      if (idx >= nx) {
        exitg1 = true;
      } else {
        e++;
      }
    } else {
      e++;
    }
  }

  if (x->size[0] == 1) {
    if (idx == 0) {
      ii->size[0] = 0;
    }
  } else {
    AutomatedParkin_emxInit_int32_T(&ii_0, 1);
    if (1 > idx) {
      idx = 0;
    }

    e = ii_0->size[0];
    ii_0->size[0] = idx;
    Autom_emxEnsureCapacity_int32_T(ii_0, e);
    for (e = 0; e < idx; e++) {
      ii_0->data[e] = ii->data[e];
    }

    e = ii->size[0];
    ii->size[0] = ii_0->size[0];
    Autom_emxEnsureCapacity_int32_T(ii, e);
    loop_ub = ii_0->size[0];
    for (e = 0; e < loop_ub; e++) {
      ii->data[e] = ii_0->data[e];
    }

    AutomatedParkin_emxFree_int32_T(&ii_0);
  }

  AutomatedPark_emxFree_boolean_T(&x);
  AutomatedParking_emxInit_real_T(&switchIndex, 1);
  e = switchIndex->size[0];
  switchIndex->size[0] = ii->size[0];
  Automa_emxEnsureCapacity_real_T(switchIndex, e);
  loop_ub = ii->size[0];
  for (e = 0; e < loop_ub; e++) {
    switchIndex->data[e] = ii->data[e];
  }

  AutomatedParkin_emxFree_int32_T(&ii);

  /*  Divide the path into segments */
  e = obj->SegmentStartIndex->size[0];
  obj->SegmentStartIndex->size[0] = switchIndex->size[0] + 1;
  Automa_emxEnsureCapacity_real_T(obj->SegmentStartIndex, e);
  obj->SegmentStartIndex->data[0] = 1.0;
  loop_ub = switchIndex->size[0];
  for (e = 0; e < loop_ub; e++) {
    obj->SegmentStartIndex->data[e + 1] = switchIndex->data[e] + 1.0;
  }

  e = obj->SegmentEndIndex->size[0];
  obj->SegmentEndIndex->size[0] = switchIndex->size[0] + 1;
  Automa_emxEnsureCapacity_real_T(obj->SegmentEndIndex, e);
  loop_ub = switchIndex->size[0];
  for (e = 0; e < loop_ub; e++) {
    obj->SegmentEndIndex->data[e] = switchIndex->data[e];
  }

  obj->SegmentEndIndex->data[switchIndex->size[0]] = directions->size[0];
  obj->NumPathSegments = obj->SegmentStartIndex->size[0];
  AutomatedParking_emxFree_real_T(&switchIndex);
  AutomatedParking_emxFree_real_T(&directions);
  if (obj->CurrentSegmentIndex > obj->NumPathSegments) {
    refPose[0] = obj->LastRefPoseOutput[0];
    refPose[1] = obj->LastRefPoseOutput[1];
    refPose[2] = obj->LastRefPoseOutput[2];
    *refVel = obj->LastRefVelocityOutput;
    *direction = obj->LastDirectionOutput;
    *curvature = obj->LastCurvatureOutput;

    /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
    /*    HelperPathAnalyzer computes the reference pose and the reference */
    /*    velocity based on the current pose of the vehicle. */
    /*  */
    /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
    /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
    /*  */
    /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
    /*    pathAnalyzer, with additional options specified by one or more */
    /*    Name,Value pair arguments: */
    /*  */
    /*    'Wheelbase'             Wheelbase of the vehicle */
    /*  */
    /*                            Default: 2.8 (meters) */
    /*  */
    /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
    /*                            reference path */
    /*  */
    /*    'Directions'            A N-by-1 vector representing the driving */
    /*                            directions at each point on the reference path. */
    /*                            The vector is composed by possible values: 1 */
    /*                            for forward motion and -1 for reverse motion. */
    /*  */
    /*    'Curvatures'            A N-by-1 vector representing the curvature */
    /*                            of the reference path */
    /*  */
    /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
    /*                            the reference path (in meters/second) */
    /*  */
    /*  */
    /*    Step method syntax: */
    /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
    /*    returns the reference pose, refPose, reference velocity, refVel, and */
    /*    the driving direction based on the current pose, currPose and the */
    /*    current velocity, currVel of the vehicle. */
    /*  */
    /*    System objects may be called directly like a function instead of using */
    /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
    /*  */
    /*    HelperPathAnalyzer properties: */
    /*    Wheelbase              - Wheelbase of the vehicle */
    /*    RefPoses               - Poses of the reference path */
    /*    VelocityProfile        - Velocities along the reference path */
    /*    Directions             - Driving directions at each point on the path */
    /*    Curvatures             - Path curvaturesa at each point on the path */
    /*  */
    /*    HelperPathAnalyzer methods: */
    /*    step                   - Compute reference poses, velocity and direction */
    /*    release                - Allow property value changes */
    /*    clone                  - Create a copy of the object */
    /*    isLocked               - Locked status (logical) */
    /*  */
    /*    See also lateralControllerStanley, HelperLongitudinalController, */
    /*      smoothPathSpline, helperGenerateVelocityProfile */
    /*    Copyright 2018 The MathWorks, Inc. */
    /*  Public, non-tunable properties */
    /* Wheelbase Vehicle wheelbase (m) */
    /*    A scalar specifying the distance between the front and the rear */
    /*    axles. */
    /*  */
    /*    Default: 2.8 (m) */
    /*  Public properties (Only used in MATLAB) */
    /* RefPoses Vehicle poses along the reference path */
    /*     */
    /* VelocityProfile Speed profile along the reference path */
    /*  */
    /* Directions Driving directions corresponding to RefPoses */
    /*  */
    /* Curvatures Path curvatures  */
    /*  */
    /*  Public properties (Only used in Simulink) */
    /* HasResetOutput Show Reset output port */
    /*    Flag indicating if the Reset output port is enabled.  */
    /*  */
    /*    Default:      false */
    /* ClosestPointIndex Store the previous projection point index */
    /*    to handle encircled path */
    /*  */
    /*    Default: 1 */
    /* NumPathSegments Number of segments in a path. When  */
    /*  */
    /*    Default: 1 */
    /* CurrentSegmentIndex Index of the current segment */
    /*  */
    /* SegmentStartIndex A vector storing the indices of the starting  */
    /*    points of all the path segments */
    /*  */
    /* SegmentStartIndex  A vector storing the indices of the ending  */
    /*    points of all the path segments */
    /*  The following four properties are used to transfer reference  */
    /*  data within the system object. Depending on the environment the  */
    /*  object is executing in, they are assigned either by public */
    /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
    /*  in MATLAB, or by the input ports in Simulink. The selection is  */
    /*  determined by the HasReferenceInports property. */
    /* RefPosesInternal */
    /* DirectionsInternal */
    /* CurvaturesInternal */
    /* VelocityProfileInternal */
    /*  The following four properties are used to store the last output. */
    /* LastRefPoseOutput */
    /* LastRefVelocityOutput */
    /* LastCurvatureOutput */
    /* LastDirectionOutput */
    /* HasReferenceInports Flag indicating if there are refPose, directions */
    /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
    /*     values are set via properties while in Simulink they are  */
    /*     passed as inputs via input ports. */
    /*  */
    /*    Default:          false */
    /* ---------------------------------------------------------------------- */
    /*  Setter and constructor */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* HelperPathAnalyzer Constructor  */
    /* ---------------------------------------------------------------------- */
    /*  Main algorithm */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /* setupImpl Perform one-time calculations */
    /*  In Simulink */
    /*  In MATLAB */
    /* ------------------------------------------------------------------ */
    /*  processTunedPropertiesImpl Perform actions when tunable  */
    /*  properties change between calls to the System object */
    /* ------------------------------------------------------------------ */
    /* stepImpl Implement the main algorithm and return the reference */
    /*    pose, velocity and driving direction. varargout is an */
    /*    optional output in Simulink that signifies reaching */
    /*    intermediate goals within a reference path, i.e., reaching */
    /*    the direction-switching positions.  */
    /*  Check if the reference path is new */
    /*  In MATLAB, values are from properties */
    /*  Divide the path to segments based on driving direction */
    /*  Check if reaching the final goal. If yes, use the previous */
    /*  outputs */
    /*  Get the desired pose, desired velocity and driving direction */
    /*  Check if the vehicle reaches the intermediate goal. If yes, */
    /*  increment the path segment index and reset reference velocity */
    /*  to zero as the vehicle needs to switch direction at the */
    /*  intermediate goal positions */
    /*  Store the output */
    /* ------------------------------------------------------------------ */
    /* findDesiredPoseAndVelocity Determine the desired pose and */
    /*    velocity based on the current pose. The desired pose is */
    /*    determined by searching the closest point on the reference */
    /*    path. The desired velocity is the velocity corresponding to */
    /*    the closest point. */
    /*  Get the current segment indexes */
    /*  Only search within the current segment of the path */
    /*  Current driving direction */
    /*  Compute the index of the closest point on the path segment */
    /*  Convert the segment index to the whole path index */
    /*  Get the desired velocity. Set a lower threshold to avoid zero  */
    /*  reference velocity at the very beginning. */
    /*  Get the desired pose. In forward motion, the refPose is */
    /*  specified for the front wheel. */
    /*  forward */
    /*  Workaround to support lateralControllerStanley in MATLAB */
    /*  that does not require curvature input */
    /* ------------------------------------------------------------------ */
    /* findClosestPathPoint Find the index of the closest point */
    /*  forward driving uses front wheel as reference */
    /*  Find the closest point on the reference path */
    /*  Enforce to be a scalar in Simulink */
    /*  If the reference pose is lagging behind the current pose, */
    /*  move to the next reference path. */
    /* ------------------------------------------------------------------ */
    /* moveToNext Check if the refPose is lagging behind the current */
    /*    pose. If yes, move to the next refPose. */
    /*    The is necessary when the vehicle is at accelerating stage. */
    /*    When the reference speed is small it takes relatively */
    /*    longer time to reach the desired maximum speed. When the */
    /*    vehicle reaches somewhere between two reference points, */
    /*    use the next one as the reference to set a larger */
    /*    reference speed. */
    /* ---------------------------------------------------------------------- */
    /*  Common methods */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /*  Validate inputs to the step method at initialization */
    /*  RefPoses */
    /*  Directions */
    /*  Curvatures */
    /*  VelocityProfile */
    /* ------------------------------------------------------------------ */
    /*  Define total number of inputs for system with optional inputs */
    /* ------------------------------------------------------------------ */
    /*  Define total number of outputs for system with optional */
    /*  outputs */
    /* ------------------------------------------------------------------ */
    /*  Set properties in structure s to values in object obj */
    /*  Set public properties and states */
    /*  Set private and protected properties */
    /* ------------------------------------------------------------------ */
    /*  Set properties in object obj to values in structure s */
    /*  Set private and protected properties */
    /*  Set public properties and states */
    /* ---------------------------------------------------------------------- */
    /*  Simulink-only methods */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /*  Define icon for System block */
    /*  Use class name */
    /* ------------------------------------------------------------------ */
    /*  Return input port names for System block */
    /* ------------------------------------------------------------------ */
    /*  Return output port names for System block */
    /* ------------------------------------------------------------------ */
    /*  Return size for each output port */
    /*  RefPose */
    /*  RefVelocity */
    /*  Direction */
    /*  Curvature */
    /*  Reset */
    /* ------------------------------------------------------------------ */
    /*  Return data type for each output port */
    /* ------------------------------------------------------------------ */
    /*  Return true for each output port with complex data */
    /* ------------------------------------------------------------------ */
    /*  Return true for each output port with fixed size */
    /* ------------------------------------------------------------------ */
    /*  Return false if input size cannot change */
    /*  between calls to the System object */
    /*  refPoses, directions, curvatures, and speeProfile are variable-size */
    /* ------------------------------------------------------------------ */
    /*  Return false if property is visible based on object */
    /*  configuration, for the command line and System block dialog */
    /* ---------------------------------------------------------------------- */
    /*  Simulink dialog */
    /* ---------------------------------------------------------------------- */
    /*  Define property section(s) for System block dialog */
    /* ---------------------------------------------------------------------- */
    /*  Utility functions */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /* isSimulinkBlock Check if the system object in used in Simulink */
    /*  0 for MATLAB, 1 for Simulink */
    *varargout_1 = 1.0;
  } else {
    pose[0] = currPose[0];
    pose[1] = currPose[1];
    pose[2] = 0.017453292519943295 * currPose[2];
    e = (int32_T)obj->CurrentSegmentIndex - 1;
    if (obj->SegmentStartIndex->data[e] > obj->SegmentEndIndex->data[e]) {
      nx = 0;
      idx = -1;
    } else {
      nx = (int32_T)obj->SegmentStartIndex->data[e] - 1;
      idx = (int32_T)obj->SegmentEndIndex->data[e] - 1;
    }

    AutomatedParking_emxInit_real_T(&segRefPoses, 2);
    loop_ub = obj->RefPosesInternal->size[1];
    obj_0 = segRefPoses->size[0] * segRefPoses->size[1];
    loop_ub_0 = idx - nx;
    segRefPoses->size[0] = loop_ub_0 + 1;
    segRefPoses->size[1] = loop_ub;
    Automa_emxEnsureCapacity_real_T(segRefPoses, obj_0);
    for (obj_0 = 0; obj_0 < loop_ub; obj_0++) {
      for (idx = 0; idx <= loop_ub_0; idx++) {
        segRefPoses->data[idx + segRefPoses->size[0] * obj_0] =
          obj->RefPosesInternal->data[(nx + idx) + obj->RefPosesInternal->size[0]
          * obj_0];
      }
    }

    for (obj_0 = 0; obj_0 <= loop_ub_0; obj_0++) {
      segRefPoses->data[obj_0 + (segRefPoses->size[0] << 1)] =
        obj->RefPosesInternal->data[(nx + obj_0) + (obj->RefPosesInternal->size
        [0] << 1)] * 0.017453292519943295;
    }

    AutomatedParking_emxInit_real_T(&segRefPoses_0, 2);
    *direction = obj->DirectionsInternal->data[(int32_T)obj->
      SegmentEndIndex->data[e] - 1];
    obj_0 = segRefPoses_0->size[0] * segRefPoses_0->size[1];
    segRefPoses_0->size[0] = segRefPoses->size[0];
    segRefPoses_0->size[1] = segRefPoses->size[1];
    Automa_emxEnsureCapacity_real_T(segRefPoses_0, obj_0);
    loop_ub = segRefPoses->size[0] * segRefPoses->size[1];
    for (obj_0 = 0; obj_0 < loop_ub; obj_0++) {
      segRefPoses_0->data[obj_0] = segRefPoses->data[obj_0];
    }

    segClosestPointIndex = HelperPathAnalyzer_findClosestP(obj, pose,
      segRefPoses_0);
    obj->ClosestPointIndex = (obj->SegmentStartIndex->data[e] +
      segClosestPointIndex) - 1.0;
    AutomatedParking_emxFree_real_T(&segRefPoses_0);
    if (segClosestPointIndex == 1.0) {
      *refVel = fmax(fabs(obj->VelocityProfileInternal->data[(int32_T)
                          obj->ClosestPointIndex - 1]), 0.1) * *direction;
    } else {
      *refVel = obj->VelocityProfileInternal->data[(int32_T)
        obj->ClosestPointIndex - 1];
    }

    if (*direction == 1.0) {
      pose[2] = segRefPoses->data[((segRefPoses->size[0] << 1) + (int32_T)
        segClosestPointIndex) - 1];
      pose[0] = cos(segRefPoses->data[((segRefPoses->size[0] << 1) + (int32_T)
        segClosestPointIndex) - 1]) * 2.8 + segRefPoses->data[(int32_T)
        segClosestPointIndex - 1];
      pose[1] = sin(segRefPoses->data[((segRefPoses->size[0] << 1) + (int32_T)
        segClosestPointIndex) - 1]) * 2.8 + segRefPoses->data[((int32_T)
        segClosestPointIndex + segRefPoses->size[0]) - 1];
    } else {
      e = (int32_T)segClosestPointIndex;
      pose[0] = segRefPoses->data[e - 1];
      pose[1] = segRefPoses->data[(e + segRefPoses->size[0]) - 1];
      pose[2] = segRefPoses->data[((segRefPoses->size[0] << 1) + e) - 1];
    }

    AutomatedParking_emxFree_real_T(&segRefPoses);
    if (obj->CurvaturesInternal->size[0] != 0) {
      *curvature = obj->CurvaturesInternal->data[(int32_T)obj->ClosestPointIndex
        - 1];
    } else {
      *curvature = 0.0;
    }

    pose[2] *= 57.295779513082323;
    refPose[0] = pose[0];
    refPose[1] = pose[1];
    refPose[2] = pose[2];
    segClosestPointIndex = obj->VelocityProfileInternal->data[(int32_T)
      obj->SegmentEndIndex->data[(int32_T)obj->CurrentSegmentIndex - 1] - 1];
    *varargout_1 = 0.0;

    /* helperGoalChecker Check if the current pose has reached the goal pose */
    /*   */
    /*  Copyright 2018 The MathWorks, Inc. */
    /*  The goal checker acts when the distance from the vehicle to the goal */
    /*  point is within a distance tolerance, disTol.  */
    /*  meters */
    e = (int32_T)obj->SegmentEndIndex->data[(int32_T)obj->CurrentSegmentIndex -
      1];
    distToGoal = obj->RefPosesInternal->data[e - 1] - currPose[0];
    x_idx_1 = obj->RefPosesInternal->data[(e + obj->RefPosesInternal->size[0]) -
      1] - currPose[1];
    scale = 3.3121686421112381E-170;
    absxk = fabs(distToGoal);
    if (absxk > 3.3121686421112381E-170) {
      distToGoal = 1.0;
      scale = absxk;
    } else {
      t = absxk / 3.3121686421112381E-170;
      distToGoal = t * t;
    }

    absxk = fabs(x_idx_1);
    if (absxk > scale) {
      t = scale / absxk;
      distToGoal = distToGoal * t * t + 1.0;
      scale = absxk;
    } else {
      t = absxk / scale;
      distToGoal += t * t;
    }

    distToGoal = scale * sqrt(distToGoal);
    if (distToGoal > 3.0) {
      reachGoal = false;
    } else {
      /*  Check if the vehicle has passed the goal position by checking the angle */
      /*  between two vectors */
      e = (int32_T)obj->SegmentEndIndex->data[(int32_T)obj->CurrentSegmentIndex
        - 1];
      obj_0 = (int32_T)obj->SegmentEndIndex->data[(int32_T)
        obj->CurrentSegmentIndex - 1];
      if (rtIsInf(obj->RefPosesInternal->data[((obj->RefPosesInternal->size[0] <<
             1) + e) - 1]) || rtIsNaN(obj->RefPosesInternal->data
           [((obj->RefPosesInternal->size[0] << 1) + obj_0) - 1])) {
        distToGoal = (rtNaN);
      } else {
        e = (int32_T)obj->SegmentEndIndex->data[(int32_T)
          obj->CurrentSegmentIndex - 1];
        distToGoal = rt_remd_snf(obj->RefPosesInternal->data
          [((obj->RefPosesInternal->size[0] << 1) + e) - 1], 360.0);
        scale = fabs(distToGoal);
        if (scale > 180.0) {
          if (distToGoal > 0.0) {
            distToGoal -= 360.0;
          } else {
            distToGoal += 360.0;
          }

          scale = fabs(distToGoal);
        }

        if (scale <= 45.0) {
          distToGoal *= 0.017453292519943295;
          distToGoal = cos(distToGoal);
        } else {
          if (scale <= 135.0) {
            if (distToGoal > 0.0) {
              distToGoal = (distToGoal - 90.0) * 0.017453292519943295;
              n = 1;
            } else {
              distToGoal = (distToGoal + 90.0) * 0.017453292519943295;
              n = -1;
            }
          } else if (distToGoal > 0.0) {
            distToGoal = (distToGoal - 180.0) * 0.017453292519943295;
            n = 2;
          } else {
            distToGoal = (distToGoal + 180.0) * 0.017453292519943295;
            n = -2;
          }

          if (n == 1) {
            distToGoal = -sin(distToGoal);
          } else if (n == -1) {
            distToGoal = sin(distToGoal);
          } else {
            distToGoal = -cos(distToGoal);
          }
        }
      }

      e = (int32_T)obj->SegmentEndIndex->data[(int32_T)obj->CurrentSegmentIndex
        - 1];
      obj_0 = (int32_T)obj->SegmentEndIndex->data[(int32_T)
        obj->CurrentSegmentIndex - 1];
      if (rtIsInf(obj->RefPosesInternal->data[((obj->RefPosesInternal->size[0] <<
             1) + e) - 1]) || rtIsNaN(obj->RefPosesInternal->data
           [((obj->RefPosesInternal->size[0] << 1) + obj_0) - 1])) {
        scale = (rtNaN);
      } else {
        e = (int32_T)obj->SegmentEndIndex->data[(int32_T)
          obj->CurrentSegmentIndex - 1];
        absxk = rt_remd_snf(obj->RefPosesInternal->data[((obj->
          RefPosesInternal->size[0] << 1) + e) - 1], 360.0);
        scale = fabs(absxk);
        if (scale > 180.0) {
          if (absxk > 0.0) {
            absxk -= 360.0;
          } else {
            absxk += 360.0;
          }

          scale = fabs(absxk);
        }

        if (scale <= 45.0) {
          absxk *= 0.017453292519943295;
          scale = sin(absxk);
        } else {
          if (scale <= 135.0) {
            if (absxk > 0.0) {
              absxk = (absxk - 90.0) * 0.017453292519943295;
              n = 1;
            } else {
              absxk = (absxk + 90.0) * 0.017453292519943295;
              n = -1;
            }
          } else if (absxk > 0.0) {
            absxk = (absxk - 180.0) * 0.017453292519943295;
            n = 2;
          } else {
            absxk = (absxk + 180.0) * 0.017453292519943295;
            n = -2;
          }

          if (n == 1) {
            scale = cos(absxk);
          } else if (n == -1) {
            scale = -cos(absxk);
          } else {
            scale = -sin(absxk);
          }
        }
      }

      /*  Steps of goal checking: */
      /*  1) If the vehicle passes the goal, check its current velocity.  */
      /*  2) If the velocity is less than a threshold, assume the vehicle stops. */
      /*  Otherwise, check the reference velocity at the goal position. */
      /*  3) If the goal reference velocity is non-zero, then assume the vehicle   */
      /*  reaches the goal. If the goal reference velocity is zero, i.e., the  */
      /*  vehicle is supposed to stop at the goal position, then allow the vehicle  */
      /*  to move until its velocity decreases below the threshold. */
      /*  meters/second */
      e = (int32_T)obj->SegmentEndIndex->data[(int32_T)obj->CurrentSegmentIndex
        - 1];
      obj_0 = (int32_T)obj->SegmentEndIndex->data[(int32_T)
        obj->CurrentSegmentIndex - 1];
      x_idx_1 = currPose[0] - obj->RefPosesInternal->data[e - 1];
      absxk = currPose[1] - obj->RefPosesInternal->data[(obj_0 +
        obj->RefPosesInternal->size[0]) - 1];
      if ((distToGoal * x_idx_1 + scale * absxk) * *direction > 0.0) {
        reachGoal = ((fabs(currVel) < 0.05) || (obj->
          VelocityProfileInternal->data[(int32_T)obj->SegmentEndIndex->data
          [(int32_T)obj->CurrentSegmentIndex - 1] - 1] != 0.0));
      } else {
        reachGoal = (fabs(currVel) < 0.05);
      }
    }

    if (reachGoal) {
      obj->CurrentSegmentIndex++;
      *refVel = segClosestPointIndex;
      *varargout_1 = 1.0;
    }

    /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
    /*    HelperPathAnalyzer computes the reference pose and the reference */
    /*    velocity based on the current pose of the vehicle. */
    /*  */
    /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
    /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
    /*  */
    /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
    /*    pathAnalyzer, with additional options specified by one or more */
    /*    Name,Value pair arguments: */
    /*  */
    /*    'Wheelbase'             Wheelbase of the vehicle */
    /*  */
    /*                            Default: 2.8 (meters) */
    /*  */
    /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
    /*                            reference path */
    /*  */
    /*    'Directions'            A N-by-1 vector representing the driving */
    /*                            directions at each point on the reference path. */
    /*                            The vector is composed by possible values: 1 */
    /*                            for forward motion and -1 for reverse motion. */
    /*  */
    /*    'Curvatures'            A N-by-1 vector representing the curvature */
    /*                            of the reference path */
    /*  */
    /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
    /*                            the reference path (in meters/second) */
    /*  */
    /*  */
    /*    Step method syntax: */
    /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
    /*    returns the reference pose, refPose, reference velocity, refVel, and */
    /*    the driving direction based on the current pose, currPose and the */
    /*    current velocity, currVel of the vehicle. */
    /*  */
    /*    System objects may be called directly like a function instead of using */
    /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
    /*  */
    /*    HelperPathAnalyzer properties: */
    /*    Wheelbase              - Wheelbase of the vehicle */
    /*    RefPoses               - Poses of the reference path */
    /*    VelocityProfile        - Velocities along the reference path */
    /*    Directions             - Driving directions at each point on the path */
    /*    Curvatures             - Path curvaturesa at each point on the path */
    /*  */
    /*    HelperPathAnalyzer methods: */
    /*    step                   - Compute reference poses, velocity and direction */
    /*    release                - Allow property value changes */
    /*    clone                  - Create a copy of the object */
    /*    isLocked               - Locked status (logical) */
    /*  */
    /*    See also lateralControllerStanley, HelperLongitudinalController, */
    /*      smoothPathSpline, helperGenerateVelocityProfile */
    /*    Copyright 2018 The MathWorks, Inc. */
    /*  Public, non-tunable properties */
    /* Wheelbase Vehicle wheelbase (m) */
    /*    A scalar specifying the distance between the front and the rear */
    /*    axles. */
    /*  */
    /*    Default: 2.8 (m) */
    /*  Public properties (Only used in MATLAB) */
    /* RefPoses Vehicle poses along the reference path */
    /*     */
    /* VelocityProfile Speed profile along the reference path */
    /*  */
    /* Directions Driving directions corresponding to RefPoses */
    /*  */
    /* Curvatures Path curvatures  */
    /*  */
    /*  Public properties (Only used in Simulink) */
    /* HasResetOutput Show Reset output port */
    /*    Flag indicating if the Reset output port is enabled.  */
    /*  */
    /*    Default:      false */
    /* ClosestPointIndex Store the previous projection point index */
    /*    to handle encircled path */
    /*  */
    /*    Default: 1 */
    /* NumPathSegments Number of segments in a path. When  */
    /*  */
    /*    Default: 1 */
    /* CurrentSegmentIndex Index of the current segment */
    /*  */
    /* SegmentStartIndex A vector storing the indices of the starting  */
    /*    points of all the path segments */
    /*  */
    /* SegmentStartIndex  A vector storing the indices of the ending  */
    /*    points of all the path segments */
    /*  The following four properties are used to transfer reference  */
    /*  data within the system object. Depending on the environment the  */
    /*  object is executing in, they are assigned either by public */
    /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
    /*  in MATLAB, or by the input ports in Simulink. The selection is  */
    /*  determined by the HasReferenceInports property. */
    /* RefPosesInternal */
    /* DirectionsInternal */
    /* CurvaturesInternal */
    /* VelocityProfileInternal */
    /*  The following four properties are used to store the last output. */
    /* LastRefPoseOutput */
    /* LastRefVelocityOutput */
    /* LastCurvatureOutput */
    /* LastDirectionOutput */
    /* HasReferenceInports Flag indicating if there are refPose, directions */
    /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
    /*     values are set via properties while in Simulink they are  */
    /*     passed as inputs via input ports. */
    /*  */
    /*    Default:          false */
    /* ---------------------------------------------------------------------- */
    /*  Setter and constructor */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* ------------------------------------------------------------------ */
    /* HelperPathAnalyzer Constructor  */
    /* ---------------------------------------------------------------------- */
    /*  Main algorithm */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /* setupImpl Perform one-time calculations */
    /*  In Simulink */
    /*  In MATLAB */
    /* ------------------------------------------------------------------ */
    /*  processTunedPropertiesImpl Perform actions when tunable  */
    /*  properties change between calls to the System object */
    /* ------------------------------------------------------------------ */
    /* stepImpl Implement the main algorithm and return the reference */
    /*    pose, velocity and driving direction. varargout is an */
    /*    optional output in Simulink that signifies reaching */
    /*    intermediate goals within a reference path, i.e., reaching */
    /*    the direction-switching positions.  */
    /*  Check if the reference path is new */
    /*  In MATLAB, values are from properties */
    /*  Divide the path to segments based on driving direction */
    /*  Check if reaching the final goal. If yes, use the previous */
    /*  outputs */
    /*  Get the desired pose, desired velocity and driving direction */
    /*  Check if the vehicle reaches the intermediate goal. If yes, */
    /*  increment the path segment index and reset reference velocity */
    /*  to zero as the vehicle needs to switch direction at the */
    /*  intermediate goal positions */
    /*  Store the output */
    /* ------------------------------------------------------------------ */
    /* findDesiredPoseAndVelocity Determine the desired pose and */
    /*    velocity based on the current pose. The desired pose is */
    /*    determined by searching the closest point on the reference */
    /*    path. The desired velocity is the velocity corresponding to */
    /*    the closest point. */
    /*  Get the current segment indexes */
    /*  Only search within the current segment of the path */
    /*  Current driving direction */
    /*  Compute the index of the closest point on the path segment */
    /*  Convert the segment index to the whole path index */
    /*  Get the desired velocity. Set a lower threshold to avoid zero  */
    /*  reference velocity at the very beginning. */
    /*  Get the desired pose. In forward motion, the refPose is */
    /*  specified for the front wheel. */
    /*  forward */
    /*  Workaround to support lateralControllerStanley in MATLAB */
    /*  that does not require curvature input */
    /* ------------------------------------------------------------------ */
    /* findClosestPathPoint Find the index of the closest point */
    /*  forward driving uses front wheel as reference */
    /*  Find the closest point on the reference path */
    /*  Enforce to be a scalar in Simulink */
    /*  If the reference pose is lagging behind the current pose, */
    /*  move to the next reference path. */
    /* ------------------------------------------------------------------ */
    /* moveToNext Check if the refPose is lagging behind the current */
    /*    pose. If yes, move to the next refPose. */
    /*    The is necessary when the vehicle is at accelerating stage. */
    /*    When the reference speed is small it takes relatively */
    /*    longer time to reach the desired maximum speed. When the */
    /*    vehicle reaches somewhere between two reference points, */
    /*    use the next one as the reference to set a larger */
    /*    reference speed. */
    /* ---------------------------------------------------------------------- */
    /*  Common methods */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /*  Validate inputs to the step method at initialization */
    /*  RefPoses */
    /*  Directions */
    /*  Curvatures */
    /*  VelocityProfile */
    /* ------------------------------------------------------------------ */
    /*  Define total number of inputs for system with optional inputs */
    /* ------------------------------------------------------------------ */
    /*  Define total number of outputs for system with optional */
    /*  outputs */
    /* ------------------------------------------------------------------ */
    /*  Set properties in structure s to values in object obj */
    /*  Set public properties and states */
    /*  Set private and protected properties */
    /* ------------------------------------------------------------------ */
    /*  Set properties in object obj to values in structure s */
    /*  Set private and protected properties */
    /*  Set public properties and states */
    /* ---------------------------------------------------------------------- */
    /*  Simulink-only methods */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /*  Define icon for System block */
    /*  Use class name */
    /* ------------------------------------------------------------------ */
    /*  Return input port names for System block */
    /* ------------------------------------------------------------------ */
    /*  Return output port names for System block */
    /* ------------------------------------------------------------------ */
    /*  Return size for each output port */
    /*  RefPose */
    /*  RefVelocity */
    /*  Direction */
    /*  Curvature */
    /*  Reset */
    /* ------------------------------------------------------------------ */
    /*  Return data type for each output port */
    /* ------------------------------------------------------------------ */
    /*  Return true for each output port with complex data */
    /* ------------------------------------------------------------------ */
    /*  Return true for each output port with fixed size */
    /* ------------------------------------------------------------------ */
    /*  Return false if input size cannot change */
    /*  between calls to the System object */
    /*  refPoses, directions, curvatures, and speeProfile are variable-size */
    /* ------------------------------------------------------------------ */
    /*  Return false if property is visible based on object */
    /*  configuration, for the command line and System block dialog */
    /* ---------------------------------------------------------------------- */
    /*  Simulink dialog */
    /* ---------------------------------------------------------------------- */
    /*  Define property section(s) for System block dialog */
    /* ---------------------------------------------------------------------- */
    /*  Utility functions */
    /* ---------------------------------------------------------------------- */
    /* ------------------------------------------------------------------ */
    /* isSimulinkBlock Check if the system object in used in Simulink */
    /*  0 for MATLAB, 1 for Simulink */
    obj->LastRefPoseOutput[0] = pose[0];
    obj->LastRefPoseOutput[1] = pose[1];
    obj->LastRefPoseOutput[2] = pose[2];
    obj->LastRefVelocityOutput = *refVel;
    obj->LastDirectionOutput = *direction;
    obj->LastCurvatureOutput = *curvature;
  }
}

/* Function for MATLAB Function: '<S16>/vehicle model' */
static void AutomatedP_automlvehdynftiresat(real_T Ftire_y, real_T b_Fxtire_sat,
  real_T b_Fytire_sat, real_T *Ftire_xs, real_T *Ftire_ys)
{
  real_T theta_Ftire;
  real_T Ftire_y_max;
  real_T b_a;
  theta_Ftire = rt_atan2d_snf(0.0, Ftire_y);
  Ftire_y_max = cos(theta_Ftire);
  b_a = b_Fxtire_sat * Ftire_y_max;
  theta_Ftire = b_Fytire_sat * sin(theta_Ftire);
  Ftire_y_max *= b_Fxtire_sat * b_Fytire_sat / sqrt(b_a * b_a + theta_Ftire *
    theta_Ftire);
  *Ftire_xs = 0.0;
  *Ftire_ys = Ftire_y;
  if (fabs(Ftire_y) > fabs(Ftire_y_max)) {
    *Ftire_ys = Ftire_y_max;
  }
}

static void Au_emxFreeStruct_pathPlannerRRT(pathPlannerRRT_AutomatedParki_T
  *pStruct)
{
  Auto_emxFreeStruct_driving_Path(&pStruct->Path);
}

static void emxFreeStruct_driving_internal_(driving_internal_planning_Pat_T
  *pStruct)
{
  AutomatedParking_emxFree_real_T(&pStruct->RefPosesInternal);
  AutomatedParking_emxFree_real_T(&pStruct->RefDirectionsInternal);
}

static void emxFreeStruct_driving_interna_p(driving_internal_planning_Vel_T
  *pStruct)
{
  AutomatedParking_emxFree_real_T(&pStruct->LastVelocities);
  AutomatedParking_emxFree_real_T(&pStruct->LastCumLengths);
  AutomatedParking_emxFree_real_T(&pStruct->LastCurvatures);
  AutomatedParking_emxFree_real_T(&pStruct->LastDirections);
}

static void emxFreeStruct_HelperPathAnalyze(HelperPathAnalyzer_AutomatedP_T
  *pStruct)
{
  AutomatedParking_emxFree_real_T(&pStruct->SegmentStartIndex);
  AutomatedParking_emxFree_real_T(&pStruct->SegmentEndIndex);
  AutomatedParking_emxFree_real_T(&pStruct->RefPosesInternal);
  AutomatedParking_emxFree_real_T(&pStruct->DirectionsInternal);
  AutomatedParking_emxFree_real_T(&pStruct->CurvaturesInternal);
  AutomatedParking_emxFree_real_T(&pStruct->VelocityProfileInternal);
}

/* Model step function */
void AutomatedParkingValet_step(void)
{
  /* local block i/o variables */
  real_T rtb_CurrVelocity_i;
  if (rtmIsMajorTimeStep(AutomatedParkingValet_M)) {
    /* set solver stop time */
    if (!(AutomatedParkingValet_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&AutomatedParkingValet_M->solverInfo,
                            ((AutomatedParkingValet_M->Timing.clockTickH0 + 1) *
        AutomatedParkingValet_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&AutomatedParkingValet_M->solverInfo,
                            ((AutomatedParkingValet_M->Timing.clockTick0 + 1) *
        AutomatedParkingValet_M->Timing.stepSize0 +
        AutomatedParkingValet_M->Timing.clockTickH0 *
        AutomatedParkingValet_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(AutomatedParkingValet_M)) {
    AutomatedParkingValet_M->Timing.t[0] = rtsiGetT
      (&AutomatedParkingValet_M->solverInfo);
  }

  {
    real_T absxk;
    real_T t;
    int32_T k;
    c_matlabshared_planning_inter_T lobj_3;
    d_matlabshared_planning_inter_T lobj_2;
    pathPlannerRRT_AutomatedParki_T *this;
    emxArray_real_T_AutomatedPark_T *pathPoses;
    emxArray_real_T_AutomatedPark_T *directions;
    g_matlabshared_planning_inter_T *b_this;
    c_driving_internal_costmap_Ve_T *b_costmap;
    real_T poses[6];
    driving_Path_AutomatedParking_T refPath;
    emxArray_real_T_AutomatedPark_T *b_poses;
    emxArray_real_T_AutomatedPark_T *b_directions;
    real_T worldExtent[4];
    boolean_T b_p;
    real_T xyPoints[16];
    int8_T b_data[8];
    int32_T b_k;
    d_driving_internal_planning_D_T d;
    ZCEventType zcEvent;
    real_T Fy_f;
    real_T Fy_r;
    real_T yddot;
    real_T b_Fy_ft;
    uint32_T inSize[8];
    boolean_T rtb_UnitDelay;
    real_T rtb_Product_c[3];
    real_T rtb_VectorConcatenate_h[9];
    real_T rtb_PathSmootherSpline_o3[500];
    real_T rtb_CurrPose[3];
    real_T rtb_TrigonometricFunction;
    real_T rtb_VectorConcatenate2_k[3];
    real_T rtb_CurrYawRate;
    real_T rtb_CurrVelocity;
    int32_T i;
    real_T tmp[2];
    real_T xyPoints_data[16];
    emxArray_real_T_AutomatedPark_T *tmp_0;
    emxArray_real_T_AutomatedPark_T *tmp_1;
    emxArray_c_driving_internal_p_T *tmp_2;
    int32_T xyPoints_size[2];
    emxArray_real_T_AutomatedPark_T *b_costmap_0;
    emxArray_real_T_AutomatedPark_T xyPoints_data_0;
    real_T rtb_CurrPose_o;
    real_T mapLocation_idx_0;
    real_T mapLocation_idx_1;
    real_T rtb_VectorConcatenate_j_tmp;
    static const int8_T C[15000] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
      1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };

    boolean_T exitg1;
    Au_emxInitStruct_pathPlannerRRT(&AutomatedParkingValet_B.motionPlanner);
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* RateTransition: '<S11>/Rate Transition1' incorporates:
       *  UnitDelay: '<S11>/Unit Delay2'
       */
      if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
          AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
        AutomatedParkingValet_DW.RateTransition1_Buffer[0] =
          AutomatedParkingValet_DW.UnitDelay2_DSTATE[0];
        AutomatedParkingValet_DW.RateTransition1_Buffer[1] =
          AutomatedParkingValet_DW.UnitDelay2_DSTATE[1];
        AutomatedParkingValet_DW.RateTransition1_Buffer[2] =
          AutomatedParkingValet_DW.UnitDelay2_DSTATE[2];
      }

      /* RateTransition: '<S11>/Rate Transition' incorporates:
       *  UnitDelay: '<S11>/Unit Delay4'
       */
      if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
          AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
        AutomatedParkingValet_DW.RateTransition_Buffer =
          AutomatedParkingValet_DW.UnitDelay4_DSTATE;
      }
    }

    /* RateTransition: '<S11>/Rate Transition1' */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      rtb_CurrPose[0] = AutomatedParkingValet_DW.RateTransition1_Buffer[0];
      rtb_CurrPose[1] = AutomatedParkingValet_DW.RateTransition1_Buffer[1];
      rtb_CurrPose[2] = AutomatedParkingValet_DW.RateTransition1_Buffer[2];
    }

    if ((rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
         AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) &&
        (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
         AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0)) {
      /* RateTransition: '<S11>/Rate Transition2' incorporates:
       *  UnitDelay: '<S11>/Unit Delay5'
       */
      AutomatedParkingValet_DW.RateTransition2_Buffer =
        AutomatedParkingValet_DW.UnitDelay5_DSTATE;
    }

    /* RateTransition: '<S11>/Rate Transition' */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      rtb_CurrVelocity = AutomatedParkingValet_DW.RateTransition_Buffer;
    }

    if ((rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
         AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) &&
        (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
         AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0)) {
      /* RateTransition: '<S11>/Rate Transition3' incorporates:
       *  UnitDelay: '<S11>/Unit Delay3'
       */
      AutomatedParkingValet_DW.RateTransition3_Buffer =
        AutomatedParkingValet_DW.UnitDelay3_DSTATE;
    }

    /* RateTransition: '<S11>/Rate Transition2' incorporates:
     *  RateTransition: '<S11>/Rate Transition3'
     */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      rtb_CurrYawRate = AutomatedParkingValet_DW.RateTransition2_Buffer;

      /* BusCreator: '<S11>/Bus Creator' incorporates:
       *  UnitDelay: '<S11>/Unit Delay1'
       */
      AutomatedParkingValet_B.BusCreator.CurrPose[0] = rtb_CurrPose[0];
      AutomatedParkingValet_B.BusCreator.CurrPose[1] = rtb_CurrPose[1];
      AutomatedParkingValet_B.BusCreator.CurrPose[2] = rtb_CurrPose[2];
      AutomatedParkingValet_B.BusCreator.CurrVelocity = rtb_CurrVelocity;
      AutomatedParkingValet_B.BusCreator.CurrYawRate = rtb_CurrYawRate;
      AutomatedParkingValet_B.BusCreator.CurrSteer =
        AutomatedParkingValet_DW.RateTransition3_Buffer;
      AutomatedParkingValet_B.BusCreator.Direction =
        AutomatedParkingValet_DW.UnitDelay1_DSTATE;
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[3] == 0) {
      /* Outputs for Atomic SubSystem: '<Root>/Subsystem1' */
      /* UnitDelay: '<S2>/Unit Delay' */
      rtb_UnitDelay = AutomatedParkingValet_DW.UnitDelay_DSTATE_b;

      /* End of Outputs for SubSystem: '<Root>/Subsystem1' */

      /* MATLAB Function: '<Root>/BehaviorPlanner' */
      if (!AutomatedParkingValet_DW.behavioralPlanner_not_empty) {
        memcpy(&AutomatedParkingValet_DW.behavioralPlanner.RoutePlan[0],
               &AutomatedParkingValet_P.BehaviorPlanner_routePlanStruct[0], 5U *
               sizeof(struct_rferERfyUA8TpTz2UpTSiD));
        AutomatedParkingValet_DW.behavioralPlanner.GoalIndex = 1.0;
        AutomatedParkingValet_DW.behavioralPlanner_not_empty = true;
        HelperBehavioralPlanner_request
          (&AutomatedParkingValet_DW.behavioralPlanner,
           AutomatedParkingValet_DW.pose,
           AutomatedParkingValet_P.BehaviorPlanner_StartSpeed,
           AutomatedParkingValet_DW.nextGoalPose_a,
           &AutomatedParkingValet_DW.plannerConfig.ConnectionDistance,
           &AutomatedParkingValet_DW.plannerConfig.MinIterations,
           AutomatedParkingValet_DW.plannerConfig.GoalTolerance,
           &AutomatedParkingValet_DW.plannerConfig.MinTurningRadius,
           &AutomatedParkingValet_DW.plannerConfig.IsParkManeuver,
           &AutomatedParkingValet_DW.speedConfig.StartSpeed,
           &AutomatedParkingValet_DW.speedConfig.EndSpeed,
           &AutomatedParkingValet_DW.speedConfig.MaxSpeed);
      }

      AutomatedParkingValet_DW.pose[0] =
        AutomatedParkingValet_B.BusCreator.CurrPose[0];
      AutomatedParkingValet_DW.pose[1] =
        AutomatedParkingValet_B.BusCreator.CurrPose[1];
      AutomatedParkingValet_DW.pose[2] =
        AutomatedParkingValet_B.BusCreator.CurrPose[2];
      if (rtb_UnitDelay &&
          (!(AutomatedParkingValet_DW.behavioralPlanner.GoalIndex > 5.0))) {
        HelperBehavioralPlanner_request
          (&AutomatedParkingValet_DW.behavioralPlanner,
           AutomatedParkingValet_DW.pose,
           AutomatedParkingValet_B.BusCreator.CurrVelocity,
           AutomatedParkingValet_DW.nextGoalPose_a,
           &AutomatedParkingValet_DW.plannerConfig.ConnectionDistance,
           &AutomatedParkingValet_DW.plannerConfig.MinIterations,
           AutomatedParkingValet_DW.plannerConfig.GoalTolerance,
           &AutomatedParkingValet_DW.plannerConfig.MinTurningRadius,
           &AutomatedParkingValet_DW.plannerConfig.IsParkManeuver,
           &AutomatedParkingValet_DW.speedConfig.StartSpeed,
           &AutomatedParkingValet_DW.speedConfig.EndSpeed,
           &AutomatedParkingValet_DW.speedConfig.MaxSpeed);
      }

      if (rtb_UnitDelay && (AutomatedParkingValet_DW.behavioralPlanner.GoalIndex
                            > 5.0)) {
        rtb_CurrYawRate = 3.3121686421112381E-170;
        absxk = fabs(AutomatedParkingValet_DW.pose[0] -
                     AutomatedParkingValet_DW.nextGoalPose_a[0]);
        if (absxk > 3.3121686421112381E-170) {
          rtb_CurrVelocity = 1.0;
          rtb_CurrYawRate = absxk;
        } else {
          t = absxk / 3.3121686421112381E-170;
          rtb_CurrVelocity = t * t;
        }

        absxk = fabs(AutomatedParkingValet_DW.pose[1] -
                     AutomatedParkingValet_DW.nextGoalPose_a[1]);
        if (absxk > rtb_CurrYawRate) {
          t = rtb_CurrYawRate / absxk;
          rtb_CurrVelocity = rtb_CurrVelocity * t * t + 1.0;
          rtb_CurrYawRate = absxk;
        } else {
          t = absxk / rtb_CurrYawRate;
          rtb_CurrVelocity += t * t;
        }

        rtb_CurrVelocity = rtb_CurrYawRate * sqrt(rtb_CurrVelocity);
        if (rtb_CurrVelocity < 1.0) {
        } else {
          rtb_UnitDelay = false;
        }
      } else {
        rtb_UnitDelay = false;
      }

      AutomatedParkingValet_B.motionPlannerConfig.ConnectionDistance =
        AutomatedParkingValet_DW.plannerConfig.ConnectionDistance;
      AutomatedParkingValet_B.motionPlannerConfig.MinIterations =
        AutomatedParkingValet_DW.plannerConfig.MinIterations;
      AutomatedParkingValet_B.motionPlannerConfig.MinTurningRadius =
        AutomatedParkingValet_DW.plannerConfig.MinTurningRadius;
      AutomatedParkingValet_B.motionPlannerConfig.GoalTolerance[0] =
        AutomatedParkingValet_DW.plannerConfig.GoalTolerance[0];
      AutomatedParkingValet_B.nextGoal[0] =
        AutomatedParkingValet_DW.nextGoalPose_a[0];
      AutomatedParkingValet_B.motionPlannerConfig.GoalTolerance[1] =
        AutomatedParkingValet_DW.plannerConfig.GoalTolerance[1];
      AutomatedParkingValet_B.nextGoal[1] =
        AutomatedParkingValet_DW.nextGoalPose_a[1];
      AutomatedParkingValet_B.motionPlannerConfig.GoalTolerance[2] =
        AutomatedParkingValet_DW.plannerConfig.GoalTolerance[2];
      AutomatedParkingValet_B.nextGoal[2] =
        AutomatedParkingValet_DW.nextGoalPose_a[2];
      AutomatedParkingValet_B.speedProfilerConfig =
        AutomatedParkingValet_DW.speedConfig;

      /* Stop: '<Root>/Stop Simulation' incorporates:
       *  MATLAB Function: '<Root>/BehaviorPlanner'
       */
      if (rtb_UnitDelay) {
        rtmSetStopRequested(AutomatedParkingValet_M, 1);
      }

      /* End of Stop: '<Root>/Stop Simulation' */
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      /* SignalConversion generated from: '<S5>/Bus Selector1' */
      rtb_CurrVelocity_i = AutomatedParkingValet_B.BusCreator.CurrVelocity;
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[3] == 0) {
      /* MATLAB Function: '<Root>/motionPlanning' */
      rtb_CurrPose[0] = AutomatedParkingValet_B.BusCreator.CurrPose[0];
      rtb_VectorConcatenate2_k[0] = AutomatedParkingValet_B.nextGoal[0];
      rtb_CurrPose[1] = AutomatedParkingValet_B.BusCreator.CurrPose[1];
      rtb_VectorConcatenate2_k[1] = AutomatedParkingValet_B.nextGoal[1];
      if (!AutomatedParkingValet_DW.posesInternal_not_empty) {
        AutomatedParkingValet_DW.posesInternal.size[0] = 1;
        AutomatedParkingValet_DW.posesInternal.size[1] = 3;
        AutomatedParkingValet_DW.posesInternal.data[0] = 0.0;
        AutomatedParkingValet_DW.posesInternal.data[1] = 0.0;
        AutomatedParkingValet_DW.posesInternal.data[2] = 0.0;
        AutomatedParkingValet_DW.posesInternal_not_empty = true;
      }

      if (!AutomatedParkingValet_DW.directionsInternal_not_empty) {
        AutomatedParkingValet_DW.directionsInternal.size = 1;
        AutomatedParkingValet_DW.directionsInternal.data[0] = 1.0;
        AutomatedParkingValet_DW.directionsInternal_not_empty = true;
      }

      AutomatedParkingValet_B.costmap.MapLocation[0] = 0.0;
      AutomatedParkingValet_B.costmap.MapLocation[1] = 0.0;
      for (i = 0; i < 15000; i++) {
        AutomatedParkingValet_B.costmap.Costmap[i] = C[i];
      }

      AutomatedParkingValet_B.costmap.pFreeThreshold = 0.2;
      AutomatedParkingValet_B.costmap.pOccupiedThreshold = 0.65;
      VehicleCostmapCodegen_configure(&AutomatedParkingValet_B.costmap);
      this = &AutomatedParkingValet_B.motionPlanner;
      AutomatedParkingValet_B.motionPlanner.Costmap =
        Auto_VehicleCostmapCodegen_copy(&AutomatedParkingValet_B.costmap,
        &AutomatedParkingValet_B.lobj_4);
      b_this = &AutomatedParkingValet_B.motionPlanner.InternalPlanner;
      b_costmap = AutomatedParkingValet_B.motionPlanner.Costmap;
      this->InternalPlanner.Costmap = b_costmap;
      b_costmap = this->InternalPlanner.Costmap;
      b_this->Sampler.Costmap = b_costmap;
      mapLocation_idx_0 = b_costmap->MapLocation[0];
      mapLocation_idx_1 = b_costmap->MapLocation[1];
      b_this->Sampler.LowerLimits[0] = mapLocation_idx_0;
      b_this->Sampler.LowerLimits[1] = mapLocation_idx_1;
      b_this->Sampler.LowerLimits[2] = 0.0;
      b_this->Sampler.UpperLimits[0] = mapLocation_idx_0 + 75.0;
      b_this->Sampler.UpperLimits[1] = mapLocation_idx_1 + 50.0;
      b_this->Sampler.UpperLimits[2] = 6.2831853071795862;
      UniformPoseSampler_fillPoseBuff(&b_this->Sampler);
      AutomatedParkingValet_rand_n(AutomatedParkingValet_B.r_b);
      for (i = 0; i < 5000; i++) {
        b_this->Sampler.GoalBiasBuffer[i] = AutomatedParkingValet_B.r_b[i];
      }

      b_this->Sampler.GoalBiasIndex = 1.0;
      lobj_3.ConnectionDistance =
        AutomatedParkingValet_B.motionPlannerConfig.ConnectionDistance;
      lobj_3.TurningRadius =
        AutomatedParkingValet_B.motionPlannerConfig.MinTurningRadius;
      tmp[0] = 100.0;
      tmp[1] = 150.0;
      if ((!rtIsInf
           (AutomatedParkingValet_B.motionPlannerConfig.ConnectionDistance)) &&
          (!rtIsNaN
           (AutomatedParkingValet_B.motionPlannerConfig.ConnectionDistance))) {
        lobj_3.NumSteps = fmax(3.0, ceil
          (AutomatedParkingValet_B.motionPlannerConfig.ConnectionDistance / 0.5))
          * 5.0;
      } else {
        lobj_3.NumSteps = 5.0 * ceil(norm_Sv0LdesD(tmp));
      }

      this->InternalPlanner.ConnectionMechanism = &lobj_3;
      lobj_2.ConnectionMechanism = &lobj_3;
      lobj_2.Offset = 0.0;
      this->InternalPlanner.MinIterations =
        AutomatedParkingValet_B.motionPlannerConfig.MinIterations;
      this->InternalPlanner.MaxIterations = 10000.0;
      this->InternalPlanner.GoalTolerance[0] =
        AutomatedParkingValet_B.motionPlannerConfig.GoalTolerance[0];
      this->InternalPlanner.GoalTolerance[1] =
        AutomatedParkingValet_B.motionPlannerConfig.GoalTolerance[1];
      this->InternalPlanner.GoalTolerance[2] = 0.017453292519943295 *
        AutomatedParkingValet_B.motionPlannerConfig.GoalTolerance[2];
      this->InternalPlanner.GoalBias = 0.1;
      b_this->Tree.NeighborSearcher = &lobj_2;
      for (i = 0; i < 30003; i++) {
        b_this->Tree.NodeBuffer[i] = 0.0;
      }

      for (i = 0; i < 20002; i++) {
        b_this->Tree.EdgeBuffer[i] = 0U;
      }

      for (i = 0; i < 10001; i++) {
        b_this->Tree.CostBuffer[i] = 0.0;
      }

      b_this->Tree.NodeIndex = 1.0;
      b_this->Tree.EdgeIndex = 1.0;
      rtb_UnitDelay = false;
      b_p = true;
      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k < 3)) {
        if (!(AutomatedParkingValet_DW.nextGoalPose[k] ==
              AutomatedParkingValet_B.nextGoal[k])) {
          b_p = false;
          exitg1 = true;
        } else {
          k++;
        }
      }

      if (b_p) {
        rtb_UnitDelay = true;
      }

      AutomatedParking_emxInit_real_T(&directions, 1);

      /* MATLAB Function: '<Root>/motionPlanning' */
      if (!rtb_UnitDelay) {
        AutomatedParkingValet_DW.nextGoalPose[0] =
          AutomatedParkingValet_B.nextGoal[0];
        AutomatedParkingValet_DW.nextGoalPose[1] =
          AutomatedParkingValet_B.nextGoal[1];
        AutomatedParkingValet_DW.nextGoalPose[2] =
          AutomatedParkingValet_B.nextGoal[2];
        poses[4] = 0.017453292519943295 *
          AutomatedParkingValet_B.BusCreator.CurrPose[2];
        poses[5] = 0.017453292519943295 * AutomatedParkingValet_DW.nextGoalPose
          [2];
        b_costmap = AutomatedParkingValet_B.motionPlanner.Costmap;
        worldExtent[0] = b_costmap->CollisionCheckOffsets[0];
        worldExtent[1] = b_costmap->CollisionCheckOffsets[1];
        worldExtent[2] = b_costmap->CollisionCheckOffsets[2];
        worldExtent[3] = b_costmap->CollisionCheckOffsets[3];
        memset(&xyPoints[0], 0, sizeof(real_T) << 4U);
        mapLocation_idx_0 = 1.0;
        mapLocation_idx_1 = 2.0;
        for (k = 0; k < 4; k++) {
          i = (int32_T)mapLocation_idx_0;
          xyPoints[i - 1] = worldExtent[k] * cos(poses[4]) +
            AutomatedParkingValet_B.BusCreator.CurrPose[0];
          xyPoints[i + 7] = worldExtent[k] * sin(poses[4]) +
            AutomatedParkingValet_B.BusCreator.CurrPose[1];
          i = (int32_T)mapLocation_idx_1;
          xyPoints[i - 1] = worldExtent[k] * cos(poses[5]) +
            AutomatedParkingValet_DW.nextGoalPose[0];
          xyPoints[i + 7] = worldExtent[k] * sin(poses[5]) +
            AutomatedParkingValet_DW.nextGoalPose[1];
          mapLocation_idx_0 += 2.0;
          mapLocation_idx_1 += 2.0;
        }

        mapLocation_idx_0 = b_costmap->MapLocation[0];
        mapLocation_idx_1 = b_costmap->MapLocation[1];
        i = 0;
        b_k = 0;
        for (k = 0; k < 8; k++) {
          rtb_CurrPose_o = xyPoints[k + 8];
          if ((xyPoints[k] >= mapLocation_idx_0) && (xyPoints[k] <=
               mapLocation_idx_0 + 75.0) && (rtb_CurrPose_o >= mapLocation_idx_1)
              && (rtb_CurrPose_o <= mapLocation_idx_1 + 50.0)) {
            i++;
            b_data[b_k] = (int8_T)(k + 1);
            b_k++;
          }
        }

        xyPoints_size[0] = i;
        xyPoints_size[1] = 2;
        for (k = 0; k < i; k++) {
          xyPoints_data[k] = xyPoints[b_data[k] - 1];
        }

        for (k = 0; k < i; k++) {
          xyPoints_data[k + xyPoints_size[0]] = xyPoints[b_data[k] + 7];
        }

        AutomatedParking_emxInit_real_T(&pathPoses, 2);
        Auto_emxInitStruct_driving_Path(&refPath);
        AutomatedParking_emxInit_real_T(&tmp_0, 1);
        AutomatedParking_emxInit_real_T(&b_costmap_0, 1);
        xyPoints_data_0.data = &xyPoints_data[0];
        xyPoints_data_0.size = &xyPoints_size[0];
        xyPoints_data_0.allocatedSize = 16;
        xyPoints_data_0.numDimensions = 2;
        xyPoints_data_0.canFreeData = false;
        VehicleCostmapImpl_xyPointsToGr(b_costmap, &xyPoints_data_0, b_costmap_0);
        rtb_CurrPose[2] = 0.017453292519943295 *
          AutomatedParkingValet_B.BusCreator.CurrPose[2];
        angleUtilities_wrapTo2_bbViJ3IV(&rtb_CurrPose[2]);
        rtb_VectorConcatenate2_k[2] = 0.017453292519943295 *
          AutomatedParkingValet_B.nextGoal[2];
        angleUtilities_wrapTo2_bbViJ3IV(&rtb_VectorConcatenate2_k[2]);
        DubinsPathSegmentCodegen_makeem(refPath.PathSegments.Data);
        Auto_emxCopyStruct_driving_Path
          (&AutomatedParkingValet_B.motionPlanner.Path, &refPath);
        AutomatedPa_RRTPlanner_planPath
          (&AutomatedParkingValet_B.motionPlanner.InternalPlanner, rtb_CurrPose,
           rtb_VectorConcatenate2_k, pathPoses);
        k = pathPoses->size[0] - 1;
        i = tmp_0->size[0];
        tmp_0->size[0] = k + 1;
        Automa_emxEnsureCapacity_real_T(tmp_0, i);
        AutomatedParking_emxFree_real_T(&b_costmap_0);
        for (i = 0; i <= k; i++) {
          tmp_0->data[i] = pathPoses->data[(pathPoses->size[0] << 1) + i] *
            57.295779513082323;
        }

        k = tmp_0->size[0];
        for (i = 0; i < k; i++) {
          pathPoses->data[i + (pathPoses->size[0] << 1)] = tmp_0->data[i];
        }

        AutomatedParking_emxFree_real_T(&tmp_0);
        emxInit_c_driving_internal_plan(&tmp_2, 2);
        Autom_pathPlannerRRT_createPath(&AutomatedParkingValet_B.motionPlanner,
          pathPoses, tmp_2);
        i = AutomatedParkingValet_B.motionPlanner.Path.PathSegments.Data->size[0]
          * AutomatedParkingValet_B.motionPlanner.Path.PathSegments.Data->size[1];
        AutomatedParkingValet_B.motionPlanner.Path.PathSegments.Data->size[0] =
          tmp_2->size[0];
        AutomatedParkingValet_B.motionPlanner.Path.PathSegments.Data->size[1] =
          tmp_2->size[1];
        emxEnsureCapacity_c_driving_int
          (AutomatedParkingValet_B.motionPlanner.Path.PathSegments.Data, i);
        k = tmp_2->size[0] * tmp_2->size[1];
        AutomatedParking_emxFree_real_T(&pathPoses);
        for (i = 0; i < k; i++) {
          AutomatedParkingValet_B.motionPlanner.Path.PathSegments.Data->data[i] =
            tmp_2->data[i];
        }

        emxFree_c_driving_internal_plan(&tmp_2);
        Auto_emxCopyStruct_driving_Path(&refPath,
          &AutomatedParkingValet_B.motionPlanner.Path);
        AutomatedParking_emxInit_real_T(&b_poses, 2);
        if (refPath.PathSegments.Data->size[0] * refPath.PathSegments.Data->
            size[1] == 0) {
          b_poses->size[0] = 0;
          b_poses->size[1] = 3;
          if (refPath.PathSegments.Data->size[0] *
              refPath.PathSegments.Data->size[1] != 0) {
            emxInitStruct_d_driving_interna(&d);
            emxCopyStruct_d_driving_interna(&d, &refPath.PathSegments);
            OneDimArrayBehavior_parenRefere(&d);
            emxFreeStruct_d_driving_interna(&d);
          }

          directions->size[0] = 0;
        } else {
          AutomatedParking_emxInit_real_T(&b_directions, 2);
          AutomatedPar_Path_interpolateCG(refPath.PathSegments, b_poses,
            b_directions);
          i = directions->size[0];
          directions->size[0] = b_directions->size[0];
          Automa_emxEnsureCapacity_real_T(directions, i);
          k = b_directions->size[0];
          for (i = 0; i < k; i++) {
            directions->data[i] = b_directions->data[i];
          }

          AutomatedParking_emxFree_real_T(&b_directions);
        }

        Auto_emxFreeStruct_driving_Path(&refPath);
        AutomatedParking_emxInit_real_T(&tmp_1, 1);
        k = b_poses->size[0] - 1;
        i = tmp_1->size[0];
        tmp_1->size[0] = k + 1;
        Automa_emxEnsureCapacity_real_T(tmp_1, i);
        for (i = 0; i <= k; i++) {
          tmp_1->data[i] = b_poses->data[(b_poses->size[0] << 1) + i] *
            57.295779513082323;
        }

        k = tmp_1->size[0];
        for (i = 0; i < k; i++) {
          b_poses->data[i + (b_poses->size[0] << 1)] = tmp_1->data[i];
        }

        AutomatedParking_emxFree_real_T(&tmp_1);
        AutomatedParkingValet_DW.SFunction_DIMS2[0] = b_poses->size[0];
        AutomatedParkingValet_DW.SFunction_DIMS2[1] = b_poses->size[1];
        k = b_poses->size[0] * b_poses->size[1];
        for (i = 0; i < k; i++) {
          AutomatedParkingValet_B.refPoses[i] = b_poses->data[i];
        }

        AutomatedParkingValet_DW.SFunction_DIMS3[0] = directions->size[0];
        AutomatedParkingValet_DW.SFunction_DIMS3[1] = 1;
        k = directions->size[0];
        for (i = 0; i < k; i++) {
          AutomatedParkingValet_B.directions[i] = directions->data[i];
        }

        AutomatedParkingValet_DW.posesInternal.size[0] = b_poses->size[0];
        AutomatedParkingValet_DW.posesInternal.size[1] = 3;
        k = b_poses->size[0] * b_poses->size[1] - 1;
        for (i = 0; i <= k; i++) {
          AutomatedParkingValet_DW.posesInternal.data[i] = b_poses->data[i];
        }

        AutomatedParking_emxFree_real_T(&b_poses);
        AutomatedParkingValet_DW.posesInternal_not_empty =
          (AutomatedParkingValet_DW.posesInternal.size[0] != 0);
        AutomatedParkingValet_DW.directionsInternal.size = directions->size[0];
        k = directions->size[0];
        for (i = 0; i < k; i++) {
          AutomatedParkingValet_DW.directionsInternal.data[i] = directions->
            data[i];
        }

        AutomatedParkingValet_DW.directionsInternal_not_empty =
          (AutomatedParkingValet_DW.directionsInternal.size != 0);
      } else {
        AutomatedParkingValet_DW.SFunction_DIMS2[0] =
          AutomatedParkingValet_DW.posesInternal.size[0];
        AutomatedParkingValet_DW.SFunction_DIMS2[1] =
          AutomatedParkingValet_DW.posesInternal.size[1];
        k = AutomatedParkingValet_DW.posesInternal.size[0] *
          AutomatedParkingValet_DW.posesInternal.size[1];
        if (0 <= k - 1) {
          memcpy(&AutomatedParkingValet_B.refPoses[0],
                 &AutomatedParkingValet_DW.posesInternal.data[0], k * sizeof
                 (real_T));
        }

        AutomatedParkingValet_DW.SFunction_DIMS3[0] =
          AutomatedParkingValet_DW.directionsInternal.size;
        AutomatedParkingValet_DW.SFunction_DIMS3[1] = 1;
        k = AutomatedParkingValet_DW.directionsInternal.size;
        if (0 <= k - 1) {
          memcpy(&AutomatedParkingValet_B.directions[0],
                 &AutomatedParkingValet_DW.directionsInternal.data[0], k *
                 sizeof(real_T));
        }
      }

      /* MATLABSystem: '<S3>/Path Smoother Spline' */
      i = AutomatedParkingValet_DW.SFunction_DIMS3[0];
      AutomatedParkin_SystemCore_step(&AutomatedParkingValet_DW.obj,
        AutomatedParkingValet_B.refPoses,
        AutomatedParkingValet_DW.SFunction_DIMS2,
        AutomatedParkingValet_B.directions, &i,
        AutomatedParkingValet_B.PathSmootherSpline_o1,
        AutomatedParkingValet_B.PathSmootherSpline_o2, rtb_PathSmootherSpline_o3,
        AutomatedParkingValet_B.PathSmootherSpline_o4);
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[0] = 500;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[1] = 3;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0] = 500;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[1] = 1;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0] = 500;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[1] = 1;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0] = 500;
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[1] = 1;

      /* MATLABSystem: '<S3>/Velocity Profiler' */
      if (AutomatedParkingValet_DW.obj_j.MaxSpeed !=
          AutomatedParkingValet_P.VelocityProfiler_MaxSpeed) {
        AutomatedParkingValet_DW.obj_j.MaxSpeed =
          AutomatedParkingValet_P.VelocityProfiler_MaxSpeed;
      }

      if (!AutomatedParkingValet_DW.obj_j.CacheInputSizes) {
        AutomatedParkingValet_DW.obj_j.CacheInputSizes = true;
        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_j.inputVarSize[0].f1[0] = (uint32_T)i;
        AutomatedParkingValet_DW.obj_j.inputVarSize[0].f1[1] = 1U;
        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_j.inputVarSize[1].f1[0] = (uint32_T)i;
        AutomatedParkingValet_DW.obj_j.inputVarSize[1].f1[1] = 1U;
        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_j.inputVarSize[2].f1[0] = (uint32_T)i;
        AutomatedParkingValet_DW.obj_j.inputVarSize[2].f1[1] = 1U;
        AutomatedParkingValet_DW.obj_j.inputVarSize[3].f1[0] = 1U;
        AutomatedParkingValet_DW.obj_j.inputVarSize[3].f1[1] = 1U;
        AutomatedParkingValet_DW.obj_j.inputVarSize[4].f1[0] = 1U;
        AutomatedParkingValet_DW.obj_j.inputVarSize[4].f1[1] = 1U;
        for (i = 0; i < 6; i++) {
          AutomatedParkingValet_DW.obj_j.inputVarSize[0].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_j.inputVarSize[1].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_j.inputVarSize[2].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_j.inputVarSize[3].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_j.inputVarSize[4].f1[i + 2] = 1U;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      inSize[1] = 1U;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      b_k = 0;
      exitg1 = false;
      while ((!exitg1) && (b_k < 8)) {
        if (AutomatedParkingValet_DW.obj_j.inputVarSize[0].f1[b_k] != inSize[b_k])
        {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_j.inputVarSize[0].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          b_k++;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      inSize[1] = 1U;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      b_k = 0;
      exitg1 = false;
      while ((!exitg1) && (b_k < 8)) {
        if (AutomatedParkingValet_DW.obj_j.inputVarSize[1].f1[b_k] != inSize[b_k])
        {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_j.inputVarSize[1].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          b_k++;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      inSize[1] = 1U;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k < 8)) {
        if (AutomatedParkingValet_DW.obj_j.inputVarSize[2].f1[k] != inSize[k]) {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_j.inputVarSize[2].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          k++;
        }
      }

      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k < 8)) {
        if (AutomatedParkingValet_DW.obj_j.inputVarSize[3].f1[k] != 1U) {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_j.inputVarSize[3].f1[i] = 1U;
          }

          exitg1 = true;
        } else {
          k++;
        }
      }

      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k < 8)) {
        if (AutomatedParkingValet_DW.obj_j.inputVarSize[4].f1[k] != 1U) {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_j.inputVarSize[4].f1[i] = 1U;
          }

          exitg1 = true;
        } else {
          k++;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
      b_k = AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0];
      k = AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
      Autom_VelocityProfiler_stepImpl(&AutomatedParkingValet_DW.obj_j,
        AutomatedParkingValet_B.PathSmootherSpline_o2, &i,
        rtb_PathSmootherSpline_o3, &b_k,
        AutomatedParkingValet_B.PathSmootherSpline_o4, &k,
        AutomatedParkingValet_B.speedProfilerConfig.StartSpeed,
        AutomatedParkingValet_B.speedProfilerConfig.EndSpeed, directions);
      AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0] = directions->size[0];
      AutomatedParkingValet_DW.VelocityProfiler_DIMS1[1] = 1;
      k = directions->size[0];
      for (i = 0; i < k; i++) {
        AutomatedParkingValet_B.VelocityProfiler[i] = directions->data[i];
      }

      /* End of MATLABSystem: '<S3>/Velocity Profiler' */
      AutomatedParking_emxFree_real_T(&directions);
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      /* MATLABSystem: '<Root>/MATLAB System' */
      if (!AutomatedParkingValet_DW.obj_d.CacheInputSizes) {
        AutomatedParkingValet_DW.obj_d.CacheInputSizes = true;
        for (i = 0; i < 8; i++) {
          AutomatedParkingValet_DW.obj_d.inputVarSize[0].f1[i] = 1U;
          AutomatedParkingValet_DW.obj_d.inputVarSize[1].f1[i] = 1U;
        }

        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[0];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_d.inputVarSize[2].f1[0] = (uint32_T)i;
        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[1];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[1] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_d.inputVarSize[2].f1[1] = (uint32_T)i;
        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_d.inputVarSize[3].f1[0] = (uint32_T)i;
        AutomatedParkingValet_DW.obj_d.inputVarSize[3].f1[1] = 1U;
        i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
        if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_d.inputVarSize[4].f1[0] = (uint32_T)i;
        AutomatedParkingValet_DW.obj_d.inputVarSize[4].f1[1] = 1U;
        i = AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0];
        if (AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0] < 0) {
          i = 0;
        }

        AutomatedParkingValet_DW.obj_d.inputVarSize[5].f1[0] = (uint32_T)i;
        AutomatedParkingValet_DW.obj_d.inputVarSize[5].f1[1] = 1U;
        for (i = 0; i < 6; i++) {
          AutomatedParkingValet_DW.obj_d.inputVarSize[2].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_d.inputVarSize[3].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_d.inputVarSize[4].f1[i + 2] = 1U;
          AutomatedParkingValet_DW.obj_d.inputVarSize[5].f1[i + 2] = 1U;
        }

        /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
        /*    HelperPathAnalyzer computes the reference pose and the reference */
        /*    velocity based on the current pose of the vehicle. */
        /*  */
        /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
        /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
        /*  */
        /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
        /*    pathAnalyzer, with additional options specified by one or more */
        /*    Name,Value pair arguments: */
        /*  */
        /*    'Wheelbase'             Wheelbase of the vehicle */
        /*  */
        /*                            Default: 2.8 (meters) */
        /*  */
        /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
        /*                            reference path */
        /*  */
        /*    'Directions'            A N-by-1 vector representing the driving */
        /*                            directions at each point on the reference path. */
        /*                            The vector is composed by possible values: 1 */
        /*                            for forward motion and -1 for reverse motion. */
        /*  */
        /*    'Curvatures'            A N-by-1 vector representing the curvature */
        /*                            of the reference path */
        /*  */
        /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
        /*                            the reference path (in meters/second) */
        /*  */
        /*  */
        /*    Step method syntax: */
        /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
        /*    returns the reference pose, refPose, reference velocity, refVel, and */
        /*    the driving direction based on the current pose, currPose and the */
        /*    current velocity, currVel of the vehicle. */
        /*  */
        /*    System objects may be called directly like a function instead of using */
        /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
        /*  */
        /*    HelperPathAnalyzer properties: */
        /*    Wheelbase              - Wheelbase of the vehicle */
        /*    RefPoses               - Poses of the reference path */
        /*    VelocityProfile        - Velocities along the reference path */
        /*    Directions             - Driving directions at each point on the path */
        /*    Curvatures             - Path curvaturesa at each point on the path */
        /*  */
        /*    HelperPathAnalyzer methods: */
        /*    step                   - Compute reference poses, velocity and direction */
        /*    release                - Allow property value changes */
        /*    clone                  - Create a copy of the object */
        /*    isLocked               - Locked status (logical) */
        /*  */
        /*    See also lateralControllerStanley, HelperLongitudinalController, */
        /*      smoothPathSpline, helperGenerateVelocityProfile */
        /*    Copyright 2018 The MathWorks, Inc. */
        /*  Public, non-tunable properties */
        /* Wheelbase Vehicle wheelbase (m) */
        /*    A scalar specifying the distance between the front and the rear */
        /*    axles. */
        /*  */
        /*    Default: 2.8 (m) */
        /*  Public properties (Only used in MATLAB) */
        /* RefPoses Vehicle poses along the reference path */
        /*     */
        /* VelocityProfile Speed profile along the reference path */
        /*  */
        /* Directions Driving directions corresponding to RefPoses */
        /*  */
        /* Curvatures Path curvatures  */
        /*  */
        /*  Public properties (Only used in Simulink) */
        /* HasResetOutput Show Reset output port */
        /*    Flag indicating if the Reset output port is enabled.  */
        /*  */
        /*    Default:      false */
        /* ClosestPointIndex Store the previous projection point index */
        /*    to handle encircled path */
        /*  */
        /*    Default: 1 */
        /* NumPathSegments Number of segments in a path. When  */
        /*  */
        /*    Default: 1 */
        /* CurrentSegmentIndex Index of the current segment */
        /*  */
        /* SegmentStartIndex A vector storing the indices of the starting  */
        /*    points of all the path segments */
        /*  */
        /* SegmentStartIndex  A vector storing the indices of the ending  */
        /*    points of all the path segments */
        /*  The following four properties are used to transfer reference  */
        /*  data within the system object. Depending on the environment the  */
        /*  object is executing in, they are assigned either by public */
        /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
        /*  in MATLAB, or by the input ports in Simulink. The selection is  */
        /*  determined by the HasReferenceInports property. */
        /* RefPosesInternal */
        /* DirectionsInternal */
        /* CurvaturesInternal */
        /* VelocityProfileInternal */
        /*  The following four properties are used to store the last output. */
        /* LastRefPoseOutput */
        /* LastRefVelocityOutput */
        /* LastCurvatureOutput */
        /* LastDirectionOutput */
        /* HasReferenceInports Flag indicating if there are refPose, directions */
        /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
        /*     values are set via properties while in Simulink they are  */
        /*     passed as inputs via input ports. */
        /*  */
        /*    Default:          false */
        /* ---------------------------------------------------------------------- */
        /*  Setter and constructor */
        /* ---------------------------------------------------------------------- */
        /* ------------------------------------------------------------------ */
        /* ------------------------------------------------------------------ */
        /* ------------------------------------------------------------------ */
        /* ------------------------------------------------------------------ */
        /* ------------------------------------------------------------------ */
        /* ------------------------------------------------------------------ */
        /* HelperPathAnalyzer Constructor  */
        /* ---------------------------------------------------------------------- */
        /*  Main algorithm */
        /* ---------------------------------------------------------------------- */
        /* ------------------------------------------------------------------ */
        /* setupImpl Perform one-time calculations */
        /*  In Simulink */
        /*  In MATLAB */
        /* ------------------------------------------------------------------ */
        /*  processTunedPropertiesImpl Perform actions when tunable  */
        /*  properties change between calls to the System object */
        /* ------------------------------------------------------------------ */
        /* stepImpl Implement the main algorithm and return the reference */
        /*    pose, velocity and driving direction. varargout is an */
        /*    optional output in Simulink that signifies reaching */
        /*    intermediate goals within a reference path, i.e., reaching */
        /*    the direction-switching positions.  */
        /*  Check if the reference path is new */
        /*  In MATLAB, values are from properties */
        /*  Divide the path to segments based on driving direction */
        /*  Check if reaching the final goal. If yes, use the previous */
        /*  outputs */
        /*  Get the desired pose, desired velocity and driving direction */
        /*  Check if the vehicle reaches the intermediate goal. If yes, */
        /*  increment the path segment index and reset reference velocity */
        /*  to zero as the vehicle needs to switch direction at the */
        /*  intermediate goal positions */
        /*  Store the output */
        /* ------------------------------------------------------------------ */
        /* findDesiredPoseAndVelocity Determine the desired pose and */
        /*    velocity based on the current pose. The desired pose is */
        /*    determined by searching the closest point on the reference */
        /*    path. The desired velocity is the velocity corresponding to */
        /*    the closest point. */
        /*  Get the current segment indexes */
        /*  Only search within the current segment of the path */
        /*  Current driving direction */
        /*  Compute the index of the closest point on the path segment */
        /*  Convert the segment index to the whole path index */
        /*  Get the desired velocity. Set a lower threshold to avoid zero  */
        /*  reference velocity at the very beginning. */
        /*  Get the desired pose. In forward motion, the refPose is */
        /*  specified for the front wheel. */
        /*  forward */
        /*  Workaround to support lateralControllerStanley in MATLAB */
        /*  that does not require curvature input */
        /* ------------------------------------------------------------------ */
        /* findClosestPathPoint Find the index of the closest point */
        /*  forward driving uses front wheel as reference */
        /*  Find the closest point on the reference path */
        /*  Enforce to be a scalar in Simulink */
        /*  If the reference pose is lagging behind the current pose, */
        /*  move to the next reference path. */
        /* ------------------------------------------------------------------ */
        /* moveToNext Check if the refPose is lagging behind the current */
        /*    pose. If yes, move to the next refPose. */
        /*    The is necessary when the vehicle is at accelerating stage. */
        /*    When the reference speed is small it takes relatively */
        /*    longer time to reach the desired maximum speed. When the */
        /*    vehicle reaches somewhere between two reference points, */
        /*    use the next one as the reference to set a larger */
        /*    reference speed. */
        /* ---------------------------------------------------------------------- */
        /*  Common methods */
        /* ---------------------------------------------------------------------- */
        /* ------------------------------------------------------------------ */
        /*  Validate inputs to the step method at initialization */
        /*  RefPoses */
        /*  Directions */
        /*  Curvatures */
        /*  VelocityProfile */
        /* ------------------------------------------------------------------ */
        /*  Define total number of inputs for system with optional inputs */
        /* ------------------------------------------------------------------ */
        /*  Define total number of outputs for system with optional */
        /*  outputs */
        /* ------------------------------------------------------------------ */
        /*  Set properties in structure s to values in object obj */
        /*  Set public properties and states */
        /*  Set private and protected properties */
        /* ------------------------------------------------------------------ */
        /*  Set properties in object obj to values in structure s */
        /*  Set private and protected properties */
        /*  Set public properties and states */
        /* ---------------------------------------------------------------------- */
        /*  Simulink-only methods */
        /* ---------------------------------------------------------------------- */
        /* ------------------------------------------------------------------ */
        /*  Define icon for System block */
        /*  Use class name */
        /* ------------------------------------------------------------------ */
        /*  Return input port names for System block */
        /* ------------------------------------------------------------------ */
        /*  Return output port names for System block */
        /* ------------------------------------------------------------------ */
        /*  Return size for each output port */
        /*  RefPose */
        /*  RefVelocity */
        /*  Direction */
        /*  Curvature */
        /*  Reset */
        /* ------------------------------------------------------------------ */
        /*  Return data type for each output port */
        /* ------------------------------------------------------------------ */
        /*  Return true for each output port with complex data */
        /* ------------------------------------------------------------------ */
        /*  Return true for each output port with fixed size */
        /* ------------------------------------------------------------------ */
        /*  Return false if input size cannot change */
        /*  between calls to the System object */
        /*  refPoses, directions, curvatures, and speeProfile are variable-size */
        /* ------------------------------------------------------------------ */
        /*  Return false if property is visible based on object */
        /*  configuration, for the command line and System block dialog */
        /* ---------------------------------------------------------------------- */
        /*  Simulink dialog */
        /* ---------------------------------------------------------------------- */
        /*  Define property section(s) for System block dialog */
        /* ---------------------------------------------------------------------- */
        /*  Utility functions */
        /* ---------------------------------------------------------------------- */
        /* ------------------------------------------------------------------ */
        /* isSimulinkBlock Check if the system object in used in Simulink */
        /*  0 for MATLAB, 1 for Simulink */
      }

      if (AutomatedParkingValet_DW.obj_d.TunablePropsChanged) {
        AutomatedParkingValet_DW.obj_d.TunablePropsChanged = false;
        if (AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[0] ||
            AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[1] ||
            AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[2]) {
          AutomatedParkingValet_DW.obj_d.CurrentSegmentIndex = 1.0;
          AutomatedParkingValet_DW.obj_d.ClosestPointIndex = 1.0;
        }

        AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[0] = false;
        AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[1] = false;
        AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[2] = false;
        AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[3] = false;
      }

      /* HelperPathAnalyzer Provide reference inputs for vehicle controllers. */
      /*    HelperPathAnalyzer computes the reference pose and the reference */
      /*    velocity based on the current pose of the vehicle. */
      /*  */
      /*    pathAnalyzer = HelperPathAnalyzer creates a system object, */
      /*    pathAnalyzer, that calculate reference inputs for vehicle controllers. */
      /*  */
      /*    pathAnalyzer = HelperPathAnalyzer(Name,Value) creates a system object, */
      /*    pathAnalyzer, with additional options specified by one or more */
      /*    Name,Value pair arguments: */
      /*  */
      /*    'Wheelbase'             Wheelbase of the vehicle */
      /*  */
      /*                            Default: 2.8 (meters) */
      /*  */
      /*    'RefPoses'              A N-by-3 matrix representing the poses of the */
      /*                            reference path */
      /*  */
      /*    'Directions'            A N-by-1 vector representing the driving */
      /*                            directions at each point on the reference path. */
      /*                            The vector is composed by possible values: 1 */
      /*                            for forward motion and -1 for reverse motion. */
      /*  */
      /*    'Curvatures'            A N-by-1 vector representing the curvature */
      /*                            of the reference path */
      /*  */
      /*    'VelocityProfile'       A N-by-1 vector representing the velocities along */
      /*                            the reference path (in meters/second) */
      /*  */
      /*  */
      /*    Step method syntax: */
      /*    [refPose, refVel, direction] = step(pathAnalyzer, currPose, currVel) */
      /*    returns the reference pose, refPose, reference velocity, refVel, and */
      /*    the driving direction based on the current pose, currPose and the */
      /*    current velocity, currVel of the vehicle. */
      /*  */
      /*    System objects may be called directly like a function instead of using */
      /*    the step method. For example, y = step(obj) and y = obj() are equivalent. */
      /*  */
      /*    HelperPathAnalyzer properties: */
      /*    Wheelbase              - Wheelbase of the vehicle */
      /*    RefPoses               - Poses of the reference path */
      /*    VelocityProfile        - Velocities along the reference path */
      /*    Directions             - Driving directions at each point on the path */
      /*    Curvatures             - Path curvaturesa at each point on the path */
      /*  */
      /*    HelperPathAnalyzer methods: */
      /*    step                   - Compute reference poses, velocity and direction */
      /*    release                - Allow property value changes */
      /*    clone                  - Create a copy of the object */
      /*    isLocked               - Locked status (logical) */
      /*  */
      /*    See also lateralControllerStanley, HelperLongitudinalController, */
      /*      smoothPathSpline, helperGenerateVelocityProfile */
      /*    Copyright 2018 The MathWorks, Inc. */
      /*  Public, non-tunable properties */
      /* Wheelbase Vehicle wheelbase (m) */
      /*    A scalar specifying the distance between the front and the rear */
      /*    axles. */
      /*  */
      /*    Default: 2.8 (m) */
      /*  Public properties (Only used in MATLAB) */
      /* RefPoses Vehicle poses along the reference path */
      /*     */
      /* VelocityProfile Speed profile along the reference path */
      /*  */
      /* Directions Driving directions corresponding to RefPoses */
      /*  */
      /* Curvatures Path curvatures  */
      /*  */
      /*  Public properties (Only used in Simulink) */
      /* HasResetOutput Show Reset output port */
      /*    Flag indicating if the Reset output port is enabled.  */
      /*  */
      /*    Default:      false */
      /* ClosestPointIndex Store the previous projection point index */
      /*    to handle encircled path */
      /*  */
      /*    Default: 1 */
      /* NumPathSegments Number of segments in a path. When  */
      /*  */
      /*    Default: 1 */
      /* CurrentSegmentIndex Index of the current segment */
      /*  */
      /* SegmentStartIndex A vector storing the indices of the starting  */
      /*    points of all the path segments */
      /*  */
      /* SegmentStartIndex  A vector storing the indices of the ending  */
      /*    points of all the path segments */
      /*  The following four properties are used to transfer reference  */
      /*  data within the system object. Depending on the environment the  */
      /*  object is executing in, they are assigned either by public */
      /*  properties, RefPoses, VelocityProfile, Directions and Curvatures  */
      /*  in MATLAB, or by the input ports in Simulink. The selection is  */
      /*  determined by the HasReferenceInports property. */
      /* RefPosesInternal */
      /* DirectionsInternal */
      /* CurvaturesInternal */
      /* VelocityProfileInternal */
      /*  The following four properties are used to store the last output. */
      /* LastRefPoseOutput */
      /* LastRefVelocityOutput */
      /* LastCurvatureOutput */
      /* LastDirectionOutput */
      /* HasReferenceInports Flag indicating if there are refPose, directions */
      /*     and VelocityProfile inputs in stepImp. In MATLAB, all these  */
      /*     values are set via properties while in Simulink they are  */
      /*     passed as inputs via input ports. */
      /*  */
      /*    Default:          false */
      /* ---------------------------------------------------------------------- */
      /*  Setter and constructor */
      /* ---------------------------------------------------------------------- */
      /* ------------------------------------------------------------------ */
      /* ------------------------------------------------------------------ */
      /* ------------------------------------------------------------------ */
      /* ------------------------------------------------------------------ */
      /* ------------------------------------------------------------------ */
      /* ------------------------------------------------------------------ */
      /* HelperPathAnalyzer Constructor  */
      /* ---------------------------------------------------------------------- */
      /*  Main algorithm */
      /* ---------------------------------------------------------------------- */
      /* ------------------------------------------------------------------ */
      /* setupImpl Perform one-time calculations */
      /*  In Simulink */
      /*  In MATLAB */
      /* ------------------------------------------------------------------ */
      /*  processTunedPropertiesImpl Perform actions when tunable  */
      /*  properties change between calls to the System object */
      /* ------------------------------------------------------------------ */
      /* stepImpl Implement the main algorithm and return the reference */
      /*    pose, velocity and driving direction. varargout is an */
      /*    optional output in Simulink that signifies reaching */
      /*    intermediate goals within a reference path, i.e., reaching */
      /*    the direction-switching positions.  */
      /*  Check if the reference path is new */
      /*  In MATLAB, values are from properties */
      /*  Divide the path to segments based on driving direction */
      /*  Check if reaching the final goal. If yes, use the previous */
      /*  outputs */
      /*  Get the desired pose, desired velocity and driving direction */
      /*  Check if the vehicle reaches the intermediate goal. If yes, */
      /*  increment the path segment index and reset reference velocity */
      /*  to zero as the vehicle needs to switch direction at the */
      /*  intermediate goal positions */
      /*  Store the output */
      /* ------------------------------------------------------------------ */
      /* findDesiredPoseAndVelocity Determine the desired pose and */
      /*    velocity based on the current pose. The desired pose is */
      /*    determined by searching the closest point on the reference */
      /*    path. The desired velocity is the velocity corresponding to */
      /*    the closest point. */
      /*  Get the current segment indexes */
      /*  Only search within the current segment of the path */
      /*  Current driving direction */
      /*  Compute the index of the closest point on the path segment */
      /*  Convert the segment index to the whole path index */
      /*  Get the desired velocity. Set a lower threshold to avoid zero  */
      /*  reference velocity at the very beginning. */
      /*  Get the desired pose. In forward motion, the refPose is */
      /*  specified for the front wheel. */
      /*  forward */
      /*  Workaround to support lateralControllerStanley in MATLAB */
      /*  that does not require curvature input */
      /* ------------------------------------------------------------------ */
      /* findClosestPathPoint Find the index of the closest point */
      /*  forward driving uses front wheel as reference */
      /*  Find the closest point on the reference path */
      /*  Enforce to be a scalar in Simulink */
      /*  If the reference pose is lagging behind the current pose, */
      /*  move to the next reference path. */
      /* ------------------------------------------------------------------ */
      /* moveToNext Check if the refPose is lagging behind the current */
      /*    pose. If yes, move to the next refPose. */
      /*    The is necessary when the vehicle is at accelerating stage. */
      /*    When the reference speed is small it takes relatively */
      /*    longer time to reach the desired maximum speed. When the */
      /*    vehicle reaches somewhere between two reference points, */
      /*    use the next one as the reference to set a larger */
      /*    reference speed. */
      /* ---------------------------------------------------------------------- */
      /*  Common methods */
      /* ---------------------------------------------------------------------- */
      /* ------------------------------------------------------------------ */
      /*  Validate inputs to the step method at initialization */
      /*  RefPoses */
      /*  Directions */
      /*  Curvatures */
      /*  VelocityProfile */
      /* ------------------------------------------------------------------ */
      /*  Define total number of inputs for system with optional inputs */
      /* ------------------------------------------------------------------ */
      /*  Define total number of outputs for system with optional */
      /*  outputs */
      /* ------------------------------------------------------------------ */
      /*  Set properties in structure s to values in object obj */
      /*  Set public properties and states */
      /*  Set private and protected properties */
      /* ------------------------------------------------------------------ */
      /*  Set properties in object obj to values in structure s */
      /*  Set private and protected properties */
      /*  Set public properties and states */
      /* ---------------------------------------------------------------------- */
      /*  Simulink-only methods */
      /* ---------------------------------------------------------------------- */
      /* ------------------------------------------------------------------ */
      /*  Define icon for System block */
      /*  Use class name */
      /* ------------------------------------------------------------------ */
      /*  Return input port names for System block */
      /* ------------------------------------------------------------------ */
      /*  Return output port names for System block */
      /* ------------------------------------------------------------------ */
      /*  Return size for each output port */
      /*  RefPose */
      /*  RefVelocity */
      /*  Direction */
      /*  Curvature */
      /*  Reset */
      /* ------------------------------------------------------------------ */
      /*  Return data type for each output port */
      /* ------------------------------------------------------------------ */
      /*  Return true for each output port with complex data */
      /* ------------------------------------------------------------------ */
      /*  Return true for each output port with fixed size */
      /* ------------------------------------------------------------------ */
      /*  Return false if input size cannot change */
      /*  between calls to the System object */
      /*  refPoses, directions, curvatures, and speeProfile are variable-size */
      /* ------------------------------------------------------------------ */
      /*  Return false if property is visible based on object */
      /*  configuration, for the command line and System block dialog */
      /* ---------------------------------------------------------------------- */
      /*  Simulink dialog */
      /* ---------------------------------------------------------------------- */
      /*  Define property section(s) for System block dialog */
      /* ---------------------------------------------------------------------- */
      /*  Utility functions */
      /* ---------------------------------------------------------------------- */
      /* ------------------------------------------------------------------ */
      /* isSimulinkBlock Check if the system object in used in Simulink */
      /*  0 for MATLAB, 1 for Simulink */
      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[0];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[1];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[1] < 0) {
        i = 0;
      }

      inSize[1] = (uint32_T)i;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      b_k = 0;
      exitg1 = false;
      while ((!exitg1) && (b_k < 8)) {
        if (AutomatedParkingValet_DW.obj_d.inputVarSize[2].f1[b_k] != inSize[b_k])
        {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_d.inputVarSize[2].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          b_k++;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      inSize[1] = 1U;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      b_k = 0;
      exitg1 = false;
      while ((!exitg1) && (b_k < 8)) {
        if (AutomatedParkingValet_DW.obj_d.inputVarSize[3].f1[b_k] != inSize[b_k])
        {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_d.inputVarSize[3].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          b_k++;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
      if (AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      inSize[1] = 1U;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k < 8)) {
        if (AutomatedParkingValet_DW.obj_d.inputVarSize[4].f1[k] != inSize[k]) {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_d.inputVarSize[4].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          k++;
        }
      }

      i = AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0];
      if (AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0] < 0) {
        i = 0;
      }

      inSize[0] = (uint32_T)i;
      inSize[1] = 1U;
      for (i = 0; i < 6; i++) {
        inSize[i + 2] = 1U;
      }

      k = 0;
      exitg1 = false;
      while ((!exitg1) && (k < 8)) {
        if (AutomatedParkingValet_DW.obj_d.inputVarSize[5].f1[k] != inSize[k]) {
          for (i = 0; i < 8; i++) {
            AutomatedParkingValet_DW.obj_d.inputVarSize[5].f1[i] = inSize[i];
          }

          exitg1 = true;
        } else {
          k++;
        }
      }

      i = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
      k = AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
      b_k = AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0];
      Aut_HelperPathAnalyzer_stepImpl(&AutomatedParkingValet_DW.obj_d,
        AutomatedParkingValet_B.BusCreator.CurrPose,
        AutomatedParkingValet_B.BusCreator.CurrVelocity,
        AutomatedParkingValet_B.PathSmootherSpline_o1,
        AutomatedParkingValet_DW.PathSmootherSpline_DIMS1,
        AutomatedParkingValet_B.PathSmootherSpline_o2, &i,
        AutomatedParkingValet_B.PathSmootherSpline_o4, &k,
        AutomatedParkingValet_B.VelocityProfiler, &b_k, rtb_CurrPose,
        &AutomatedParkingValet_B.MATLABSystem_o2,
        &AutomatedParkingValet_B.MATLABSystem_o3,
        &AutomatedParkingValet_B.MATLABSystem_o4,
        &AutomatedParkingValet_B.MATLABSystem_o5);
      AutomatedParkingValet_B.MATLABSystem_o1[0] = rtb_CurrPose[0];
      AutomatedParkingValet_B.MATLABSystem_o1[1] = rtb_CurrPose[1];
      AutomatedParkingValet_B.MATLABSystem_o1[2] = rtb_CurrPose[2];

      /* End of MATLABSystem: '<Root>/MATLAB System' */
    }

    /* ModelReference generated from: '<Root>/Vehicle Controller' */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0 ||
        rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      StanleyRefMdl
        (&(AutomatedParkingValet_DW.VehicleController_InstanceData.rtm),
         &AutomatedParkingValet_B.MATLABSystem_o1[0],
         &AutomatedParkingValet_B.MATLABSystem_o2,
         &AutomatedParkingValet_B.MATLABSystem_o3,
         &AutomatedParkingValet_B.MATLABSystem_o4,
         &AutomatedParkingValet_B.MATLABSystem_o5,
         &AutomatedParkingValet_B.BusCreator.CurrPose[0],
         &AutomatedParkingValet_B.BusCreator.CurrVelocity,
         &AutomatedParkingValet_B.BusCreator.CurrYawRate,
         &AutomatedParkingValet_B.BusCreator.CurrSteer,
         &AutomatedParkingValet_B.SteerCmd, &AutomatedParkingValet_B.AccelCmd,
         &AutomatedParkingValet_B.DecelCmd,
         &(AutomatedParkingValet_DW.VehicleController_InstanceData.rtb),
         &(AutomatedParkingValet_DW.VehicleController_InstanceData.rtdw));
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      /* Outputs for Atomic SubSystem: '<S4>/Acceleration to Velocity' */
      /* RelationalOperator: '<S14>/Compare' incorporates:
       *  Constant: '<S14>/Constant'
       */
      AutomatedParkingValet_B.Compare = (AutomatedParkingValet_B.DecelCmd >
        AutomatedParkingValet_P.Constant_Value_g);

      /* End of Outputs for SubSystem: '<S4>/Acceleration to Velocity' */
    }

    /* Outputs for Atomic SubSystem: '<S4>/Acceleration to Velocity' */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Logic: '<S8>/AND' incorporates:
       *  Abs: '<S8>/Abs'
       *  Constant: '<S13>/Constant'
       *  Constant: '<S8>/Constant'
       *  RelationalOperator: '<S13>/Compare'
       *  Sum: '<S8>/Minus'
       *  UnitDelay: '<S8>/Unit Delay'
       */
      AutomatedParkingValet_B.Resetvelocitytozero =
        (AutomatedParkingValet_B.Compare && (fabs
          (AutomatedParkingValet_DW.UnitDelay_DSTATE) -
          AutomatedParkingValet_P.Constant_Value_l <=
          AutomatedParkingValet_P.Constant_Value));
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      /* Sum: '<S8>/Add' */
      AutomatedParkingValet_B.Add_n = AutomatedParkingValet_B.AccelCmd -
        AutomatedParkingValet_B.DecelCmd;
    }

    /* Integrator: '<S8>/Saturated integrator' */
    /* Limited  Integrator  */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M)) {
      zcEvent = rt_ZCFcn(ANY_ZERO_CROSSING,
                         &AutomatedParkingValet_PrevZCX.Saturatedintegrator_Reset_ZCE,
                         (AutomatedParkingValet_B.MATLABSystem_o3));

      /* evaluate zero-crossings */
      if (zcEvent != NO_ZCEVENT) {
        AutomatedParkingValet_X.Saturatedintegrator_CSTATE =
          AutomatedParkingValet_P.Saturatedintegrator_IC;
      }
    }

    if (AutomatedParkingValet_X.Saturatedintegrator_CSTATE >=
        AutomatedParkingValet_P.Saturatedintegrator_UpperSat) {
      if (AutomatedParkingValet_X.Saturatedintegrator_CSTATE >
          AutomatedParkingValet_P.Saturatedintegrator_UpperSat) {
        rtsiSetBlockStateForSolverChangedAtMajorStep
          (&AutomatedParkingValet_M->solverInfo, true);
      }

      AutomatedParkingValet_X.Saturatedintegrator_CSTATE =
        AutomatedParkingValet_P.Saturatedintegrator_UpperSat;
    } else {
      if (AutomatedParkingValet_X.Saturatedintegrator_CSTATE <=
          AutomatedParkingValet_P.Saturatedintegrator_LowerSat) {
        if (AutomatedParkingValet_X.Saturatedintegrator_CSTATE <
            AutomatedParkingValet_P.Saturatedintegrator_LowerSat) {
          rtsiSetBlockStateForSolverChangedAtMajorStep
            (&AutomatedParkingValet_M->solverInfo, true);
        }

        AutomatedParkingValet_X.Saturatedintegrator_CSTATE =
          AutomatedParkingValet_P.Saturatedintegrator_LowerSat;
      }
    }

    /* Switch: '<S8>/Switch' incorporates:
     *  Constant: '<S8>/Constant1'
     *  Integrator: '<S8>/Saturated integrator'
     *  Product: '<S8>/Product1'
     */
    if (AutomatedParkingValet_B.Resetvelocitytozero) {
      AutomatedParkingValet_B.Switch = AutomatedParkingValet_P.Constant1_Value;
    } else {
      AutomatedParkingValet_B.Switch =
        AutomatedParkingValet_X.Saturatedintegrator_CSTATE *
        AutomatedParkingValet_B.MATLABSystem_o3;
    }

    /* End of Switch: '<S8>/Switch' */
    /* End of Outputs for SubSystem: '<S4>/Acceleration to Velocity' */

    /* TransferFcn: '<S10>/Delay' */
    AutomatedParkingValet_B.Delay = 0.0;
    AutomatedParkingValet_B.Delay += AutomatedParkingValet_P.Delay_C *
      AutomatedParkingValet_X.Delay_CSTATE;

    /* Gain: '<S9>/Gain1' */
    rtb_CurrVelocity = AutomatedParkingValet_P.Gain1_Gain *
      AutomatedParkingValet_B.Delay;

    /* Sum: '<S10>/Add' */
    AutomatedParkingValet_B.Add = AutomatedParkingValet_B.SteerCmd -
      AutomatedParkingValet_B.Delay;

    /* SignalConversion generated from: '<S88>/Vector Concatenate1' incorporates:
     *  UnitConversion: '<S88>/Unit Conversion6'
     */
    /* Unit Conversion - from: m/s to: m/s
       Expression: output = (1*input) + (0) */
    AutomatedParkingValet_B.VectorConcatenate1[0] =
      AutomatedParkingValet_B.Switch;

    /* SignalConversion generated from: '<S88>/Vector Concatenate' incorporates:
     *  UnitConversion: '<S88>/Unit Conversion6'
     */
    AutomatedParkingValet_B.VectorConcatenate_n[0] =
      AutomatedParkingValet_B.Switch;
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Constant: '<S16>/xdot_oConstant' */
      AutomatedParkingValet_B.VectorConcatenate[0] =
        AutomatedParkingValet_P.xdot_oConstant_Value;

      /* Constant: '<S16>/ydot_oConstant' */
      AutomatedParkingValet_B.VectorConcatenate[1] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_ydot_o;

      /* Constant: '<S16>/psi_oConstant' */
      AutomatedParkingValet_B.VectorConcatenate[2] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_psi_o;

      /* Constant: '<S16>/r_oConstant' */
      AutomatedParkingValet_B.VectorConcatenate[3] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_r_o;
    }

    /* SignalConversion generated from: '<S88>/Vector Concatenate' */
    AutomatedParkingValet_B.VectorConcatenate_n[1] =
      AutomatedParkingValet_B.VectorConcatenate[1];
    AutomatedParkingValet_B.VectorConcatenate_n[2] =
      AutomatedParkingValet_B.VectorConcatenate[2];
    AutomatedParkingValet_B.VectorConcatenate_n[3] =
      AutomatedParkingValet_B.VectorConcatenate[3];

    /* Integrator: '<S88>/Integrator' */
    if (AutomatedParkingValet_DW.Integrator_IWORK != 0) {
      AutomatedParkingValet_X.Integrator_CSTATE[0] =
        AutomatedParkingValet_B.VectorConcatenate_n[0];
      AutomatedParkingValet_X.Integrator_CSTATE[1] =
        AutomatedParkingValet_B.VectorConcatenate_n[1];
      AutomatedParkingValet_X.Integrator_CSTATE[2] =
        AutomatedParkingValet_B.VectorConcatenate_n[2];
      AutomatedParkingValet_X.Integrator_CSTATE[3] =
        AutomatedParkingValet_B.VectorConcatenate_n[3];
    }

    /* SignalConversion generated from: '<S88>/Vector Concatenate1' incorporates:
     *  Integrator: '<S88>/Integrator'
     */
    AutomatedParkingValet_B.VectorConcatenate1[1] =
      AutomatedParkingValet_X.Integrator_CSTATE[1];
    AutomatedParkingValet_B.VectorConcatenate1[2] =
      AutomatedParkingValet_X.Integrator_CSTATE[2];
    AutomatedParkingValet_B.VectorConcatenate1[3] =
      AutomatedParkingValet_X.Integrator_CSTATE[3];

    /* Gain: '<S15>/Gain' */
    AutomatedParkingValet_B.Gain = AutomatedParkingValet_P.Gain_Gain *
      AutomatedParkingValet_B.VectorConcatenate1[2];

    /* Trigonometry: '<S31>/Trigonometric Function' incorporates:
     *  Trigonometry: '<S60>/sincos'
     */
    absxk = sin(AutomatedParkingValet_B.VectorConcatenate1[2]);
    mapLocation_idx_0 = cos(AutomatedParkingValet_B.VectorConcatenate1[2]);
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* SignalConversion generated from: '<S89>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_m[0] = 0.0;

      /* SignalConversion generated from: '<S89>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_m[1] = 0.0;

      /* SignalConversion generated from: '<S89>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_m[2] = 0.0;

      /* Constant: '<S30>/Constant' */
      AutomatedParkingValet_B.VectorConcatenate_m[0] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Cd;
    }

    /* Sum: '<S30>/Add1' incorporates:
     *  Product: '<S31>/Product1'
     *  Product: '<S31>/Product3'
     *  SignalConversion generated from: '<S18>/Vector Concatenate1'
     *  Sum: '<S31>/Add'
     *  Trigonometry: '<S31>/Trigonometric Function'
     */
    rtb_CurrPose_o = AutomatedParkingValet_B.VectorConcatenate1[0] -
      (mapLocation_idx_0 * AutomatedParkingValet_B.VectorConcatenate1_m[0] +
       absxk * AutomatedParkingValet_B.VectorConcatenate1_m[1]);
    rtb_CurrPose[0] = rtb_CurrPose_o;

    /* Product: '<S30>/Product' */
    rtb_VectorConcatenate2_k[0] = rtb_CurrPose_o * rtb_CurrPose_o;

    /* Sum: '<S30>/Add1' incorporates:
     *  Product: '<S31>/Product'
     *  Product: '<S31>/Product2'
     *  SignalConversion generated from: '<S18>/Vector Concatenate1'
     *  Sum: '<S31>/Add1'
     *  Trigonometry: '<S31>/Trigonometric Function'
     */
    rtb_CurrPose_o = AutomatedParkingValet_B.VectorConcatenate1[1] -
      (mapLocation_idx_0 * AutomatedParkingValet_B.VectorConcatenate1_m[1] -
       absxk * AutomatedParkingValet_B.VectorConcatenate1_m[0]);

    /* Sqrt: '<S30>/Sqrt' incorporates:
     *  Product: '<S30>/Product'
     *  SignalConversion generated from: '<S31>/Vector Concatenate2'
     *  Sum: '<S30>/Add1'
     *  Sum: '<S30>/Sum of Elements'
     */
    rtb_TrigonometricFunction = sqrt((rtb_CurrPose_o * rtb_CurrPose_o +
      rtb_VectorConcatenate2_k[0]) + (0.0 -
      AutomatedParkingValet_B.VectorConcatenate1_m[2]) * (0.0 -
      AutomatedParkingValet_B.VectorConcatenate1_m[2]));

    /* Product: '<S30>/Product2' */
    t = rtb_TrigonometricFunction * rtb_TrigonometricFunction;

    /* Trigonometry: '<S30>/Trigonometric Function' */
    rtb_TrigonometricFunction = rt_atan2d_snf(rtb_CurrPose_o, rtb_CurrPose[0]);

    /* Lookup_n-D: '<S30>/Cs' */
    AutomatedParkingValet_B.VectorConcatenate_m[1] = look1_binlcpw
      (rtb_TrigonometricFunction,
       AutomatedParkingValet_P.VehicleBody3DOFLateral_beta_w,
       AutomatedParkingValet_P.VehicleBody3DOFLateral_Cs, 30U);
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Constant: '<S30>/Constant1' */
      AutomatedParkingValet_B.VectorConcatenate_m[2] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Cl;

      /* UnaryMinus: '<S30>/Unary Minus' incorporates:
       *  Constant: '<S30>/Constant4'
       */
      AutomatedParkingValet_B.UnaryMinus[0] =
        -AutomatedParkingValet_P.Constant4_Value[0];
      AutomatedParkingValet_B.UnaryMinus[1] =
        -AutomatedParkingValet_P.Constant4_Value[1];
      AutomatedParkingValet_B.UnaryMinus[2] =
        -AutomatedParkingValet_P.Constant4_Value[2];
    }

    /* Lookup_n-D: '<S30>/Crm' */
    AutomatedParkingValet_B.VectorConcatenate_m[3] = look1_binlxpw
      (rtb_TrigonometricFunction, AutomatedParkingValet_P.Crm_bp01Data,
       AutomatedParkingValet_P.Crm_tableData, 1U);

    /* Switch: '<S30>/Switch' incorporates:
     *  Constant: '<S30>/Constant4'
     */
    if (rtb_CurrPose[0] >= AutomatedParkingValet_P.Switch_Threshold) {
      rtb_CurrPose[0] = AutomatedParkingValet_P.Constant4_Value[0];
    } else {
      rtb_CurrPose[0] = AutomatedParkingValet_B.UnaryMinus[0];
    }

    /* Product: '<S30>/Product5' incorporates:
     *  Constant: '<S30>/Constant2'
     */
    AutomatedParkingValet_B.VectorConcatenate_m[4] = rtb_CurrPose[0] *
      AutomatedParkingValet_P.VehicleBody3DOFLateral_Cpm;

    /* Lookup_n-D: '<S30>/Cym' */
    AutomatedParkingValet_B.VectorConcatenate_m[5] = look1_binlxpw
      (rtb_TrigonometricFunction,
       AutomatedParkingValet_P.VehicleBody3DOFLateral_beta_w,
       AutomatedParkingValet_P.VehicleBody3DOFLateral_Cym, 30U);

    /* Gain: '<S30>/.5.*A.*Pabs.//R.//T' incorporates:
     *  Constant: '<S16>/AirTempConstant'
     *  Product: '<S30>/Product1'
     */
    rtb_TrigonometricFunction = 0.5 *
      AutomatedParkingValet_P.VehicleBody3DOFLateral_Af *
      AutomatedParkingValet_P.VehicleBody3DOFLateral_Pabs /
      AutomatedParkingValet_P.DragForce_R;
    for (i = 0; i < 6; i++) {
      poses[i] = t * AutomatedParkingValet_B.VectorConcatenate_m[i] /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Tair *
        rtb_TrigonometricFunction;
    }

    /* End of Gain: '<S30>/.5.*A.*Pabs.//R.//T' */

    /* Product: '<S30>/Product4' incorporates:
     *  Constant: '<S30>/Constant3'
     *  MATLAB Function: '<S16>/vehicle model'
     */
    rtb_CurrYawRate = AutomatedParkingValet_P.VehicleBody3DOFLateral_a +
      AutomatedParkingValet_P.VehicleBody3DOFLateral_b;

    /* Product: '<S30>/Product3' incorporates:
     *  UnaryMinus: '<S18>/Unary Minus'
     */
    /* Unit Conversion - from: rad to: rad
       Expression: output = (1*input) + (0) */
    rtb_CurrPose[0] = -(rtb_CurrPose[0] * poses[0]);

    /* Sum: '<S16>/Add' incorporates:
     *  Constant: '<S30>/Constant3'
     *  Product: '<S30>/Product4'
     *  UnaryMinus: '<S18>/Unary Minus1'
     */
    rtb_VectorConcatenate2_k[1] = -(poses[4] * rtb_CurrYawRate);

    /* Switch: '<S30>/Switch' incorporates:
     *  Constant: '<S30>/Constant4'
     */
    if (rtb_CurrPose_o >= AutomatedParkingValet_P.Switch_Threshold) {
      rtb_CurrPose_o = AutomatedParkingValet_P.Constant4_Value[1];
    } else {
      rtb_CurrPose_o = AutomatedParkingValet_B.UnaryMinus[1];
    }

    /* Product: '<S30>/Product3' incorporates:
     *  UnaryMinus: '<S18>/Unary Minus'
     */
    rtb_CurrPose[1] = -(rtb_CurrPose_o * poses[1]);

    /* Sum: '<S16>/Add' incorporates:
     *  Constant: '<S30>/Constant3'
     *  Product: '<S30>/Product4'
     *  UnaryMinus: '<S18>/Unary Minus1'
     */
    rtb_VectorConcatenate2_k[2] = -(poses[5] * rtb_CurrYawRate);

    /* Switch: '<S30>/Switch' incorporates:
     *  Constant: '<S30>/Constant4'
     *  SignalConversion generated from: '<S31>/Vector Concatenate2'
     *  Sum: '<S30>/Add1'
     */
    if (0.0 - AutomatedParkingValet_B.VectorConcatenate1_m[2] >=
        AutomatedParkingValet_P.Switch_Threshold) {
      rtb_CurrPose_o = AutomatedParkingValet_P.Constant4_Value[2];
    } else {
      rtb_CurrPose_o = AutomatedParkingValet_B.UnaryMinus[2];
    }

    /* UnaryMinus: '<S18>/Unary Minus' incorporates:
     *  Product: '<S30>/Product3'
     */
    rtb_CurrPose_o = -(rtb_CurrPose_o * poses[2]);
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Constant: '<S16>/X_oConstant' */
      AutomatedParkingValet_B.VectorConcatenate3[0] = rtP_startPose[0] + 1.6;

      /* Constant: '<S16>/Y_oConstant' */
      AutomatedParkingValet_B.VectorConcatenate3[1] = rtP_startPose[1];
    }

    /* Integrator: '<S37>/Integrator' */
    if (AutomatedParkingValet_DW.Integrator_IWORK_k != 0) {
      AutomatedParkingValet_X.Integrator_CSTATE_l[0] =
        AutomatedParkingValet_B.VectorConcatenate3[0];
      AutomatedParkingValet_X.Integrator_CSTATE_l[1] =
        AutomatedParkingValet_B.VectorConcatenate3[1];
    }

    /* Trigonometry: '<S60>/sincos' incorporates:
     *  Constant: '<S37>/Constant2'
     *  Constant: '<S37>/Constant7'
     */
    rtb_Product_c[1] = cos(AutomatedParkingValet_P.Constant7_Value);
    t = sin(AutomatedParkingValet_P.Constant7_Value);
    rtb_Product_c[2] = cos(AutomatedParkingValet_P.Constant2_Value);
    rtb_TrigonometricFunction = sin(AutomatedParkingValet_P.Constant2_Value);

    /* Fcn: '<S60>/Fcn11' */
    rtb_VectorConcatenate_h[0] = rtb_Product_c[1] * mapLocation_idx_0;

    /* Fcn: '<S60>/Fcn21' incorporates:
     *  Fcn: '<S60>/Fcn22'
     */
    rtb_VectorConcatenate_j_tmp = rtb_TrigonometricFunction * t;
    rtb_VectorConcatenate_h[1] = rtb_VectorConcatenate_j_tmp * mapLocation_idx_0
      - rtb_Product_c[2] * absxk;

    /* Fcn: '<S60>/Fcn31' incorporates:
     *  Fcn: '<S60>/Fcn32'
     */
    mapLocation_idx_1 = rtb_Product_c[2] * t;
    rtb_VectorConcatenate_h[2] = mapLocation_idx_1 * mapLocation_idx_0 +
      rtb_TrigonometricFunction * absxk;

    /* Fcn: '<S60>/Fcn12' */
    rtb_VectorConcatenate_h[3] = rtb_Product_c[1] * absxk;

    /* Fcn: '<S60>/Fcn22' */
    rtb_VectorConcatenate_h[4] = rtb_VectorConcatenate_j_tmp * absxk +
      rtb_Product_c[2] * mapLocation_idx_0;

    /* Fcn: '<S60>/Fcn32' */
    rtb_VectorConcatenate_h[5] = mapLocation_idx_1 * absxk -
      rtb_TrigonometricFunction * mapLocation_idx_0;

    /* Fcn: '<S60>/Fcn13' */
    rtb_VectorConcatenate_h[6] = -t;

    /* Fcn: '<S60>/Fcn23' */
    rtb_VectorConcatenate_h[7] = rtb_TrigonometricFunction * rtb_Product_c[1];

    /* Fcn: '<S60>/Fcn33' */
    rtb_VectorConcatenate_h[8] = rtb_Product_c[2] * rtb_Product_c[1];
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Constant: '<S40>/R_T1' */
      AutomatedParkingValet_B.VectorConcatenate_p[0] =
        -AutomatedParkingValet_P.VehicleBody3DOFLateral_b;

      /* Constant: '<S40>/R_T2' */
      AutomatedParkingValet_B.VectorConcatenate_p[1] =
        AutomatedParkingValet_P.HardPointCoordinateTransformRea;

      /* Constant: '<S40>/R_T3' */
      AutomatedParkingValet_B.VectorConcatenate_p[2] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_h;
    }

    /* Product: '<S62>/Product' incorporates:
     *  Math: '<S40>/Transpose1'
     */
    for (i = 0; i < 3; i++) {
      rtb_Product_c[i] = rtb_VectorConcatenate_h[3 * i + 2] *
        AutomatedParkingValet_B.VectorConcatenate_p[2] +
        (rtb_VectorConcatenate_h[3 * i + 1] *
         AutomatedParkingValet_B.VectorConcatenate_p[1] +
         rtb_VectorConcatenate_h[3 * i] *
         AutomatedParkingValet_B.VectorConcatenate_p[0]);
    }

    /* End of Product: '<S62>/Product' */

    /* Sum: '<S40>/Add' incorporates:
     *  Constant: '<S37>/Constant'
     *  Integrator: '<S37>/Integrator'
     */
    AutomatedParkingValet_B.Add_c[0] =
      AutomatedParkingValet_X.Integrator_CSTATE_l[0] + rtb_Product_c[0];
    AutomatedParkingValet_B.Add_c[1] =
      AutomatedParkingValet_X.Integrator_CSTATE_l[1] + rtb_Product_c[1];
    AutomatedParkingValet_B.Add_c[2] = AutomatedParkingValet_P.Constant_Value_i
      + rtb_Product_c[2];

    /* MATLAB Function: '<S37>/COMB2I' incorporates:
     *  Trigonometry: '<S31>/Trigonometric Function'
     */
    AutomatedParkingValet_B.y[0] = AutomatedParkingValet_B.VectorConcatenate1[0]
      * mapLocation_idx_0 - AutomatedParkingValet_B.VectorConcatenate1[1] *
      absxk;
    AutomatedParkingValet_B.y[1] = AutomatedParkingValet_B.VectorConcatenate1[0]
      * absxk + AutomatedParkingValet_B.VectorConcatenate1[1] *
      mapLocation_idx_0;
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* SignalConversion generated from: '<S82>/Vector Concatenate1' incorporates:
       *  Constant: '<S82>/Constant'
       */
      AutomatedParkingValet_B.VectorConcatenate1_k[0] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_mu;

      /* SignalConversion generated from: '<S82>/Vector Concatenate1' incorporates:
       *  Constant: '<S82>/Constant'
       */
      AutomatedParkingValet_B.VectorConcatenate1_k[1] =
        AutomatedParkingValet_P.VehicleBody3DOFLateral_mu;

      /* SignalConversion generated from: '<S83>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_g[0] = 0.0;

      /* SignalConversion generated from: '<S83>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_g[1] = 0.0;

      /* SignalConversion generated from: '<S85>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_d[0] = 0.0;

      /* SignalConversion generated from: '<S85>/Vector Concatenate1' */
      AutomatedParkingValet_B.VectorConcatenate1_d[1] = 0.0;
    }

    /* MATLAB Function: '<S16>/vehicle model' incorporates:
     *  Constant: '<S29>/Cyf'
     *  Constant: '<S29>/Cyr'
     *  Sum: '<S30>/Sum of Elements'
     *  UnitConversion: '<S84>/Unit Conversion1'
     */
    absxk = AutomatedParkingValet_B.VectorConcatenate1[3];
    t = fabs(AutomatedParkingValet_B.VectorConcatenate1[0]);
    i = 0;
    if (t < AutomatedParkingValet_P.VehicleBody3DOFLateral_xdot_tol) {
      i = 1;
    }

    if (0 <= i - 1) {
      Fy_r = t / AutomatedParkingValet_P.VehicleBody3DOFLateral_xdot_tol;
    }

    if (0 <= i - 1) {
      Fy_r *= Fy_r;
    }

    k = i - 1;
    for (i = 0; i <= k; i++) {
      Fy_r = 2.0 * AutomatedParkingValet_P.VehicleBody3DOFLateral_xdot_tol /
        (3.0 - Fy_r);
    }

    mapLocation_idx_0 = t;
    if (t < AutomatedParkingValet_P.VehicleBody3DOFLateral_xdot_tol) {
      mapLocation_idx_0 = Fy_r;
    }

    rtb_TrigonometricFunction = tanh(4.0 *
      AutomatedParkingValet_B.VectorConcatenate1[0]);
    t = rt_atan2d_snf(AutomatedParkingValet_P.VehicleBody3DOFLateral_a *
                      AutomatedParkingValet_B.VectorConcatenate1[3] +
                      AutomatedParkingValet_B.VectorConcatenate1[1],
                      mapLocation_idx_0) - rtb_CurrVelocity *
      rtb_TrigonometricFunction;
    rtb_TrigonometricFunction = rt_atan2d_snf
      (AutomatedParkingValet_B.VectorConcatenate1[1] -
       AutomatedParkingValet_P.VehicleBody3DOFLateral_b *
       AutomatedParkingValet_B.VectorConcatenate1[3], mapLocation_idx_0) - 0.0 *
      rtb_TrigonometricFunction;
    mapLocation_idx_0 = 0.0;
    mapLocation_idx_1 = 0.0;
    rtb_VectorConcatenate_j_tmp = cos(rtb_CurrVelocity);
    for (b_k = 0; b_k < 6; b_k++) {
      if (b_k == 0) {
        mapLocation_idx_1 = rtb_CurrPose[0] *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_h;
        mapLocation_idx_0 = (((AutomatedParkingValet_P.VehicleBody3DOFLateral_g *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_b *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_m + rtb_CurrPose_o *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_b) + mapLocation_idx_1)
                             - rtb_VectorConcatenate2_k[1]) / rtb_CurrYawRate;
        mapLocation_idx_1 = (((AutomatedParkingValet_P.VehicleBody3DOFLateral_g *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_a *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_m + rtb_CurrPose_o *
          AutomatedParkingValet_P.VehicleBody3DOFLateral_a) - mapLocation_idx_1)
                             + rtb_VectorConcatenate2_k[1]) / rtb_CurrYawRate;
        if (mapLocation_idx_0 < 0.0) {
          mapLocation_idx_0 = 0.0;
        }

        if (mapLocation_idx_1 < 0.0) {
          mapLocation_idx_1 = 0.0;
        }
      }

      Fy_f = -AutomatedParkingValet_P.VehicleBody3DOFLateral_Cy_f * t *
        AutomatedParkingValet_B.VectorConcatenate1_k[0] * mapLocation_idx_0 /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom;
      Fy_r = -AutomatedParkingValet_P.VehicleBody3DOFLateral_Cy_r *
        rtb_TrigonometricFunction *
        AutomatedParkingValet_B.VectorConcatenate1_k[1] * mapLocation_idx_1 /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom;
      AutomatedP_automlvehdynftiresat(Fy_f,
        AutomatedParkingValet_P.vehiclemodel_Fxtire_sat * mapLocation_idx_0 /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom,
        AutomatedParkingValet_P.vehiclemodel_Fytire_sat * mapLocation_idx_0 /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom, &yddot, &b_Fy_ft);
      AutomatedP_automlvehdynftiresat(Fy_r,
        AutomatedParkingValet_P.vehiclemodel_Fxtire_sat * mapLocation_idx_1 /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom,
        AutomatedParkingValet_P.vehiclemodel_Fytire_sat * mapLocation_idx_1 /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom, &mapLocation_idx_0,
        &yddot);
      mapLocation_idx_0 = sin(rtb_CurrVelocity);
      Fy_f = -(0.0 * rtb_VectorConcatenate_j_tmp - b_Fy_ft * mapLocation_idx_0) *
        mapLocation_idx_0 + Fy_f * rtb_VectorConcatenate_j_tmp;
      Fy_r += -(0.0 - yddot * 0.0) * 0.0;
      yddot = ((Fy_f + Fy_r) + rtb_CurrPose[1]) /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_m +
        -AutomatedParkingValet_B.VectorConcatenate1[0] * absxk;
      Fy_f = ((AutomatedParkingValet_P.VehicleBody3DOFLateral_a * Fy_f -
               AutomatedParkingValet_P.VehicleBody3DOFLateral_b * Fy_r) +
              rtb_VectorConcatenate2_k[2]) /
        AutomatedParkingValet_P.VehicleBody3DOFLateral_Izz;
      mapLocation_idx_1 = (0.0 - AutomatedParkingValet_B.VectorConcatenate1[1] *
                           absxk) *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_h;
      Fy_r = rtb_CurrPose[0] * AutomatedParkingValet_P.VehicleBody3DOFLateral_h;
      mapLocation_idx_0 = ((((AutomatedParkingValet_P.VehicleBody3DOFLateral_g *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_b - mapLocation_idx_1) *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_m + rtb_CurrPose_o *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_b) + Fy_r) -
                           rtb_VectorConcatenate2_k[1]) / rtb_CurrYawRate;
      mapLocation_idx_1 = ((((mapLocation_idx_1 +
        AutomatedParkingValet_P.VehicleBody3DOFLateral_g *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_a) *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_m + rtb_CurrPose_o *
        AutomatedParkingValet_P.VehicleBody3DOFLateral_a) - Fy_r) +
                           rtb_VectorConcatenate2_k[1]) / rtb_CurrYawRate;
      if (mapLocation_idx_0 < 0.0) {
        mapLocation_idx_0 = 0.0;
      }

      if (mapLocation_idx_1 < 0.0) {
        mapLocation_idx_1 = 0.0;
      }
    }

    AutomatedParkingValet_B.stateDer[0] = 0.0;
    AutomatedParkingValet_B.stateDer[1] = yddot;
    AutomatedParkingValet_B.stateDer[2] =
      AutomatedParkingValet_B.VectorConcatenate1[3];
    AutomatedParkingValet_B.stateDer[3] = Fy_f;
    Au_emxFreeStruct_pathPlannerRRT(&AutomatedParkingValet_B.motionPlanner);
  }

  if (rtmIsMajorTimeStep(AutomatedParkingValet_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(AutomatedParkingValet_M->rtwLogInfo,
                        (AutomatedParkingValet_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(AutomatedParkingValet_M)) {
    real_T distToGoal;
    int8_T n;
    real_T scale;
    real_T absxk;
    real_T t;
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Update for UnitDelay: '<S11>/Unit Delay2' */
      AutomatedParkingValet_DW.UnitDelay2_DSTATE[0] =
        AutomatedParkingValet_B.Add_c[0];
      AutomatedParkingValet_DW.UnitDelay2_DSTATE[1] =
        AutomatedParkingValet_B.Add_c[1];
      AutomatedParkingValet_DW.UnitDelay2_DSTATE[2] =
        AutomatedParkingValet_B.Gain;

      /* Update for UnitDelay: '<S11>/Unit Delay4' */
      AutomatedParkingValet_DW.UnitDelay4_DSTATE =
        AutomatedParkingValet_B.VectorConcatenate1[0];

      /* Update for UnitDelay: '<S11>/Unit Delay5' */
      AutomatedParkingValet_DW.UnitDelay5_DSTATE =
        AutomatedParkingValet_B.VectorConcatenate1[3];

      /* Update for UnitDelay: '<S11>/Unit Delay3' */
      AutomatedParkingValet_DW.UnitDelay3_DSTATE = AutomatedParkingValet_B.Delay;
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[2] == 0) {
      /* Update for UnitDelay: '<S11>/Unit Delay1' */
      AutomatedParkingValet_DW.UnitDelay1_DSTATE =
        AutomatedParkingValet_B.MATLABSystem_o3;
    }

    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[3] == 0) {
      /* Update for Atomic SubSystem: '<Root>/Subsystem1' */
      /* MATLAB Function: '<S2>/MATLAB Function' */
      scale = 3.3121686421112381E-170;
      absxk = fabs(AutomatedParkingValet_B.nextGoal[0] -
                   AutomatedParkingValet_B.BusCreator.CurrPose[0]);
      if (absxk > 3.3121686421112381E-170) {
        distToGoal = 1.0;
        scale = absxk;
      } else {
        t = absxk / 3.3121686421112381E-170;
        distToGoal = t * t;
      }

      absxk = fabs(AutomatedParkingValet_B.nextGoal[1] -
                   AutomatedParkingValet_B.BusCreator.CurrPose[1]);
      if (absxk > scale) {
        t = scale / absxk;
        distToGoal = distToGoal * t * t + 1.0;
        scale = absxk;
      } else {
        t = absxk / scale;
        distToGoal += t * t;
      }

      distToGoal = scale * sqrt(distToGoal);
      if (distToGoal > 3.0) {
        /* Update for UnitDelay: '<S2>/Unit Delay' */
        AutomatedParkingValet_DW.UnitDelay_DSTATE_b = false;
      } else {
        if (rtIsInf(AutomatedParkingValet_B.nextGoal[2]) || rtIsNaN
            (AutomatedParkingValet_B.nextGoal[2])) {
          distToGoal = (rtNaN);
          scale = (rtNaN);
        } else {
          t = rt_remd_snf(AutomatedParkingValet_B.nextGoal[2], 360.0);
          distToGoal = t;
          scale = fabs(t);
          if (scale > 180.0) {
            if (t > 0.0) {
              distToGoal = t - 360.0;
            } else {
              distToGoal = t + 360.0;
            }

            scale = fabs(distToGoal);
          }

          if (scale <= 45.0) {
            distToGoal *= 0.017453292519943295;
            distToGoal = cos(distToGoal);
          } else {
            if (scale <= 135.0) {
              if (distToGoal > 0.0) {
                distToGoal = (distToGoal - 90.0) * 0.017453292519943295;
                n = 1;
              } else {
                distToGoal = (distToGoal + 90.0) * 0.017453292519943295;
                n = -1;
              }
            } else if (distToGoal > 0.0) {
              distToGoal = (distToGoal - 180.0) * 0.017453292519943295;
              n = 2;
            } else {
              distToGoal = (distToGoal + 180.0) * 0.017453292519943295;
              n = -2;
            }

            if (n == 1) {
              distToGoal = -sin(distToGoal);
            } else if (n == -1) {
              distToGoal = sin(distToGoal);
            } else {
              distToGoal = -cos(distToGoal);
            }
          }

          scale = t;
          absxk = fabs(t);
          if (absxk > 180.0) {
            if (t > 0.0) {
              scale = t - 360.0;
            } else {
              scale = t + 360.0;
            }

            absxk = fabs(scale);
          }

          if (absxk <= 45.0) {
            scale *= 0.017453292519943295;
            scale = sin(scale);
          } else {
            if (absxk <= 135.0) {
              if (scale > 0.0) {
                scale = (scale - 90.0) * 0.017453292519943295;
                n = 1;
              } else {
                scale = (scale + 90.0) * 0.017453292519943295;
                n = -1;
              }
            } else if (scale > 0.0) {
              scale = (scale - 180.0) * 0.017453292519943295;
              n = 2;
            } else {
              scale = (scale + 180.0) * 0.017453292519943295;
              n = -2;
            }

            if (n == 1) {
              scale = cos(scale);
            } else if (n == -1) {
              scale = -cos(scale);
            } else {
              scale = -sin(scale);
            }
          }
        }

        if (((AutomatedParkingValet_B.BusCreator.CurrPose[0] -
              AutomatedParkingValet_B.nextGoal[0]) * distToGoal +
             (AutomatedParkingValet_B.BusCreator.CurrPose[1] -
              AutomatedParkingValet_B.nextGoal[1]) * scale) *
            AutomatedParkingValet_B.BusCreator.Direction > 0.0) {
          /* Update for UnitDelay: '<S2>/Unit Delay' */
          AutomatedParkingValet_DW.UnitDelay_DSTATE_b = ((fabs
            (AutomatedParkingValet_B.BusCreator.CurrVelocity) < 0.05) ||
            (AutomatedParkingValet_B.speedProfilerConfig.EndSpeed != 0.0));
        } else {
          /* Update for UnitDelay: '<S2>/Unit Delay' */
          AutomatedParkingValet_DW.UnitDelay_DSTATE_b = (fabs
            (AutomatedParkingValet_B.BusCreator.CurrVelocity) < 0.05);
        }
      }

      /* End of MATLAB Function: '<S2>/MATLAB Function' */
      /* End of Update for SubSystem: '<Root>/Subsystem1' */
    }

    /* Update for Atomic SubSystem: '<S4>/Acceleration to Velocity' */
    if (rtmIsMajorTimeStep(AutomatedParkingValet_M) &&
        AutomatedParkingValet_M->Timing.TaskCounters.TID[1] == 0) {
      /* Update for UnitDelay: '<S8>/Unit Delay' */
      AutomatedParkingValet_DW.UnitDelay_DSTATE = AutomatedParkingValet_B.Switch;
    }

    /* End of Update for SubSystem: '<S4>/Acceleration to Velocity' */

    /* Update for Integrator: '<S88>/Integrator' */
    AutomatedParkingValet_DW.Integrator_IWORK = 0;

    /* Update for Integrator: '<S37>/Integrator' */
    AutomatedParkingValet_DW.Integrator_IWORK_k = 0;
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(AutomatedParkingValet_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(AutomatedParkingValet_M)!=-1) &&
          !((rtmGetTFinal(AutomatedParkingValet_M)-
             (((AutomatedParkingValet_M->Timing.clockTick1+
                AutomatedParkingValet_M->Timing.clockTickH1* 4294967296.0)) *
              0.001)) > (((AutomatedParkingValet_M->Timing.clockTick1+
                           AutomatedParkingValet_M->Timing.clockTickH1*
                           4294967296.0)) * 0.001) * (DBL_EPSILON))) {
        rtmSetErrorStatus(AutomatedParkingValet_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&AutomatedParkingValet_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++AutomatedParkingValet_M->Timing.clockTick0)) {
      ++AutomatedParkingValet_M->Timing.clockTickH0;
    }

    AutomatedParkingValet_M->Timing.t[0] = rtsiGetSolverStopTime
      (&AutomatedParkingValet_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.001s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.001, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      AutomatedParkingValet_M->Timing.clockTick1++;
      if (!AutomatedParkingValet_M->Timing.clockTick1) {
        AutomatedParkingValet_M->Timing.clockTickH1++;
      }
    }

    rate_scheduler();
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void AutomatedParkingValet_derivatives(void)
{
  boolean_T lsat;
  boolean_T usat;
  XDot_AutomatedParkingValet_T *_rtXdot;
  _rtXdot = ((XDot_AutomatedParkingValet_T *) AutomatedParkingValet_M->derivs);

  /* Derivatives for Atomic SubSystem: '<S4>/Acceleration to Velocity' */
  /* Derivatives for Integrator: '<S8>/Saturated integrator' */
  lsat = (AutomatedParkingValet_X.Saturatedintegrator_CSTATE <=
          AutomatedParkingValet_P.Saturatedintegrator_LowerSat);
  usat = (AutomatedParkingValet_X.Saturatedintegrator_CSTATE >=
          AutomatedParkingValet_P.Saturatedintegrator_UpperSat);
  if (((!lsat) && (!usat)) || (lsat && (AutomatedParkingValet_B.Add_n > 0.0)) ||
      (usat && (AutomatedParkingValet_B.Add_n < 0.0))) {
    _rtXdot->Saturatedintegrator_CSTATE = AutomatedParkingValet_B.Add_n;
  } else {
    /* in saturation */
    _rtXdot->Saturatedintegrator_CSTATE = 0.0;
  }

  /* End of Derivatives for Integrator: '<S8>/Saturated integrator' */
  /* End of Derivatives for SubSystem: '<S4>/Acceleration to Velocity' */

  /* Derivatives for TransferFcn: '<S10>/Delay' */
  _rtXdot->Delay_CSTATE = 0.0;
  _rtXdot->Delay_CSTATE += AutomatedParkingValet_P.Delay_A *
    AutomatedParkingValet_X.Delay_CSTATE;
  _rtXdot->Delay_CSTATE += AutomatedParkingValet_B.Add;

  /* Derivatives for Integrator: '<S88>/Integrator' */
  _rtXdot->Integrator_CSTATE[0] = AutomatedParkingValet_B.stateDer[0];
  _rtXdot->Integrator_CSTATE[1] = AutomatedParkingValet_B.stateDer[1];
  _rtXdot->Integrator_CSTATE[2] = AutomatedParkingValet_B.stateDer[2];
  _rtXdot->Integrator_CSTATE[3] = AutomatedParkingValet_B.stateDer[3];

  /* Derivatives for Integrator: '<S37>/Integrator' */
  _rtXdot->Integrator_CSTATE_l[0] = AutomatedParkingValet_B.y[0];
  _rtXdot->Integrator_CSTATE_l[1] = AutomatedParkingValet_B.y[1];
}

/* Model initialize function */
void AutomatedParkingValet_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  AutomatedParkingValet_P.Saturatedintegrator_UpperSat = rtInf;

  /* initialize real-time model */
  (void) memset((void *)AutomatedParkingValet_M, 0,
                sizeof(RT_MODEL_AutomatedParkingVale_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&AutomatedParkingValet_M->solverInfo,
                          &AutomatedParkingValet_M->Timing.simTimeStep);
    rtsiSetTPtr(&AutomatedParkingValet_M->solverInfo, &rtmGetTPtr
                (AutomatedParkingValet_M));
    rtsiSetStepSizePtr(&AutomatedParkingValet_M->solverInfo,
                       &AutomatedParkingValet_M->Timing.stepSize0);
    rtsiSetdXPtr(&AutomatedParkingValet_M->solverInfo,
                 &AutomatedParkingValet_M->derivs);
    rtsiSetContStatesPtr(&AutomatedParkingValet_M->solverInfo, (real_T **)
                         &AutomatedParkingValet_M->contStates);
    rtsiSetNumContStatesPtr(&AutomatedParkingValet_M->solverInfo,
      &AutomatedParkingValet_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&AutomatedParkingValet_M->solverInfo,
      &AutomatedParkingValet_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&AutomatedParkingValet_M->solverInfo,
      &AutomatedParkingValet_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&AutomatedParkingValet_M->solverInfo,
      &AutomatedParkingValet_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&AutomatedParkingValet_M->solverInfo,
                          (&rtmGetErrorStatus(AutomatedParkingValet_M)));
    rtsiSetRTModelPtr(&AutomatedParkingValet_M->solverInfo,
                      AutomatedParkingValet_M);
  }

  rtsiSetSimTimeStep(&AutomatedParkingValet_M->solverInfo, MAJOR_TIME_STEP);
  AutomatedParkingValet_M->intgData.y = AutomatedParkingValet_M->odeY;
  AutomatedParkingValet_M->intgData.f[0] = AutomatedParkingValet_M->odeF[0];
  AutomatedParkingValet_M->intgData.f[1] = AutomatedParkingValet_M->odeF[1];
  AutomatedParkingValet_M->intgData.f[2] = AutomatedParkingValet_M->odeF[2];
  AutomatedParkingValet_M->contStates = ((X_AutomatedParkingValet_T *)
    &AutomatedParkingValet_X);
  rtsiSetSolverData(&AutomatedParkingValet_M->solverInfo, (void *)
                    &AutomatedParkingValet_M->intgData);
  rtsiSetSolverName(&AutomatedParkingValet_M->solverInfo,"ode3");
  rtmSetTPtr(AutomatedParkingValet_M, &AutomatedParkingValet_M->Timing.tArray[0]);
  rtmSetTFinal(AutomatedParkingValet_M, -1);
  AutomatedParkingValet_M->Timing.stepSize0 = 0.001;
  rtmSetFirstInitCond(AutomatedParkingValet_M, 1);

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    AutomatedParkingValet_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(AutomatedParkingValet_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(AutomatedParkingValet_M->rtwLogInfo, (NULL));
    rtliSetLogT(AutomatedParkingValet_M->rtwLogInfo, "");
    rtliSetLogX(AutomatedParkingValet_M->rtwLogInfo, "");
    rtliSetLogXFinal(AutomatedParkingValet_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(AutomatedParkingValet_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(AutomatedParkingValet_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(AutomatedParkingValet_M->rtwLogInfo, 0);
    rtliSetLogDecimation(AutomatedParkingValet_M->rtwLogInfo, 1);
    rtliSetLogY(AutomatedParkingValet_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(AutomatedParkingValet_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(AutomatedParkingValet_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &AutomatedParkingValet_B), 0,
                sizeof(B_AutomatedParkingValet_T));

  /* states (continuous) */
  {
    (void) memset((void *)&AutomatedParkingValet_X, 0,
                  sizeof(X_AutomatedParkingValet_T));
  }

  /* states (dwork) */
  (void) memset((void *)&AutomatedParkingValet_DW, 0,
                sizeof(DW_AutomatedParkingValet_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  AutomatedParkingValet_InitializeDataMapInfo();

  {
    static uint32_T *clockTickPtrs[4];
    static uint32_T *clockTickHPtrs[4];
    static real_T *taskTimePtrs[4];
    static uint32_T *taskCounterPtrs;
    AutomatedParkingVale_TimingBrdg.nTasks = 4;
    clockTickPtrs[0] = &(AutomatedParkingValet_M->Timing.clockTick0);
    clockTickHPtrs[0] = &(AutomatedParkingValet_M->Timing.clockTickH0);
    clockTickPtrs[1] = &(AutomatedParkingValet_M->Timing.clockTick1);
    clockTickHPtrs[1] = &(AutomatedParkingValet_M->Timing.clockTickH1);
    clockTickPtrs[2] = (NULL);
    clockTickHPtrs[2] = (NULL);
    clockTickPtrs[3] = (NULL);
    clockTickHPtrs[3] = (NULL);
    AutomatedParkingVale_TimingBrdg.clockTick = clockTickPtrs;
    AutomatedParkingVale_TimingBrdg.clockTickH = clockTickHPtrs;
    taskCounterPtrs = &(AutomatedParkingValet_M->Timing.TaskCounters.TID[0]);
    AutomatedParkingVale_TimingBrdg.taskCounter = taskCounterPtrs;
    taskTimePtrs[0] = &(AutomatedParkingValet_M->Timing.t[0]);
    taskTimePtrs[1] = (NULL);
    taskTimePtrs[2] = (NULL);
    taskTimePtrs[3] = (NULL);
    AutomatedParkingVale_TimingBrdg.taskTime = taskTimePtrs;
    AutomatedParkingVale_TimingBrdg.firstInitCond = &rtmIsFirstInitCond
      (AutomatedParkingValet_M);
  }

  /* Model Initialize function for ModelReference Block: '<Root>/Vehicle Controller' */
  StanleyRefMdl_initialize(rtmGetErrorStatusPointer(AutomatedParkingValet_M),
    &AutomatedParkingVale_TimingBrdg, 1, 2,
    &(AutomatedParkingValet_DW.VehicleController_InstanceData.rtm),
    &(AutomatedParkingValet_DW.VehicleController_InstanceData.rtb),
    &(AutomatedParkingValet_DW.VehicleController_InstanceData.rtdw),
    &(AutomatedParkingValet_M->DataMapInfo.mmi),
    "AutomatedParkingValet/Vehicle Controller", 0, -1);

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(AutomatedParkingValet_M->rtwLogInfo, 0.0,
    rtmGetTFinal(AutomatedParkingValet_M),
    AutomatedParkingValet_M->Timing.stepSize0, (&rtmGetErrorStatus
    (AutomatedParkingValet_M)));
  AutomatedParkingValet_PrevZCX.Saturatedintegrator_Reset_ZCE =
    UNINITIALIZED_ZCSIG;

  {
    int_T is;
    uint32_T r;
    int32_T PathSmootherSpline_DIMS3;
    int32_T PathSmootherSpline_DIMS4;

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay2' */
    AutomatedParkingValet_DW.UnitDelay2_DSTATE[0] = rtP_startPose[0];
    AutomatedParkingValet_DW.UnitDelay2_DSTATE[1] = rtP_startPose[1];
    AutomatedParkingValet_DW.UnitDelay2_DSTATE[2] = rtP_startPose[2];

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay4' */
    AutomatedParkingValet_DW.UnitDelay4_DSTATE =
      AutomatedParkingValet_P.UnitDelay4_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay5' */
    AutomatedParkingValet_DW.UnitDelay5_DSTATE =
      AutomatedParkingValet_P.UnitDelay5_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay3' */
    AutomatedParkingValet_DW.UnitDelay3_DSTATE =
      AutomatedParkingValet_P.UnitDelay3_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay1' */
    AutomatedParkingValet_DW.UnitDelay1_DSTATE =
      AutomatedParkingValet_P.UnitDelay1_InitialCondition;

    /* InitializeConditions for TransferFcn: '<S10>/Delay' */
    AutomatedParkingValet_X.Delay_CSTATE = 0.0;

    /* InitializeConditions for Integrator: '<S88>/Integrator' incorporates:
     *  Integrator: '<S37>/Integrator'
     */
    if (rtmIsFirstInitCond(AutomatedParkingValet_M)) {
      AutomatedParkingValet_X.Integrator_CSTATE[0] = 0.0;
      AutomatedParkingValet_X.Integrator_CSTATE[1] = 0.0;
      AutomatedParkingValet_X.Integrator_CSTATE[2] = 0.0;
      AutomatedParkingValet_X.Integrator_CSTATE[3] = 0.0;
      AutomatedParkingValet_X.Integrator_CSTATE_l[0] = 0.0;
      AutomatedParkingValet_X.Integrator_CSTATE_l[1] = 0.0;
    }

    AutomatedParkingValet_DW.Integrator_IWORK = 1;

    /* End of InitializeConditions for Integrator: '<S88>/Integrator' */

    /* InitializeConditions for Integrator: '<S37>/Integrator' */
    AutomatedParkingValet_DW.Integrator_IWORK_k = 1;

    /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem1' */
    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    AutomatedParkingValet_DW.UnitDelay_DSTATE_b =
      AutomatedParkingValet_P.UnitDelay_InitialCondition_a;

    /* End of SystemInitialize for SubSystem: '<Root>/Subsystem1' */

    /* SystemInitialize for MATLAB Function: '<Root>/BehaviorPlanner' */
    AutomatedParkingValet_DW.pose[0] = 4.0;
    AutomatedParkingValet_DW.pose[1] = 12.0;
    AutomatedParkingValet_DW.pose[2] = 0.0;
    AutomatedParkingValet_DW.behavioralPlanner_not_empty = false;

    /* SystemInitialize for MATLAB Function: '<Root>/motionPlanning' */
    AutomatedParkingValet_DW.posesInternal_not_empty = false;
    AutomatedParkingValet_DW.directionsInternal_not_empty = false;
    AutomatedParkingValet_DW.posesInternal.size[1] = 0;
    AutomatedParkingValet_DW.directionsInternal.size = 0;

    /* SystemInitialize for MATLAB Function: '<Root>/motionPlanning' */
    memset(&AutomatedParkingValet_DW.state[0], 0, 625U * sizeof(uint32_T));
    r = 5489U;
    AutomatedParkingValet_DW.state[0] = 5489U;
    for (is = 0; is < 623; is++) {
      r = ((r >> 30U ^ r) * 1812433253U + is) + 1U;
      AutomatedParkingValet_DW.state[is + 1] = r;
    }

    AutomatedParkingValet_DW.state[624] = 624U;
    AutomatedParkingValet_DW.nextGoalPose[0] = 0.0;
    AutomatedParkingValet_DW.nextGoalPose[1] = 0.0;
    AutomatedParkingValet_DW.nextGoalPose[2] = 0.0;

    /* SystemInitialize for ModelReference generated from: '<Root>/Vehicle Controller' */
    StanleyRefMdl_Init
      (&(AutomatedParkingValet_DW.VehicleController_InstanceData.rtb),
       &(AutomatedParkingValet_DW.VehicleController_InstanceData.rtdw));

    /* SystemInitialize for Atomic SubSystem: '<S4>/Acceleration to Velocity' */
    /* InitializeConditions for UnitDelay: '<S8>/Unit Delay' */
    AutomatedParkingValet_DW.UnitDelay_DSTATE =
      AutomatedParkingValet_P.UnitDelay_InitialCondition;

    /* InitializeConditions for Integrator: '<S8>/Saturated integrator' */
    AutomatedParkingValet_X.Saturatedintegrator_CSTATE =
      AutomatedParkingValet_P.Saturatedintegrator_IC;

    /* End of SystemInitialize for SubSystem: '<S4>/Acceleration to Velocity' */
    emxInitStruct_driving_internal_(&AutomatedParkingValet_DW.obj);

    /* Start for MATLABSystem: '<S3>/Path Smoother Spline' */
    AutomatedParkingValet_DW.obj.isInitialized = 0;
    AutomatedParkingValet_DW.obj.CacheInputSizes = false;
    AutomatedParkingValet_DW.objisempty = true;
    is = AutomatedParkingValet_DW.SFunction_DIMS3[0];
    AutomatedPa_SystemCore_setup_pm(&AutomatedParkingValet_DW.obj,
      AutomatedParkingValet_DW.SFunction_DIMS2, &is);
    emxInitStruct_driving_interna_p(&AutomatedParkingValet_DW.obj_j);

    /* Start for MATLABSystem: '<S3>/Velocity Profiler' */
    AutomatedParkingValet_DW.obj_j.isInitialized = 0;
    AutomatedParkingValet_DW.obj_j.CacheInputSizes = false;
    AutomatedParkingValet_DW.objisempty_i = true;
    AutomatedParkingValet_DW.obj_j.MaxSpeed =
      AutomatedParkingValet_P.VelocityProfiler_MaxSpeed;
    is = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
    PathSmootherSpline_DIMS3 =
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS3[0];
    PathSmootherSpline_DIMS4 =
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
    AutomatedPar_SystemCore_setup_p(&AutomatedParkingValet_DW.obj_j, &is,
      &PathSmootherSpline_DIMS3, &PathSmootherSpline_DIMS4);
    emxInitStruct_HelperPathAnalyze(&AutomatedParkingValet_DW.obj_d);

    /* Start for MATLABSystem: '<Root>/MATLAB System' */
    AutomatedParkingValet_DW.obj_d.LastRefPoseOutput[0] = 0.0;
    AutomatedParkingValet_DW.obj_d.LastRefPoseOutput[1] = 0.0;
    AutomatedParkingValet_DW.obj_d.LastRefPoseOutput[2] = 0.0;
    AutomatedParkingValet_DW.obj_d.LastRefVelocityOutput = 0.0;
    AutomatedParkingValet_DW.obj_d.LastCurvatureOutput = 0.0;
    AutomatedParkingValet_DW.obj_d.LastDirectionOutput = 1.0;
    AutomatedParkingValet_DW.obj_d.isInitialized = 0;
    AutomatedParkingValet_DW.obj_d.CacheInputSizes = false;
    AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[0] = false;
    AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[1] = false;
    AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[2] = false;
    AutomatedParkingValet_DW.obj_d.tunablePropertyChanged[3] = false;
    AutomatedParkingValet_DW.objisempty_d = true;
    is = AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0];
    PathSmootherSpline_DIMS4 =
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0];
    PathSmootherSpline_DIMS3 = AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0];
    AutomatedParki_SystemCore_setup(&AutomatedParkingValet_DW.obj_d,
      AutomatedParkingValet_DW.PathSmootherSpline_DIMS1, &is,
      &PathSmootherSpline_DIMS4, &PathSmootherSpline_DIMS3);

    /* set "at time zero" to false */
    if (rtmIsFirstInitCond(AutomatedParkingValet_M)) {
      rtmSetFirstInitCond(AutomatedParkingValet_M, 0);
    }
  }
}

/* Model terminate function */
void AutomatedParkingValet_terminate(void)
{
  emxFreeStruct_driving_internal_(&AutomatedParkingValet_DW.obj);
  emxFreeStruct_driving_interna_p(&AutomatedParkingValet_DW.obj_j);
  emxFreeStruct_HelperPathAnalyze(&AutomatedParkingValet_DW.obj_d);
}
