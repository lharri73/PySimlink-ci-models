/*
 * AutomatedParkingValet.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:14:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_AutomatedParkingValet_h_
#define RTW_HEADER_AutomatedParkingValet_h_
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef AutomatedParkingValet_COMMON_INCLUDES_
# define AutomatedParkingValet_COMMON_INCLUDES_
#include <string.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#include "autonomouscodegen_dubins_api.hpp"
#endif                              /* AutomatedParkingValet_COMMON_INCLUDES_ */

#include "AutomatedParkingValet_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"

/* Child system includes */
#include "StanleyRefMdl.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#include "rt_zcfcn.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetErrorStatusPointer
# define rtmGetErrorStatusPointer(rtm) ((const char_T **)(&((rtm)->errorStatus)))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  pathPlannerRRT_AutomatedParki_T motionPlanner;
  real_T xyPoints[40000];
  real_T this[30003];
  real_T nodeBuffer[30003];
  real_T r[15000];
  real_T vehiclePoses[15000];
  c_driving_internal_costmap_Ve_T lobj_4;
  c_driving_internal_costmap_Ve_T costmap;
  uint32_T b_path_data[10002];
  int32_T idx_data[10002];
  int32_T itmp_data[10002];
  int32_T iwork_data[10002];
  uint32_T path_data[10001];
  int32_T ia_data[10001];
  int32_T ib_data[10001];
  uint32_T path_data_m[10001];
  int32_T aperm_data[10001];
  int32_T ib_data_c[10001];
  int32_T iwork_data_k[10001];
  int32_T vwork_data[10001];
  int32_T iidx_data[10001];
  int32_T iwork_data_c[10001];
  int32_T xwork_data[10001];
  int32_T b_x_data[10001];
  int16_T c_data[20000];
  real_T r_b[5000];
  real_T idx[5000];
  real_T b[5000];
  real_T c[5000];
  real_T r_p[5000];
  boolean_T freeMat[20000];
  boolean_T insideMap[20000];
  boolean_T this_c[15000];
  real_T posesSeg_data[1500];
  boolean_T x[5000];
  real_T splineDx_coefs_data[594];
  real_T splineDy_coefs_data[594];
  real_T tmp_data[594];
  real_T splineX_coefs_data[594];
  vehicleInfoBus BusCreator;           /* '<S11>/Bus Creator' */
  plannerConfigBus motionPlannerConfig;/* '<Root>/BehaviorPlanner' */
  speedConfigBus speedProfilerConfig;  /* '<Root>/BehaviorPlanner' */
  real_T SteerCmd;                     /* '<Root>/Vehicle Controller' */
  real_T AccelCmd;                     /* '<Root>/Vehicle Controller' */
  real_T DecelCmd;                     /* '<Root>/Vehicle Controller' */
  real_T Delay;                        /* '<S10>/Delay' */
  real_T Add;                          /* '<S10>/Add' */
  real_T VectorConcatenate[4];         /* '<S16>/Vector Concatenate' */
  real_T VectorConcatenate_n[4];       /* '<S88>/Vector Concatenate' */
  real_T VectorConcatenate1[4];        /* '<S88>/Vector Concatenate1' */
  real_T Gain;                         /* '<S15>/Gain' */
  real_T VectorConcatenate1_m[3];      /* '<S89>/Vector Concatenate1' */
  real_T UnaryMinus[3];                /* '<S30>/Unary Minus' */
  real_T VectorConcatenate_m[6];       /* '<S30>/Vector Concatenate' */
  real_T VectorConcatenate3[2];        /* '<S16>/Vector Concatenate3' */
  real_T VectorConcatenate_p[3];       /* '<S40>/Vector Concatenate' */
  real_T Add_c[3];                     /* '<S40>/Add' */
  real_T VectorConcatenate1_k[2];      /* '<S82>/Vector Concatenate1' */
  real_T VectorConcatenate1_g[2];      /* '<S83>/Vector Concatenate1' */
  real_T VectorConcatenate1_d[2];      /* '<S85>/Vector Concatenate1' */
  real_T refPoses[300];                /* '<Root>/motionPlanning' */
  real_T directions[100];              /* '<Root>/motionPlanning' */
  real_T stateDer[4];                  /* '<S16>/vehicle model' */
  real_T y[2];                         /* '<S37>/COMB2I' */
  real_T Add_n;                        /* '<S8>/Add' */
  real_T Switch;                       /* '<S8>/Switch' */
  real_T PathSmootherSpline_o1[1500];  /* '<S3>/Path Smoother Spline' */
  real_T PathSmootherSpline_o2[500];   /* '<S3>/Path Smoother Spline' */
  real_T PathSmootherSpline_o4[500];   /* '<S3>/Path Smoother Spline' */
  real_T VelocityProfiler[500];        /* '<S3>/Velocity Profiler' */
  real_T nextGoal[3];                  /* '<Root>/BehaviorPlanner' */
  real_T MATLABSystem_o1[3];           /* '<Root>/MATLAB System' */
  real_T MATLABSystem_o2;              /* '<Root>/MATLAB System' */
  real_T MATLABSystem_o3;              /* '<Root>/MATLAB System' */
  real_T MATLABSystem_o4;              /* '<Root>/MATLAB System' */
  real_T MATLABSystem_o5;              /* '<Root>/MATLAB System' */
  boolean_T Compare;                   /* '<S14>/Compare' */
  boolean_T Resetvelocitytozero;       /* '<S8>/AND' */
} B_AutomatedParkingValet_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  driving_internal_planning_Pat_T obj; /* '<S3>/Path Smoother Spline' */
  emxArray_real_T_100x3_Automat_T posesInternal;/* '<Root>/motionPlanning' */
  emxArray_real_T_100_Automated_T directionsInternal;/* '<Root>/motionPlanning' */
  HelperBehavioralPlanner_Autom_T behavioralPlanner;/* '<Root>/BehaviorPlanner' */
  HelperPathAnalyzer_AutomatedP_T obj_d;/* '<Root>/MATLAB System' */
  driving_internal_planning_Vel_T obj_j;/* '<S3>/Velocity Profiler' */
  s4Osf6W5BpyvZGijeirsFz_Automa_T plannerConfig;/* '<Root>/BehaviorPlanner' */
  speedConfigBus speedConfig;          /* '<Root>/BehaviorPlanner' */
  real_T UnitDelay2_DSTATE[3];         /* '<S11>/Unit Delay2' */
  real_T UnitDelay4_DSTATE;            /* '<S11>/Unit Delay4' */
  real_T UnitDelay5_DSTATE;            /* '<S11>/Unit Delay5' */
  real_T UnitDelay3_DSTATE;            /* '<S11>/Unit Delay3' */
  real_T UnitDelay1_DSTATE;            /* '<S11>/Unit Delay1' */
  real_T UnitDelay_DSTATE;             /* '<S8>/Unit Delay' */
  real_T RateTransition1_Buffer[3];    /* '<S11>/Rate Transition1' */
  real_T RateTransition_Buffer;        /* '<S11>/Rate Transition' */
  real_T RateTransition2_Buffer;       /* '<S11>/Rate Transition2' */
  real_T RateTransition3_Buffer;       /* '<S11>/Rate Transition3' */
  real_T nextGoalPose[3];              /* '<Root>/motionPlanning' */
  real_T nextGoalPose_a[3];            /* '<Root>/BehaviorPlanner' */
  real_T pose[3];                      /* '<Root>/BehaviorPlanner' */
  int32_T SFunction_DIMS2[2];          /* '<Root>/motionPlanning' */
  int32_T SFunction_DIMS3[2];          /* '<Root>/motionPlanning' */
  int32_T PathSmootherSpline_DIMS1[2]; /* '<S3>/Path Smoother Spline' */
  int32_T PathSmootherSpline_DIMS2[2]; /* '<S3>/Path Smoother Spline' */
  int32_T PathSmootherSpline_DIMS3[2]; /* '<S3>/Path Smoother Spline' */
  int32_T PathSmootherSpline_DIMS4[2]; /* '<S3>/Path Smoother Spline' */
  int32_T VelocityProfiler_DIMS1[2];   /* '<S3>/Velocity Profiler' */
  uint32_T state[625];                 /* '<Root>/motionPlanning' */
  int_T Integrator_IWORK;              /* '<S88>/Integrator' */
  int_T Integrator_IWORK_k;            /* '<S37>/Integrator' */
  boolean_T UnitDelay_DSTATE_b;        /* '<S2>/Unit Delay' */
  boolean_T posesInternal_not_empty;   /* '<Root>/motionPlanning' */
  boolean_T directionsInternal_not_empty;/* '<Root>/motionPlanning' */
  boolean_T objisempty;                /* '<S3>/Path Smoother Spline' */
  boolean_T objisempty_i;              /* '<S3>/Velocity Profiler' */
  boolean_T behavioralPlanner_not_empty;/* '<Root>/BehaviorPlanner' */
  boolean_T objisempty_d;              /* '<Root>/MATLAB System' */
  MdlrefDW_StanleyRefMdl_T VehicleController_InstanceData;/* '<Root>/Vehicle Controller' */
} DW_AutomatedParkingValet_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Delay_CSTATE;                 /* '<S10>/Delay' */
  real_T Integrator_CSTATE[4];         /* '<S88>/Integrator' */
  real_T Integrator_CSTATE_l[2];       /* '<S37>/Integrator' */
  real_T Saturatedintegrator_CSTATE;   /* '<S8>/Saturated integrator' */
} X_AutomatedParkingValet_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Delay_CSTATE;                 /* '<S10>/Delay' */
  real_T Integrator_CSTATE[4];         /* '<S88>/Integrator' */
  real_T Integrator_CSTATE_l[2];       /* '<S37>/Integrator' */
  real_T Saturatedintegrator_CSTATE;   /* '<S8>/Saturated integrator' */
} XDot_AutomatedParkingValet_T;

/* State disabled  */
typedef struct {
  boolean_T Delay_CSTATE;              /* '<S10>/Delay' */
  boolean_T Integrator_CSTATE[4];      /* '<S88>/Integrator' */
  boolean_T Integrator_CSTATE_l[2];    /* '<S37>/Integrator' */
  boolean_T Saturatedintegrator_CSTATE;/* '<S8>/Saturated integrator' */
} XDis_AutomatedParkingValet_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState Saturatedintegrator_Reset_ZCE;/* '<S8>/Saturated integrator' */
} PrevZCX_AutomatedParkingValet_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Parameters (default storage) */
struct P_AutomatedParkingValet_T_ {
  real_T VehicleBody3DOFLateral_Af; /* Mask Parameter: VehicleBody3DOFLateral_Af
                                     * Referenced by: '<S30>/.5.*A.*Pabs.//R.//T'
                                     */
  real_T VehicleBody3DOFLateral_Cd; /* Mask Parameter: VehicleBody3DOFLateral_Cd
                                     * Referenced by: '<S30>/Constant'
                                     */
  real_T VehicleBody3DOFLateral_Cl; /* Mask Parameter: VehicleBody3DOFLateral_Cl
                                     * Referenced by: '<S30>/Constant1'
                                     */
  real_T VehicleBody3DOFLateral_Cpm;
                                   /* Mask Parameter: VehicleBody3DOFLateral_Cpm
                                    * Referenced by: '<S30>/Constant2'
                                    */
  real_T VehicleBody3DOFLateral_Cs[31];
                                    /* Mask Parameter: VehicleBody3DOFLateral_Cs
                                     * Referenced by: '<S30>/Cs'
                                     */
  real_T VehicleBody3DOFLateral_Cy_f;
                                  /* Mask Parameter: VehicleBody3DOFLateral_Cy_f
                                   * Referenced by: '<S29>/Cyf'
                                   */
  real_T VehicleBody3DOFLateral_Cy_r;
                                  /* Mask Parameter: VehicleBody3DOFLateral_Cy_r
                                   * Referenced by: '<S29>/Cyr'
                                   */
  real_T VehicleBody3DOFLateral_Cym[31];
                                   /* Mask Parameter: VehicleBody3DOFLateral_Cym
                                    * Referenced by: '<S30>/Cym'
                                    */
  real_T VehicleBody3DOFLateral_Fznom;
                                 /* Mask Parameter: VehicleBody3DOFLateral_Fznom
                                  * Referenced by: '<S16>/vehicle model'
                                  */
  real_T VehicleBody3DOFLateral_Izz;
                                   /* Mask Parameter: VehicleBody3DOFLateral_Izz
                                    * Referenced by: '<S16>/vehicle model'
                                    */
  real_T VehicleBody3DOFLateral_NF; /* Mask Parameter: VehicleBody3DOFLateral_NF
                                     * Referenced by: '<S16>/vehicle model'
                                     */
  real_T VehicleBody3DOFLateral_NR; /* Mask Parameter: VehicleBody3DOFLateral_NR
                                     * Referenced by: '<S16>/vehicle model'
                                     */
  real_T VehicleBody3DOFLateral_Pabs;
                                  /* Mask Parameter: VehicleBody3DOFLateral_Pabs
                                   * Referenced by: '<S30>/.5.*A.*Pabs.//R.//T'
                                   */
  real_T DragForce_R;                  /* Mask Parameter: DragForce_R
                                        * Referenced by: '<S30>/.5.*A.*Pabs.//R.//T'
                                        */
  real_T HardPointCoordinateTransformFro;
                              /* Mask Parameter: HardPointCoordinateTransformFro
                               * Referenced by: '<S38>/R_T2'
                               */
  real_T HardPointCoordinateTransformRea;
                              /* Mask Parameter: HardPointCoordinateTransformRea
                               * Referenced by: '<S40>/R_T2'
                               */
  real_T BehaviorPlanner_StartSpeed;
                                   /* Mask Parameter: BehaviorPlanner_StartSpeed
                                    * Referenced by: '<Root>/BehaviorPlanner'
                                    */
  real_T VehicleBody3DOFLateral_Tair;
                                  /* Mask Parameter: VehicleBody3DOFLateral_Tair
                                   * Referenced by: '<S16>/AirTempConstant'
                                   */
  real_T VehicleBody3DOFLateral_a;   /* Mask Parameter: VehicleBody3DOFLateral_a
                                      * Referenced by:
                                      *   '<S16>/vehicle model'
                                      *   '<S30>/Constant3'
                                      *   '<S38>/R_T1'
                                      */
  real_T VehicleBody3DOFLateral_b;   /* Mask Parameter: VehicleBody3DOFLateral_b
                                      * Referenced by:
                                      *   '<S16>/vehicle model'
                                      *   '<S30>/Constant3'
                                      *   '<S40>/R_T1'
                                      */
  real_T VehicleBody3DOFLateral_beta_w[31];
                                /* Mask Parameter: VehicleBody3DOFLateral_beta_w
                                 * Referenced by:
                                 *   '<S30>/Cs'
                                 *   '<S30>/Cym'
                                 */
  real_T VehicleBody3DOFLateral_g;   /* Mask Parameter: VehicleBody3DOFLateral_g
                                      * Referenced by: '<S16>/vehicle model'
                                      */
  real_T VehicleBody3DOFLateral_h;   /* Mask Parameter: VehicleBody3DOFLateral_h
                                      * Referenced by:
                                      *   '<S16>/vehicle model'
                                      *   '<S38>/R_T3'
                                      *   '<S40>/R_T3'
                                      */
  real_T VehicleBody3DOFLateral_latOff;
                                /* Mask Parameter: VehicleBody3DOFLateral_latOff
                                 * Referenced by: '<S39>/latOff'
                                 */
  real_T VehicleBody3DOFLateral_longOff;
                               /* Mask Parameter: VehicleBody3DOFLateral_longOff
                                * Referenced by: '<S39>/longOff'
                                */
  real_T VehicleBody3DOFLateral_m;   /* Mask Parameter: VehicleBody3DOFLateral_m
                                      * Referenced by: '<S16>/vehicle model'
                                      */
  real_T VehicleBody3DOFLateral_mu; /* Mask Parameter: VehicleBody3DOFLateral_mu
                                     * Referenced by: '<S82>/Constant'
                                     */
  real_T VehicleBody3DOFLateral_psi_o;
                                 /* Mask Parameter: VehicleBody3DOFLateral_psi_o
                                  * Referenced by: '<S16>/psi_oConstant'
                                  */
  real_T VehicleBody3DOFLateral_r_o;
                                   /* Mask Parameter: VehicleBody3DOFLateral_r_o
                                    * Referenced by: '<S16>/r_oConstant'
                                    */
  real_T VehicleBody3DOFLateral_vertOff;
                               /* Mask Parameter: VehicleBody3DOFLateral_vertOff
                                * Referenced by: '<S39>/vertOff'
                                */
  real_T VehicleBody3DOFLateral_xdot_tol;
                              /* Mask Parameter: VehicleBody3DOFLateral_xdot_tol
                               * Referenced by: '<S16>/vehicle model'
                               */
  real_T VehicleBody3DOFLateral_ydot_o;
                                /* Mask Parameter: VehicleBody3DOFLateral_ydot_o
                                 * Referenced by: '<S16>/ydot_oConstant'
                                 */
  struct_kJRa1iGO6f3jvSZ9QaEDZG ComparePath_costmapStruct;/* Expression: costmapStruct
                                                           * Referenced by: '<S5>/Compare Path'
                                                           */
  struct_rferERfyUA8TpTz2UpTSiD BehaviorPlanner_routePlanStruct[5];/* Expression: routePlanStruct
                                                                    * Referenced by: '<Root>/BehaviorPlanner'
                                                                    */
  struct_FKjU11iU2S4H4cpnH8MhqG ComparePath_vehicleDimsStruct;/* Expression: vehicleDimsStruct
                                                               * Referenced by: '<S5>/Compare Path'
                                                               */
  real_T VelocityProfiler_MaxSpeed;    /* Expression: 10
                                        * Referenced by: '<S3>/Velocity Profiler'
                                        */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S13>/Constant'
                                        */
  real_T Constant_Value_g;             /* Expression: 0
                                        * Referenced by: '<S14>/Constant'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S8>/Unit Delay'
                                        */
  real_T Constant_Value_l;             /* Expression: 0.05
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S8>/Constant1'
                                        */
  real_T Saturatedintegrator_IC;       /* Expression: 0
                                        * Referenced by: '<S8>/Saturated integrator'
                                        */
  real_T Saturatedintegrator_UpperSat; /* Expression: inf
                                        * Referenced by: '<S8>/Saturated integrator'
                                        */
  real_T Saturatedintegrator_LowerSat; /* Expression: 0
                                        * Referenced by: '<S8>/Saturated integrator'
                                        */
  real_T vehiclemodel_Fxtire_sat;      /* Expression: Fxtire_sat
                                        * Referenced by: '<S16>/vehicle model'
                                        */
  real_T vehiclemodel_Fytire_sat;      /* Expression: Fytire_sat
                                        * Referenced by: '<S16>/vehicle model'
                                        */
  real_T vehiclemodel_d;               /* Expression: d
                                        * Referenced by: '<S16>/vehicle model'
                                        */
  real_T vehiclemodel_w[2];            /* Expression: w
                                        * Referenced by: '<S16>/vehicle model'
                                        */
  real_T UnitDelay4_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S11>/Unit Delay4'
                                        */
  real_T UnitDelay5_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S11>/Unit Delay5'
                                        */
  real_T UnitDelay3_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S11>/Unit Delay3'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 1
                                        * Referenced by: '<S11>/Unit Delay1'
                                        */
  real_T Delay_A;                      /* Computed Parameter: Delay_A
                                        * Referenced by: '<S10>/Delay'
                                        */
  real_T Delay_C;                      /* Computed Parameter: Delay_C
                                        * Referenced by: '<S10>/Delay'
                                        */
  real_T Gain1_Gain;                   /* Expression: pi/180
                                        * Referenced by: '<S9>/Gain1'
                                        */
  real_T xdot_oConstant_Value;         /* Expression: 0
                                        * Referenced by: '<S16>/xdot_oConstant'
                                        */
  real_T Gain_Gain;                    /* Expression: 180/pi
                                        * Referenced by: '<S15>/Gain'
                                        */
  real_T Crm_tableData[2];             /* Expression: [0 0]
                                        * Referenced by: '<S30>/Crm'
                                        */
  real_T Crm_bp01Data[2];              /* Expression: [-1 1]
                                        * Referenced by: '<S30>/Crm'
                                        */
  real_T Constant4_Value[3];           /* Expression: ones(1,3)
                                        * Referenced by: '<S30>/Constant4'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S30>/Switch'
                                        */
  real_T Constant7_Value;              /* Expression: 0
                                        * Referenced by: '<S37>/Constant7'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S37>/Constant2'
                                        */
  real_T Constant_Value_i;             /* Expression: 0
                                        * Referenced by: '<S37>/Constant'
                                        */
  real_T Constant6_Value;              /* Expression: 0
                                        * Referenced by: '<S37>/Constant6'
                                        */
  real_T Constant4_Value_l;            /* Expression: 0
                                        * Referenced by: '<S37>/Constant4'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S37>/Constant5'
                                        */
  boolean_T UnitDelay_InitialCondition_a;
                             /* Computed Parameter: UnitDelay_InitialCondition_a
                              * Referenced by: '<S2>/Unit Delay'
                              */
};

/* Real-time Model Data Structure */
struct tag_RTM_AutomatedParkingValet_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_AutomatedParkingValet_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[8];
  real_T odeF[3][8];
  ODE3_IntgData intgData;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    rtwCAPI_ModelMappingInfo* childMMI[1];
  } DataMapInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    boolean_T firstInitCondFlag;
    struct {
      uint32_T TID[4];
    } TaskCounters;

    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[4];
  } Timing;
};

/* Block parameters (default storage) */
extern P_AutomatedParkingValet_T AutomatedParkingValet_P;

/* Block signals (default storage) */
extern B_AutomatedParkingValet_T AutomatedParkingValet_B;

/* Continuous states (default storage) */
extern X_AutomatedParkingValet_T AutomatedParkingValet_X;

/* Block states (default storage) */
extern DW_AutomatedParkingValet_T AutomatedParkingValet_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_AutomatedParkingValet_T AutomatedParkingValet_PrevZCX;

/* Model block global parameters (default storage) */
extern real_T rtP_startPose[3];        /* Variable: startPose
                                        * Referenced by:
                                        *   '<S11>/Unit Delay2'
                                        *   '<S16>/X_oConstant'
                                        *   '<S16>/Y_oConstant'
                                        */

/* Model entry point functions */
extern void AutomatedParkingValet_initialize(void);
extern void AutomatedParkingValet_step(void);
extern void AutomatedParkingValet_terminate(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  AutomatedParkingValet_GetCAPIStaticMap(void);

/* Real-time Model object */
extern RT_MODEL_AutomatedParkingVale_T *const AutomatedParkingValet_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'AutomatedParkingValet'
 * '<S1>'   : 'AutomatedParkingValet/BehaviorPlanner'
 * '<S2>'   : 'AutomatedParkingValet/Subsystem1'
 * '<S3>'   : 'AutomatedParkingValet/Trajectory Generation'
 * '<S4>'   : 'AutomatedParkingValet/Vehicle Model'
 * '<S5>'   : 'AutomatedParkingValet/Visualization'
 * '<S6>'   : 'AutomatedParkingValet/motionPlanning'
 * '<S7>'   : 'AutomatedParkingValet/Subsystem1/MATLAB Function'
 * '<S8>'   : 'AutomatedParkingValet/Vehicle Model/Acceleration to Velocity'
 * '<S9>'   : 'AutomatedParkingValet/Vehicle Model/Degrees to Radians'
 * '<S10>'  : 'AutomatedParkingValet/Vehicle Model/Delayed Steering System'
 * '<S11>'  : 'AutomatedParkingValet/Vehicle Model/Subsystem'
 * '<S12>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral'
 * '<S13>'  : 'AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Compare To Zero'
 * '<S14>'  : 'AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Compare To Zero1'
 * '<S15>'  : 'AutomatedParkingValet/Vehicle Model/Subsystem/Radians to Degrees'
 * '<S16>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track'
 * '<S17>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Cy'
 * '<S18>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag'
 * '<S19>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing'
 * '<S20>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/friction'
 * '<S21>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/front forces'
 * '<S22>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/front steer'
 * '<S23>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/rear forces'
 * '<S24>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/rear steer'
 * '<S25>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/sigma'
 * '<S26>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/state'
 * '<S27>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/vehicle model'
 * '<S28>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/wind'
 * '<S29>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Cy/Cy const'
 * '<S30>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force'
 * '<S31>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/inertial2body'
 * '<S32>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing'
 * '<S33>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Forces 3DOF'
 * '<S34>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF'
 * '<S35>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Moments'
 * '<S36>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power'
 * '<S37>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus'
 * '<S38>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front'
 * '<S39>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric'
 * '<S40>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear'
 * '<S41>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/Rotation Angles to Direction Cosine Matrix'
 * '<S42>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/transform to Inertial axes'
 * '<S43>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/transform to Inertial axes1'
 * '<S44>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/wxR'
 * '<S45>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S46>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/wxR/Subsystem'
 * '<S47>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front/wxR/Subsystem1'
 * '<S48>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta'
 * '<S49>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/Body Slip'
 * '<S50>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/Rotation Angles to Direction Cosine Matrix'
 * '<S51>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/transform to Inertial axes'
 * '<S52>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/transform to Inertial axes1'
 * '<S53>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/wxR'
 * '<S54>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/Body Slip/div0protect - abs poly'
 * '<S55>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/Body Slip/div0protect - abs poly/Compare To Constant'
 * '<S56>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/Body Slip/div0protect - abs poly/Compare To Constant1'
 * '<S57>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S58>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/wxR/Subsystem'
 * '<S59>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Geometric/Hard Point Coordinate Transform External Displacement Beta/wxR/Subsystem1'
 * '<S60>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/Rotation Angles to Direction Cosine Matrix'
 * '<S61>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/transform to Inertial axes'
 * '<S62>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/transform to Inertial axes1'
 * '<S63>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/wxR'
 * '<S64>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix'
 * '<S65>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/wxR/Subsystem'
 * '<S66>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/wxR/Subsystem1'
 * '<S67>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power/Power Accounting Bus Creator'
 * '<S68>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power/xdot mode'
 * '<S69>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power/Power Accounting Bus Creator/PwrNotTrnsfrd Input'
 * '<S70>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power/Power Accounting Bus Creator/PwrStored Input'
 * '<S71>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power/Power Accounting Bus Creator/PwrTrnsfrd Input'
 * '<S72>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Power/xdot mode/xdotin'
 * '<S73>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Angle Wrap'
 * '<S74>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Body Slip'
 * '<S75>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/COMB2I'
 * '<S76>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/xddot2ax'
 * '<S77>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Angle Wrap/None'
 * '<S78>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Body Slip/div0protect - abs poly'
 * '<S79>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Body Slip/div0protect - abs poly/Compare To Constant'
 * '<S80>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Body Slip/div0protect - abs poly/Compare To Constant1'
 * '<S81>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/xddot2ax/m^22gn'
 * '<S82>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/friction/mu int'
 * '<S83>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/front forces/int'
 * '<S84>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/front steer/delta ext'
 * '<S85>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/rear forces/int'
 * '<S86>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/rear steer/delta int'
 * '<S87>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/sigma/no sigma'
 * '<S88>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/state/xdot ext'
 * '<S89>'  : 'AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/wind/wind int'
 * '<S90>'  : 'AutomatedParkingValet/Visualization/Compare Path'
 */
#endif                                 /* RTW_HEADER_AutomatedParkingValet_h_ */
