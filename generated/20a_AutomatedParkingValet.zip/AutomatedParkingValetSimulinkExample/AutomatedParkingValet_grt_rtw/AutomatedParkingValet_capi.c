/*
 * AutomatedParkingValet_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:14:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "AutomatedParkingValet_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "AutomatedParkingValet.h"
#include "AutomatedParkingValet_capi.h"
#include "AutomatedParkingValet_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 2, TARGET_STRING("AutomatedParkingValet/BehaviorPlanner"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 1, 2, TARGET_STRING("AutomatedParkingValet/BehaviorPlanner"),
    TARGET_STRING(""), 2, 1, 1, 0, 0 },

  { 2, 2, TARGET_STRING("AutomatedParkingValet/BehaviorPlanner"),
    TARGET_STRING(""), 3, 2, 1, 0, 0 },

  { 3, 13, TARGET_STRING("AutomatedParkingValet/motionPlanning"),
    TARGET_STRING(""), 0, 0, 2, 0, 0 },

  { 4, 13, TARGET_STRING("AutomatedParkingValet/motionPlanning"),
    TARGET_STRING(""), 1, 0, 3, 0, 0 },

  { 5, 0, TARGET_STRING("AutomatedParkingValet/Vehicle Controller"),
    TARGET_STRING("SteerCmd"), 0, 0, 1, 0, 1 },

  { 6, 0, TARGET_STRING("AutomatedParkingValet/Vehicle Controller"),
    TARGET_STRING("AccelCmd"), 1, 0, 1, 0, 1 },

  { 7, 0, TARGET_STRING("AutomatedParkingValet/Vehicle Controller"),
    TARGET_STRING("DecelCmd"), 2, 0, 1, 0, 1 },

  { 8, 1, TARGET_STRING("AutomatedParkingValet/MATLAB System"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 9, 1, TARGET_STRING("AutomatedParkingValet/MATLAB System"),
    TARGET_STRING(""), 1, 0, 1, 0, 1 },

  { 10, 1, TARGET_STRING("AutomatedParkingValet/MATLAB System"),
    TARGET_STRING(""), 2, 0, 1, 0, 1 },

  { 11, 1, TARGET_STRING("AutomatedParkingValet/MATLAB System"),
    TARGET_STRING(""), 3, 0, 1, 0, 1 },

  { 12, 1, TARGET_STRING("AutomatedParkingValet/MATLAB System"),
    TARGET_STRING(""), 4, 0, 1, 0, 1 },

  { 13, 7, TARGET_STRING(
    "AutomatedParkingValet/Trajectory Generation/Path Smoother Spline"),
    TARGET_STRING(""), 0, 0, 4, 0, 0 },

  { 14, 7, TARGET_STRING(
    "AutomatedParkingValet/Trajectory Generation/Path Smoother Spline"),
    TARGET_STRING(""), 1, 0, 5, 0, 0 },

  { 15, 7, TARGET_STRING(
    "AutomatedParkingValet/Trajectory Generation/Path Smoother Spline"),
    TARGET_STRING(""), 3, 0, 6, 0, 0 },

  { 16, 6, TARGET_STRING(
    "AutomatedParkingValet/Trajectory Generation/Velocity Profiler"),
    TARGET_STRING(""), 0, 0, 7, 0, 0 },

  { 17, 9, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 18, 9, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/AND"),
    TARGET_STRING("Reset velocity to zero"), 0, 3, 1, 0, 3 },

  { 19, 9, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Add"),
    TARGET_STRING(""), 0, 0, 1, 0, 1 },

  { 20, 9, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Switch"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 21, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Delayed Steering System/Add"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 22, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Delayed Steering System/Delay"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 23, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Bus Creator"),
    TARGET_STRING(""), 0, 4, 1, 0, 1 },

  { 24, 9, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Compare To Zero1/Compare"),
    TARGET_STRING(""), 0, 3, 1, 0, 1 },

  { 25, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Radians to Degrees/Gain"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 26, 11, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/vehicle model"),
    TARGET_STRING(""), 7, 0, 8, 0, 2 },

  { 27, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 8, 0, 3 },

  { 28, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Vector Concatenate3"),
    TARGET_STRING(""), 0, 0, 9, 0, 3 },

  { 29, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/X_oConstant"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 30, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Y_oConstant"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 31, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/psi_oConstant"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 32, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/r_oConstant"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 33, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/xdot_oConstant"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 34, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/ydot_oConstant"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 35, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 10, 0, 2 },

  { 36, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Constant"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 37, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Constant1"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 38, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Crm"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 39, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Cs"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 40, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Cym"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 41, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Product5"),
    TARGET_STRING(""), 0, 0, 1, 0, 2 },

  { 42, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Unary Minus"),
    TARGET_STRING(""), 0, 0, 11, 0, 3 },

  { 43, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/friction/mu int/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 9, 0, 3 },

  { 44, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/front forces/int/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 9, 0, 3 },

  { 45, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/rear forces/int/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 9, 0, 3 },

  { 46, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/state/xdot ext/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 8, 0, 2 },

  { 47, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/state/xdot ext/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 8, 0, 2 },

  { 48, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/wind/wind int/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 11, 0, 3 },

  { 49, 10, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/COMB2I"),
    TARGET_STRING(""), 0, 0, 9, 0, 2 },

  { 50, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 11, 0, 3 },

  { 51, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/R_T1"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 52, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/R_T2"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 53, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/R_T3"),
    TARGET_STRING(""), 0, 0, 1, 0, 3 },

  { 54, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear/Add"),
    TARGET_STRING(""), 0, 0, 11, 0, 2 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 55, TARGET_STRING("AutomatedParkingValet/BehaviorPlanner"),
    TARGET_STRING("StartSpeed"), 0, 1, 0 },

  { 56, TARGET_STRING("AutomatedParkingValet/BehaviorPlanner"),
    TARGET_STRING("routePlanStruct"), 6, 13, 0 },

  { 57, TARGET_STRING("AutomatedParkingValet/Subsystem1/Unit Delay"),
    TARGET_STRING("InitialCondition"), 3, 1, 0 },

  { 58, TARGET_STRING("AutomatedParkingValet/Trajectory Generation/Velocity Profiler"),
    TARGET_STRING("MaxSpeed"), 0, 1, 0 },

  { 59, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("NF"), 0, 1, 0 },

  { 60, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("NR"), 0, 1, 0 },

  { 61, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("m"), 0, 1, 0 },

  { 62, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("a"), 0, 1, 0 },

  { 63, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("b"), 0, 1, 0 },

  { 64, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("h"), 0, 1, 0 },

  { 65, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cy_f"), 0, 1, 0 },

  { 66, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cy_r"), 0, 1, 0 },

  { 67, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("ydot_o"), 0, 1, 0 },

  { 68, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Izz"), 0, 1, 0 },

  { 69, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("psi_o"), 0, 1, 0 },

  { 70, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("r_o"), 0, 1, 0 },

  { 71, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Af"), 0, 1, 0 },

  { 72, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cd"), 0, 1, 0 },

  { 73, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cl"), 0, 1, 0 },

  { 74, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cpm"), 0, 1, 0 },

  { 75, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("beta_w"), 0, 14, 0 },

  { 76, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cs"), 0, 14, 0 },

  { 77, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Cym"), 0, 14, 0 },

  { 78, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Pabs"), 0, 1, 0 },

  { 79, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Tair"), 0, 1, 0 },

  { 80, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("g"), 0, 1, 0 },

  { 81, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("mu"), 0, 1, 0 },

  { 82, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("xdot_tol"), 0, 1, 0 },

  { 83, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("Fznom"), 0, 1, 0 },

  { 84, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("longOff"), 0, 1, 0 },

  { 85, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("latOff"), 0, 1, 0 },

  { 86, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral"),
    TARGET_STRING("vertOff"), 0, 1, 0 },

  { 87, TARGET_STRING("AutomatedParkingValet/Visualization/Compare Path"),
    TARGET_STRING("costmapStruct"), 8, 1, 0 },

  { 88, TARGET_STRING("AutomatedParkingValet/Visualization/Compare Path"),
    TARGET_STRING("vehicleDimsStruct"), 10, 1, 0 },

  { 89, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 90, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Constant1"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 91, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Saturated integrator"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 92, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Saturated integrator"),
    TARGET_STRING("UpperSaturationLimit"), 0, 1, 0 },

  { 93, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Saturated integrator"),
    TARGET_STRING("LowerSaturationLimit"), 0, 1, 0 },

  { 94, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 95, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Degrees to Radians/Gain1"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 96, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Delayed Steering System/Delay"),
    TARGET_STRING("A"), 0, 1, 0 },

  { 97, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Delayed Steering System/Delay"),
    TARGET_STRING("C"), 0, 1, 0 },

  { 98, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay1"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 99, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay3"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 100, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay4"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 101, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay5"),
    TARGET_STRING("InitialCondition"), 0, 1, 0 },

  { 102, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 103, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Compare To Zero1/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 104, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Subsystem/Radians to Degrees/Gain"),
    TARGET_STRING("Gain"), 0, 1, 0 },

  { 105, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/vehicle model"),
    TARGET_STRING("Fxtire_sat"), 0, 1, 0 },

  { 106, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/vehicle model"),
    TARGET_STRING("Fytire_sat"), 0, 1, 0 },

  { 107, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/vehicle model"),
    TARGET_STRING("d"), 0, 1, 0 },

  { 108, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/vehicle model"),
    TARGET_STRING("w"), 0, 19, 0 },

  { 109, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/xdot_oConstant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 110, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force"),
    TARGET_STRING("R"), 0, 1, 0 },

  { 111, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Constant4"),
    TARGET_STRING("Value"), 0, 20, 0 },

  { 112, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Crm"),
    TARGET_STRING("Table"), 0, 19, 0 },

  { 113, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Crm"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 19, 0 },

  { 114, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Drag/Drag Force/Switch"),
    TARGET_STRING("Threshold"), 0, 1, 0 },

  { 115, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Front"),
    TARGET_STRING("R_T2"), 0, 1, 0 },

  { 116, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/Lateral 3DOF/Hard Point Coordinate Transform Rear"),
    TARGET_STRING("R_T2"), 0, 1, 0 },

  { 117, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Constant"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 118, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Constant2"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 119, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Constant4"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 120, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Constant5"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 121, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Constant6"),
    TARGET_STRING("Value"), 0, 1, 0 },

  { 122, TARGET_STRING("AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Constant7"),
    TARGET_STRING("Value"), 0, 1, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static const rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 123, -1, TARGET_STRING("AutomatedParkingValet/Subsystem1/Unit Delay"),
    TARGET_STRING("DSTATE"), "", 0, 3, 1, 0, 0, 0, -1, 0 },

  { 124, 7, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Saturated integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 2, 1, -1, 0 },

  { 125, -1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Acceleration to Velocity/Unit Delay"),
    TARGET_STRING("DSTATE"), "", 0, 0, 1, 0, 3, 0, -1, 0 },

  { 126, 0, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Delayed Steering System/Delay"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 1, 0, 2, 1, -1, 0 },

  { 127, -1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay1"),
    TARGET_STRING("DSTATE"), "", 0, 0, 1, 0, 1, 0, -1, 0 },

  { 128, -1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay2"),
    TARGET_STRING("DSTATE"), "", 0, 0, 11, 0, 3, 0, -1, 0 },

  { 129, -1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay3"),
    TARGET_STRING("DSTATE"), "", 0, 0, 1, 0, 3, 0, -1, 0 },

  { 130, -1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay4"),
    TARGET_STRING("DSTATE"), "", 0, 0, 1, 0, 3, 0, -1, 0 },

  { 131, -1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Subsystem/Unit Delay5"),
    TARGET_STRING("DSTATE"), "", 0, 0, 1, 0, 3, 0, -1, 0 },

  { 132, 1, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/state/xdot ext/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 8, 0, 2, 1, -1, 0 },

  { 133, 5, TARGET_STRING(
    "AutomatedParkingValet/Vehicle Model/Vehicle Body 3DOF Lateral/Vehicle Body 3DOF Single Track/Signal Routing/Signal Routing/state2bus/Integrator"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 9, 0, 2, 1, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Root Inputs information */
static const rtwCAPI_Signals rtRootInputs[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

/* Root Outputs information */
static const rtwCAPI_Signals rtRootOutputs[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 134, TARGET_STRING("startPose"), 0, 20, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &AutomatedParkingValet_B.nextGoal[0],/* 0: Signal */
  &AutomatedParkingValet_B.motionPlannerConfig,/* 1: Signal */
  &AutomatedParkingValet_B.speedProfilerConfig,/* 2: Signal */
  &AutomatedParkingValet_B.refPoses[0],/* 3: Signal */
  &AutomatedParkingValet_B.directions[0],/* 4: Signal */
  &AutomatedParkingValet_B.SteerCmd,   /* 5: Signal */
  &AutomatedParkingValet_B.AccelCmd,   /* 6: Signal */
  &AutomatedParkingValet_B.DecelCmd,   /* 7: Signal */
  &AutomatedParkingValet_B.MATLABSystem_o1[0],/* 8: Signal */
  &AutomatedParkingValet_B.MATLABSystem_o2,/* 9: Signal */
  &AutomatedParkingValet_B.MATLABSystem_o3,/* 10: Signal */
  &AutomatedParkingValet_B.MATLABSystem_o4,/* 11: Signal */
  &AutomatedParkingValet_B.MATLABSystem_o5,/* 12: Signal */
  &AutomatedParkingValet_B.PathSmootherSpline_o1[0],/* 13: Signal */
  &AutomatedParkingValet_B.PathSmootherSpline_o2[0],/* 14: Signal */
  &AutomatedParkingValet_B.PathSmootherSpline_o4[0],/* 15: Signal */
  &AutomatedParkingValet_B.VelocityProfiler[0],/* 16: Signal */
  &AutomatedParkingValet_B.Switch,     /* 17: Signal */
  &AutomatedParkingValet_B.Resetvelocitytozero,/* 18: Signal */
  &AutomatedParkingValet_B.Add_n,      /* 19: Signal */
  &AutomatedParkingValet_B.Switch,     /* 20: Signal */
  &AutomatedParkingValet_B.Add,        /* 21: Signal */
  &AutomatedParkingValet_B.Delay,      /* 22: Signal */
  &AutomatedParkingValet_B.BusCreator, /* 23: Signal */
  &AutomatedParkingValet_B.Compare,    /* 24: Signal */
  &AutomatedParkingValet_B.Gain,       /* 25: Signal */
  &AutomatedParkingValet_B.stateDer[0],/* 26: Signal */
  &AutomatedParkingValet_B.VectorConcatenate[0],/* 27: Signal */
  &AutomatedParkingValet_B.VectorConcatenate3[0],/* 28: Signal */
  &AutomatedParkingValet_B.VectorConcatenate3[0],/* 29: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate3[0] + 1),/* 30: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate[0] + 2),/* 31: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate[0] + 3),/* 32: Signal */
  &AutomatedParkingValet_B.VectorConcatenate[0],/* 33: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate[0] + 1),/* 34: Signal */
  &AutomatedParkingValet_B.VectorConcatenate_m[0],/* 35: Signal */
  &AutomatedParkingValet_B.VectorConcatenate_m[0],/* 36: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_m[0] + 2),/* 37: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_m[0] + 3),/* 38: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_m[0] + 1),/* 39: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_m[0] + 5),/* 40: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_m[0] + 4),/* 41: Signal */
  &AutomatedParkingValet_B.UnaryMinus[0],/* 42: Signal */
  &AutomatedParkingValet_B.VectorConcatenate1_k[0],/* 43: Signal */
  &AutomatedParkingValet_B.VectorConcatenate1_g[0],/* 44: Signal */
  &AutomatedParkingValet_B.VectorConcatenate1_d[0],/* 45: Signal */
  &AutomatedParkingValet_B.VectorConcatenate_n[0],/* 46: Signal */
  &AutomatedParkingValet_B.VectorConcatenate1[0],/* 47: Signal */
  &AutomatedParkingValet_B.VectorConcatenate1_m[0],/* 48: Signal */
  &AutomatedParkingValet_B.y[0],       /* 49: Signal */
  &AutomatedParkingValet_B.VectorConcatenate_p[0],/* 50: Signal */
  &AutomatedParkingValet_B.VectorConcatenate_p[0],/* 51: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_p[0] + 1),/* 52: Signal */
  ( &AutomatedParkingValet_B.VectorConcatenate_p[0] + 2),/* 53: Signal */
  &AutomatedParkingValet_B.Add_c[0],   /* 54: Signal */
  &AutomatedParkingValet_P.BehaviorPlanner_StartSpeed,/* 55: Block Parameter */
  &AutomatedParkingValet_P.BehaviorPlanner_routePlanStruct[0],/* 56: Block Parameter */
  &AutomatedParkingValet_P.UnitDelay_InitialCondition_a,/* 57: Block Parameter */
  &AutomatedParkingValet_P.VelocityProfiler_MaxSpeed,/* 58: Block Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_NF,/* 59: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_NR,/* 60: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_m,/* 61: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_a,/* 62: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_b,/* 63: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_h,/* 64: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cy_f,/* 65: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cy_r,/* 66: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_ydot_o,/* 67: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Izz,/* 68: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_psi_o,/* 69: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_r_o,/* 70: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Af,/* 71: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cd,/* 72: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cl,/* 73: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cpm,/* 74: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_beta_w[0],/* 75: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cs[0],/* 76: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Cym[0],/* 77: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Pabs,/* 78: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Tair,/* 79: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_g,/* 80: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_mu,/* 81: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_xdot_tol,/* 82: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_Fznom,/* 83: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_longOff,/* 84: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_latOff,/* 85: Mask Parameter */
  &AutomatedParkingValet_P.VehicleBody3DOFLateral_vertOff,/* 86: Mask Parameter */
  &AutomatedParkingValet_P.ComparePath_costmapStruct,/* 87: Block Parameter */
  &AutomatedParkingValet_P.ComparePath_vehicleDimsStruct,/* 88: Block Parameter */
  &AutomatedParkingValet_P.Constant_Value_l,/* 89: Block Parameter */
  &AutomatedParkingValet_P.Constant1_Value,/* 90: Block Parameter */
  &AutomatedParkingValet_P.Saturatedintegrator_IC,/* 91: Block Parameter */
  &AutomatedParkingValet_P.Saturatedintegrator_UpperSat,/* 92: Block Parameter */
  &AutomatedParkingValet_P.Saturatedintegrator_LowerSat,/* 93: Block Parameter */
  &AutomatedParkingValet_P.UnitDelay_InitialCondition,/* 94: Block Parameter */
  &AutomatedParkingValet_P.Gain1_Gain, /* 95: Block Parameter */
  &AutomatedParkingValet_P.Delay_A,    /* 96: Block Parameter */
  &AutomatedParkingValet_P.Delay_C,    /* 97: Block Parameter */
  &AutomatedParkingValet_P.UnitDelay1_InitialCondition,/* 98: Block Parameter */
  &AutomatedParkingValet_P.UnitDelay3_InitialCondition,/* 99: Block Parameter */
  &AutomatedParkingValet_P.UnitDelay4_InitialCondition,/* 100: Block Parameter */
  &AutomatedParkingValet_P.UnitDelay5_InitialCondition,/* 101: Block Parameter */
  &AutomatedParkingValet_P.Constant_Value,/* 102: Block Parameter */
  &AutomatedParkingValet_P.Constant_Value_g,/* 103: Block Parameter */
  &AutomatedParkingValet_P.Gain_Gain,  /* 104: Block Parameter */
  &AutomatedParkingValet_P.vehiclemodel_Fxtire_sat,/* 105: Block Parameter */
  &AutomatedParkingValet_P.vehiclemodel_Fytire_sat,/* 106: Block Parameter */
  &AutomatedParkingValet_P.vehiclemodel_d,/* 107: Block Parameter */
  &AutomatedParkingValet_P.vehiclemodel_w[0],/* 108: Block Parameter */
  &AutomatedParkingValet_P.xdot_oConstant_Value,/* 109: Block Parameter */
  &AutomatedParkingValet_P.DragForce_R,/* 110: Mask Parameter */
  &AutomatedParkingValet_P.Constant4_Value[0],/* 111: Block Parameter */
  &AutomatedParkingValet_P.Crm_tableData[0],/* 112: Block Parameter */
  &AutomatedParkingValet_P.Crm_bp01Data[0],/* 113: Block Parameter */
  &AutomatedParkingValet_P.Switch_Threshold,/* 114: Block Parameter */
  &AutomatedParkingValet_P.HardPointCoordinateTransformFro,/* 115: Mask Parameter */
  &AutomatedParkingValet_P.HardPointCoordinateTransformRea,/* 116: Mask Parameter */
  &AutomatedParkingValet_P.Constant_Value_i,/* 117: Block Parameter */
  &AutomatedParkingValet_P.Constant2_Value,/* 118: Block Parameter */
  &AutomatedParkingValet_P.Constant4_Value_l,/* 119: Block Parameter */
  &AutomatedParkingValet_P.Constant5_Value,/* 120: Block Parameter */
  &AutomatedParkingValet_P.Constant6_Value,/* 121: Block Parameter */
  &AutomatedParkingValet_P.Constant7_Value,/* 122: Block Parameter */
  &AutomatedParkingValet_DW.UnitDelay_DSTATE_b,/* 123: Discrete State */
  &AutomatedParkingValet_X.Saturatedintegrator_CSTATE,/* 124: Continuous State */
  &AutomatedParkingValet_DW.UnitDelay_DSTATE,/* 125: Discrete State */
  &AutomatedParkingValet_X.Delay_CSTATE,/* 126: Continuous State */
  &AutomatedParkingValet_DW.UnitDelay1_DSTATE,/* 127: Discrete State */
  &AutomatedParkingValet_DW.UnitDelay2_DSTATE[0],/* 128: Discrete State */
  &AutomatedParkingValet_DW.UnitDelay3_DSTATE,/* 129: Discrete State */
  &AutomatedParkingValet_DW.UnitDelay4_DSTATE,/* 130: Discrete State */
  &AutomatedParkingValet_DW.UnitDelay5_DSTATE,/* 131: Discrete State */
  &AutomatedParkingValet_X.Integrator_CSTATE[0],/* 132: Continuous State */
  &AutomatedParkingValet_X.Integrator_CSTATE_l[0],/* 133: Continuous State */
  rtP_startPose,                       /* 134: Model Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL),
  &AutomatedParkingValet_DW.SFunction_DIMS2[0],
  &AutomatedParkingValet_DW.SFunction_DIMS3[0],
  &AutomatedParkingValet_DW.PathSmootherSpline_DIMS1[0],
  &AutomatedParkingValet_DW.PathSmootherSpline_DIMS2[0],
  &AutomatedParkingValet_DW.PathSmootherSpline_DIMS4[0],
  &AutomatedParkingValet_DW.VelocityProfiler_DIMS1[0]
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "struct", "plannerConfigBus", 4, 1, sizeof(plannerConfigBus), SS_STRUCT, 0,
    0, 0 },

  { "struct", "speedConfigBus", 3, 5, sizeof(speedConfigBus), SS_STRUCT, 0, 0, 0
  },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0, 0 },

  { "struct", "vehicleInfoBus", 5, 8, sizeof(vehicleInfoBus), SS_STRUCT, 0, 0, 0
  },

  { "struct", "struct_Z8uqU3ciwvx8VrHPOjtKVB", 4, 13, sizeof
    (struct_Z8uqU3ciwvx8VrHPOjtKVB), SS_STRUCT, 0, 0, 0 },

  { "struct", "struct_rferERfyUA8TpTz2UpTSiD", 3, 17, sizeof
    (struct_rferERfyUA8TpTz2UpTSiD), SS_STRUCT, 0, 0, 0 },

  { "float", "real32_T", 0, 0, sizeof(real32_T), SS_SINGLE, 0, 0, 0 },

  { "struct", "struct_kJRa1iGO6f3jvSZ9QaEDZG", 7, 20, sizeof
    (struct_kJRa1iGO6f3jvSZ9QaEDZG), SS_STRUCT, 0, 0, 0 },

  { "unsigned char", "uint8_T", 0, 0, sizeof(uint8_T), SS_UINT8, 0, 0, 0 },

  { "struct", "struct_FKjU11iU2S4H4cpnH8MhqG", 7, 27, sizeof
    (struct_FKjU11iU2S4H4cpnH8MhqG), SS_STRUCT, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },

  { "ConnectionDistance", rt_offsetof(plannerConfigBus, ConnectionDistance), 0,
    1, 0 },

  { "MinIterations", rt_offsetof(plannerConfigBus, MinIterations), 0, 1, 0 },

  { "GoalTolerance", rt_offsetof(plannerConfigBus, GoalTolerance), 0, 0, 0 },

  { "MinTurningRadius", rt_offsetof(plannerConfigBus, MinTurningRadius), 0, 1, 0
  },

  { "StartSpeed", rt_offsetof(speedConfigBus, StartSpeed), 0, 1, 0 },

  { "EndSpeed", rt_offsetof(speedConfigBus, EndSpeed), 0, 1, 0 },

  { "MaxSpeed", rt_offsetof(speedConfigBus, MaxSpeed), 0, 1, 0 },

  { "CurrPose", rt_offsetof(vehicleInfoBus, CurrPose), 0, 0, 0 },

  { "CurrVelocity", rt_offsetof(vehicleInfoBus, CurrVelocity), 0, 1, 0 },

  { "CurrYawRate", rt_offsetof(vehicleInfoBus, CurrYawRate), 0, 1, 0 },

  { "CurrSteer", rt_offsetof(vehicleInfoBus, CurrSteer), 0, 1, 0 },

  { "Direction", rt_offsetof(vehicleInfoBus, Direction), 0, 1, 0 },

  { "StopLine", rt_offsetof(struct_Z8uqU3ciwvx8VrHPOjtKVB, StopLine), 3, 12, 0 },

  { "TurnManeuver", rt_offsetof(struct_Z8uqU3ciwvx8VrHPOjtKVB, TurnManeuver), 3,
    12, 0 },

  { "MaxSpeed", rt_offsetof(struct_Z8uqU3ciwvx8VrHPOjtKVB, MaxSpeed), 0, 12, 0 },

  { "EndSpeed", rt_offsetof(struct_Z8uqU3ciwvx8VrHPOjtKVB, EndSpeed), 0, 12, 0 },

  { "StartPose", rt_offsetof(struct_rferERfyUA8TpTz2UpTSiD, StartPose), 0, 0, 0
  },

  { "EndPose", rt_offsetof(struct_rferERfyUA8TpTz2UpTSiD, EndPose), 0, 0, 0 },

  { "Attributes", rt_offsetof(struct_rferERfyUA8TpTz2UpTSiD, Attributes), 5, 12,
    0 },

  { "FreeThreshold", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG, FreeThreshold),
    0, 12, 0 },

  { "OccupiedThreshold", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG,
    OccupiedThreshold), 0, 12, 0 },

  { "CellSize", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG, CellSize), 0, 12, 0 },

  { "MapSize", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG, MapSize), 0, 15, 0 },

  { "MapExtent", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG, MapExtent), 0, 16, 0
  },

  { "InflationRadius", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG,
    InflationRadius), 0, 12, 0 },

  { "Costs", rt_offsetof(struct_kJRa1iGO6f3jvSZ9QaEDZG, Costs), 7, 17, 0 },

  { "Length", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, Length), 0, 12, 0 },

  { "Width", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, Width), 0, 12, 0 },

  { "Height", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, Height), 0, 12, 0 },

  { "Wheelbase", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, Wheelbase), 0, 12, 0
  },

  { "RearOverhang", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, RearOverhang), 0,
    12, 0 },

  { "FrontOverhang", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, FrontOverhang),
    0, 12, 0 },

  { "WorldUnits", rt_offsetof(struct_FKjU11iU2S4H4cpnH8MhqG, WorldUnits), 9, 18,
    0 }
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_MATRIX_COL_MAJOR, 0, 2, 0 },

  { rtwCAPI_SCALAR, 2, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 4, 2, 1 },

  { rtwCAPI_MATRIX_COL_MAJOR, 6, 2, 2 },

  { rtwCAPI_MATRIX_COL_MAJOR, 8, 2, 3 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 4 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 5 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 6 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_VECTOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 20, 2, 0 },

  { rtwCAPI_VECTOR, 22, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 24, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 26, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 28, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 30, 2, 0 },

  { rtwCAPI_VECTOR, 24, 2, 0 },

  { rtwCAPI_VECTOR, 0, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  3,                                   /* 1 */
  1,                                   /* 2 */
  1,                                   /* 3 */
  100,                                 /* 4 */
  3,                                   /* 5 */
  100,                                 /* 6 */
  1,                                   /* 7 */
  500,                                 /* 8 */
  3,                                   /* 9 */
  500,                                 /* 10 */
  1,                                   /* 11 */
  4,                                   /* 12 */
  1,                                   /* 13 */
  2,                                   /* 14 */
  1,                                   /* 15 */
  6,                                   /* 16 */
  1,                                   /* 17 */
  3,                                   /* 18 */
  1,                                   /* 19 */
  5,                                   /* 20 */
  1,                                   /* 21 */
  1,                                   /* 22 */
  31,                                  /* 23 */
  1,                                   /* 24 */
  2,                                   /* 25 */
  1,                                   /* 26 */
  4,                                   /* 27 */
  100,                                 /* 28 */
  150,                                 /* 29 */
  1,                                   /* 30 */
  6                                    /* 31 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.1, 0.0, 0.05, 0.001
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    3, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[1],
    2, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[1],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[3], (const void *) &rtcapiStoredFloats[1],
    1, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 55,
    rtRootInputs, 0,
    rtRootOutputs, 0 },

  { rtBlockParameters, 68,
    rtModelParameters, 1 },

  { rtBlockStates, 11 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 3684762126U,
    2137356678U,
    769623674U,
    4123415864U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  AutomatedParkingValet_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void AutomatedParkingValet_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(AutomatedParkingValet_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(AutomatedParkingValet_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(AutomatedParkingValet_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(AutomatedParkingValet_M->DataMapInfo.mmi,
    rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(AutomatedParkingValet_M->DataMapInfo.mmi,
    rtVarDimsAddrMap);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(AutomatedParkingValet_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(AutomatedParkingValet_M->DataMapInfo.mmi,
    AutomatedParkingValet_M->DataMapInfo.childMMI);
  rtwCAPI_SetChildMMIArrayLen(AutomatedParkingValet_M->DataMapInfo.mmi, 1);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void AutomatedParkingValet_host_InitializeDataMapInfo
    (AutomatedParkingValet_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    dataMap->childMMI[0] = &(dataMap->child0.mmi);
    StanleyRefMdl_host_InitializeDataMapInfo(&(dataMap->child0),
      "AutomatedParkingValet/Vehicle Controller");
    rtwCAPI_SetChildMMIArray(dataMap->mmi, dataMap->childMMI);
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 1);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: AutomatedParkingValet_capi.c */
