/*
 * AutomatedParkingValet_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:14:47 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_AutomatedParkingValet_types_h_
#define RTW_HEADER_AutomatedParkingValet_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_plannerConfigBus_
#define DEFINED_TYPEDEF_FOR_plannerConfigBus_

typedef struct {
  real_T ConnectionDistance;
  real_T MinIterations;
  real_T GoalTolerance[3];
  real_T MinTurningRadius;
} plannerConfigBus;

#endif

#ifndef DEFINED_TYPEDEF_FOR_speedConfigBus_
#define DEFINED_TYPEDEF_FOR_speedConfigBus_

typedef struct {
  real_T StartSpeed;
  real_T EndSpeed;
  real_T MaxSpeed;
} speedConfigBus;

#endif

#ifndef DEFINED_TYPEDEF_FOR_vehicleInfoBus_
#define DEFINED_TYPEDEF_FOR_vehicleInfoBus_

typedef struct {
  real_T CurrPose[3];
  real_T CurrVelocity;
  real_T CurrYawRate;
  real_T CurrSteer;
  real_T Direction;
} vehicleInfoBus;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Z8uqU3ciwvx8VrHPOjtKVB_
#define DEFINED_TYPEDEF_FOR_struct_Z8uqU3ciwvx8VrHPOjtKVB_

typedef struct {
  boolean_T StopLine;
  boolean_T TurnManeuver;
  real_T MaxSpeed;
  real_T EndSpeed;
} struct_Z8uqU3ciwvx8VrHPOjtKVB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_rferERfyUA8TpTz2UpTSiD_
#define DEFINED_TYPEDEF_FOR_struct_rferERfyUA8TpTz2UpTSiD_

typedef struct {
  real_T StartPose[3];
  real_T EndPose[3];
  struct_Z8uqU3ciwvx8VrHPOjtKVB Attributes;
} struct_rferERfyUA8TpTz2UpTSiD;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_kJRa1iGO6f3jvSZ9QaEDZG_
#define DEFINED_TYPEDEF_FOR_struct_kJRa1iGO6f3jvSZ9QaEDZG_

typedef struct {
  real_T FreeThreshold;
  real_T OccupiedThreshold;
  real_T CellSize;
  real_T MapSize[2];
  real_T MapExtent[4];
  real_T InflationRadius;
  real32_T Costs[15000];
} struct_kJRa1iGO6f3jvSZ9QaEDZG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_FKjU11iU2S4H4cpnH8MhqG_
#define DEFINED_TYPEDEF_FOR_struct_FKjU11iU2S4H4cpnH8MhqG_

typedef struct {
  real_T Length;
  real_T Width;
  real_T Height;
  real_T Wheelbase;
  real_T RearOverhang;
  real_T FrontOverhang;
  uint8_T WorldUnits[6];
} struct_FKjU11iU2S4H4cpnH8MhqG;

#endif

/* Custom Type definition for MATLAB Function: '<Root>/motionPlanning' */
#ifndef struct_tag_4bTbSulEo3Iysn4yjY4Ow
#define struct_tag_4bTbSulEo3Iysn4yjY4Ow

struct tag_4bTbSulEo3Iysn4yjY4Ow
{
  real_T ConnectionDistance;
  real_T NumSteps;
  real_T TurningRadius;
};

#endif                                 /*struct_tag_4bTbSulEo3Iysn4yjY4Ow*/

#ifndef typedef_c_matlabshared_planning_inter_T
#define typedef_c_matlabshared_planning_inter_T

typedef struct tag_4bTbSulEo3Iysn4yjY4Ow c_matlabshared_planning_inter_T;

#endif                               /*typedef_c_matlabshared_planning_inter_T*/

#ifndef struct_tag_R5KbmAufkvZFvfkEuzsQHG
#define struct_tag_R5KbmAufkvZFvfkEuzsQHG

struct tag_R5KbmAufkvZFvfkEuzsQHG
{
  c_matlabshared_planning_inter_T *ConnectionMechanism;
  real_T Offset;
};

#endif                                 /*struct_tag_R5KbmAufkvZFvfkEuzsQHG*/

#ifndef typedef_d_matlabshared_planning_inter_T
#define typedef_d_matlabshared_planning_inter_T

typedef struct tag_R5KbmAufkvZFvfkEuzsQHG d_matlabshared_planning_inter_T;

#endif                               /*typedef_d_matlabshared_planning_inter_T*/

#ifndef struct_emxArray_real_T_100x3
#define struct_emxArray_real_T_100x3

struct emxArray_real_T_100x3
{
  real_T data[300];
  int32_T size[2];
};

#endif                                 /*struct_emxArray_real_T_100x3*/

#ifndef typedef_emxArray_real_T_100x3_Automat_T
#define typedef_emxArray_real_T_100x3_Automat_T

typedef struct emxArray_real_T_100x3 emxArray_real_T_100x3_Automat_T;

#endif                               /*typedef_emxArray_real_T_100x3_Automat_T*/

#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T

struct emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_real_T*/

#ifndef typedef_emxArray_real_T_AutomatedPark_T
#define typedef_emxArray_real_T_AutomatedPark_T

typedef struct emxArray_real_T emxArray_real_T_AutomatedPark_T;

#endif                               /*typedef_emxArray_real_T_AutomatedPark_T*/

#ifndef struct_emxArray_real_T_100x1
#define struct_emxArray_real_T_100x1

struct emxArray_real_T_100x1
{
  real_T data[100];
  int32_T size[2];
};

#endif                                 /*struct_emxArray_real_T_100x1*/

#ifndef typedef_emxArray_real_T_100x1_Automat_T
#define typedef_emxArray_real_T_100x1_Automat_T

typedef struct emxArray_real_T_100x1 emxArray_real_T_100x1_Automat_T;

#endif                               /*typedef_emxArray_real_T_100x1_Automat_T*/

#ifndef struct_emxArray_boolean_T
#define struct_emxArray_boolean_T

struct emxArray_boolean_T
{
  boolean_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_boolean_T*/

#ifndef typedef_emxArray_boolean_T_AutomatedP_T
#define typedef_emxArray_boolean_T_AutomatedP_T

typedef struct emxArray_boolean_T emxArray_boolean_T_AutomatedP_T;

#endif                               /*typedef_emxArray_boolean_T_AutomatedP_T*/

#ifndef struct_emxArray_int32_T
#define struct_emxArray_int32_T

struct emxArray_int32_T
{
  int32_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_int32_T*/

#ifndef typedef_emxArray_int32_T_AutomatedPar_T
#define typedef_emxArray_int32_T_AutomatedPar_T

typedef struct emxArray_int32_T emxArray_int32_T_AutomatedPar_T;

#endif                               /*typedef_emxArray_int32_T_AutomatedPar_T*/

#ifndef struct_emxArray_uint32_T
#define struct_emxArray_uint32_T

struct emxArray_uint32_T
{
  uint32_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_uint32_T*/

#ifndef typedef_emxArray_uint32_T_AutomatedPa_T
#define typedef_emxArray_uint32_T_AutomatedPa_T

typedef struct emxArray_uint32_T emxArray_uint32_T_AutomatedPa_T;

#endif                               /*typedef_emxArray_uint32_T_AutomatedPa_T*/

#ifndef struct_tag_PMfBDzoakfdM9QAdfx2o6D
#define struct_tag_PMfBDzoakfdM9QAdfx2o6D

struct tag_PMfBDzoakfdM9QAdfx2o6D
{
  uint32_T f1[8];
};

#endif                                 /*struct_tag_PMfBDzoakfdM9QAdfx2o6D*/

#ifndef typedef_cell_wrap_AutomatedParkingVal_T
#define typedef_cell_wrap_AutomatedParkingVal_T

typedef struct tag_PMfBDzoakfdM9QAdfx2o6D cell_wrap_AutomatedParkingVal_T;

#endif                               /*typedef_cell_wrap_AutomatedParkingVal_T*/

#ifndef struct_tag_IWIrDYT7LyB4jOsXgKrpNG
#define struct_tag_IWIrDYT7LyB4jOsXgKrpNG

struct tag_IWIrDYT7LyB4jOsXgKrpNG
{
  boolean_T tunablePropertyChanged[4];
  int32_T isInitialized;
  boolean_T TunablePropsChanged;
  cell_wrap_AutomatedParkingVal_T inputVarSize[6];
  boolean_T CacheInputSizes;
  real_T ClosestPointIndex;
  real_T NumPathSegments;
  real_T CurrentSegmentIndex;
  emxArray_real_T_AutomatedPark_T *SegmentStartIndex;
  emxArray_real_T_AutomatedPark_T *SegmentEndIndex;
  emxArray_real_T_AutomatedPark_T *RefPosesInternal;
  emxArray_real_T_AutomatedPark_T *DirectionsInternal;
  emxArray_real_T_AutomatedPark_T *CurvaturesInternal;
  emxArray_real_T_AutomatedPark_T *VelocityProfileInternal;
  real_T LastRefPoseOutput[3];
  real_T LastRefVelocityOutput;
  real_T LastCurvatureOutput;
  real_T LastDirectionOutput;
};

#endif                                 /*struct_tag_IWIrDYT7LyB4jOsXgKrpNG*/

#ifndef typedef_HelperPathAnalyzer_AutomatedP_T
#define typedef_HelperPathAnalyzer_AutomatedP_T

typedef struct tag_IWIrDYT7LyB4jOsXgKrpNG HelperPathAnalyzer_AutomatedP_T;

#endif                               /*typedef_HelperPathAnalyzer_AutomatedP_T*/

/* Custom Type definition for MATLAB Function: '<Root>/BehaviorPlanner' */
#ifndef struct_tag_s4Osf6W5BpyvZGijeirsFz
#define struct_tag_s4Osf6W5BpyvZGijeirsFz

struct tag_s4Osf6W5BpyvZGijeirsFz
{
  real_T ConnectionDistance;
  real_T MinIterations;
  real_T GoalTolerance[3];
  real_T MinTurningRadius;
  boolean_T IsParkManeuver;
};

#endif                                 /*struct_tag_s4Osf6W5BpyvZGijeirsFz*/

#ifndef typedef_s4Osf6W5BpyvZGijeirsFz_Automa_T
#define typedef_s4Osf6W5BpyvZGijeirsFz_Automa_T

typedef struct tag_s4Osf6W5BpyvZGijeirsFz s4Osf6W5BpyvZGijeirsFz_Automa_T;

#endif                               /*typedef_s4Osf6W5BpyvZGijeirsFz_Automa_T*/

#ifndef struct_tag_JalWXubp9KnhtGCdffL7dF
#define struct_tag_JalWXubp9KnhtGCdffL7dF

struct tag_JalWXubp9KnhtGCdffL7dF
{
  struct_rferERfyUA8TpTz2UpTSiD RoutePlan[5];
  real_T GoalIndex;
};

#endif                                 /*struct_tag_JalWXubp9KnhtGCdffL7dF*/

#ifndef typedef_HelperBehavioralPlanner_Autom_T
#define typedef_HelperBehavioralPlanner_Autom_T

typedef struct tag_JalWXubp9KnhtGCdffL7dF HelperBehavioralPlanner_Autom_T;

#endif                               /*typedef_HelperBehavioralPlanner_Autom_T*/

#ifndef struct_tag_Qvv3hTS7QLycpStLi8gBfC
#define struct_tag_Qvv3hTS7QLycpStLi8gBfC

struct tag_Qvv3hTS7QLycpStLi8gBfC
{
  int32_T isInitialized;
  cell_wrap_AutomatedParkingVal_T inputVarSize[5];
  boolean_T CacheInputSizes;
  real_T MaxSpeed;
  emxArray_real_T_AutomatedPark_T *LastVelocities;
  real_T LastStartVelocity;
  real_T LastEndVelocity;
  emxArray_real_T_AutomatedPark_T *LastCumLengths;
  emxArray_real_T_AutomatedPark_T *LastCurvatures;
  emxArray_real_T_AutomatedPark_T *LastDirections;
};

#endif                                 /*struct_tag_Qvv3hTS7QLycpStLi8gBfC*/

#ifndef typedef_driving_internal_planning_Vel_T
#define typedef_driving_internal_planning_Vel_T

typedef struct tag_Qvv3hTS7QLycpStLi8gBfC driving_internal_planning_Vel_T;

#endif                               /*typedef_driving_internal_planning_Vel_T*/

#ifndef struct_tag_PCA1IC1b55IoA886DSrkXB
#define struct_tag_PCA1IC1b55IoA886DSrkXB

struct tag_PCA1IC1b55IoA886DSrkXB
{
  int32_T isInitialized;
  cell_wrap_AutomatedParkingVal_T inputVarSize[2];
  boolean_T CacheInputSizes;
  emxArray_real_T_AutomatedPark_T *RefPosesInternal;
  emxArray_real_T_AutomatedPark_T *RefDirectionsInternal;
  real_T LastPosesOutput[1500];
  real_T LastDirectionsOutput[500];
  real_T LastCumLengthsOutput[500];
  real_T LastCurvaturesOutput[500];
};

#endif                                 /*struct_tag_PCA1IC1b55IoA886DSrkXB*/

#ifndef typedef_driving_internal_planning_Pat_T
#define typedef_driving_internal_planning_Pat_T

typedef struct tag_PCA1IC1b55IoA886DSrkXB driving_internal_planning_Pat_T;

#endif                               /*typedef_driving_internal_planning_Pat_T*/

/* Custom Type definition for MATLAB Function: '<Root>/motionPlanning' */
#ifndef struct_tag_MoNAvqUu4uu2kWQeckaczB
#define struct_tag_MoNAvqUu4uu2kWQeckaczB

struct tag_MoNAvqUu4uu2kWQeckaczB
{
  char_T f1[3];
};

#endif                                 /*struct_tag_MoNAvqUu4uu2kWQeckaczB*/

#ifndef typedef_cell_wrap_38_AutomatedParking_T
#define typedef_cell_wrap_38_AutomatedParking_T

typedef struct tag_MoNAvqUu4uu2kWQeckaczB cell_wrap_38_AutomatedParking_T;

#endif                               /*typedef_cell_wrap_38_AutomatedParking_T*/

#ifndef struct_tag_A7fn6GojmjPrArvmh1X8sG
#define struct_tag_A7fn6GojmjPrArvmh1X8sG

struct tag_A7fn6GojmjPrArvmh1X8sG
{
  real32_T Costmap[15000];
  boolean_T OccupiedMap[15000];
  boolean_T FreeMap[15000];
  real_T MapLocation[2];
  real_T CollisionCheckOffsets[4];
  real_T pFreeThreshold;
  real_T pOccupiedThreshold;
};

#endif                                 /*struct_tag_A7fn6GojmjPrArvmh1X8sG*/

#ifndef typedef_c_driving_internal_costmap_Ve_T
#define typedef_c_driving_internal_costmap_Ve_T

typedef struct tag_A7fn6GojmjPrArvmh1X8sG c_driving_internal_costmap_Ve_T;

#endif                               /*typedef_c_driving_internal_costmap_Ve_T*/

#ifndef struct_tag_VFAqICV9AeI5GCFZwJjLFF
#define struct_tag_VFAqICV9AeI5GCFZwJjLFF

struct tag_VFAqICV9AeI5GCFZwJjLFF
{
  real_T PoseBuffer[15000];
  real_T PoseIndex;
  real_T GoalBiasBuffer[5000];
  real_T GoalBiasIndex;
  real_T LowerLimits[3];
  real_T UpperLimits[3];
  c_driving_internal_costmap_Ve_T *Costmap;
  boolean_T CollisionFree[5000];
};

#endif                                 /*struct_tag_VFAqICV9AeI5GCFZwJjLFF*/

#ifndef typedef_e_matlabshared_planning_inter_T
#define typedef_e_matlabshared_planning_inter_T

typedef struct tag_VFAqICV9AeI5GCFZwJjLFF e_matlabshared_planning_inter_T;

#endif                               /*typedef_e_matlabshared_planning_inter_T*/

#ifndef struct_tag_wImMhIqgid9rcqvmW8dgJC
#define struct_tag_wImMhIqgid9rcqvmW8dgJC

struct tag_wImMhIqgid9rcqvmW8dgJC
{
  d_matlabshared_planning_inter_T *NeighborSearcher;
  real_T NodeBuffer[30003];
  real_T NodeIndex;
  uint32_T EdgeBuffer[20002];
  real_T EdgeIndex;
  real_T CostBuffer[10001];
};

#endif                                 /*struct_tag_wImMhIqgid9rcqvmW8dgJC*/

#ifndef typedef_f_matlabshared_planning_inter_T
#define typedef_f_matlabshared_planning_inter_T

typedef struct tag_wImMhIqgid9rcqvmW8dgJC f_matlabshared_planning_inter_T;

#endif                               /*typedef_f_matlabshared_planning_inter_T*/

#ifndef struct_tag_bAaBOvF95g6Hq4Ed1rOWyC
#define struct_tag_bAaBOvF95g6Hq4Ed1rOWyC

struct tag_bAaBOvF95g6Hq4Ed1rOWyC
{
  c_driving_internal_costmap_Ve_T *Costmap;
  c_matlabshared_planning_inter_T *ConnectionMechanism;
  e_matlabshared_planning_inter_T Sampler;
  f_matlabshared_planning_inter_T Tree;
  real_T StartPose[3];
  real_T GoalPose[3];
  real_T GoalTolerance[3];
  real_T GoalBias;
  real_T MinIterations;
  real_T MaxIterations;
};

#endif                                 /*struct_tag_bAaBOvF95g6Hq4Ed1rOWyC*/

#ifndef typedef_g_matlabshared_planning_inter_T
#define typedef_g_matlabshared_planning_inter_T

typedef struct tag_bAaBOvF95g6Hq4Ed1rOWyC g_matlabshared_planning_inter_T;

#endif                               /*typedef_g_matlabshared_planning_inter_T*/

#ifndef struct_tag_yYGOlp2B4Vvg0jZN1mm1LF
#define struct_tag_yYGOlp2B4Vvg0jZN1mm1LF

struct tag_yYGOlp2B4Vvg0jZN1mm1LF
{
  real_T StartPoseInternal[3];
  real_T GoalPoseInternal[3];
  real_T MinTurningRadius;
  real_T MotionLengths[3];
  char_T MotionTypes[3];
};

#endif                                 /*struct_tag_yYGOlp2B4Vvg0jZN1mm1LF*/

#ifndef typedef_c_driving_internal_planning_D_T
#define typedef_c_driving_internal_planning_D_T

typedef struct tag_yYGOlp2B4Vvg0jZN1mm1LF c_driving_internal_planning_D_T;

#endif                               /*typedef_c_driving_internal_planning_D_T*/

#ifndef struct_emxArray_tag_yYGOlp2B4Vvg0jZN1m
#define struct_emxArray_tag_yYGOlp2B4Vvg0jZN1m

struct emxArray_tag_yYGOlp2B4Vvg0jZN1m
{
  c_driving_internal_planning_D_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                /*struct_emxArray_tag_yYGOlp2B4Vvg0jZN1m*/

#ifndef typedef_emxArray_c_driving_internal_p_T
#define typedef_emxArray_c_driving_internal_p_T

typedef struct emxArray_tag_yYGOlp2B4Vvg0jZN1m emxArray_c_driving_internal_p_T;

#endif                               /*typedef_emxArray_c_driving_internal_p_T*/

/* Custom Type definition for MATLAB Function: '<Root>/motionPlanning' */
#ifndef struct_tag_PKZHW5HLIyXM4X7GZaeYeE
#define struct_tag_PKZHW5HLIyXM4X7GZaeYeE

struct tag_PKZHW5HLIyXM4X7GZaeYeE
{
  emxArray_c_driving_internal_p_T *Data;
};

#endif                                 /*struct_tag_PKZHW5HLIyXM4X7GZaeYeE*/

#ifndef typedef_d_driving_internal_planning_D_T
#define typedef_d_driving_internal_planning_D_T

typedef struct tag_PKZHW5HLIyXM4X7GZaeYeE d_driving_internal_planning_D_T;

#endif                               /*typedef_d_driving_internal_planning_D_T*/

#ifndef struct_tag_Wf9ocLN39j426gi1WawKcF
#define struct_tag_Wf9ocLN39j426gi1WawKcF

struct tag_Wf9ocLN39j426gi1WawKcF
{
  d_driving_internal_planning_D_T PathSegments;
};

#endif                                 /*struct_tag_Wf9ocLN39j426gi1WawKcF*/

#ifndef typedef_driving_Path_AutomatedParking_T
#define typedef_driving_Path_AutomatedParking_T

typedef struct tag_Wf9ocLN39j426gi1WawKcF driving_Path_AutomatedParking_T;

#endif                               /*typedef_driving_Path_AutomatedParking_T*/

#ifndef struct_tag_24hIJfbHi8dq5mm7uqnscD
#define struct_tag_24hIJfbHi8dq5mm7uqnscD

struct tag_24hIJfbHi8dq5mm7uqnscD
{
  c_driving_internal_costmap_Ve_T *Costmap;
  g_matlabshared_planning_inter_T InternalPlanner;
  driving_Path_AutomatedParking_T Path;
};

#endif                                 /*struct_tag_24hIJfbHi8dq5mm7uqnscD*/

#ifndef typedef_pathPlannerRRT_AutomatedParki_T
#define typedef_pathPlannerRRT_AutomatedParki_T

typedef struct tag_24hIJfbHi8dq5mm7uqnscD pathPlannerRRT_AutomatedParki_T;

#endif                               /*typedef_pathPlannerRRT_AutomatedParki_T*/

#ifndef struct_emxArray_tag_MoNAvqUu4uu2kWQeck
#define struct_emxArray_tag_MoNAvqUu4uu2kWQeck

struct emxArray_tag_MoNAvqUu4uu2kWQeck
{
  cell_wrap_38_AutomatedParking_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                /*struct_emxArray_tag_MoNAvqUu4uu2kWQeck*/

#ifndef typedef_emxArray_cell_wrap_38_Automat_T
#define typedef_emxArray_cell_wrap_38_Automat_T

typedef struct emxArray_tag_MoNAvqUu4uu2kWQeck emxArray_cell_wrap_38_Automat_T;

#endif                               /*typedef_emxArray_cell_wrap_38_Automat_T*/

/* Custom Type definition for MATLAB Function: '<Root>/motionPlanning' */
#ifndef struct_tag_gI8IjDc0xm9ykKgw8MPtcC
#define struct_tag_gI8IjDc0xm9ykKgw8MPtcC

struct tag_gI8IjDc0xm9ykKgw8MPtcC
{
  real_T MinTurningRadius;
  emxArray_cell_wrap_38_Automat_T *DisabledPathTypesInternal;
};

#endif                                 /*struct_tag_gI8IjDc0xm9ykKgw8MPtcC*/

#ifndef typedef_e_driving_internal_planning_D_T
#define typedef_e_driving_internal_planning_D_T

typedef struct tag_gI8IjDc0xm9ykKgw8MPtcC e_driving_internal_planning_D_T;

#endif                               /*typedef_e_driving_internal_planning_D_T*/

#ifndef struct_emxArray_real_T_100
#define struct_emxArray_real_T_100

struct emxArray_real_T_100
{
  real_T data[100];
  int32_T size;
};

#endif                                 /*struct_emxArray_real_T_100*/

#ifndef typedef_emxArray_real_T_100_Automated_T
#define typedef_emxArray_real_T_100_Automated_T

typedef struct emxArray_real_T_100 emxArray_real_T_100_Automated_T;

#endif                               /*typedef_emxArray_real_T_100_Automated_T*/

#ifndef struct_emxArray_real_T_1x1
#define struct_emxArray_real_T_1x1

struct emxArray_real_T_1x1
{
  real_T data;
  int32_T size[2];
};

#endif                                 /*struct_emxArray_real_T_1x1*/

#ifndef typedef_emxArray_real_T_1x1_Automated_T
#define typedef_emxArray_real_T_1x1_Automated_T

typedef struct emxArray_real_T_1x1 emxArray_real_T_1x1_Automated_T;

#endif                               /*typedef_emxArray_real_T_1x1_Automated_T*/

/* Parameters (default storage) */
typedef struct P_AutomatedParkingValet_T_ P_AutomatedParkingValet_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_AutomatedParkingValet_T RT_MODEL_AutomatedParkingVale_T;

#endif                           /* RTW_HEADER_AutomatedParkingValet_types_h_ */
