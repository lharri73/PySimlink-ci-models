/*
 * Code generation for system model 'StanleyRefMdl'
 *
 * Model                      : StanleyRefMdl
 * Model version              : 1.948
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:13:52 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "StanleyRefMdl_capi.h"
#include "StanleyRefMdl.h"
#include "StanleyRefMdl_private.h"
#include "angleUtilities_wrapTo2_bbViJ3IV.h"

P_StanleyRefMdl_T StanleyRefMdl_P = {
  /* Mask Parameter: LateralControllerStanley_DelayG
   * Referenced by: '<S6>/Gain2'
   */
  0.2,

  /* Mask Parameter: PIForward_InitialConditionForIn
   * Referenced by: '<S45>/Integrator'
   */
  0.0,

  /* Mask Parameter: PIReverse_InitialConditionForIn
   * Referenced by: '<S94>/Integrator'
   */
  0.0,

  /* Mask Parameter: LongitudinalControllerStanley_K
   * Referenced by:
   *   '<S42>/Integral Gain'
   *   '<S91>/Integral Gain'
   */
  1.0,

  /* Mask Parameter: LongitudinalControllerStanley_d
   * Referenced by:
   *   '<S50>/Proportional Gain'
   *   '<S99>/Proportional Gain'
   */
  2.5,

  /* Mask Parameter: PIForward_LowerSaturationLimit
   * Referenced by:
   *   '<S38>/DeadZone'
   *   '<S52>/Saturation'
   */
  -6.0,

  /* Mask Parameter: PIReverse_LowerSaturationLimit
   * Referenced by:
   *   '<S87>/DeadZone'
   *   '<S101>/Saturation'
   */
  -3.0,

  /* Mask Parameter: LateralControllerStanley_Positi
   * Referenced by: '<S1>/Kinematic'
   */
  2.0,

  /* Mask Parameter: LateralControllerStanley_Posi_p
   * Referenced by: '<S1>/Kinematic'
   */
  2.5,

  /* Mask Parameter: PIForward_UpperSaturationLimit
   * Referenced by:
   *   '<S38>/DeadZone'
   *   '<S52>/Saturation'
   */
  3.0,

  /* Mask Parameter: PIReverse_UpperSaturationLimit
   * Referenced by:
   *   '<S87>/DeadZone'
   *   '<S101>/Saturation'
   */
  6.0,

  /* Mask Parameter: LateralControllerStanley_YawRat
   * Referenced by: '<S6>/Gain'
   */
  0.25,

  /* Expression: MaxSteeringAngle
   * Referenced by: '<S1>/Kinematic'
   */
  35.0,

  /* Expression: Wheelbase
   * Referenced by: '<S1>/Kinematic'
   */
  2.8,

  /* Expression: 0
   * Referenced by: '<S38>/Constant1'
   */
  0.0,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S45>/Integrator'
   */
  0.05,

  /* Expression: 0
   * Referenced by: '<S38>/ZeroGain'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S87>/Constant1'
   */
  0.0,

  /* Computed Parameter: Integrator_gainval_b
   * Referenced by: '<S94>/Integrator'
   */
  0.05,

  /* Expression: 0
   * Referenced by: '<S87>/ZeroGain'
   */
  0.0,

  /* Expression: 180/pi
   * Referenced by: '<S7>/Gain'
   */
  57.295779513082323,

  /* Expression: VehicleMass/(2*TireStiffness*(1+Lf/Lr))
   * Referenced by: '<S6>/Gain1'
   */
  0.020723684210526314,

  /* Expression: 0
   * Referenced by: '<S6>/Unit Delay'
   */
  0.0,

  /* Expression: MaxSteeringAngle
   * Referenced by: '<S6>/Saturation'
   */
  35.0,

  /* Expression: -MaxSteeringAngle
   * Referenced by: '<S6>/Saturation'
   */
  -35.0,

  /* Expression: 0
   * Referenced by: '<S10>/Constant4'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/Constant1'
   */
  0.0,

  /* Expression: -1
   * Referenced by: '<S10>/Constant3'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S10>/Constant2'
   */
  1.0,

  /* Computed Parameter: Merge_InitialOutput
   * Referenced by: '<S9>/Merge'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S8>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S8>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S8>/Switch1'
   */
  0.0
};

/* System initialize for referenced model: 'StanleyRefMdl' */
void StanleyRefMdl_Init(B_StanleyRefMdl_c_T *localB, DW_StanleyRefMdl_f_T
  *localDW)
{
  /* InitializeConditions for UnitDelay: '<S6>/Unit Delay' */
  localDW->UnitDelay_DSTATE = StanleyRefMdl_P.UnitDelay_InitialCondition;

  /* SystemInitialize for IfAction SubSystem: '<S9>/Forward' */
  /* InitializeConditions for DiscreteIntegrator: '<S45>/Integrator' */
  localDW->Integrator_DSTATE_a = StanleyRefMdl_P.PIForward_InitialConditionForIn;
  localDW->Integrator_PrevResetState_h = 0;

  /* End of SystemInitialize for SubSystem: '<S9>/Forward' */

  /* SystemInitialize for IfAction SubSystem: '<S9>/Reverse' */
  /* InitializeConditions for DiscreteIntegrator: '<S94>/Integrator' */
  localDW->Integrator_DSTATE = StanleyRefMdl_P.PIReverse_InitialConditionForIn;
  localDW->Integrator_PrevResetState = 0;

  /* End of SystemInitialize for SubSystem: '<S9>/Reverse' */

  /* SystemInitialize for Merge: '<S9>/Merge' */
  localB->Merge = StanleyRefMdl_P.Merge_InitialOutput;
}

/* System reset for referenced model: 'StanleyRefMdl' */
void StanleyRefMdl_Reset(DW_StanleyRefMdl_f_T *localDW)
{
  /* InitializeConditions for UnitDelay: '<S6>/Unit Delay' */
  localDW->UnitDelay_DSTATE = StanleyRefMdl_P.UnitDelay_InitialCondition;
}

/* Output and update for referenced model: 'StanleyRefMdl' */
void StanleyRefMdl(RT_MODEL_StanleyRefMdl_T * const StanleyRefMdl_M, const
                   real_T rtu_RefPose[3], const real_T *rtu_RefVelocity, const
                   real_T *rtu_Direction, const real_T *rtu_Curvature, const
                   real_T *rtu_Reset, const real_T rtu_VehicleInfo_CurrPose[3],
                   const real_T *rtu_VehicleInfo_CurrVelocity, const real_T
                   *rtu_VehicleInfo_CurrYawRate, const real_T
                   *rtu_VehicleInfo_CurrSteer, real_T *rty_SteerCmd, real_T
                   *rty_AccelCmd, real_T *rty_DecelCmd, B_StanleyRefMdl_c_T
                   *localB, DW_StanleyRefMdl_f_T *localDW)
{
  real_T refPose[3];
  real_T currPose[3];
  real_T delta;
  real_T rtb_Add;
  boolean_T rtb_NotEqual_o;
  real_T d_idx_0;
  real_T d_idx_1;
  real_T rtu_Direction_0;
  real_T delta_0;
  if (rtmIsSampleHit(StanleyRefMdl_M, 1, 0)) {
    /* MATLAB Function: '<S1>/Kinematic' */
    refPose[0] = rtu_RefPose[0];
    currPose[0] = rtu_VehicleInfo_CurrPose[0];
    refPose[1] = rtu_RefPose[1];
    currPose[1] = rtu_VehicleInfo_CurrPose[1];
    delta = 0.017453292519943295 * rtu_RefPose[2];
    angleUtilities_wrapTo2_bbViJ3IV(&delta);
    refPose[2] = 0.017453292519943295 * rtu_RefPose[2];
    angleUtilities_wrapTo2_bbViJ3IV(&refPose[2]);
    currPose[2] = 0.017453292519943295 * rtu_VehicleInfo_CurrPose[2];
    angleUtilities_wrapTo2_bbViJ3IV(&currPose[2]);
    delta_0 = cos(delta);
    rtb_Add = sin(delta);
    if (*rtu_Direction == 1.0) {
      d_idx_0 = (StanleyRefMdl_P.Kinematic_Wheelbase * cos(currPose[2]) +
                 rtu_VehicleInfo_CurrPose[0]) - refPose[0];
      d_idx_1 = (StanleyRefMdl_P.Kinematic_Wheelbase * sin(currPose[2]) +
                 rtu_VehicleInfo_CurrPose[1]) - refPose[1];
    } else {
      d_idx_0 = currPose[0] - refPose[0];
      d_idx_1 = currPose[1] - refPose[1];
    }

    delta = (currPose[2] - refPose[2]) + 3.1415926535897931;
    angleUtilities_wrapTo2_bbViJ3IV(&delta);
    if (*rtu_Direction == 1.0) {
      delta = -(atan(-(d_idx_0 * rtb_Add - d_idx_1 * delta_0) *
                     StanleyRefMdl_P.LateralControllerStanley_Positi /
                     (*rtu_VehicleInfo_CurrVelocity + 1.0)) + (delta -
                 3.1415926535897931));
    } else {
      if (*rtu_Direction == 1.0) {
        rtu_Direction_0 = StanleyRefMdl_P.LateralControllerStanley_Positi;
      } else {
        rtu_Direction_0 = StanleyRefMdl_P.LateralControllerStanley_Posi_p;
      }

      delta = atan(-(d_idx_0 * rtb_Add - d_idx_1 * delta_0) * rtu_Direction_0 /
                   (*rtu_VehicleInfo_CurrVelocity + -1.0)) + (delta -
        3.1415926535897931);
    }

    delta *= 57.295779513082323;
    if (delta < 0.0) {
      delta_0 = -1.0;
    } else if (delta > 0.0) {
      delta_0 = 1.0;
    } else if (delta == 0.0) {
      delta_0 = 0.0;
    } else {
      delta_0 = (rtNaN);
    }

    delta = delta_0 * fmin(fabs(delta),
      StanleyRefMdl_P.Kinematic_MaxSteeringAngle);

    /* End of MATLAB Function: '<S1>/Kinematic' */

    /* Gain: '<S7>/Gain' incorporates:
     *  Product: '<S6>/Product'
     */
    rtb_Add = *rtu_VehicleInfo_CurrVelocity * *rtu_Curvature *
      StanleyRefMdl_P.Gain_Gain;

    /* Sum: '<S6>/Add' incorporates:
     *  Gain: '<S6>/Gain'
     *  Gain: '<S6>/Gain1'
     *  Gain: '<S6>/Gain2'
     *  Product: '<S6>/Multiply'
     *  Sum: '<S6>/Minus'
     *  Sum: '<S6>/Minus1'
     *  UnitDelay: '<S6>/Unit Delay'
     */
    delta = ((*rtu_VehicleInfo_CurrVelocity * rtb_Add *
              StanleyRefMdl_P.Gain1_Gain + delta) + (rtb_Add -
              *rtu_VehicleInfo_CurrYawRate) *
             StanleyRefMdl_P.LateralControllerStanley_YawRat) +
      (localDW->UnitDelay_DSTATE - *rtu_VehicleInfo_CurrSteer) *
      StanleyRefMdl_P.LateralControllerStanley_DelayG;

    /* Saturate: '<S6>/Saturation' */
    if (delta > StanleyRefMdl_P.Saturation_UpperSat) {
      *rty_SteerCmd = StanleyRefMdl_P.Saturation_UpperSat;
    } else if (delta < StanleyRefMdl_P.Saturation_LowerSat) {
      *rty_SteerCmd = StanleyRefMdl_P.Saturation_LowerSat;
    } else {
      *rty_SteerCmd = delta;
    }

    /* End of Saturate: '<S6>/Saturation' */

    /* Signum: '<S10>/Sign2' */
    if (*rtu_RefVelocity < 0.0) {
      delta = -1.0;
    } else if (*rtu_RefVelocity > 0.0) {
      delta = 1.0;
    } else if (*rtu_RefVelocity == 0.0) {
      delta = 0.0;
    } else {
      delta = (rtNaN);
    }

    /* End of Signum: '<S10>/Sign2' */

    /* Signum: '<S10>/Sign1' */
    if (*rtu_VehicleInfo_CurrVelocity < 0.0) {
      delta_0 = -1.0;
    } else if (*rtu_VehicleInfo_CurrVelocity > 0.0) {
      delta_0 = 1.0;
    } else if (*rtu_VehicleInfo_CurrVelocity == 0.0) {
      delta_0 = 0.0;
    } else {
      delta_0 = (rtNaN);
    }

    /* End of Signum: '<S10>/Sign1' */

    /* Assertion: '<S10>/Assertion' incorporates:
     *  Constant: '<S10>/Constant1'
     *  Constant: '<S10>/Constant4'
     *  Logic: '<S10>/AND1'
     *  Logic: '<S10>/AND3'
     *  Logic: '<S10>/NOT1'
     *  Logic: '<S10>/OR'
     *  RelationalOperator: '<S10>/Equal1'
     *  RelationalOperator: '<S10>/Equal2'
     *  RelationalOperator: '<S10>/Equal3'
     *  RelationalOperator: '<S10>/Equal6'
     */
    utAssert(((!(*rtu_Direction != delta)) || (!(*rtu_RefVelocity !=
                StanleyRefMdl_P.Constant4_Value))) && ((!(*rtu_Direction !=
                delta_0)) || (!(*rtu_VehicleInfo_CurrVelocity !=
                StanleyRefMdl_P.Constant1_Value_m))));

    /* Assertion: '<S10>/Assertion1' incorporates:
     *  Constant: '<S10>/Constant2'
     *  Constant: '<S10>/Constant3'
     *  Logic: '<S10>/AND2'
     *  Logic: '<S10>/NOT'
     *  RelationalOperator: '<S10>/Equal4'
     *  RelationalOperator: '<S10>/Equal5'
     */
    utAssert((!(StanleyRefMdl_P.Constant3_Value != *rtu_Direction)) ||
             (!(StanleyRefMdl_P.Constant2_Value != *rtu_Direction)));

    /* Sum: '<S2>/Minus' */
    delta = *rtu_RefVelocity - *rtu_VehicleInfo_CurrVelocity;

    /* SwitchCase: '<S9>/Switch Case' */
    delta_0 = trunc(*rtu_Direction);
    if (rtIsNaN(delta_0) || rtIsInf(delta_0)) {
      delta_0 = 0.0;
    } else {
      delta_0 = fmod(delta_0, 4.294967296E+9);
    }

    switch (delta_0 < 0.0 ? -(int32_T)(uint32_T)-delta_0 : (int32_T)(uint32_T)
            delta_0) {
     case 1:
      /* Outputs for IfAction SubSystem: '<S9>/Forward' incorporates:
       *  ActionPort: '<S11>/Action Port'
       */
      /* DiscreteIntegrator: '<S45>/Integrator' incorporates:
       *  DataTypeConversion: '<S9>/Data Type Conversion'
       */
      if ((*rtu_Reset != 0.0) || (localDW->Integrator_PrevResetState_h != 0)) {
        localDW->Integrator_DSTATE_a =
          StanleyRefMdl_P.PIForward_InitialConditionForIn;
      }

      /* Sum: '<S54>/Sum' incorporates:
       *  DiscreteIntegrator: '<S45>/Integrator'
       *  Gain: '<S50>/Proportional Gain'
       */
      rtb_Add = StanleyRefMdl_P.LongitudinalControllerStanley_d * delta +
        localDW->Integrator_DSTATE_a;

      /* DeadZone: '<S38>/DeadZone' */
      if (rtb_Add > StanleyRefMdl_P.PIForward_UpperSaturationLimit) {
        d_idx_0 = rtb_Add - StanleyRefMdl_P.PIForward_UpperSaturationLimit;
      } else if (rtb_Add >= StanleyRefMdl_P.PIForward_LowerSaturationLimit) {
        d_idx_0 = 0.0;
      } else {
        d_idx_0 = rtb_Add - StanleyRefMdl_P.PIForward_LowerSaturationLimit;
      }

      /* End of DeadZone: '<S38>/DeadZone' */

      /* RelationalOperator: '<S38>/NotEqual' incorporates:
       *  Gain: '<S38>/ZeroGain'
       */
      rtb_NotEqual_o = (StanleyRefMdl_P.ZeroGain_Gain * rtb_Add != d_idx_0);

      /* Signum: '<S38>/SignPreSat' */
      if (d_idx_0 < 0.0) {
        d_idx_0 = -1.0;
      } else if (d_idx_0 > 0.0) {
        d_idx_0 = 1.0;
      } else if (d_idx_0 == 0.0) {
        d_idx_0 = 0.0;
      } else {
        d_idx_0 = (rtNaN);
      }

      /* End of Signum: '<S38>/SignPreSat' */

      /* DataTypeConversion: '<S38>/DataTypeConv1' */
      if (rtIsNaN(d_idx_0)) {
        delta_0 = 0.0;
      } else {
        delta_0 = fmod(d_idx_0, 256.0);
      }

      /* Gain: '<S42>/Integral Gain' */
      d_idx_0 = StanleyRefMdl_P.LongitudinalControllerStanley_K * delta;

      /* Saturate: '<S52>/Saturation' */
      if (rtb_Add > StanleyRefMdl_P.PIForward_UpperSaturationLimit) {
        localB->Merge = StanleyRefMdl_P.PIForward_UpperSaturationLimit;
      } else if (rtb_Add < StanleyRefMdl_P.PIForward_LowerSaturationLimit) {
        localB->Merge = StanleyRefMdl_P.PIForward_LowerSaturationLimit;
      } else {
        localB->Merge = rtb_Add;
      }

      /* End of Saturate: '<S52>/Saturation' */

      /* Signum: '<S38>/SignPreIntegrator' */
      if (d_idx_0 < 0.0) {
        /* DataTypeConversion: '<S38>/DataTypeConv2' */
        rtb_Add = -1.0;
      } else if (d_idx_0 > 0.0) {
        /* DataTypeConversion: '<S38>/DataTypeConv2' */
        rtb_Add = 1.0;
      } else if (d_idx_0 == 0.0) {
        /* DataTypeConversion: '<S38>/DataTypeConv2' */
        rtb_Add = 0.0;
      } else {
        /* DataTypeConversion: '<S38>/DataTypeConv2' */
        rtb_Add = (rtNaN);
      }

      /* End of Signum: '<S38>/SignPreIntegrator' */

      /* DataTypeConversion: '<S38>/DataTypeConv2' */
      if (rtIsNaN(rtb_Add)) {
        rtb_Add = 0.0;
      } else {
        rtb_Add = fmod(rtb_Add, 256.0);
      }

      /* Switch: '<S38>/Switch' incorporates:
       *  Constant: '<S38>/Constant1'
       *  DataTypeConversion: '<S38>/DataTypeConv1'
       *  DataTypeConversion: '<S38>/DataTypeConv2'
       *  Logic: '<S38>/AND3'
       *  RelationalOperator: '<S38>/Equal1'
       */
      if (rtb_NotEqual_o && ((int8_T)(delta_0 < 0.0 ? (int32_T)(int8_T)-(int8_T)
            (uint8_T)-delta_0 : (int32_T)(int8_T)(uint8_T)delta_0) == (rtb_Add <
            0.0 ? (int32_T)(int8_T)-(int8_T)(uint8_T)-rtb_Add : (int32_T)(int8_T)
            (uint8_T)rtb_Add))) {
        d_idx_0 = StanleyRefMdl_P.Constant1_Value;
      }

      /* End of Switch: '<S38>/Switch' */

      /* Update for DiscreteIntegrator: '<S45>/Integrator' incorporates:
       *  DataTypeConversion: '<S9>/Data Type Conversion'
       */
      localDW->Integrator_DSTATE_a += StanleyRefMdl_P.Integrator_gainval *
        d_idx_0;
      localDW->Integrator_PrevResetState_h = (int8_T)(*rtu_Reset != 0.0);

      /* End of Outputs for SubSystem: '<S9>/Forward' */
      break;

     case -1:
      /* Outputs for IfAction SubSystem: '<S9>/Reverse' incorporates:
       *  ActionPort: '<S12>/Action Port'
       */
      /* DiscreteIntegrator: '<S94>/Integrator' incorporates:
       *  DataTypeConversion: '<S9>/Data Type Conversion'
       */
      if ((*rtu_Reset != 0.0) || (localDW->Integrator_PrevResetState != 0)) {
        localDW->Integrator_DSTATE =
          StanleyRefMdl_P.PIReverse_InitialConditionForIn;
      }

      /* Sum: '<S103>/Sum' incorporates:
       *  DiscreteIntegrator: '<S94>/Integrator'
       *  Gain: '<S99>/Proportional Gain'
       */
      rtb_Add = StanleyRefMdl_P.LongitudinalControllerStanley_d * delta +
        localDW->Integrator_DSTATE;

      /* DeadZone: '<S87>/DeadZone' */
      if (rtb_Add > StanleyRefMdl_P.PIReverse_UpperSaturationLimit) {
        d_idx_0 = rtb_Add - StanleyRefMdl_P.PIReverse_UpperSaturationLimit;
      } else if (rtb_Add >= StanleyRefMdl_P.PIReverse_LowerSaturationLimit) {
        d_idx_0 = 0.0;
      } else {
        d_idx_0 = rtb_Add - StanleyRefMdl_P.PIReverse_LowerSaturationLimit;
      }

      /* End of DeadZone: '<S87>/DeadZone' */

      /* RelationalOperator: '<S87>/NotEqual' incorporates:
       *  Gain: '<S87>/ZeroGain'
       */
      rtb_NotEqual_o = (StanleyRefMdl_P.ZeroGain_Gain_g * rtb_Add != d_idx_0);

      /* Signum: '<S87>/SignPreSat' */
      if (d_idx_0 < 0.0) {
        d_idx_0 = -1.0;
      } else if (d_idx_0 > 0.0) {
        d_idx_0 = 1.0;
      } else if (d_idx_0 == 0.0) {
        d_idx_0 = 0.0;
      } else {
        d_idx_0 = (rtNaN);
      }

      /* End of Signum: '<S87>/SignPreSat' */

      /* DataTypeConversion: '<S87>/DataTypeConv1' */
      if (rtIsNaN(d_idx_0)) {
        delta_0 = 0.0;
      } else {
        delta_0 = fmod(d_idx_0, 256.0);
      }

      /* Gain: '<S91>/Integral Gain' */
      d_idx_0 = StanleyRefMdl_P.LongitudinalControllerStanley_K * delta;

      /* Saturate: '<S101>/Saturation' */
      if (rtb_Add > StanleyRefMdl_P.PIReverse_UpperSaturationLimit) {
        localB->Merge = StanleyRefMdl_P.PIReverse_UpperSaturationLimit;
      } else if (rtb_Add < StanleyRefMdl_P.PIReverse_LowerSaturationLimit) {
        localB->Merge = StanleyRefMdl_P.PIReverse_LowerSaturationLimit;
      } else {
        localB->Merge = rtb_Add;
      }

      /* End of Saturate: '<S101>/Saturation' */

      /* Signum: '<S87>/SignPreIntegrator' */
      if (d_idx_0 < 0.0) {
        /* DataTypeConversion: '<S87>/DataTypeConv2' */
        rtb_Add = -1.0;
      } else if (d_idx_0 > 0.0) {
        /* DataTypeConversion: '<S87>/DataTypeConv2' */
        rtb_Add = 1.0;
      } else if (d_idx_0 == 0.0) {
        /* DataTypeConversion: '<S87>/DataTypeConv2' */
        rtb_Add = 0.0;
      } else {
        /* DataTypeConversion: '<S87>/DataTypeConv2' */
        rtb_Add = (rtNaN);
      }

      /* End of Signum: '<S87>/SignPreIntegrator' */

      /* DataTypeConversion: '<S87>/DataTypeConv2' */
      if (rtIsNaN(rtb_Add)) {
        rtb_Add = 0.0;
      } else {
        rtb_Add = fmod(rtb_Add, 256.0);
      }

      /* Switch: '<S87>/Switch' incorporates:
       *  Constant: '<S87>/Constant1'
       *  DataTypeConversion: '<S87>/DataTypeConv1'
       *  DataTypeConversion: '<S87>/DataTypeConv2'
       *  Logic: '<S87>/AND3'
       *  RelationalOperator: '<S87>/Equal1'
       */
      if (rtb_NotEqual_o && ((int8_T)(delta_0 < 0.0 ? (int32_T)(int8_T)-(int8_T)
            (uint8_T)-delta_0 : (int32_T)(int8_T)(uint8_T)delta_0) == (rtb_Add <
            0.0 ? (int32_T)(int8_T)-(int8_T)(uint8_T)-rtb_Add : (int32_T)(int8_T)
            (uint8_T)rtb_Add))) {
        d_idx_0 = StanleyRefMdl_P.Constant1_Value_c;
      }

      /* End of Switch: '<S87>/Switch' */

      /* Update for DiscreteIntegrator: '<S94>/Integrator' incorporates:
       *  DataTypeConversion: '<S9>/Data Type Conversion'
       */
      localDW->Integrator_DSTATE += StanleyRefMdl_P.Integrator_gainval_b *
        d_idx_0;
      localDW->Integrator_PrevResetState = (int8_T)(*rtu_Reset != 0.0);

      /* End of Outputs for SubSystem: '<S9>/Reverse' */
      break;
    }

    /* End of SwitchCase: '<S9>/Switch Case' */

    /* Product: '<S8>/Multiply' */
    delta = *rtu_Direction * localB->Merge;

    /* Switch: '<S8>/Switch' incorporates:
     *  Constant: '<S8>/Constant'
     */
    if (delta > StanleyRefMdl_P.Switch_Threshold) {
      *rty_AccelCmd = delta;
    } else {
      *rty_AccelCmd = StanleyRefMdl_P.Constant_Value;
    }

    /* End of Switch: '<S8>/Switch' */

    /* Switch: '<S8>/Switch1' incorporates:
     *  Abs: '<S8>/Abs'
     *  Constant: '<S8>/Constant'
     */
    if (delta > StanleyRefMdl_P.Switch1_Threshold) {
      *rty_DecelCmd = StanleyRefMdl_P.Constant_Value;
    } else {
      *rty_DecelCmd = fabs(delta);
    }

    /* End of Switch: '<S8>/Switch1' */

    /* Update for UnitDelay: '<S6>/Unit Delay' */
    localDW->UnitDelay_DSTATE = *rtu_VehicleInfo_CurrSteer;
  }
}

/* Model initialize function */
void StanleyRefMdl_initialize(const char_T **rt_errorStatus, const
  rtTimingBridge *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_StanleyRefMdl_T *const StanleyRefMdl_M, B_StanleyRefMdl_c_T *localB,
  DW_StanleyRefMdl_f_T *localDW, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const
  char_T *rt_ChildPath, int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)StanleyRefMdl_M, 0,
                sizeof(RT_MODEL_StanleyRefMdl_T));

  /* setup the global timing engine */
  StanleyRefMdl_M->Timing.mdlref_GlobalTID[0] = mdlref_TID0;
  StanleyRefMdl_M->Timing.mdlref_GlobalTID[1] = mdlref_TID1;
  StanleyRefMdl_M->timingBridge = (timingBridge);

  /* initialize error status */
  rtmSetErrorStatusPointer(StanleyRefMdl_M, rt_errorStatus);

  /* block I/O */
  (void) memset(((void *) localB), 0,
                sizeof(B_StanleyRefMdl_c_T));

  /* states (dwork) */
  (void) memset((void *)localDW, 0,
                sizeof(DW_StanleyRefMdl_f_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  {
    StanleyRefMdl_InitializeDataMapInfo(StanleyRefMdl_M, localB, localDW);
  }

  /* Initialize Parent model MMI */
  if ((rt_ParentMMI != (NULL)) && (rt_ChildPath != (NULL))) {
    rtwCAPI_SetChildMMI(*rt_ParentMMI, rt_ChildMMIIdx,
                        &(StanleyRefMdl_M->DataMapInfo.mmi));
    rtwCAPI_SetPath(StanleyRefMdl_M->DataMapInfo.mmi, rt_ChildPath);
    rtwCAPI_MMISetContStateStartIndex(StanleyRefMdl_M->DataMapInfo.mmi,
      rt_CSTATEIdx);
  }
}
