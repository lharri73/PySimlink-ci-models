/*
 * StanleyRefMdl_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "StanleyRefMdl".
 *
 * Model version              : 1.948
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:13:52 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_StanleyRefMdl_capi_h
#define RTW_HEADER_StanleyRefMdl_capi_h
#include "StanleyRefMdl.h"

extern void StanleyRefMdl_InitializeDataMapInfo(RT_MODEL_StanleyRefMdl_T *const
  StanleyRefMdl_M, B_StanleyRefMdl_c_T *localB, DW_StanleyRefMdl_f_T *localDW);

#endif                                 /* RTW_HEADER_StanleyRefMdl_capi_h */

/* EOF: StanleyRefMdl_capi.h */
