/*
 * Code generation for system model 'StanleyRefMdl'
 * For more details, see corresponding source file StanleyRefMdl.c
 *
 */

#ifndef RTW_HEADER_StanleyRefMdl_h_
#define RTW_HEADER_StanleyRefMdl_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef StanleyRefMdl_COMMON_INCLUDES_
# define StanleyRefMdl_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* StanleyRefMdl_COMMON_INCLUDES_ */

#include "StanleyRefMdl_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rt_nonfinite.h"
#include "rt_assert.h"
#include "rtGetInf.h"

/* Block signals for model 'StanleyRefMdl' */
typedef struct {
  real_T Merge;                        /* '<S9>/Merge' */
} B_StanleyRefMdl_c_T;

/* Block states (default storage) for model 'StanleyRefMdl' */
typedef struct {
  real_T UnitDelay_DSTATE;             /* '<S6>/Unit Delay' */
  real_T Integrator_DSTATE;            /* '<S94>/Integrator' */
  real_T Integrator_DSTATE_a;          /* '<S45>/Integrator' */
  void* Assertion_slioAccessor;        /* '<S10>/Assertion' */
  void* Assertion1_slioAccessor;       /* '<S10>/Assertion1' */
  int8_T Integrator_PrevResetState;    /* '<S94>/Integrator' */
  int8_T Integrator_PrevResetState_h;  /* '<S45>/Integrator' */
} DW_StanleyRefMdl_f_T;

/* Parameters (default storage) */
struct P_StanleyRefMdl_T_ {
  real_T LateralControllerStanley_DelayG;
                              /* Mask Parameter: LateralControllerStanley_DelayG
                               * Referenced by: '<S6>/Gain2'
                               */
  real_T PIForward_InitialConditionForIn;
                              /* Mask Parameter: PIForward_InitialConditionForIn
                               * Referenced by: '<S45>/Integrator'
                               */
  real_T PIReverse_InitialConditionForIn;
                              /* Mask Parameter: PIReverse_InitialConditionForIn
                               * Referenced by: '<S94>/Integrator'
                               */
  real_T LongitudinalControllerStanley_K;
                              /* Mask Parameter: LongitudinalControllerStanley_K
                               * Referenced by:
                               *   '<S42>/Integral Gain'
                               *   '<S91>/Integral Gain'
                               */
  real_T LongitudinalControllerStanley_d;
                              /* Mask Parameter: LongitudinalControllerStanley_d
                               * Referenced by:
                               *   '<S50>/Proportional Gain'
                               *   '<S99>/Proportional Gain'
                               */
  real_T PIForward_LowerSaturationLimit;
                               /* Mask Parameter: PIForward_LowerSaturationLimit
                                * Referenced by:
                                *   '<S38>/DeadZone'
                                *   '<S52>/Saturation'
                                */
  real_T PIReverse_LowerSaturationLimit;
                               /* Mask Parameter: PIReverse_LowerSaturationLimit
                                * Referenced by:
                                *   '<S87>/DeadZone'
                                *   '<S101>/Saturation'
                                */
  real_T LateralControllerStanley_Positi;
                              /* Mask Parameter: LateralControllerStanley_Positi
                               * Referenced by: '<S1>/Kinematic'
                               */
  real_T LateralControllerStanley_Posi_p;
                              /* Mask Parameter: LateralControllerStanley_Posi_p
                               * Referenced by: '<S1>/Kinematic'
                               */
  real_T PIForward_UpperSaturationLimit;
                               /* Mask Parameter: PIForward_UpperSaturationLimit
                                * Referenced by:
                                *   '<S38>/DeadZone'
                                *   '<S52>/Saturation'
                                */
  real_T PIReverse_UpperSaturationLimit;
                               /* Mask Parameter: PIReverse_UpperSaturationLimit
                                * Referenced by:
                                *   '<S87>/DeadZone'
                                *   '<S101>/Saturation'
                                */
  real_T LateralControllerStanley_YawRat;
                              /* Mask Parameter: LateralControllerStanley_YawRat
                               * Referenced by: '<S6>/Gain'
                               */
  real_T Kinematic_MaxSteeringAngle;   /* Expression: MaxSteeringAngle
                                        * Referenced by: '<S1>/Kinematic'
                                        */
  real_T Kinematic_Wheelbase;          /* Expression: Wheelbase
                                        * Referenced by: '<S1>/Kinematic'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S38>/Constant1'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S45>/Integrator'
                                        */
  real_T ZeroGain_Gain;                /* Expression: 0
                                        * Referenced by: '<S38>/ZeroGain'
                                        */
  real_T Constant1_Value_c;            /* Expression: 0
                                        * Referenced by: '<S87>/Constant1'
                                        */
  real_T Integrator_gainval_b;       /* Computed Parameter: Integrator_gainval_b
                                      * Referenced by: '<S94>/Integrator'
                                      */
  real_T ZeroGain_Gain_g;              /* Expression: 0
                                        * Referenced by: '<S87>/ZeroGain'
                                        */
  real_T Gain_Gain;                    /* Expression: 180/pi
                                        * Referenced by: '<S7>/Gain'
                                        */
  real_T Gain1_Gain;      /* Expression: VehicleMass/(2*TireStiffness*(1+Lf/Lr))
                           * Referenced by: '<S6>/Gain1'
                           */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S6>/Unit Delay'
                                        */
  real_T Saturation_UpperSat;          /* Expression: MaxSteeringAngle
                                        * Referenced by: '<S6>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -MaxSteeringAngle
                                        * Referenced by: '<S6>/Saturation'
                                        */
  real_T Constant4_Value;              /* Expression: 0
                                        * Referenced by: '<S10>/Constant4'
                                        */
  real_T Constant1_Value_m;            /* Expression: 0
                                        * Referenced by: '<S10>/Constant1'
                                        */
  real_T Constant3_Value;              /* Expression: -1
                                        * Referenced by: '<S10>/Constant3'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S10>/Constant2'
                                        */
  real_T Merge_InitialOutput;         /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S9>/Merge'
                                       */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S8>/Constant'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S8>/Switch'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S8>/Switch1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_StanleyRefMdl_T {
  const char_T **errorStatus;
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[41];
    int32_T* vardimsAddress[41];
    RTWLoggingFcnPtr loggingPtrs[41];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    int_T mdlref_GlobalTID[2];
  } Timing;
};

typedef struct {
  B_StanleyRefMdl_c_T rtb;
  DW_StanleyRefMdl_f_T rtdw;
  RT_MODEL_StanleyRefMdl_T rtm;
} MdlrefDW_StanleyRefMdl_T;

/* Model reference registration function */
extern void StanleyRefMdl_initialize(const char_T **rt_errorStatus, const
  rtTimingBridge *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_StanleyRefMdl_T *const StanleyRefMdl_M, B_StanleyRefMdl_c_T *localB,
  DW_StanleyRefMdl_f_T *localDW, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const
  char_T *rt_ChildPath, int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  StanleyRefMdl_GetCAPIStaticMap(void);
extern void StanleyRefMdl_Init(B_StanleyRefMdl_c_T *localB, DW_StanleyRefMdl_f_T
  *localDW);
extern void StanleyRefMdl_Reset(DW_StanleyRefMdl_f_T *localDW);
extern void StanleyRefMdl(RT_MODEL_StanleyRefMdl_T * const StanleyRefMdl_M,
  const real_T rtu_RefPose[3], const real_T *rtu_RefVelocity, const real_T
  *rtu_Direction, const real_T *rtu_Curvature, const real_T *rtu_Reset, const
  real_T rtu_VehicleInfo_CurrPose[3], const real_T *rtu_VehicleInfo_CurrVelocity,
  const real_T *rtu_VehicleInfo_CurrYawRate, const real_T
  *rtu_VehicleInfo_CurrSteer, real_T *rty_SteerCmd, real_T *rty_AccelCmd, real_T
  *rty_DecelCmd, B_StanleyRefMdl_c_T *localB, DW_StanleyRefMdl_f_T *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'StanleyRefMdl'
 * '<S1>'   : 'StanleyRefMdl/Lateral Controller Stanley'
 * '<S2>'   : 'StanleyRefMdl/Longitudinal Controller Stanley'
 * '<S3>'   : 'StanleyRefMdl/Subsystem'
 * '<S4>'   : 'StanleyRefMdl/Lateral Controller Stanley/Dynamic'
 * '<S5>'   : 'StanleyRefMdl/Lateral Controller Stanley/Kinematic'
 * '<S6>'   : 'StanleyRefMdl/Lateral Controller Stanley/Dynamic/Dynamic Enabled'
 * '<S7>'   : 'StanleyRefMdl/Lateral Controller Stanley/Dynamic/Dynamic Enabled/Radians to Degrees'
 * '<S8>'   : 'StanleyRefMdl/Longitudinal Controller Stanley/Convert Command '
 * '<S9>'   : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller'
 * '<S10>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/Verify Direction'
 * '<S11>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward'
 * '<S12>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse'
 * '<S13>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward '
 * '<S14>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Anti-windup'
 * '<S15>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /D Gain'
 * '<S16>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Filter'
 * '<S17>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Filter ICs'
 * '<S18>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /I Gain'
 * '<S19>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Ideal P Gain'
 * '<S20>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Ideal P Gain Fdbk'
 * '<S21>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Integrator'
 * '<S22>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Integrator ICs'
 * '<S23>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /N Copy'
 * '<S24>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /N Gain'
 * '<S25>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /P Copy'
 * '<S26>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Parallel P Gain'
 * '<S27>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Reset Signal'
 * '<S28>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Saturation'
 * '<S29>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Saturation Fdbk'
 * '<S30>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Sum'
 * '<S31>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Sum Fdbk'
 * '<S32>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tracking Mode'
 * '<S33>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tracking Mode Sum'
 * '<S34>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tsamp - Integral'
 * '<S35>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tsamp - Ngain'
 * '<S36>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /postSat Signal'
 * '<S37>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /preSat Signal'
 * '<S38>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Anti-windup/Disc. Clamping Parallel'
 * '<S39>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /D Gain/Disabled'
 * '<S40>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Filter/Disabled'
 * '<S41>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Filter ICs/Disabled'
 * '<S42>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /I Gain/Internal Parameters'
 * '<S43>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Ideal P Gain/Passthrough'
 * '<S44>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Ideal P Gain Fdbk/Disabled'
 * '<S45>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Integrator/Discrete'
 * '<S46>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Integrator ICs/Internal IC'
 * '<S47>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /N Copy/Disabled wSignal Specification'
 * '<S48>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /N Gain/Disabled'
 * '<S49>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /P Copy/Disabled'
 * '<S50>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Parallel P Gain/Internal Parameters'
 * '<S51>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Reset Signal/External Reset'
 * '<S52>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Saturation/Enabled'
 * '<S53>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Saturation Fdbk/Disabled'
 * '<S54>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Sum/Sum_PI'
 * '<S55>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Sum Fdbk/Disabled'
 * '<S56>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tracking Mode/Disabled'
 * '<S57>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tracking Mode Sum/Passthrough'
 * '<S58>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tsamp - Integral/Passthrough'
 * '<S59>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /Tsamp - Ngain/Passthrough'
 * '<S60>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /postSat Signal/Forward_Path'
 * '<S61>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Forward/PI Forward /preSat Signal/Forward_Path'
 * '<S62>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse'
 * '<S63>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Anti-windup'
 * '<S64>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/D Gain'
 * '<S65>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Filter'
 * '<S66>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Filter ICs'
 * '<S67>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/I Gain'
 * '<S68>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Ideal P Gain'
 * '<S69>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Ideal P Gain Fdbk'
 * '<S70>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Integrator'
 * '<S71>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Integrator ICs'
 * '<S72>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/N Copy'
 * '<S73>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/N Gain'
 * '<S74>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/P Copy'
 * '<S75>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Parallel P Gain'
 * '<S76>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Reset Signal'
 * '<S77>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Saturation'
 * '<S78>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Saturation Fdbk'
 * '<S79>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Sum'
 * '<S80>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Sum Fdbk'
 * '<S81>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tracking Mode'
 * '<S82>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tracking Mode Sum'
 * '<S83>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tsamp - Integral'
 * '<S84>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tsamp - Ngain'
 * '<S85>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/postSat Signal'
 * '<S86>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/preSat Signal'
 * '<S87>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Anti-windup/Disc. Clamping Parallel'
 * '<S88>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/D Gain/Disabled'
 * '<S89>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Filter/Disabled'
 * '<S90>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Filter ICs/Disabled'
 * '<S91>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/I Gain/Internal Parameters'
 * '<S92>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Ideal P Gain/Passthrough'
 * '<S93>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Ideal P Gain Fdbk/Disabled'
 * '<S94>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Integrator/Discrete'
 * '<S95>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Integrator ICs/Internal IC'
 * '<S96>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/N Copy/Disabled wSignal Specification'
 * '<S97>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/N Gain/Disabled'
 * '<S98>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/P Copy/Disabled'
 * '<S99>'  : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Parallel P Gain/Internal Parameters'
 * '<S100>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Reset Signal/External Reset'
 * '<S101>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Saturation/Enabled'
 * '<S102>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Saturation Fdbk/Disabled'
 * '<S103>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Sum/Sum_PI'
 * '<S104>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Sum Fdbk/Disabled'
 * '<S105>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tracking Mode/Disabled'
 * '<S106>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tracking Mode Sum/Passthrough'
 * '<S107>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tsamp - Integral/Passthrough'
 * '<S108>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/Tsamp - Ngain/Passthrough'
 * '<S109>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/postSat Signal/Forward_Path'
 * '<S110>' : 'StanleyRefMdl/Longitudinal Controller Stanley/PI Controller/Reverse/PI Reverse/preSat Signal/Forward_Path'
 */
#endif                                 /* RTW_HEADER_StanleyRefMdl_h_ */
