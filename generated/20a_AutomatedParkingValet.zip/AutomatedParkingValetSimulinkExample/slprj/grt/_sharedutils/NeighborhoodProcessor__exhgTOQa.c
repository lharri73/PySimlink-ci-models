/*
 * NeighborhoodProcessor__exhgTOQa.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:11:34 2022
 * Created for block: AutomatedParkingValet
 */

#include "rtwtypes.h"
#include <string.h>
#include "rt_remd_snf.h"
#include "NeighborhoodProcessor__exhgTOQa.h"

/* Function for MATLAB Function: '<Root>/motionPlanning' */
void NeighborhoodProcessor__exhgTOQa(int32_T imSize[2], const boolean_T nhConn
  [49], int32_T loffsets[45], int32_T linds[45], int32_T soffsets[90], real_T
  interiorStart[2])
{
  real_T indx;
  int32_T nz;
  int32_T vi;
  int32_T a[90];
  int32_T k;
  int32_T indx_0;
  int32_T pixelsPerImPage_idx_1;
  int32_T z_tmp;
  pixelsPerImPage_idx_1 = imSize[0];
  interiorStart[0] = 4.0;
  imSize[0] -= 3;
  interiorStart[1] = 4.0;
  imSize[1] -= 3;
  nz = nhConn[0];
  for (k = 0; k < 48; k++) {
    nz += nhConn[k + 1];
  }

  if (nz != 0) {
    indx = 1.0;
    for (k = 0; k < 49; k++) {
      if (nhConn[k]) {
        nz = (int32_T)rt_remd_snf(((real_T)k + 1.0) - 1.0, 7.0);
        vi = nz + 1;
        z_tmp = (int32_T)((real_T)(k - nz) / 7.0);
        indx_0 = (int32_T)indx;
        soffsets[indx_0 - 1] = (int8_T)(nz + 1);
        soffsets[indx_0 + 44] = (int8_T)(z_tmp + 1);
        linds[(int32_T)indx - 1] = z_tmp * 7 + vi;
        loffsets[(int32_T)indx - 1] = z_tmp * pixelsPerImPage_idx_1 + vi;
        indx++;
      }
    }

    k = 3 * pixelsPerImPage_idx_1;
    for (pixelsPerImPage_idx_1 = 0; pixelsPerImPage_idx_1 < 45;
         pixelsPerImPage_idx_1++) {
      loffsets[pixelsPerImPage_idx_1] -= (int32_T)((real_T)k + 4.0);
    }

    memcpy(&a[0], &soffsets[0], 90U * sizeof(int32_T));
    for (k = 0; k < 2; k++) {
      for (nz = 0; nz < 45; nz++) {
        pixelsPerImPage_idx_1 = 45 * k + nz;
        soffsets[pixelsPerImPage_idx_1] = a[pixelsPerImPage_idx_1] - 4;
      }
    }
  }
}
