/*
 * rt_remd_snf.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:11:34 2022
 * Created for block: AutomatedParkingValet
 */

#ifndef SHARE_rt_remd_snf
#define SHARE_rt_remd_snf
#include "rtwtypes.h"

extern real_T rt_remd_snf(real_T u0, real_T u1);

#endif
