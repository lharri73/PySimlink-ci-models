/*
 * all_NdIgJbYL.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "AutomatedParkingValet".
 *
 * Model version              : 1.965
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:11:34 2022
 * Created for block: AutomatedParkingValet
 */

#include "rtwtypes.h"
#include "all_NdIgJbYL.h"

/* Function for MATLAB Function: '<Root>/motionPlanning' */
void all_NdIgJbYL(const boolean_T x[20000], boolean_T y[5000])
{
  int32_T i2;
  int32_T i1;
  int32_T j;
  int32_T ix;
  int32_T i;
  boolean_T exitg1;
  for (i = 0; i < 5000; i++) {
    y[i] = true;
  }

  i = -1;
  i1 = 0;
  i2 = 15000;
  for (j = 0; j < 5000; j++) {
    i1++;
    i2++;
    i++;
    ix = i1;
    exitg1 = false;
    while ((!exitg1) && (ix <= i2)) {
      if (!x[ix - 1]) {
        y[i] = false;
        exitg1 = true;
      } else {
        ix += 5000;
      }
    }
  }
}
