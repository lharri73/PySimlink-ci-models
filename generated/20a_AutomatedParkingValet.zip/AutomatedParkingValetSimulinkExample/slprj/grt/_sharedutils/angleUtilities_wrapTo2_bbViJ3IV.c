/*
 * angleUtilities_wrapTo2_bbViJ3IV.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "StanleyRefMdl".
 *
 * Model version              : 1.948
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:09:41 2022
 * Created for block: StanleyRefMdl
 */

#include "rtwtypes.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include <math.h>
#include "angleUtilities_wrapTo2_bbViJ3IV.h"

/* Function for MATLAB Function: '<S1>/Kinematic' */
void angleUtilities_wrapTo2_bbViJ3IV(real_T *theta)
{
  boolean_T positiveInput;
  real_T x;
  boolean_T rEQ0;
  real_T q;
  positiveInput = (*theta > 0.0);
  x = *theta;
  if (rtIsNaN(*theta) || rtIsInf(*theta)) {
    *theta = (rtNaN);
  } else if (*theta == 0.0) {
    *theta = 0.0;
  } else {
    *theta = fmod(*theta, 6.2831853071795862);
    rEQ0 = (*theta == 0.0);
    if (!rEQ0) {
      q = fabs(x / 6.2831853071795862);
      rEQ0 = !(fabs(q - floor(q + 0.5)) > 2.2204460492503131E-16 * q);
    }

    if (rEQ0) {
      *theta = 0.0;
    } else {
      if (x < 0.0) {
        *theta += 6.2831853071795862;
      }
    }
  }

  positiveInput = ((*theta == 0.0) && positiveInput);
  *theta += 6.2831853071795862 * (real_T)positiveInput;
}
