/*
 * angleUtilities_wrapTo2_bbViJ3IV.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "StanleyRefMdl".
 *
 * Model version              : 1.948
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Jul 23 16:09:41 2022
 * Created for block: StanleyRefMdl
 */

#ifndef SHARE_angleUtilities_wrapTo2_bbViJ3IV
#define SHARE_angleUtilities_wrapTo2_bbViJ3IV
#include "rtwtypes.h"

extern void angleUtilities_wrapTo2_bbViJ3IV(real_T *theta);

#endif
