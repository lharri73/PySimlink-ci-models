/*
 * sfcndemo_matadd.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sfcndemo_matadd".
 *
 * Model version              : 5.0
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 18:47:04 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_sfcndemo_matadd_h_
#define RTW_HEADER_sfcndemo_matadd_h_
#include <stddef.h>
#include <float.h>
#include <string.h>
#include "rtw_modelmap.h"
#ifndef sfcndemo_matadd_COMMON_INCLUDES_
#define sfcndemo_matadd_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* sfcndemo_matadd_COMMON_INCLUDES_ */

#include "sfcndemo_matadd_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm)         ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val)    ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Scalarparam;                  /* '<Root>/Scalar param' */
  real_T Matrixparam2[8];              /* '<Root>/Matrix param2' */
  real_T Matrixparam[4];               /* '<Root>/Matrix param' */
  real_T Scalarparam1[2];              /* '<Root>/Scalar param1' */
  real_T Matrixparam1[6];              /* '<Root>/Matrix param1' */
} B_sfcndemo_matadd_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  struct {
    void *LoggedData;
  } ToWorkspace_PWORK;                 /* '<Root>/To Workspace' */
} DW_sfcndemo_matadd_T;

/* Parameters (default storage) */
struct P_sfcndemo_matadd_T_ {
  real_T Scalarparam_Operand;          /* Mask Parameter: Scalarparam_Operand
                                        * Referenced by: '<Root>/Scalar param'
                                        */
  real_T Matrixparam2_Operand[8];      /* Mask Parameter: Matrixparam2_Operand
                                        * Referenced by: '<Root>/Matrix param2'
                                        */
  real_T Matrixparam_Operand[4];       /* Mask Parameter: Matrixparam_Operand
                                        * Referenced by: '<Root>/Matrix param'
                                        */
  real_T Scalarparam1_Operand;         /* Mask Parameter: Scalarparam1_Operand
                                        * Referenced by: '<Root>/Scalar param1'
                                        */
  real_T Matrixparam1_Operand[6];      /* Mask Parameter: Matrixparam1_Operand
                                        * Referenced by: '<Root>/Matrix param1'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Constant1_Value[8];       /* Expression: cat(3, [1 2; 3 4], [5 6; 7 8])
                                    * Referenced by: '<Root>/Constant1'
                                    */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Constant3_Value[2];           /* Expression: [1 2]
                                        * Referenced by: '<Root>/Constant3'
                                        */
  real_T Constant5_Value[6];           /* Expression: [1 3 5;2 4 6]
                                        * Referenced by: '<Root>/Constant5'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_sfcndemo_matadd_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_sfcndemo_matadd_T sfcndemo_matadd_P;

/* Block signals (default storage) */
extern B_sfcndemo_matadd_T sfcndemo_matadd_B;

/* Block states (default storage) */
extern DW_sfcndemo_matadd_T sfcndemo_matadd_DW;

/* Model entry point functions */
extern void sfcndemo_matadd_initialize(void);
extern void sfcndemo_matadd_step(void);
extern void sfcndemo_matadd_terminate(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  sfcndemo_matadd_GetCAPIStaticMap(void);

/* Real-time Model object */
extern RT_MODEL_sfcndemo_matadd_T *const sfcndemo_matadd_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'sfcndemo_matadd'
 */
#endif                                 /* RTW_HEADER_sfcndemo_matadd_h_ */
