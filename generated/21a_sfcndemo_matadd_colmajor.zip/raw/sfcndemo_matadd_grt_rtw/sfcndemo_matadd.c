/*
 * sfcndemo_matadd.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sfcndemo_matadd".
 *
 * Model version              : 5.0
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 18:47:04 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rt_logging_mmi.h"
#include "sfcndemo_matadd_capi.h"
#include "sfcndemo_matadd.h"
#include "sfcndemo_matadd_private.h"

/* Block signals (default storage) */
B_sfcndemo_matadd_T sfcndemo_matadd_B;

/* Block states (default storage) */
DW_sfcndemo_matadd_T sfcndemo_matadd_DW;

/* Real-time model */
static RT_MODEL_sfcndemo_matadd_T sfcndemo_matadd_M_;
RT_MODEL_sfcndemo_matadd_T *const sfcndemo_matadd_M = &sfcndemo_matadd_M_;

/* Model step function */
void sfcndemo_matadd_step(void)
{
  /* S-Function (sfun_matadd): '<Root>/Scalar param' incorporates:
   *  Constant: '<Root>/Constant'
   */
  /* S-Function Block: <Root>/Scalar param */
  sfcndemo_matadd_B.Scalarparam = sfcndemo_matadd_P.Constant_Value +
    sfcndemo_matadd_P.Scalarparam_Operand;

  /* S-Function (sfun_matadd): '<Root>/Matrix param2' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  /* S-Function Block: <Root>/Matrix param2 */
  {
    int_T i1;
    const real_T *u0 = &sfcndemo_matadd_P.Constant1_Value[0];
    real_T *y0 = &sfcndemo_matadd_B.Matrixparam2[0];
    const real_T *p_Matrixparam2_Operand =
      sfcndemo_matadd_P.Matrixparam2_Operand;
    for (i1=0; i1 < 8; i1++) {
      y0[i1] = u0[i1] + p_Matrixparam2_Operand[i1];
    }
  }

  /* ToWorkspace: '<Root>/To Workspace' */
  rt_UpdateStructLogVar((StructLogVar *)
                        sfcndemo_matadd_DW.ToWorkspace_PWORK.LoggedData, (NULL),
                        &sfcndemo_matadd_B.Matrixparam2[0]);

  /* S-Function (sfun_matadd): '<Root>/Matrix param' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  /* S-Function Block: <Root>/Matrix param */
  sfcndemo_matadd_B.Matrixparam[0] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[0];
  sfcndemo_matadd_B.Matrixparam[1] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[1];
  sfcndemo_matadd_B.Matrixparam[2] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[2];
  sfcndemo_matadd_B.Matrixparam[3] = sfcndemo_matadd_P.Constant2_Value +
    sfcndemo_matadd_P.Matrixparam_Operand[3];

  /* S-Function (sfun_matadd): '<Root>/Scalar param1' incorporates:
   *  Constant: '<Root>/Constant3'
   */
  /* S-Function Block: <Root>/Scalar param1 */
  sfcndemo_matadd_B.Scalarparam1[0] = sfcndemo_matadd_P.Constant3_Value[0] +
    sfcndemo_matadd_P.Scalarparam1_Operand;
  sfcndemo_matadd_B.Scalarparam1[1] = sfcndemo_matadd_P.Constant3_Value[1] +
    sfcndemo_matadd_P.Scalarparam1_Operand;

  /* S-Function (sfun_matadd): '<Root>/Matrix param1' incorporates:
   *  Constant: '<Root>/Constant5'
   */
  /* S-Function Block: <Root>/Matrix param1 */
  {
    int_T i1;
    const real_T *u0 = &sfcndemo_matadd_P.Constant5_Value[0];
    real_T *y0 = &sfcndemo_matadd_B.Matrixparam1[0];
    const real_T *p_Matrixparam1_Operand =
      sfcndemo_matadd_P.Matrixparam1_Operand;
    for (i1=0; i1 < 6; i1++) {
      y0[i1] = u0[i1] + p_Matrixparam1_Operand[i1];
    }
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(sfcndemo_matadd_M->rtwLogInfo,
                      (&sfcndemo_matadd_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.2s, 0.0s] */
    if ((rtmGetTFinal(sfcndemo_matadd_M)!=-1) &&
        !((rtmGetTFinal(sfcndemo_matadd_M)-sfcndemo_matadd_M->Timing.taskTime0) >
          sfcndemo_matadd_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(sfcndemo_matadd_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++sfcndemo_matadd_M->Timing.clockTick0)) {
    ++sfcndemo_matadd_M->Timing.clockTickH0;
  }

  sfcndemo_matadd_M->Timing.taskTime0 = sfcndemo_matadd_M->Timing.clockTick0 *
    sfcndemo_matadd_M->Timing.stepSize0 + sfcndemo_matadd_M->Timing.clockTickH0 *
    sfcndemo_matadd_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void sfcndemo_matadd_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)sfcndemo_matadd_M, 0,
                sizeof(RT_MODEL_sfcndemo_matadd_T));
  rtmSetTFinal(sfcndemo_matadd_M, 10.0);
  sfcndemo_matadd_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    sfcndemo_matadd_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(sfcndemo_matadd_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(sfcndemo_matadd_M->rtwLogInfo, (NULL));
    rtliSetLogT(sfcndemo_matadd_M->rtwLogInfo, "tout");
    rtliSetLogX(sfcndemo_matadd_M->rtwLogInfo, "");
    rtliSetLogXFinal(sfcndemo_matadd_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(sfcndemo_matadd_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(sfcndemo_matadd_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(sfcndemo_matadd_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(sfcndemo_matadd_M->rtwLogInfo, 1);
    rtliSetLogY(sfcndemo_matadd_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(sfcndemo_matadd_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(sfcndemo_matadd_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      sfcndemo_matadd_B.Matrixparam2[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      sfcndemo_matadd_B.Matrixparam1[i] = 0.0;
    }

    sfcndemo_matadd_B.Scalarparam = 0.0;
    sfcndemo_matadd_B.Matrixparam[0] = 0.0;
    sfcndemo_matadd_B.Matrixparam[1] = 0.0;
    sfcndemo_matadd_B.Matrixparam[2] = 0.0;
    sfcndemo_matadd_B.Matrixparam[3] = 0.0;
    sfcndemo_matadd_B.Scalarparam1[0] = 0.0;
    sfcndemo_matadd_B.Scalarparam1[1] = 0.0;
  }

  /* states (dwork) */
  (void) memset((void *)&sfcndemo_matadd_DW, 0,
                sizeof(DW_sfcndemo_matadd_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  sfcndemo_matadd_InitializeDataMapInfo();

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(sfcndemo_matadd_M->rtwLogInfo, 0.0,
    rtmGetTFinal(sfcndemo_matadd_M), sfcndemo_matadd_M->Timing.stepSize0,
    (&rtmGetErrorStatus(sfcndemo_matadd_M)));

  /* SetupRuntimeResources for ToWorkspace: '<Root>/To Workspace' */
  {
    static int_T rt_ToWksWidths[] = { 8 };

    static int_T rt_ToWksNumDimensions[] = { 3 };

    static int_T rt_ToWksDimensions[] = { 2, 2, 2 };

    static boolean_T rt_ToWksIsVarDims[] = { 0 };

    static void *rt_ToWksCurrSigDims[] = { (NULL), (NULL), (NULL) };

    static int_T rt_ToWksCurrSigDimsSize[] = { 4, 4, 4 };

    static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

    static int_T rt_ToWksComplexSignals[] = { 0 };

    static int_T rt_ToWksFrameData[] = { 0 };

    static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
      (NULL)
    };

    static const char_T *rt_ToWksLabels[] = { "" };

    static RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksIsVarDims,
      rt_ToWksCurrSigDims,
      rt_ToWksCurrSigDimsSize,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLoggingPreprocessingFcnPtrs,

      { rt_ToWksLabels },
      (NULL),
      (NULL),
      (NULL),

      { (NULL) },

      { (NULL) },
      (NULL),
      (NULL)
    };

    static const char_T rt_ToWksBlockName[] = "sfcndemo_matadd/To Workspace";
    sfcndemo_matadd_DW.ToWorkspace_PWORK.LoggedData = rt_CreateStructLogVar(
      sfcndemo_matadd_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(sfcndemo_matadd_M),
      sfcndemo_matadd_M->Timing.stepSize0,
      (&rtmGetErrorStatus(sfcndemo_matadd_M)),
      "nDout",
      0,
      0,
      1,
      0.2,
      &rt_ToWksSignalInfo,
      rt_ToWksBlockName);
    if (sfcndemo_matadd_DW.ToWorkspace_PWORK.LoggedData == (NULL))
      return;
  }
}

/* Model terminate function */
void sfcndemo_matadd_terminate(void)
{
  /* (no terminate code required) */
}
