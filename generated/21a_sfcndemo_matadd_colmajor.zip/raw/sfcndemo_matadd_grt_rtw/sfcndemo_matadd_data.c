/*
 * sfcndemo_matadd_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "sfcndemo_matadd".
 *
 * Model version              : 5.0
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Aug  8 18:47:04 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "sfcndemo_matadd.h"
#include "sfcndemo_matadd_private.h"

/* Block parameters (default storage) */
P_sfcndemo_matadd_T sfcndemo_matadd_P = {
  /* Mask Parameter: Scalarparam_Operand
   * Referenced by: '<Root>/Scalar param'
   */
  1.0,

  /* Mask Parameter: Matrixparam2_Operand
   * Referenced by: '<Root>/Matrix param2'
   */
  { 1.0, 3.0, 2.0, 4.0, 5.0, 7.0, 6.0, 8.0 },

  /* Mask Parameter: Matrixparam_Operand
   * Referenced by: '<Root>/Matrix param'
   */
  { 1.0, 2.0, 3.0, 4.0 },

  /* Mask Parameter: Scalarparam1_Operand
   * Referenced by: '<Root>/Scalar param1'
   */
  1.0,

  /* Mask Parameter: Matrixparam1_Operand
   * Referenced by: '<Root>/Matrix param1'
   */
  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 },

  /* Expression: 1
   * Referenced by: '<Root>/Constant'
   */
  1.0,

  /* Expression: cat(3, [1 2; 3 4], [5 6; 7 8])
   * Referenced by: '<Root>/Constant1'
   */
  { 1.0, 3.0, 2.0, 4.0, 5.0, 7.0, 6.0, 8.0 },

  /* Expression: 1
   * Referenced by: '<Root>/Constant2'
   */
  1.0,

  /* Expression: [1 2]
   * Referenced by: '<Root>/Constant3'
   */
  { 1.0, 2.0 },

  /* Expression: [1 3 5;2 4 6]
   * Referenced by: '<Root>/Constant5'
   */
  { 1.0, 2.0, 3.0, 4.0, 5.0, 6.0 }
};
