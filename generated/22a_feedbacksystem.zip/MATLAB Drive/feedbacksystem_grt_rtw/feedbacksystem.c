/*
 * feedbacksystem.c
 *
 * Code generation for model "feedbacksystem".
 *
 * Model version              : 7.2
 * Simulink Coder version : 9.7 (R2022a) 05-Jul-2022
 * C source code generated on : Sat Jul 30 22:57:32 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "feedbacksystem.h"
#include "rtwtypes.h"
#include "feedbacksystem_private.h"
#include "rt_logging_mmi.h"
#include "feedbacksystem_capi.h"
#include "rt_nonfinite.h"

/* Block signals (default storage) */
B_feedbacksystem_T feedbacksystem_B;

/* Continuous states */
X_feedbacksystem_T feedbacksystem_X;

/* Real-time model */
static RT_MODEL_feedbacksystem_T feedbacksystem_M_;
RT_MODEL_feedbacksystem_T *const feedbacksystem_M = &feedbacksystem_M_;

/*
 * This function updates continuous states using the ODE5 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE5_A[6] = {
    1.0/5.0, 3.0/10.0, 4.0/5.0, 8.0/9.0, 1.0, 1.0
  };

  static const real_T rt_ODE5_B[6][6] = {
    { 1.0/5.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 3.0/40.0, 9.0/40.0, 0.0, 0.0, 0.0, 0.0 },

    { 44.0/45.0, -56.0/15.0, 32.0/9.0, 0.0, 0.0, 0.0 },

    { 19372.0/6561.0, -25360.0/2187.0, 64448.0/6561.0, -212.0/729.0, 0.0, 0.0 },

    { 9017.0/3168.0, -355.0/33.0, 46732.0/5247.0, 49.0/176.0, -5103.0/18656.0,
      0.0 },

    { 35.0/384.0, 0.0, 500.0/1113.0, 125.0/192.0, -2187.0/6784.0, 11.0/84.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE5_IntgData *id = (ODE5_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T *f4 = id->f[4];
  real_T *f5 = id->f[5];
  real_T hB[6];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  feedbacksystem_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE5_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[0]);
  rtsiSetdX(si, f1);
  feedbacksystem_step();
  feedbacksystem_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE5_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[1]);
  rtsiSetdX(si, f2);
  feedbacksystem_step();
  feedbacksystem_derivatives();

  /* f(:,4) = feval(odefile, t + hA(3), y + f*hB(:,3), args(:)(*)); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE5_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[2]);
  rtsiSetdX(si, f3);
  feedbacksystem_step();
  feedbacksystem_derivatives();

  /* f(:,5) = feval(odefile, t + hA(4), y + f*hB(:,4), args(:)(*)); */
  for (i = 0; i <= 3; i++) {
    hB[i] = h * rt_ODE5_B[3][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[3]);
  rtsiSetdX(si, f4);
  feedbacksystem_step();
  feedbacksystem_derivatives();

  /* f(:,6) = feval(odefile, t + hA(5), y + f*hB(:,5), args(:)(*)); */
  for (i = 0; i <= 4; i++) {
    hB[i] = h * rt_ODE5_B[4][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f5);
  feedbacksystem_step();
  feedbacksystem_derivatives();

  /* tnew = t + hA(6);
     ynew = y + f*hB(:,6); */
  for (i = 0; i <= 5; i++) {
    hB[i] = h * rt_ODE5_B[5][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4] + f5[i]*hB[5]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void feedbacksystem_step(void)
{
  real_T tmp[4];
  real_T tmp_0[4];
  real_T currentTime_0[2];
  real_T currentTime;
  real_T currentTime_1;
  int32_T i;
  if (rtmIsMajorTimeStep(feedbacksystem_M)) {
    /* set solver stop time */
    if (!(feedbacksystem_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&feedbacksystem_M->solverInfo,
                            ((feedbacksystem_M->Timing.clockTickH0 + 1) *
        feedbacksystem_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&feedbacksystem_M->solverInfo,
                            ((feedbacksystem_M->Timing.clockTick0 + 1) *
        feedbacksystem_M->Timing.stepSize0 +
        feedbacksystem_M->Timing.clockTickH0 *
        feedbacksystem_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(feedbacksystem_M)) {
    feedbacksystem_M->Timing.t[0] = rtsiGetT(&feedbacksystem_M->solverInfo);
  }

  for (i = 0; i < 2; i++) {
    /* Gain: '<Root>/C' incorporates:
     *  Integrator: '<Root>/Integrator'
     */
    feedbacksystem_B.C[i] = 0.0;
    feedbacksystem_B.C[i] += feedbacksystem_P.C_Gain[i] *
      feedbacksystem_X.Integrator_CSTATE[0];
    feedbacksystem_B.C[i] += feedbacksystem_P.C_Gain[i + 2] *
      feedbacksystem_X.Integrator_CSTATE[1];
    feedbacksystem_B.C[i] += feedbacksystem_P.C_Gain[i + 4] *
      feedbacksystem_X.Integrator_CSTATE[2];
    feedbacksystem_B.C[i] += feedbacksystem_P.C_Gain[i + 6] *
      feedbacksystem_X.Integrator_CSTATE[3];
  }

  if (rtmIsMajorTimeStep(feedbacksystem_M)) {
  }

  /* Step: '<Root>/u' */
  currentTime = feedbacksystem_M->Timing.t[0];

  /* Sum: '<Root>/Sum' incorporates:
   *  Gain: '<Root>/K'
   *  Integrator: '<Root>/Integrator'
   */
  for (i = 0; i < 2; i++) {
    /* Step: '<Root>/u' incorporates:
     *  Gain: '<Root>/K'
     */
    if (currentTime < feedbacksystem_P.u_Time[i]) {
      currentTime_1 = feedbacksystem_P.u_Y0;
    } else {
      currentTime_1 = feedbacksystem_P.u_YFinal;
    }

    currentTime_0[i] = currentTime_1 - (((feedbacksystem_P.K_Gain[i + 2] *
      feedbacksystem_X.Integrator_CSTATE[1] + feedbacksystem_P.K_Gain[i] *
      feedbacksystem_X.Integrator_CSTATE[0]) + feedbacksystem_P.K_Gain[i + 4] *
      feedbacksystem_X.Integrator_CSTATE[2]) + feedbacksystem_P.K_Gain[i + 6] *
      feedbacksystem_X.Integrator_CSTATE[3]);
  }

  /* End of Sum: '<Root>/Sum' */
  for (i = 0; i < 4; i++) {
    /* Gain: '<Root>/B' */
    tmp[i] = feedbacksystem_P.B_Gain[i + 4] * currentTime_0[1] +
      feedbacksystem_P.B_Gain[i] * currentTime_0[0];

    /* Gain: '<Root>/A' incorporates:
     *  Integrator: '<Root>/Integrator'
     */
    tmp_0[i] = ((feedbacksystem_P.A_Gain[i + 4] *
                 feedbacksystem_X.Integrator_CSTATE[1] +
                 feedbacksystem_P.A_Gain[i] *
                 feedbacksystem_X.Integrator_CSTATE[0]) +
                feedbacksystem_P.A_Gain[i + 8] *
                feedbacksystem_X.Integrator_CSTATE[2]) +
      feedbacksystem_P.A_Gain[i + 12] * feedbacksystem_X.Integrator_CSTATE[3];
  }

  /* Sum: '<Root>/Sum1' */
  feedbacksystem_B.Sum1[0] = tmp[0] + tmp_0[0];
  feedbacksystem_B.Sum1[1] = tmp[1] + tmp_0[1];
  feedbacksystem_B.Sum1[2] = tmp[2] + tmp_0[2];
  feedbacksystem_B.Sum1[3] = tmp[3] + tmp_0[3];
  if (rtmIsMajorTimeStep(feedbacksystem_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(feedbacksystem_M->rtwLogInfo,
                        (feedbacksystem_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(feedbacksystem_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(feedbacksystem_M)!=-1) &&
          !((rtmGetTFinal(feedbacksystem_M)-
             (((feedbacksystem_M->Timing.clockTick1+
                feedbacksystem_M->Timing.clockTickH1* 4294967296.0)) * 0.2)) >
            (((feedbacksystem_M->Timing.clockTick1+
               feedbacksystem_M->Timing.clockTickH1* 4294967296.0)) * 0.2) *
            (DBL_EPSILON))) {
        rtmSetErrorStatus(feedbacksystem_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&feedbacksystem_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++feedbacksystem_M->Timing.clockTick0)) {
      ++feedbacksystem_M->Timing.clockTickH0;
    }

    feedbacksystem_M->Timing.t[0] = rtsiGetSolverStopTime
      (&feedbacksystem_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.2s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.2, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      feedbacksystem_M->Timing.clockTick1++;
      if (!feedbacksystem_M->Timing.clockTick1) {
        feedbacksystem_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void feedbacksystem_derivatives(void)
{
  XDot_feedbacksystem_T *_rtXdot;
  _rtXdot = ((XDot_feedbacksystem_T *) feedbacksystem_M->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' incorporates:
   *  Sum: '<Root>/Sum1'
   */
  _rtXdot->Integrator_CSTATE[0] = feedbacksystem_B.Sum1[0];
  _rtXdot->Integrator_CSTATE[1] = feedbacksystem_B.Sum1[1];
  _rtXdot->Integrator_CSTATE[2] = feedbacksystem_B.Sum1[2];
  _rtXdot->Integrator_CSTATE[3] = feedbacksystem_B.Sum1[3];
}

/* Model initialize function */
void feedbacksystem_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)feedbacksystem_M, 0,
                sizeof(RT_MODEL_feedbacksystem_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&feedbacksystem_M->solverInfo,
                          &feedbacksystem_M->Timing.simTimeStep);
    rtsiSetTPtr(&feedbacksystem_M->solverInfo, &rtmGetTPtr(feedbacksystem_M));
    rtsiSetStepSizePtr(&feedbacksystem_M->solverInfo,
                       &feedbacksystem_M->Timing.stepSize0);
    rtsiSetdXPtr(&feedbacksystem_M->solverInfo, &feedbacksystem_M->derivs);
    rtsiSetContStatesPtr(&feedbacksystem_M->solverInfo, (real_T **)
                         &feedbacksystem_M->contStates);
    rtsiSetNumContStatesPtr(&feedbacksystem_M->solverInfo,
      &feedbacksystem_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&feedbacksystem_M->solverInfo,
      &feedbacksystem_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&feedbacksystem_M->solverInfo,
      &feedbacksystem_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&feedbacksystem_M->solverInfo,
      &feedbacksystem_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&feedbacksystem_M->solverInfo, (&rtmGetErrorStatus
      (feedbacksystem_M)));
    rtsiSetRTModelPtr(&feedbacksystem_M->solverInfo, feedbacksystem_M);
  }

  rtsiSetSimTimeStep(&feedbacksystem_M->solverInfo, MAJOR_TIME_STEP);
  feedbacksystem_M->intgData.y = feedbacksystem_M->odeY;
  feedbacksystem_M->intgData.f[0] = feedbacksystem_M->odeF[0];
  feedbacksystem_M->intgData.f[1] = feedbacksystem_M->odeF[1];
  feedbacksystem_M->intgData.f[2] = feedbacksystem_M->odeF[2];
  feedbacksystem_M->intgData.f[3] = feedbacksystem_M->odeF[3];
  feedbacksystem_M->intgData.f[4] = feedbacksystem_M->odeF[4];
  feedbacksystem_M->intgData.f[5] = feedbacksystem_M->odeF[5];
  feedbacksystem_M->contStates = ((X_feedbacksystem_T *) &feedbacksystem_X);
  rtsiSetSolverData(&feedbacksystem_M->solverInfo, (void *)
                    &feedbacksystem_M->intgData);
  rtsiSetIsMinorTimeStepWithModeChange(&feedbacksystem_M->solverInfo, false);
  rtsiSetSolverName(&feedbacksystem_M->solverInfo,"ode5");
  rtmSetTPtr(feedbacksystem_M, &feedbacksystem_M->Timing.tArray[0]);
  rtmSetTFinal(feedbacksystem_M, 10.0);
  feedbacksystem_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    feedbacksystem_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(feedbacksystem_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(feedbacksystem_M->rtwLogInfo, (NULL));
    rtliSetLogT(feedbacksystem_M->rtwLogInfo, "tout");
    rtliSetLogX(feedbacksystem_M->rtwLogInfo, "");
    rtliSetLogXFinal(feedbacksystem_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(feedbacksystem_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(feedbacksystem_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(feedbacksystem_M->rtwLogInfo, 0);
    rtliSetLogDecimation(feedbacksystem_M->rtwLogInfo, 1);
    rtliSetLogY(feedbacksystem_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(feedbacksystem_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(feedbacksystem_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &feedbacksystem_B), 0,
                sizeof(B_feedbacksystem_T));

  /* states (continuous) */
  {
    (void) memset((void *)&feedbacksystem_X, 0,
                  sizeof(X_feedbacksystem_T));
  }

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  feedbacksystem_InitializeDataMapInfo();

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(feedbacksystem_M->rtwLogInfo, 0.0,
    rtmGetTFinal(feedbacksystem_M), feedbacksystem_M->Timing.stepSize0,
    (&rtmGetErrorStatus(feedbacksystem_M)));

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  feedbacksystem_X.Integrator_CSTATE[0] = feedbacksystem_P.Integrator_IC;
  feedbacksystem_X.Integrator_CSTATE[1] = feedbacksystem_P.Integrator_IC;
  feedbacksystem_X.Integrator_CSTATE[2] = feedbacksystem_P.Integrator_IC;
  feedbacksystem_X.Integrator_CSTATE[3] = feedbacksystem_P.Integrator_IC;
}

/* Model terminate function */
void feedbacksystem_terminate(void)
{
  /* (no terminate code required) */
}
