/*
 * feedbacksystem_types.h
 *
 * Code generation for model "feedbacksystem".
 *
 * Model version              : 7.1
 * Simulink Coder version : 9.7 (R2022a) 05-Jul-2022
 * C source code generated on : Thu Jul 28 03:21:48 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_feedbacksystem_types_h_
#define RTW_HEADER_feedbacksystem_types_h_

/* Model Code Variants */
#ifndef SS_UINT64
#define SS_UINT64                      17
#endif

#ifndef SS_INT64
#define SS_INT64                       18
#endif

/* Parameters (default storage) */
typedef struct P_feedbacksystem_T_ P_feedbacksystem_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_feedbacksystem_T RT_MODEL_feedbacksystem_T;

#endif                                 /* RTW_HEADER_feedbacksystem_types_h_ */
