/*
 *  rtmodel.h:
 *
 * Code generation for model "feedbacksystem".
 *
 * Model version              : 7.1
 * Simulink Coder version : 9.7 (R2022a) 05-Jul-2022
 * C source code generated on : Thu Jul 28 03:21:48 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "feedbacksystem.h"
#define GRTINTERFACE                   1
#endif                                 /* RTW_HEADER_rtmodel_h_ */
