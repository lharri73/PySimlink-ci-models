/*
 * feedbacksystem_data.c
 *
 * Code generation for model "feedbacksystem".
 *
 * Model version              : 7.1
 * Simulink Coder version : 9.7 (R2022a) 05-Jul-2022
 * C source code generated on : Thu Jul 28 03:21:48 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "feedbacksystem.h"

/* Block parameters (default storage) */
P_feedbacksystem_T feedbacksystem_P = {
  /* Expression: 0
   * Referenced by: '<Root>/Integrator'
   */
  0.0,

  /* Expression: [1  0  0  0;0  1  0  0]
   * Referenced by: '<Root>/C'
   */
  { 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: [0 -2 1 1;1 3 0 1;1 0 -1 1;1 1 -1 -1]
   * Referenced by: '<Root>/A'
   */
  { 0.0, 1.0, 1.0, 1.0, -2.0, 3.0, 0.0, 1.0, 1.0, 0.0, -1.0, -1.0, 1.0, 1.0, 1.0,
    -1.0 },

  /* Expression: [0 0]'
   * Referenced by: '<Root>/u'
   */
  { 0.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<Root>/u'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/u'
   */
  1.0,

  /* Expression: [1.9447 -2.6462 1.6214  0.7910;0.5320  6.0553  -0.9101  0.9485]
   * Referenced by: '<Root>/K'
   */
  { 1.9447, 0.532, -2.6462, 6.0553, 1.6214, -0.9101, 0.791, 0.9485 },

  /* Expression: [1 0;0 1;0 0;0 0]
   * Referenced by: '<Root>/B'
   */
  { 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0 }
};
